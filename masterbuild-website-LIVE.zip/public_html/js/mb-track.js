/* Masterbuild Consulting — business-event tracking (Plausible custom events). */
(function () {
  window.plausible = window.plausible || function () {
    (window.plausible.q = window.plausible.q || []).push(arguments);
  };
  window.trackMBEvent = window.trackMBEvent || function (name, props) {
    if (typeof window.plausible === "function") {
      window.plausible(name, props ? { props: props } : undefined);
    }
  };
  function classify(href) {
    if (!href) return null;
    var h = href.toLowerCase();
    if (h.indexOf("buy.stripe.com") !== -1) return { name: "Stripe Checkout Click", extra: { destination: href } };
    if (h.indexOf("calendly.com") !== -1) return { name: "Scoping Call Click", extra: { destination: href } };
    if (h.indexOf("buttondown") !== -1) return { name: "Email List Click", extra: { destination: href } };
    if (h.indexOf("mailto:") === 0) return { name: "Mailto Click", extra: { subject: href } };
    if (h.indexOf("tel:") === 0) return { name: "Phone Click", extra: {} };
    if (/\.pdf(\?|$)/.test(h)) return { name: "PDF Download", extra: { href: href } };
    if (h.indexOf("linkedin.com") !== -1) return { name: "LinkedIn Click", extra: {} };
    if (h.indexOf("fbpe.org") !== -1 || h.indexOf("floridabpe") !== -1) return { name: "FBPE Lookup Click", extra: {} };
    return null;
  }
  document.addEventListener("click", function (e) {
    var a = e.target && e.target.closest ? e.target.closest("a") : null;
    if (!a) return;
    var hit = classify(a.href);
    if (!hit) return;
    hit.extra.page = location.pathname;
    window.trackMBEvent(hit.name, hit.extra);
  }, { passive: true });
  if (location.pathname === "/404.html" || document.title.indexOf("not found") !== -1) {
    window.trackMBEvent("404", { path: location.pathname + location.search, ref: document.referrer || "(direct)" });
  }

  function mountSticky() {
    var p = (location.pathname || "/").replace(/\/+$/, "") || "/";
    if (p === "/contact" || p === "/contacto") return;
    if (document.querySelector(".sticky-cta")) return;
    if (!document.getElementById("mb-sticky-css")) {
      var css = document.createElement("style");
      css.id = "mb-sticky-css";
      css.textContent =
        ".sticky-cta{display:none}" +
        "@media (max-width:700px){" +
        ".sticky-cta{display:flex;gap:10px;align-items:center;position:fixed;left:0;right:0;bottom:0;z-index:80;" +
        "padding:10px 12px calc(10px + env(safe-area-inset-bottom));background:#0F1013;border-top:1px solid rgba(202,84,10,.45)}" +
        ".sticky-cta a{flex:1;min-height:44px;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;text-decoration:none}" +
        ".sticky-cta .cta-primary{margin:0;width:auto;background:#CA540A;color:#0B0C0E;border:1px solid #CA540A}" +
        ".sticky-cta .ghost{border:1px solid rgba(255,255,255,.18);color:#F0EDE8}" +
        "body.has-sticky-cta{padding-bottom:78px}" +
        "}" +
        "@media print{.sticky-cta{display:none !important}}";
      document.head.appendChild(css);
    }
    var es = document.documentElement.lang === "es";
    var bar = document.createElement("div");
    bar.className = "sticky-cta";
    bar.setAttribute("role", "navigation");
    bar.setAttribute("aria-label", es ? "Contacto" : "Contact");
    var contactHref = es ? "/contacto/" : "/contact/";
    bar.innerHTML =
      '<a class="cta-primary" href="' + contactHref + '">' +
      (es ? "Enviar antecedentes" : "Send project background") +
      '</a><a class="ghost" href="tel:+17863986940">' +
      (es ? "Llamar" : "Call") +
      "</a>";
    document.body.appendChild(bar);
    document.body.classList.add("has-sticky-cta");
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountSticky);
  } else {
    mountSticky();
  }
})();
