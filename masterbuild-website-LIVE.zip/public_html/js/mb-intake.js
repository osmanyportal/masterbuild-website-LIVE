
(function () {
  var form = document.getElementById("mb-intake");
  if (!form) return;

  var TYPE_MAP = {
    recertification: "Electrical Building Recertification readiness — Miami-Dade",
    recert: "Electrical Building Recertification readiness — Miami-Dade",
    septic: "Miami-Dade septic / OSTDS feasibility screen",
    ostds: "Miami-Dade septic / OSTDS feasibility screen",
    well: "Private-well record and permit readiness",
    kitchen: "Commercial kitchen / Type I hood",
    hood: "Commercial kitchen / Type I hood",
    existing: "Existing-building MEP assessment",
    comments: "Permit comment response / resubmittal",
    mep: "Permit-level MEP construction documents",
    ti: "Commercial tenant improvement",
    advisory: "Monthly Design Advisory retainer",
    review: "Independent MEP review / QA",
    ventilation: "Mechanical ventilation / outdoor air",
    healthcare: "Healthcare / ASHRAE 170 ventilation",
    ashrae: "Healthcare / ASHRAE 170 ventilation",
    garage: "Parking garage ventilation",
    load: "HVAC load calculations",
    combustion: "Combustion air / venting",
    ducts: "Duct systems / fire-smoke dampers",
    damper: "Duct systems / fire-smoke dampers",
    plumbing: "Plumbing / grease interceptor / isometrics",
    grease: "Plumbing / grease interceptor / isometrics",
    fire: "Fire protection coordination",
    sprinkler: "Fire protection coordination",
    fbc: "Permit comment response / resubmittal",
    edition: "Permit comment response / resubmittal"
  };

  var HINTS = {
    "Electrical Building Recertification readiness — Miami-Dade":
      "Send the recertification notice, property address, year built, any prior recertification reports, panel schedules or riser diagrams if they exist, and a contact who can arrange electrical-room access. Missing records are normal — say what you do not have.",
    "Miami-Dade septic / OSTDS feasibility screen":
      "Send folio number and address, intended use with unit and bedroom count, survey and any elevation data, site plan or intended footprint with gross roofed area, and the date you have to decide by.",
    "Private-well record and permit readiness":
      "Send address and folio, intended use, the actual decision (sale, repair, final, operating question), well records already in hand, laboratory or treatment records if any, and the decision date.",
    "Commercial kitchen / Type I hood":
      "Send the architectural floor plan, kitchen equipment schedule, hood information or cut sheets, existing HVAC information, permit comments if the set already went in, and photos of the existing termination on a renovation.",
    "Existing-building MEP assessment":
      "Send existing plans if they exist, photographs of mechanical rooms, roofs, and panels, the proposed architectural change, prior permit information, and the observed field condition that triggered the question.",
    "Permit comment response / resubmittal":
      "Send the comment letter, the current drawing set or a share link, the permit number, jurisdiction, and which comments you want Masterbuild to own.",
    "Permit-level MEP construction documents":
      "Send project address or jurisdiction, occupancy, current design stage, disciplines needed, architectural drawings or a share link, and any deadline.",
    "Commercial tenant improvement":
      "Send the architectural TI set, existing MEP record drawings if they exist, photos of ceilings and mechanical rooms, and the permit comments if review already started.",
    "Monthly Design Advisory retainer":
      "Send the current project mix, typical monthly volume, disciplines involved, and whether you need sealed production, review, or both.",
    "Independent MEP review / QA":
      "Send the set to be reviewed or a share link, the jurisdiction, the question you need answered, and whether this is pre-permit, under review, or construction-phase.",
    "Mechanical ventilation / outdoor air":
      "Send architectural plans with occupancies and areas, existing HVAC information, exhaust that must be made up, and permit comments if any.",
    "Healthcare / ASHRAE 170 ventilation":
      "Send the room list, procedures performed, occupancy, and whether this is a clinic TI, ambulatory surgery, or an I-2 conversion.",
    "Parking garage ventilation":
      "Send garage sections and opening information, and whether this is new construction, a conversion, or a CO-system replacement.",
    "HVAC load calculations":
      "Send architectural plans and elevations, any energy forms already started, and the zoning or system type assumed.",
    "Combustion air / venting":
      "Send appliance cut sheets, mechanical-room or closet dimensions, existing opening locations, and whether this is new or a replacement.",
    "Duct systems / fire-smoke dampers":
      "Send reflected-ceiling plans, rated-assembly plans, and the current M-sheets.",
    "Plumbing / grease interceptor / isometrics":
      "Send the architectural plumbing plan, fixture list, existing riser photos on a remodel, and whether sewer/water are public or on-site. Restaurants: add the equipment schedule.",
    "Fire protection coordination":
      "Send architectural rated-assembly plans, current M-sheets, existing sprinkler drawings if they exist, and the kitchen equipment schedule when a hood is involved."
  };

  var params = new URLSearchParams(location.search);
  var isEs = (form.getAttribute("data-lang") === "es") || (document.documentElement.lang === "es");
  if (/[?&]sent=1/.test(location.search)) {
    var ok = document.getElementById("sent");
    if (ok) ok.hidden = false;
    if (window.trackMBEvent) window.trackMBEvent("Intake Success", { page: location.pathname });
  }

  var typeKey = (params.get("type") || "").toLowerCase();
  if (typeKey && TYPE_MAP[typeKey] && form.projectType) {
    var val = TYPE_MAP[typeKey];
    var found = false;
    for (var oi = 0; oi < form.projectType.options.length; oi++) {
      if (form.projectType.options[oi].value === val) { found = true; break; }
    }
    if (!found) {
      var opt = document.createElement("option");
      opt.value = val;
      opt.textContent = val;
      form.projectType.appendChild(opt);
    }
    form.projectType.value = val;
  }
  var jur = params.get("jur");
  if (jur && form.jurisdiction) {
    var opts = form.jurisdiction.options;
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].value.toLowerCase().indexOf(jur.toLowerCase()) !== -1) {
        form.jurisdiction.selectedIndex = i;
        break;
      }
    }
  }
  if (params.get("source") && form.source) form.source.value = params.get("source");

  function discs() {
    return Array.prototype.map.call(form.querySelectorAll('input[name="disciplines"]:checked'), function (el) {
      return el.value;
    }).join(", ");
  }

  function shortType(type) {
    if (/Recertification/i.test(type)) return "Recertification";
    if (/septic|OSTDS/i.test(type)) return "Septic";
    if (/well/i.test(type)) return "Private Well";
    if (/kitchen|hood/i.test(type)) return "Kitchen Exhaust";
    if (/comment/i.test(type)) return "Permit Comments";
    if (/Advisory/i.test(type)) return "Design Advisory";
    if (/review|QA/i.test(type)) return "MEP Review";
    if (/HVAC|construction documents/i.test(type)) return "MEP CDs";
    if (/tenant improvement/i.test(type)) return "TI";
    if (/Existing-building/i.test(type)) return "Existing Building";
    if (/ventilation|outdoor air/i.test(type) && /170|healthcare|ASHRAE/i.test(type)) return "Healthcare Vent";
    if (/garage/i.test(type)) return "Garage Vent";
    if (/load/i.test(type)) return "Load Calc";
    if (/combustion/i.test(type)) return "Combustion Air";
    if (/duct/i.test(type)) return "Duct Systems";
    if (/plumbing|grease interceptor/i.test(type)) return "Plumbing";
    if (/fire protection/i.test(type)) return "Fire Protection";
    if (/ventilation|outdoor air/i.test(type)) return "Ventilation";
    return (type || "Inquiry").replace(/—/g, "-").slice(0, 40);
  }

  function subject() {
    var type = form.projectType.value || "Inquiry";
    var jurVal = form.jurisdiction.value || "Jurisdiction TBD";
    var stage = form.stage.value || "Stage TBD";
    var disc = discs().split(",")[0] || "MEP";
    return "[NEW PROJECT] " + shortType(type) + " / " + disc + " / " + jurVal + " / " + stage;
  }

  function updateHint() {
    var box = document.getElementById("intake-hint");
    var body = document.getElementById("intake-hint-body");
    if (!box || !body) return;
    var text = HINTS[form.projectType.value];
    if (text) {
      body.textContent = text;
      box.hidden = false;
    } else {
      box.hidden = true;
    }
  }

  if (form.projectType) {
    form.projectType.addEventListener("change", updateHint);
    updateHint();
  }

  var nativeFallback = false;
  form.addEventListener("submit", function (e) {
    if (nativeFallback) return;
    e.preventDefault();
    var err = document.getElementById("form-error");
    err.hidden = true;
    if (form._honey && form._honey.value) return;
    if (!form.name.value.trim() || !form.email.value.trim() || !form.phone.value.trim() || !form.message.value.trim()) {
      err.hidden = false;
      err.textContent = isEs
        ? "Nombre, correo, teléfono y la pregunta real son obligatorios para poder dar seguimiento."
        : "Name, email, phone, and the actual question are required so Masterbuild can follow up.";
      var first = form.name.value.trim() ? (form.email.value.trim() ? (form.phone.value.trim() ? form.message : form.phone) : form.email) : form.name;
      try { first.focus(); } catch (ignore) {}
      return;
    }
    var sub = subject();
    form.querySelector("#mb-subject").value = sub;
    var reply = form.querySelector("#mb-replyto");
    if (reply) reply.value = form.email.value;
    var payload = {
      lead_type: "Project inquiry / proposal request",
      follow_up_priority: "High",
      source: form.source ? form.source.value : "Public website /contact/",
      submission_route: "/contact/" + location.search,
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value,
      org: form.org.value,
      role: form.role.value,
      project_type: form.projectType.value,
      disciplines: discs() || "Not specified",
      state_jurisdiction: form.jurisdiction.value,
      project_stage: form.stage.value,
      permit_deadline: form.deadline.value,
      existing_drawings: form.drawings.value,
      project_address: form.address.value,
      blocking_issue: form.blocker.value,
      document_link: form.files.value,
      message: form.message.value,
      _subject: sub,
      _replyto: form.email.value,
      _template: "table",
      _captcha: "false"
    };
    if (window.trackMBEvent) {
      window.trackMBEvent("Contact Form Submit", {
        language: "en",
        leadType: shortType(form.projectType.value),
        page: "/contact/",
        type: form.projectType.value || "unspecified"
      });
    }
    fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }).then(function (r) {
      if (!r.ok) throw new Error("fail");
      location.search = "sent=1";
    }).catch(function () {
      nativeFallback = true;
      form.submit();
    });
  });
})();
