Masterbuild Consulting — GoDaddy production package (September 2026)

UPLOAD: unzip, then upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
Include .htaccess (enable “show hidden files” in the file manager).

DO NOT upload:
  - this README
  - the _docs/ folder
  - the rollback ZIP
  - dct-data.js (intentionally omitted; archive uses dct-index.js)

DOCS: _docs/DEPLOYMENT_MANIFEST.md, CHANGELOG.md, POST_DEPLOYMENT_QA.md, ITEMS_REQUIRING_OWNER_INPUT.md

ROLLBACK: masterbuildconsulting-ROLLBACK-original-baseline-2026-09.zip
Replace public_html with that archive’s public_html/ to restore the previous site.
