// imc-glossary-data.js — IMC (International Mechanical Code) Section 202
// General Definitions glossary for Masterbuild Consulting. Plain-English
// paraphrase glossary, not verbatim ICC/IMC text — original wording only,
// reviewed by Masterbuild's licensed PE. Companion to nec-glossary-data.js.
// Batch 1 of an ongoing build-out, covering Abrasive Materials through
// Damper/Volume Damper (general, appliance/combustion, air systems,
// refrigeration, venting, commercial kitchen, and boiler terms).
window.IMC_GLOSSARY = [
{
  id: "abrasive-materials",
  cat: "General",
  term_en: "Abrasive Materials",
  def_en: "Particulate matter — such as alumina, bauxite, iron silicate, sand, or slag — that wears down duct and equipment surfaces at a moderate-to-high rate depending on concentration.",
  field_en: "Systems handling abrasive materials need heavier-gauge duct, wear-resistant fittings, and shorter inspection intervals than a standard air handling system — a common gap when an industrial exhaust design is copied from a general commercial template.",
  term_es: "Materiales Abrasivos",
  def_es: "Material particulado — como alúmina, bauxita, silicato de hierro, arena o escoria — que desgasta las superficies de ductos y equipos a una tasa moderada a alta según la concentración.",
  field_es: "Los sistemas que manejan materiales abrasivos necesitan ductos de calibre más grueso, accesorios resistentes al desgaste e intervalos de inspección más cortos que un sistema de manejo de aire estándar — una brecha común cuando un diseño de extracción industrial se copia de una plantilla comercial general."
},
{
  id: "absorption-system",
  cat: "Refrigeration & Cooling",
  term_en: "Absorption System",
  def_en: "A refrigeration system that pressurizes refrigerant by pumping a refrigerant-absorbent solution, then separates the two with heat, condenses and expands the refrigerant to produce cooling, and reabsorbs it to repeat the cycle. Multiple-effect systems reuse heat internally for better efficiency.",
  field_en: "Absorption chillers are heat-driven rather than electric-compressor-driven — confirm the heat source (steam, hot water, direct-fired) is properly sized and piped before treating the unit like a standard electric chiller on a mechanical schedule.",
  term_es: "Sistema de Absorción",
  def_es: "Un sistema de refrigeración que presuriza el refrigerante bombeando una solución de refrigerante-absorbente, luego separa los dos con calor, condensa y expande el refrigerante para producir enfriamiento, y lo reabsorbe para repetir el ciclo. Los sistemas de efecto múltiple reutilizan el calor internamente para mejorar la eficiencia.",
  field_es: "Los enfriadores de absorción funcionan con calor en lugar de un compresor eléctrico — confirme que la fuente de calor (vapor, agua caliente, disparo directo) esté correctamente dimensionada y tuberizada antes de tratar la unidad como un enfriador eléctrico estándar en un programa mecánico."
},
{
  id: "access-to",
  cat: "General",
  term_en: "Access (To)",
  def_en: "The ability to reach a device, appliance, or equipment either directly (ready access) or by first removing a panel or similar obstruction.",
  field_en: "\"Access\" is the broader, lower-bar term; \"ready access\" is stricter and requires no obstruction removal at all — mixing the two up in a plan note is a common source of a rejected equipment location.",
  term_es: "Acceso (A)",
  def_es: "La capacidad de llegar a un dispositivo, aparato o equipo ya sea directamente (acceso fácil) o retirando primero un panel u obstrucción similar.",
  field_es: "\"Acceso\" es el término más amplio y de menor exigencia; \"acceso fácil\" es más estricto y no requiere retirar ninguna obstrucción — confundir los dos en una nota de plano es una causa común de rechazo de ubicación de equipo."
},
{
  id: "air",
  cat: "Air Systems & Ventilation",
  term_en: "Air",
  def_en: "Air supplied to mechanical equipment and appliances for combustion, ventilation, cooling, and similar purposes. Standard air is measured at 70°F and 29.92 inches of mercury.",
  field_en: "Equipment capacity ratings (CFM, tonnage) are usually published at standard-air conditions — real-world altitude and temperature can shift actual performance, which matters on submittals for high-elevation or extreme-climate projects.",
  term_es: "Aire",
  def_es: "Aire suministrado a equipos y aparatos mecánicos para combustión, ventilación, enfriamiento y propósitos similares. El aire estándar se mide a 70°F y 29.92 pulgadas de mercurio.",
  field_es: "Las clasificaciones de capacidad de equipo (CFM, toneladas) generalmente se publican en condiciones de aire estándar — la altitud y temperatura reales pueden cambiar el rendimiento real, lo cual importa en presentaciones para proyectos de gran altitud o clima extremo."
},
{
  id: "air-exhaust",
  cat: "Air Systems & Ventilation",
  term_en: "Air, Exhaust",
  def_en: "Air removed from a space, appliance, or piece of equipment and conveyed directly to the outdoor atmosphere through openings or ducts.",
  field_en: "Exhaust air routed back indoors instead of to the outdoor atmosphere doesn't legally qualify as exhaust — a common finding where a contractor \"simplifies\" a duct run by tying into a return plenum.",
  term_es: "Aire, Extracción",
  def_es: "Aire removido de un espacio, aparato o pieza de equipo y conducido directamente a la atmósfera exterior a través de aberturas o ductos.",
  field_es: "El aire de extracción redirigido de vuelta al interior en lugar de a la atmósfera exterior no califica legalmente como extracción — un hallazgo común cuando un contratista \"simplifica\" una corrida de ducto conectándola a un plenum de retorno."
},
{
  id: "air-makeup",
  cat: "Air Systems & Ventilation",
  term_en: "Air, Makeup",
  def_en: "Any combination of outdoor air and transfer air intended to replace exhaust air and exfiltration.",
  field_en: "Makeup air isn't optional once exhaust volume gets large (commercial kitchens, industrial exhaust) — an undersized or missing makeup air path is one of the most common causes of a building running under negative pressure and backdrafting combustion appliances.",
  term_es: "Aire, de Reposición",
  def_es: "Cualquier combinación de aire exterior y aire de transferencia destinada a reemplazar el aire de extracción y la exfiltración.",
  field_es: "El aire de reposición no es opcional una vez que el volumen de extracción es grande (cocinas comerciales, extracción industrial) — una trayectoria de aire de reposición subdimensionada o ausente es una de las causas más comunes de que un edificio quede bajo presión negativa y provoque retroceso de tiro en aparatos de combustión."
},
{
  id: "air-outdoor",
  cat: "Air Systems & Ventilation",
  term_en: "Air, Outdoor",
  def_en: "Ambient air entering a building through a ventilation system, intentional natural-ventilation openings, or infiltration.",
  field_en: "Outdoor air intake location matters as much as its rate — an intake placed too close to an exhaust outlet, loading dock, or plumbing vent recirculates contaminants back into the building, a frequent siting error on tight urban sites.",
  term_es: "Aire, Exterior",
  def_es: "Aire ambiente que entra a un edificio a través de un sistema de ventilación, aberturas intencionales de ventilación natural, o infiltración.",
  field_es: "La ubicación de la toma de aire exterior importa tanto como su caudal — una toma colocada demasiado cerca de una salida de extracción, muelle de carga o respiradero de plomería recircula contaminantes de vuelta al edificio, un error de ubicación frecuente en sitios urbanos ajustados."
},
{
  id: "air-transfer",
  cat: "Air Systems & Ventilation",
  term_en: "Air, Transfer",
  def_en: "Air moved from one indoor space to another.",
  field_en: "Transfer air paths (grilles, transfer ducts, undercut doors) need to be sized and located correctly or a room intended to be pressure-balanced ends up starved — a common oversight when a corridor is assumed to \"just work\" as a transfer path without a documented opening.",
  term_es: "Aire, de Transferencia",
  def_es: "Aire movido de un espacio interior a otro.",
  field_es: "Las trayectorias de aire de transferencia (rejillas, ductos de transferencia, puertas recortadas) deben dimensionarse y ubicarse correctamente o un cuarto destinado a estar balanceado en presión termina desabastecido — un descuido común cuando se asume que un pasillo \"simplemente funciona\" como trayectoria de transferencia sin una abertura documentada."
},
{
  id: "air-conditioning",
  cat: "Air Systems & Ventilation",
  term_en: "Air Conditioning",
  def_en: "The simultaneous treatment of temperature, humidity, cleanliness, and distribution of air to meet the requirements of a conditioned space.",
  field_en: "\"Air conditioning\" in code terms means more than just cooling — a system that cools but doesn't address humidity or filtration in a space with a specific requirement (like a health care or lab space) may not actually satisfy the definition.",
  term_es: "Aire Acondicionado",
  def_es: "El tratamiento simultáneo de temperatura, humedad, limpieza y distribución del aire para cumplir con los requisitos de un espacio acondicionado.",
  field_es: "\"Aire acondicionado\" en términos del código significa más que solo enfriar — un sistema que enfría pero no aborda la humedad o filtración en un espacio con un requisito específico (como salud o laboratorio) puede no satisfacer realmente la definición."
},
{
  id: "air-dispersion-system",
  cat: "Air Systems & Ventilation",
  term_en: "Air Dispersion System",
  def_en: "A diffuser system, often fabric or plastic film, designed to both convey and diffuse air into a room while operating under positive pressure.",
  field_en: "Fabric duct/dispersion systems have their own support-spacing, fire-rating, and cleanability requirements that differ from sheet-metal duct — don't grade a fabric duct submittal against a standard metal duct checklist.",
  term_es: "Sistema de Dispersión de Aire",
  def_es: "Un sistema de difusores, a menudo de tela o película plástica, diseñado para transportar y dispersar aire dentro de un cuarto mientras opera bajo presión positiva.",
  field_es: "Los sistemas de ducto de tela/dispersión tienen sus propios requisitos de espaciamiento de soporte, clasificación contra incendio y capacidad de limpieza que difieren del ducto de lámina metálica — no evalúe una presentación de ducto de tela contra una lista de verificación de ducto metálico estándar."
},
{
  id: "air-distribution-system",
  cat: "Air Systems & Ventilation",
  term_en: "Air Distribution System",
  def_en: "Any system of ducts, plenums, and air-handling equipment that circulates air within a space, including systems made up of one or more air-handling units.",
  field_en: "\"Air distribution system\" is the umbrella term covering the whole assembly — useful shorthand when scoping a mechanical review across duct, plenum, and air-handler submittals together.",
  term_es: "Sistema de Distribución de Aire",
  def_es: "Cualquier sistema de ductos, plenums y equipo de manejo de aire que circula aire dentro de un espacio, incluyendo sistemas compuestos de una o más unidades manejadoras de aire.",
  field_es: "\"Sistema de distribución de aire\" es el término general que cubre todo el ensamble — una abreviatura útil al delimitar una revisión mecánica que abarca ducto, plenum y manejadoras de aire juntos."
},
{
  id: "air-conditioning-system",
  cat: "Air Systems & Ventilation",
  term_en: "Air-Conditioning System",
  def_en: "A system consisting of heat exchangers, blowers, filters, and supply/exhaust/return ducts, plus any connected apparatus.",
  field_en: "This is the physical hardware definition, distinct from \"air conditioning\" (the process definition above) — reviewers sometimes cite one when they mean the other, so read code section context carefully.",
  term_es: "Sistema de Aire Acondicionado",
  def_es: "Un sistema que consiste en intercambiadores de calor, sopladores, filtros y ductos de suministro/extracción/retorno, más cualquier aparato conectado.",
  field_es: "Esta es la definición del equipo físico, distinta de \"aire acondicionado\" (la definición del proceso arriba) — a veces los revisores citan una cuando quieren decir la otra, así que lea el contexto de la sección del código con cuidado."
},
{
  id: "air-handling-unit",
  cat: "Air Systems & Ventilation",
  term_en: "Air-Handling Unit",
  def_en: "A blower or fan used to distribute supply air to a room, space, or area.",
  field_en: "\"Air-handling unit\" (AHU) is defined narrowly around the blower/fan function here — the broader assembly with coils, filters, and dampers is usually what's meant colloquially, so confirm which sense a spec section is using.",
  term_es: "Unidad Manejadora de Aire",
  def_es: "Un soplador o ventilador usado para distribuir aire de suministro a un cuarto, espacio o área.",
  field_es: "\"Unidad manejadora de aire\" (AHU) se define aquí de forma estrecha alrededor de la función de soplador/ventilador — el ensamble más amplio con serpentines, filtros y compuertas es usualmente lo que se quiere decir coloquialmente, así que confirme qué sentido usa una sección de especificación."
},
{
  id: "alteration",
  cat: "General",
  term_en: "Alteration",
  def_en: "A change to a mechanical system that extends, adds to, or changes the arrangement, type, or purpose of the original installation.",
  field_en: "Even a straight equipment swap can trigger \"alteration\" review if the type or arrangement changes (e.g., gas furnace to heat pump) — don't assume a like-for-like replacement is automatically exempt from full review.",
  term_es: "Alteración",
  def_es: "Un cambio a un sistema mecánico que extiende, añade o cambia el arreglo, tipo o propósito de la instalación original.",
  field_es: "Incluso un cambio directo de equipo puede activar revisión de \"alteración\" si el tipo o arreglo cambia (p.ej., horno de gas a bomba de calor) — no asuma que un reemplazo idéntico está automáticamente exento de revisión completa."
},
{
  id: "ambulatory-care-facility",
  cat: "General",
  term_en: "Ambulatory Care Facility",
  def_en: "A building or portion of a building providing medical, surgical, psychiatric, nursing, or similar care on a less-than-24-hour basis to people incapable of self-preservation because of the services provided, or whose staff has accepted responsibility for already-incapable patients.",
  field_en: "Outpatient surgical centers and similar facilities pull in occupancy-driven mechanical requirements (like specific ventilation and standby power provisions) that a straight medical-office classification would miss — confirm patient-incapacitation criteria before scoping the mechanical design.",
  term_es: "Instalación de Cuidado Ambulatorio",
  def_es: "Un edificio o porción de un edificio que provee cuidado médico, quirúrgico, psiquiátrico, de enfermería o similar en menos de 24 horas a personas incapaces de autopreservación debido a los servicios provistos, o cuyo personal ha aceptado responsabilidad por pacientes ya incapacitados.",
  field_es: "Los centros de cirugía ambulatoria e instalaciones similares activan requisitos mecánicos impulsados por la ocupación (como provisiones específicas de ventilación y energía de respaldo) que una clasificación directa de oficina médica pasaría por alto — confirme los criterios de incapacitación del paciente antes de delimitar el diseño mecánico."
},
{
  id: "appliance",
  cat: "Appliances & Combustion",
  term_en: "Appliance",
  def_en: "A device or apparatus, manufactured and designed to use energy, for which the code provides specific requirements.",
  field_en: "\"Appliance\" is the umbrella term the IMC uses for furnaces, water heaters, boilers, and similar equipment — knowing this helps when tracing which code sections apply to a given piece of equipment.",
  term_es: "Aparato",
  def_es: "Un dispositivo o aparato, fabricado y diseñado para usar energía, para el cual el código provee requisitos específicos.",
  field_es: "\"Aparato\" es el término general que el IMC usa para hornos, calentadores de agua, calderas y equipo similar — saber esto ayuda al rastrear qué secciones del código aplican a una pieza de equipo dada."
},
{
  id: "appliance-existing",
  cat: "Appliances & Combustion",
  term_en: "Appliance, Existing",
  def_en: "Any appliance regulated by the code that was legally installed before the code's effective date, or for which an installation permit has already been issued.",
  field_en: "Legacy-installed status doesn't exempt an appliance from safety corrections when it's touched during a renovation — \"existing\" protects the original installation, not future work around it.",
  term_es: "Aparato, Existente",
  def_es: "Cualquier aparato regulado por el código que fue instalado legalmente antes de la fecha de vigencia del código, o para el cual ya se ha emitido un permiso de instalación.",
  field_es: "El estatus de instalación heredada no exime a un aparato de correcciones de seguridad cuando se interviene durante una renovación — \"existente\" protege la instalación original, no el trabajo futuro alrededor de ella."
},
{
  id: "appliance-vented",
  cat: "Appliances & Combustion",
  term_en: "Appliance, Vented",
  def_en: "An appliance designed and installed so that all products of combustion are conveyed directly from the appliance to the outdoor atmosphere through an approved chimney or vent system.",
  field_en: "A vented appliance connected to an undersized, mismatched, or shared vent that can't actually carry its full combustion products no longer meets this definition in practice, even though it's a \"vented\" model — verify the vent system, not just the appliance listing.",
  term_es: "Aparato, Ventilado",
  def_es: "Un aparato diseñado e instalado de manera que todos los productos de combustión se transporten directamente del aparato a la atmósfera exterior a través de un sistema de chimenea o ventilación aprobado.",
  field_es: "Un aparato ventilado conectado a un sistema de ventilación subdimensionado, incompatible o compartido que en realidad no puede transportar todos sus productos de combustión ya no cumple esta definición en la práctica, aunque sea un modelo \"ventilado\" — verifique el sistema de ventilación, no solo el listado del aparato."
},
{
  id: "appliance-type-heat",
  cat: "Appliances & Combustion",
  term_en: "Appliance Type, High-Heat / Medium-Heat / Low-Heat",
  def_en: "Classified by the flue-gas temperature at the flue entrance under normal operation: high-heat is above 2,000°F, medium-heat is 1,000-2,000°F, and low-heat (residential-type) is 1,000°F or below.",
  field_en: "Chimney and clearance requirements scale directly with this classification — a medium- or high-heat appliance connected to a chimney rated only for low-heat residential service is a serious, code-flagged mismatch.",
  term_es: "Tipo de Aparato, Alto Calor / Calor Medio / Bajo Calor",
  def_es: "Clasificado por la temperatura del gas de combustión en la entrada al conducto bajo operación normal: alto calor es superior a 2,000°F, calor medio es 1,000-2,000°F, y bajo calor (tipo residencial) es 1,000°F o menos.",
  field_es: "Los requisitos de chimenea y separación escalan directamente con esta clasificación — un aparato de calor medio o alto conectado a una chimenea clasificada solo para servicio residencial de bajo calor es un desajuste grave y marcado por el código."
},
{
  id: "approved",
  cat: "General",
  term_en: "Approved",
  def_en: "Acceptable to the code official.",
  field_en: "\"Approved\" is a local, official determination — not a factory listing or a manufacturer's claim — so a product being \"approved\" elsewhere doesn't guarantee approval on this specific project.",
  term_es: "Aprobado",
  def_es: "Aceptable para el funcionario del código.",
  field_es: "\"Aprobado\" es una determinación local y oficial — no un listado de fábrica ni una afirmación del fabricante — así que un producto \"aprobado\" en otro lugar no garantiza la aprobación en este proyecto específico."
},
{
  id: "approved-agency",
  cat: "General",
  term_en: "Approved Agency",
  def_en: "An established, recognized organization regularly engaged in testing, inspection services, or product evaluation/certification, that the code official has approved.",
  field_en: "A testing lab or agency being nationally recognized elsewhere doesn't automatically make it an \"approved agency\" for a specific jurisdiction — confirm local acceptance before submitting a certification from an unfamiliar agency.",
  term_es: "Agencia Aprobada",
  def_es: "Una organización establecida y reconocida, dedicada regularmente a pruebas, servicios de inspección, o evaluación/certificación de productos, que el funcionario del código ha aprobado.",
  field_es: "Que un laboratorio de pruebas o agencia sea reconocido nacionalmente en otro lugar no lo convierte automáticamente en una \"agencia aprobada\" para una jurisdicción específica — confirme la aceptación local antes de presentar una certificación de una agencia desconocida."
},
{
  id: "automatic-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Automatic Boiler",
  def_en: "Any class of boiler equipped with the controls and limit devices specified in the code's boiler chapter.",
  field_en: "\"Automatic\" here is a controls classification, not a marketing term — a boiler missing one of the required limit devices (low-water cutoff, pressure relief, etc.) doesn't qualify regardless of what the spec sheet calls it.",
  term_es: "Caldera Automática",
  def_es: "Cualquier clase de caldera equipada con los controles y dispositivos límite especificados en el capítulo de calderas del código.",
  field_es: "\"Automática\" aquí es una clasificación de controles, no un término de mercadeo — una caldera que carece de uno de los dispositivos límite requeridos (corte por bajo nivel de agua, alivio de presión, etc.) no califica sin importar cómo la llame la hoja de especificación."
},
{
  id: "balanced-ventilation-system",
  cat: "Air Systems & Ventilation",
  term_en: "Balanced Ventilation System",
  def_en: "A ventilation system that simultaneously supplies outdoor air and exhausts air, where the mechanical supply and exhaust airflow rates are each within 10 percent of their average.",
  field_en: "A system marketed as \"balanced\" that shows supply and exhaust rates more than 10% apart on the actual airflow schedule doesn't meet the definition — check the numbers, not the label.",
  term_es: "Sistema de Ventilación Balanceado",
  def_es: "Un sistema de ventilación que simultáneamente suministra aire exterior y extrae aire, donde las tasas de flujo de aire mecánico de suministro y extracción están cada una dentro del 10 por ciento de su promedio.",
  field_es: "Un sistema comercializado como \"balanceado\" que muestra tasas de suministro y extracción con más del 10% de diferencia en el programa real de flujo de aire no cumple la definición — verifique los números, no la etiqueta."
},
{
  id: "bathroom",
  cat: "General",
  term_en: "Bathroom",
  def_en: "A room containing a bathtub, shower, spa, or similar bathing fixture.",
  field_en: "A room with only a toilet and lavatory (no bathing fixture) is a \"toilet room,\" not a \"bathroom\" — the distinction changes which exhaust/ventilation rule table applies.",
  term_es: "Baño",
  def_es: "Un cuarto que contiene una bañera, ducha, spa u otro accesorio de baño similar.",
  field_es: "Un cuarto con solo un inodoro y lavamanos (sin accesorio de baño) es un \"cuarto de sanitario,\" no un \"baño\" — la distinción cambia qué tabla de regla de extracción/ventilación aplica."
},
{
  id: "boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Boiler",
  def_en: "A closed heating appliance supplying hot water or steam for space heating, processing, or power. Low-pressure boilers operate at or below 15 psi steam / 160 psi water; high-pressure boilers exceed those pressures.",
  field_en: "The low-pressure/high-pressure split changes which certification, relief-valve, and attendance requirements apply — always confirm actual operating pressure before evaluating a boiler room submittal against the wrong tier.",
  term_es: "Caldera",
  def_es: "Un aparato de calefacción cerrado que suministra agua caliente o vapor para calefacción de espacios, procesos o potencia. Las calderas de baja presión operan a 15 psi de vapor / 160 psi de agua o menos; las de alta presión exceden esas presiones.",
  field_es: "La división entre baja y alta presión cambia qué requisitos de certificación, válvula de alivio y atención aplican — siempre confirme la presión de operación real antes de evaluar una presentación de cuarto de calderas contra el nivel equivocado."
},
{
  id: "boiler-room",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Boiler Room",
  def_en: "A room primarily used for the installation of a boiler.",
  field_en: "\"Primarily\" matters — a room storing a boiler alongside unrelated general storage may not meet the boiler-room classification and its associated clearance/ventilation rules, a common gap on retrofit mechanical rooms.",
  term_es: "Cuarto de Calderas",
  def_es: "Un cuarto usado principalmente para la instalación de una caldera.",
  field_es: "\"Principalmente\" importa — un cuarto que almacena una caldera junto con almacenamiento general no relacionado puede no cumplir la clasificación de cuarto de calderas y sus reglas asociadas de separación/ventilación, una brecha común en cuartos mecánicos de retrofit."
},
{
  id: "brazed-joint-brazing",
  cat: "Appliances & Combustion",
  term_en: "Brazed Joint / Brazing",
  def_en: "A gastight joint made by joining metal parts with a nonferrous filler metal that melts above 1,000°F but below the base metal's melting point, drawn into the joint by capillary action between closely fitted surfaces.",
  field_en: "Brazed joints require closer-fitted surfaces than soldered ones and a higher-temperature filler — a joint description on a submittal that says \"brazed\" but specifies a filler melting below 1,000°F is actually describing a soldered joint, which has different code allowances.",
  term_es: "Junta Soldada Fuerte (Brazing) / Soldadura Fuerte",
  def_es: "Una junta hermética hecha uniendo partes metálicas con un metal de aporte no ferroso que se funde por encima de 1,000°F pero por debajo del punto de fusión del metal base, atraído a la junta por acción capilar entre superficies estrechamente ajustadas.",
  field_es: "Las juntas de soldadura fuerte requieren superficies más ajustadas que las soldadas con estaño y un material de aporte de mayor temperatura — una descripción de junta en una presentación que dice \"soldada fuerte\" pero especifica un material de aporte que funde por debajo de 1,000°F en realidad describe una junta soldada con estaño, que tiene permisos de código diferentes."
},
{
  id: "breathing-zone",
  cat: "Air Systems & Ventilation",
  term_en: "Breathing Zone",
  def_en: "The region of an occupied space between 3 and 72 inches above the floor and more than 2 feet from walls or fixed air-conditioning equipment.",
  field_en: "Ventilation effectiveness and air-quality compliance are measured in this specific zone, not just anywhere in the room — a sensor or diffuser located outside this envelope may not accurately represent occupant conditions.",
  term_es: "Zona de Respiración",
  def_es: "La región de un espacio ocupado entre 3 y 72 pulgadas sobre el piso y a más de 2 pies de las paredes o equipo fijo de aire acondicionado.",
  field_es: "La efectividad de la ventilación y el cumplimiento de calidad del aire se miden en esta zona específica, no en cualquier parte del cuarto — un sensor o difusor ubicado fuera de esta envolvente puede no representar con precisión las condiciones del ocupante."
},
{
  id: "btu",
  cat: "General",
  term_en: "BTU",
  def_en: "British thermal unit — the quantity of heat required to raise the temperature of 1 pound of water by 1°F (1 Btu = 1,055 J).",
  field_en: "Btu/h ratings on equipment nameplates are the basic unit behind every heating/cooling load calc — a mismatch between the calculated Btu/h load and the specified equipment's actual output rating is one of the first things worth spot-checking on a mechanical schedule.",
  term_es: "BTU",
  def_es: "Unidad térmica británica — la cantidad de calor requerida para elevar la temperatura de 1 libra de agua en 1°F (1 Btu = 1,055 J).",
  field_es: "Las clasificaciones de Btu/h en las placas de equipo son la unidad básica detrás de cada cálculo de carga de calefacción/enfriamiento — un desajuste entre la carga Btu/h calculada y la clasificación de salida real del equipo especificado es una de las primeras cosas que vale la pena verificar en un programa mecánico."
},
{
  id: "building",
  cat: "General",
  term_en: "Building",
  def_en: "Any structure used or intended for supporting or sheltering any occupancy.",
  field_en: "This broad definition is what lets mechanical code requirements reach beyond conventional structures — sheds, canopies, and similar structures with any occupancy purpose can still be pulled into scope.",
  term_es: "Edificio",
  def_es: "Cualquier estructura utilizada o destinada a soportar o albergar cualquier ocupación.",
  field_es: "Esta definición amplia es lo que permite que los requisitos del código mecánico alcancen más allá de estructuras convencionales — cobertizos, marquesinas y estructuras similares con cualquier propósito de ocupación aún pueden quedar dentro del alcance."
},
{
  id: "ceiling-radiation-damper",
  cat: "Venting & Chimneys",
  term_en: "Ceiling Radiation Damper",
  def_en: "A listed device in a ceiling membrane of a fire-resistance-rated floor/ceiling or roof/ceiling assembly that automatically limits radiative heat transfer through an air inlet/outlet opening. Classified as static (shuts down in a fire) or dynamic (keeps operating during a fire, tested for closure under elevated-temperature airflow).",
  field_en: "Confirm whether a project's air distribution design assumes the system keeps running during a fire event (dynamic) or shuts down (static) — specifying a static-rated damper into a dynamic smoke-control design is a life-safety mismatch, not just a paperwork issue.",
  term_es: "Compuerta de Radiación de Cielo Raso",
  def_es: "Un dispositivo listado en la membrana de cielo raso de un ensamble piso/cielo raso o techo/cielo raso clasificado contra incendio que limita automáticamente la transferencia de calor radiante a través de una abertura de entrada/salida de aire. Se clasifica como estática (se cierra durante un incendio) o dinámica (sigue operando durante un incendio, probada para cierre bajo flujo de aire a temperatura elevada).",
  field_es: "Confirme si el diseño de distribución de aire de un proyecto asume que el sistema sigue funcionando durante un evento de incendio (dinámico) o se apaga (estático) — especificar una compuerta clasificada como estática en un diseño dinámico de control de humo es un desajuste de seguridad de vida, no solo un problema de papeleo."
},
{
  id: "chimney",
  cat: "Venting & Chimneys",
  term_en: "Chimney (Factory-Built / Masonry / Metal)",
  def_en: "A primarily vertical structure containing one or more flues that carries gaseous combustion products and air from a fuel-burning appliance to the outdoor atmosphere. Factory-built chimneys are listed/labeled assemblies of factory-made components installed per the listing; masonry chimneys are field-built from solid masonry, brick, stone, or concrete; metal chimneys are field-constructed of metal.",
  field_en: "Each chimney type has its own clearance, listing, and inspection expectations — a factory-built chimney installed with field-fabricated modifications outside its listing conditions is functionally an unlisted assembly, regardless of the labeled components used.",
  term_es: "Chimenea (Fabricada en Fábrica / de Mampostería / Metálica)",
  def_es: "Una estructura principalmente vertical que contiene uno o más conductos que transportan productos gaseosos de combustión y aire desde un aparato que quema combustible hasta la atmósfera exterior. Las chimeneas fabricadas en fábrica son ensambles listados/etiquetados de componentes fabricados de fábrica instalados según el listado; las chimeneas de mampostería se construyen en campo con mampostería sólida, ladrillo, piedra o concreto; las chimeneas metálicas se construyen en campo con metal.",
  field_es: "Cada tipo de chimenea tiene sus propias expectativas de separación, listado e inspección — una chimenea fabricada en fábrica instalada con modificaciones hechas en campo fuera de las condiciones de su listado es funcionalmente un ensamble no listado, sin importar los componentes etiquetados usados."
},
{
  id: "chimney-connector",
  cat: "Venting & Chimneys",
  term_en: "Chimney Connector",
  def_en: "A pipe that connects a fuel-burning appliance to a chimney.",
  field_en: "Chimney connector material, clearance-to-combustibles, and slope requirements are frequently distinct from the chimney's own requirements — reviewing the chimney listing alone without checking the connector run is an incomplete review.",
  term_es: "Conector de Chimenea",
  def_es: "Una tubería que conecta un aparato que quema combustible a una chimenea.",
  field_es: "Los requisitos de material, separación de combustibles y pendiente del conector de chimenea frecuentemente son distintos de los requisitos de la chimenea misma — revisar solo el listado de la chimenea sin verificar la corrida del conector es una revisión incompleta."
},
{
  id: "clearance",
  cat: "General",
  term_en: "Clearance",
  def_en: "The minimum air-measured distance between the heat-producing surface of a mechanical appliance, device, or equipment and the surface of combustible material or assembly.",
  field_en: "Clearance is measured through air, not along a surface — a submittal showing an offset combustible surface \"around\" the required clearance distance instead of directly in front of it is a common misreading of this definition.",
  term_es: "Separación (Clearance)",
  def_es: "La distancia mínima medida a través del aire entre la superficie que produce calor de un aparato, dispositivo o equipo mecánico y la superficie del material o ensamble combustible.",
  field_es: "La separación se mide a través del aire, no a lo largo de una superficie — una presentación que muestra una superficie combustible desplazada \"alrededor\" de la distancia de separación requerida en lugar de directamente en frente es una interpretación errónea común de esta definición."
},
{
  id: "closed-combustion-solid-fuel-appliance",
  cat: "Appliances & Combustion",
  term_en: "Closed Combustion Solid-Fuel-Burning Appliance",
  def_en: "A heat-producing appliance whose combustion chamber has no openings other than the flue collar, fuel charging door, and adjustable combustion-air-control openings.",
  field_en: "An open-front wood stove or fireplace insert doesn't meet this definition even if it burns the same fuel — closed-combustion status changes air-supply, clearance, and listing requirements significantly.",
  term_es: "Aparato de Combustión Cerrada que Quema Combustible Sólido",
  def_es: "Un aparato que produce calor cuya cámara de combustión no tiene aberturas más allá del collar del conducto, la puerta de carga de combustible y las aberturas ajustables de control de aire de combustión.",
  field_es: "Una estufa de leña o inserto de chimenea de frente abierto no cumple esta definición aunque queme el mismo combustible — el estatus de combustión cerrada cambia significativamente los requisitos de suministro de aire, separación y listado."
},
{
  id: "clothes-dryer",
  cat: "Appliances & Combustion",
  term_en: "Clothes Dryer",
  def_en: "An appliance used to dry wet laundry by means of heat.",
  field_en: "Dryer exhaust duct length, material, and termination rules are among the most frequently violated items in residential mechanical work — lint accumulation from an oversized, undersized, or improperly terminated run is a genuine fire-risk finding, not a formality.",
  term_es: "Secadora de Ropa",
  def_es: "Un aparato usado para secar ropa mojada por medio de calor.",
  field_es: "Las reglas de longitud, material y terminación del ducto de extracción de secadora están entre los elementos más frecuentemente violados en trabajo mecánico residencial — la acumulación de pelusa por una corrida sobredimensionada, subdimensionada o terminada incorrectamente es un hallazgo genuino de riesgo de incendio, no una formalidad."
},
{
  id: "code",
  cat: "General",
  term_en: "Code",
  def_en: "The regulations in force, including subsequent amendments and any emergency rules the administrative authority has lawfully adopted.",
  field_en: "\"The code\" isn't static — confirm which edition and local amendments actually govern a given jurisdiction and permit date before citing a requirement, since adopted editions and local modifications vary by AHJ.",
  term_es: "Código",
  def_es: "Las regulaciones vigentes, incluyendo enmiendas posteriores y cualquier regla de emergencia que la autoridad administrativa haya adoptado legalmente.",
  field_es: "\"El código\" no es estático — confirme qué edición y enmiendas locales realmente rigen una jurisdicción y fecha de permiso dadas antes de citar un requisito, ya que las ediciones adoptadas y modificaciones locales varían según el AHJ."
},
{
  id: "code-official",
  cat: "General",
  term_en: "Code Official",
  def_en: "The officer or other designated authority charged with administering and enforcing the code, or a duly authorized representative.",
  field_en: "\"Code official\" can be delegated to a representative (plans examiner, field inspector) — confirm who actually holds signing authority for a given determination before treating an informal opinion as a binding ruling.",
  term_es: "Funcionario del Código",
  def_es: "El oficial u otra autoridad designada encargada de administrar y hacer cumplir el código, o un representante debidamente autorizado.",
  field_es: "\"Funcionario del código\" puede delegarse a un representante (examinador de planos, inspector de campo) — confirme quién realmente tiene autoridad de firma para una determinación dada antes de tratar una opinión informal como un dictamen vinculante."
},
{
  id: "combination-fire-smoke-damper",
  cat: "Venting & Chimneys",
  term_en: "Combination Fire/Smoke Damper",
  def_en: "A listed device in ducts and air transfer openings that closes automatically on heat detection and resists the passage of flame and smoke, operated automatically, controlled by a smoke detection system, and where required, positionable from a fire command center.",
  field_en: "A combination damper does two jobs at once (fire and smoke) — confirm a submittal isn't substituting a standalone fire damper or smoke damper alone where the design actually requires the combination-rated device.",
  term_es: "Compuerta Combinada Contra Incendio/Humo",
  def_es: "Un dispositivo listado en ductos y aberturas de transferencia de aire que se cierra automáticamente al detectar calor y resiste el paso de llama y humo, operado automáticamente, controlado por un sistema de detección de humo, y donde se requiere, posicionable desde un centro de comando de incendios.",
  field_es: "Una compuerta combinada hace dos trabajos a la vez (incendio y humo) — confirme que una presentación no esté sustituyendo una compuerta contra incendio independiente o una compuerta de humo sola donde el diseño realmente requiere el dispositivo clasificado combinado."
},
{
  id: "combustible-assembly",
  cat: "Appliances & Combustion",
  term_en: "Combustible Assembly",
  def_en: "A wall, floor, ceiling, or other assembly built from one or more component materials that don't qualify as noncombustible.",
  field_en: "An assembly counts as combustible if any single component material fails the noncombustible test — a mostly-noncombustible wall assembly with one combustible layer (like a vapor barrier or finish) is still a combustible assembly for clearance purposes.",
  term_es: "Ensamble Combustible",
  def_es: "Una pared, piso, cielo raso u otro ensamble construido con uno o más materiales componentes que no califican como no combustibles.",
  field_es: "Un ensamble cuenta como combustible si algún material componente individual falla la prueba de no combustible — un ensamble de pared mayormente no combustible con una capa combustible (como una barrera de vapor o acabado) sigue siendo un ensamble combustible para efectos de separación."
},
{
  id: "combustible-liquid",
  cat: "Appliances & Combustion",
  term_en: "Combustible Liquid (Class II / IIIA / IIIB)",
  def_en: "A liquid with a closed-cup flash point at or above 100°F. Class II: 100-140°F. Class IIIA: 140-200°F. Class IIIB: 200°F and above. Compressed gases and cryogenic fluids are excluded from this category.",
  field_en: "Storage, piping, and appliance-connection rules scale with flash point class — a fuel-oil submittal that doesn't state which class applies is missing the single data point that determines several downstream requirements.",
  term_es: "Líquido Combustible (Clase II / IIIA / IIIB)",
  def_es: "Un líquido con un punto de inflamación de copa cerrada de 100°F o más. Clase II: 100-140°F. Clase IIIA: 140-200°F. Clase IIIB: 200°F o más. Los gases comprimidos y fluidos criogénicos están excluidos de esta categoría.",
  field_es: "Las reglas de almacenamiento, tubería y conexión de aparatos escalan con la clase de punto de inflamación — una presentación de combustible de aceite que no indica qué clase aplica carece del único dato que determina varios requisitos posteriores."
},
{
  id: "combustible-material",
  cat: "Appliances & Combustion",
  term_en: "Combustible Material",
  def_en: "Any material not defined as noncombustible.",
  field_en: "This is a default-to-combustible definition — a material has to affirmatively pass a noncombustibility test (ASTM E136) to escape the combustible-material clearance rules, not the other way around.",
  term_es: "Material Combustible",
  def_es: "Cualquier material que no se define como no combustible.",
  field_es: "Esta es una definición por defecto hacia combustible — un material tiene que pasar afirmativamente una prueba de no combustibilidad (ASTM E136) para escapar de las reglas de separación de material combustible, no al revés."
},
{
  id: "combustion",
  cat: "Appliances & Combustion",
  term_en: "Combustion",
  def_en: "The rapid oxidation of fuel accompanied by the production of heat, or heat and light.",
  field_en: "This baseline definition underlies every combustion-air, venting, and clearance requirement in the code — worth anchoring a field discussion here when a crew is confused about why a rule exists.",
  term_es: "Combustión",
  def_es: "La oxidación rápida de combustible acompañada de la producción de calor, o calor y luz.",
  field_es: "Esta definición base sustenta cada requisito de aire de combustión, ventilación y separación en el código — vale la pena anclar una discusión de campo aquí cuando una cuadrilla está confundida sobre por qué existe una regla."
},
{
  id: "combustion-air",
  cat: "Appliances & Combustion",
  term_en: "Combustion Air",
  def_en: "Air necessary for complete combustion of a fuel, including theoretical air (the exact amount needed) and excess air (extra air to ensure complete combustion and prevent dangerous byproducts).",
  field_en: "A confined mechanical room with a sealed combustion appliance still needs a documented combustion-air path unless the appliance is specifically direct-vent/sealed-combustion rated — one of the most common life-safety gaps in tight equipment closets.",
  term_es: "Aire de Combustión",
  def_es: "Aire necesario para la combustión completa de un combustible, incluyendo el aire teórico (la cantidad exacta necesaria) y el exceso de aire (aire adicional para asegurar combustión completa y prevenir subproductos peligrosos).",
  field_es: "Un cuarto mecánico confinado con un aparato de combustión sellada todavía necesita una trayectoria de aire de combustión documentada a menos que el aparato esté específicamente clasificado como de ventilación directa/combustión sellada — una de las brechas de seguridad de vida más comunes en clósets de equipo ajustados."
},
{
  id: "combustion-chamber",
  cat: "Appliances & Combustion",
  term_en: "Combustion Chamber",
  def_en: "The portion of an appliance within which combustion occurs.",
  field_en: "Combustion chamber liner damage or corrosion is one of the highest-consequence field findings on an older furnace or boiler — cracks here can let combustion products bypass the intended flue path entirely.",
  term_es: "Cámara de Combustión",
  def_es: "La porción de un aparato dentro de la cual ocurre la combustión.",
  field_es: "El daño o corrosión del revestimiento de la cámara de combustión es uno de los hallazgos de campo de mayor consecuencia en un horno o caldera antiguo — las grietas aquí pueden permitir que los productos de combustión eviten completamente la trayectoria de conducto prevista."
},
{
  id: "combustion-products",
  cat: "Appliances & Combustion",
  term_en: "Combustion Products",
  def_en: "The constituents resulting from burning a fuel with the oxygen in air, including inert gases, but excluding excess air.",
  field_en: "Distinguishing combustion products from flue gases (which include the excess air) matters when interpreting temperature and volume figures on appliance and venting spec sheets.",
  term_es: "Productos de Combustión",
  def_es: "Los constituyentes resultantes de quemar un combustible con el oxígeno del aire, incluyendo gases inertes, pero excluyendo el exceso de aire.",
  field_es: "Distinguir los productos de combustión de los gases de combustión (que incluyen el exceso de aire) importa al interpretar cifras de temperatura y volumen en hojas de especificación de aparatos y ventilación."
},
{
  id: "commercial-cooking-appliances",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Commercial Cooking Appliances",
  def_en: "Appliances used in a commercial food service establishment for heating or cooking food, where the establishment prepares food for sale or at a scale not representative of domestic household cooking.",
  field_en: "A church kitchen, break room, or small catering operation can cross into \"commercial cooking\" territory depending on volume and frequency, even without a for-profit sale — don't assume a non-restaurant kitchen is automatically exempt from Type I hood requirements.",
  term_es: "Aparatos de Cocina Comercial",
  def_es: "Aparatos usados en un establecimiento comercial de servicio de alimentos para calentar o cocinar comida, donde el establecimiento prepara comida para la venta o a una escala no representativa de la cocina doméstica del hogar.",
  field_es: "Una cocina de iglesia, sala de descanso u operación de catering pequeña puede cruzar al territorio de \"cocina comercial\" según el volumen y frecuencia, incluso sin una venta con fines de lucro — no asuma que una cocina que no es de restaurante está automáticamente exenta de los requisitos de campana Tipo I."
},
{
  id: "commercial-cooking-recirculating-system",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Commercial Cooking Recirculating System",
  def_en: "A self-contained system consisting of the exhaust hood, cooking equipment, filters, and fire suppression system, designed to capture cooking vapors and residues and recirculate cleaned air back to the space instead of exhausting it outdoors.",
  field_en: "Recirculating (ventless) systems have their own listing, appliance-compatibility, and maintenance schedule requirements distinct from a conventional exhausted hood — verify the specific listed system matches the exact appliances it's paired with, since these are tested as matched assemblies.",
  term_es: "Sistema Recirculante de Cocina Comercial",
  def_es: "Un sistema autocontenido que consiste en la campana de extracción, el equipo de cocina, los filtros y el sistema de supresión de incendios, diseñado para capturar vapores y residuos de cocina y recircular el aire limpio de vuelta al espacio en lugar de extraerlo al exterior.",
  field_es: "Los sistemas recirculantes (sin ventilación) tienen sus propios requisitos de listado, compatibilidad de aparatos y programa de mantenimiento distintos de una campana extraída convencional — verifique que el sistema listado específico coincida exactamente con los aparatos con los que está emparejado, ya que se prueban como ensambles emparejados."
},
{
  id: "commercial-kitchen-hoods-shape",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Commercial Kitchen Hoods, Backshelf / Eyebrow / Pass-Over",
  def_en: "Backshelf (low-proximity/sidewall): a low front lip set back from the appliances, always closed to the rear. Eyebrow: mounted directly to an appliance face above its opening(s), such as an oven or dishwasher. Pass-Over: a free-standing backshelf-style hood built low enough to pass food over the top.",
  field_en: "Each hood style has its own effective capture geometry — swapping hood styles at value engineering without re-checking exhaust rate and appliance duty class can quietly undersize capture capacity even if the CFM number stays the same.",
  term_es: "Campanas de Cocina Comercial, de Repisa Trasera / Ceja / Paso Sobre",
  def_es: "De Repisa Trasera (baja proximidad/pared lateral): un labio frontal bajo retranqueado de los aparatos, siempre cerrada en la parte trasera. Ceja: montada directamente en la cara de un aparato sobre su(s) abertura(s), como un horno o lavaplatos. Paso Sobre: una campana estilo repisa trasera autoportante construida lo suficientemente baja para pasar comida por encima.",
  field_es: "Cada estilo de campana tiene su propia geometría de captura efectiva — cambiar estilos de campana en ingeniería de valor sin reverificar la tasa de extracción y clase de servicio del aparato puede subdimensionar silenciosamente la capacidad de captura aunque el número de CFM se mantenga igual."
},
{
  id: "commercial-kitchen-hoods-canopy",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Commercial Kitchen Hoods, Single/Double Island Canopy / Wall Canopy",
  def_en: "Single Island: placed over one appliance line, open on all sides, overhanging front/rear/sides — more susceptible to cross drafts and needs more exhaust airflow than a wall-mounted hood of the same size. Double Island: placed over back-to-back appliance lines, open on all sides. Wall Canopy: mounted against a wall above an appliance line, using the wall to help draw makeup air across the front of the equipment.",
  field_en: "Island hoods (open on all sides) need meaningfully higher exhaust CFM than an equivalent wall canopy to achieve the same capture-and-containment performance — a common undersizing error when an island layout is designed using wall-canopy CFM rules of thumb.",
  term_es: "Campanas de Cocina Comercial, de Isla Sencilla/Doble o de Pared",
  def_es: "Isla Sencilla: colocada sobre una línea de aparatos, abierta por todos lados, sobresaliendo al frente/atrás/lados — más susceptible a corrientes cruzadas y necesita más flujo de extracción que una campana de pared del mismo tamaño. Isla Doble: colocada sobre líneas de aparatos espalda con espalda, abierta por todos lados. De Pared: montada contra una pared sobre una línea de aparatos, usando la pared para ayudar a atraer aire de reposición a través del frente del equipo.",
  field_es: "Las campanas de isla (abiertas por todos lados) necesitan un CFM de extracción considerablemente mayor que una campana de pared equivalente para lograr el mismo rendimiento de captura y contención — un error común de subdimensionamiento cuando un diseño de isla se hace usando reglas empíricas de CFM de campana de pared."
},
{
  id: "compensating-hoods",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Compensating Hoods",
  def_en: "Hoods with an integral (built-in) makeup air supply, delivered via short-circuit flow from inside the hood, an air-curtain at the bottom front face, front-face discharge, or from the rear/side of the hood or cooking equipment — in any combination.",
  field_en: "A compensating hood's built-in makeup air can mask an inadequate room-level makeup air supply on paper — confirm the room's overall makeup air balance is still adequate even when the hood supplies some of its own air internally.",
  term_es: "Campanas Compensadoras",
  def_es: "Campanas con suministro integral (incorporado) de aire de reposición, entregado mediante flujo de cortocircuito desde dentro de la campana, una cortina de aire en la parte baja del frente, descarga frontal, o desde la parte trasera/lateral de la campana o del equipo de cocina — en cualquier combinación.",
  field_es: "El aire de reposición incorporado de una campana compensadora puede enmascarar en el papel un suministro inadecuado de aire de reposición a nivel de cuarto — confirme que el balance general de aire de reposición del cuarto siga siendo adecuado incluso cuando la campana suministra parte de su propio aire internamente."
},
{
  id: "compressor",
  cat: "Refrigeration & Cooling",
  term_en: "Compressor / Positive Displacement Compressor / Compressor Unit",
  def_en: "Compressor: a machine, with or without accessories, for compressing a gas. Positive Displacement: increases pressure by changing the internal volume of the compression chamber. Compressor Unit: a compressor together with its prime mover and accessories.",
  field_en: "\"Compressor\" and \"compressor unit\" are sometimes used loosely as synonyms on cut sheets — confirm whether a schedule entry is describing just the compression element or the full driven assembly before matching it to a mechanical/electrical connection point.",
  term_es: "Compresor / Compresor de Desplazamiento Positivo / Unidad Compresora",
  def_es: "Compresor: una máquina, con o sin accesorios, para comprimir un gas. Desplazamiento Positivo: aumenta la presión cambiando el volumen interno de la cámara de compresión. Unidad Compresora: un compresor junto con su motor primario y accesorios.",
  field_es: "\"Compresor\" y \"unidad compresora\" a veces se usan de forma imprecisa como sinónimos en hojas de corte — confirme si una entrada de programa describe solo el elemento de compresión o el ensamble impulsado completo antes de emparejarlo con un punto de conexión mecánica/eléctrica."
},
{
  id: "concealed-location",
  cat: "General",
  term_en: "Concealed Location",
  def_en: "A location that cannot be accessed without damaging permanent parts of the building structure or finish surface. Spaces behind readily removable panels or doors are not concealed.",
  field_en: "This is the mechanical-code counterpart to the electrical code's \"concealed\" definition — a readily removable access panel keeps equipment out of \"concealed location\" status, which changes what protection and support rules apply.",
  term_es: "Ubicación Oculta",
  def_es: "Una ubicación a la que no se puede acceder sin dañar partes permanentes de la estructura del edificio o superficie de acabado. Los espacios detrás de paneles o puertas fácilmente removibles no están ocultos.",
  field_es: "Esta es la contraparte del código mecánico a la definición de \"oculto\" del código eléctrico — un panel de acceso fácilmente removible mantiene al equipo fuera del estatus de \"ubicación oculta,\" lo cual cambia qué reglas de protección y soporte aplican."
},
{
  id: "condensate",
  cat: "Venting & Chimneys",
  term_en: "Condensate",
  def_en: "The liquid that condenses from a gas (including flue gas) because of a temperature reduction.",
  field_en: "High-efficiency condensing appliances produce acidic condensate that needs a proper drain and, often, a neutralizer — routing this condensate into a standard uninsulated or uncoated drain line is a common corrosion-related callback.",
  term_es: "Condensado",
  def_es: "El líquido que se condensa de un gas (incluyendo gas de combustión) debido a una reducción de temperatura.",
  field_es: "Los aparatos de condensación de alta eficiencia producen condensado ácido que necesita un drenaje adecuado y, a menudo, un neutralizador — dirigir este condensado a una línea de drenaje estándar sin aislamiento ni recubrimiento es una causa común de reclamo por corrosión."
},
{
  id: "condenser",
  cat: "Refrigeration & Cooling",
  term_en: "Condenser",
  def_en: "A heat exchanger designed to liquefy refrigerant vapor by removing heat.",
  field_en: "Condenser airflow or water-flow restriction (dirty coils, blocked clearances) is one of the most common causes of high-head-pressure trips in the field — often mistaken for a refrigerant charge problem.",
  term_es: "Condensador",
  def_es: "Un intercambiador de calor diseñado para licuar vapor de refrigerante removiendo calor.",
  field_es: "La restricción de flujo de aire o agua del condensador (serpentines sucios, separaciones bloqueadas) es una de las causas más comunes de disparos por alta presión de descarga en campo — a menudo confundida con un problema de carga de refrigerante."
},
{
  id: "condensing-unit",
  cat: "Refrigeration & Cooling",
  term_en: "Condensing Unit",
  def_en: "A factory-made assembly of refrigeration components designed to compress and liquefy a specific refrigerant, consisting of one or more power-driven compressors, condensers, liquid receivers (where required), and factory-supplied accessories.",
  field_en: "Refrigerant type is baked into the condensing unit's factory design — field-substituting a different refrigerant into an existing condensing unit (a \"drop-in\" retrofit) needs to be verified against the manufacturer's actual approved refrigerant list, not assumed compatible.",
  term_es: "Unidad Condensadora",
  def_es: "Un ensamble fabricado en fábrica de componentes de refrigeración diseñado para comprimir y licuar un refrigerante específico, consistiendo en uno o más compresores accionados por potencia, condensadores, recibidores de líquido (donde se requiera) y accesorios suministrados de fábrica.",
  field_es: "El tipo de refrigerante está incorporado en el diseño de fábrica de la unidad condensadora — sustituir en campo un refrigerante diferente en una unidad condensadora existente (un retrofit \"drop-in\") debe verificarse contra la lista real de refrigerantes aprobados del fabricante, no asumirse compatible."
},
{
  id: "conditioned-space",
  cat: "Air Systems & Ventilation",
  term_en: "Conditioned Space",
  def_en: "An area enclosed within the building thermal envelope that is directly or indirectly heated or cooled. Indirectly conditioned spaces communicate through openings with conditioned spaces, are separated from them only by uninsulated assemblies, or contain uninsulated ducts, piping, or other heating/cooling sources.",
  field_en: "Attics and crawlspaces containing uninsulated ductwork can end up classified as \"indirectly conditioned\" even without a supply register — this affects insulation and vapor-barrier requirements that a strictly ventilated-attic assumption would miss.",
  term_es: "Espacio Acondicionado",
  def_es: "Un área encerrada dentro de la envolvente térmica del edificio que se calienta o enfría directa o indirectamente. Los espacios acondicionados indirectamente se comunican mediante aberturas con espacios acondicionados, están separados de ellos solo por ensambles sin aislar, o contienen ductos, tubería u otras fuentes de calefacción/enfriamiento sin aislar.",
  field_es: "Los áticos y espacios de gateo que contienen ductos sin aislar pueden terminar clasificados como \"acondicionados indirectamente\" incluso sin un registro de suministro — esto afecta los requisitos de aislamiento y barrera de vapor que una suposición estrictamente de ático ventilado pasaría por alto."
},
{
  id: "construction-documents",
  cat: "General",
  term_en: "Construction Documents",
  def_en: "The written, graphic, and pictorial documents prepared or assembled to describe the design, location, and physical characteristics of a project's elements, drawn to an appropriate scale, necessary to obtain a building permit.",
  field_en: "\"Appropriate scale\" is a judgment call the code official makes — a set that's technically complete but drawn too small or cluttered to review clearly can be rejected on legibility grounds alone.",
  term_es: "Documentos de Construcción",
  def_es: "Los documentos escritos, gráficos y pictóricos preparados o ensamblados para describir el diseño, ubicación y características físicas de los elementos de un proyecto, dibujados a una escala apropiada, necesarios para obtener un permiso de construcción.",
  field_es: "\"Escala apropiada\" es un juicio que hace el funcionario del código — un juego técnicamente completo pero dibujado demasiado pequeño o saturado para revisar con claridad puede rechazarse solo por motivos de legibilidad."
},
{
  id: "control",
  cat: "General",
  term_en: "Control",
  def_en: "A manual or automatic device designed to regulate the gas, air, water, or electrical supply to, or the operation of, a mechanical system.",
  field_en: "\"Control\" is a broad umbrella term covering everything from a simple manual valve to a full building-automation sequence — when a spec references \"controls,\" confirm whether it means the physical device, the sequence of operation, or both.",
  term_es: "Control",
  def_es: "Un dispositivo manual o automático diseñado para regular el suministro de gas, aire, agua o electricidad hacia, o la operación de, un sistema mecánico.",
  field_es: "\"Control\" es un término general amplio que cubre todo desde una válvula manual simple hasta una secuencia completa de automatización de edificio — cuando una especificación referencia \"controles,\" confirme si se refiere al dispositivo físico, la secuencia de operación, o ambos."
},
{
  id: "conversion-burner",
  cat: "Appliances & Combustion",
  term_en: "Conversion Burner",
  def_en: "A burner designed to supply gaseous fuel to an appliance originally designed to use a different fuel.",
  field_en: "Converting an appliance's fuel type via a conversion burner needs the same full review as a new installation — combustion air, venting, and clearance requirements all shift with the fuel change, even though the appliance shell stays the same.",
  term_es: "Quemador de Conversión",
  def_es: "Un quemador diseñado para suministrar combustible gaseoso a un aparato originalmente diseñado para usar un combustible diferente.",
  field_es: "Convertir el tipo de combustible de un aparato mediante un quemador de conversión necesita la misma revisión completa que una instalación nueva — los requisitos de aire de combustión, ventilación y separación cambian todos con el cambio de combustible, aunque la carcasa del aparato se mantenga igual."
},
{
  id: "damper",
  cat: "Venting & Chimneys",
  term_en: "Damper / Volume Damper",
  def_en: "Damper: a manually or automatically controlled device that regulates draft or the flow rate of air or combustion gases. Volume Damper: a device installed to restrict, retard, or direct airflow in a duct, or combustion products in a heat-producing appliance and its vent connector or chimney.",
  field_en: "\"Damper\" alone can mean a fire/smoke damper, balancing damper, or barometric draft damper depending on context — confirm which specific damper function a spec note is describing before assuming it's a life-safety device.",
  term_es: "Compuerta / Compuerta de Volumen",
  def_es: "Compuerta: un dispositivo controlado manual o automáticamente que regula el tiro o la tasa de flujo de aire o gases de combustión. Compuerta de Volumen: un dispositivo instalado para restringir, retardar o dirigir el flujo de aire en un ducto, o los productos de combustión en un aparato que produce calor y su conector de ventilación o chimenea.",
  field_es: "\"Compuerta\" por sí sola puede significar una compuerta contra incendio/humo, compuerta de balanceo, o compuerta de tiro barométrico según el contexto — confirme qué función específica de compuerta describe una nota de especificación antes de asumir que es un dispositivo de seguridad de vida."
}
,
{
  id: "design-flood-elevation",
  cat: "General",
  term_en: "Design Flood Elevation",
  def_en: "The elevation of the design flood, including wave height, referenced to the datum on the community's legally designated flood hazard map. In Zone AO, it is the highest existing grade at the building perimeter plus the map's depth number (or 2 feet if none is specified).",
  field_en: "Mechanical equipment placed below the design flood elevation in a flood zone typically needs to be elevated, flood-vented, or specifically designed for flood damage resistance — a common miss when equipment layout is finalized before the flood study.",
  term_es: "Elevación de Diseño de Inundación",
  def_es: "La elevación de la inundación de diseño, incluyendo la altura de ola, referenciada al datum en el mapa de riesgo de inundación legalmente designado por la comunidad. En la Zona AO, es el grado existente más alto en el perímetro del edificio más el número de profundidad del mapa (o 2 pies si no se especifica ninguno).",
  field_es: "El equipo mecánico colocado por debajo de la elevación de diseño de inundación en una zona de inundación típicamente necesita elevarse, ventilarse contra inundación, o diseñarse específicamente para resistencia a daños por inundación — un error común cuando el diseño del equipo se finaliza antes del estudio de inundación."
},
{
  id: "design-working-pressure",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Design Working Pressure",
  def_en: "The maximum allowable working pressure for which a specific part of a system is designed.",
  field_en: "Every component in a piping run — pipe, fittings, valves — must carry a design working pressure rating at or above the system's actual operating pressure; the weakest-rated component sets the ceiling for the whole run.",
  term_es: "Presión de Trabajo de Diseño",
  def_es: "La presión máxima de trabajo permitida para la cual se diseña una parte específica de un sistema.",
  field_es: "Cada componente en una corrida de tubería — tubo, accesorios, válvulas — debe tener una clasificación de presión de trabajo de diseño igual o superior a la presión de operación real del sistema; el componente con menor clasificación establece el límite para toda la corrida."
},
{
  id: "direct-evaporative-cooling",
  cat: "Refrigeration & Cooling",
  term_en: "Direct Evaporative Cooling",
  def_en: "A cooling process where water evaporates directly into the air stream, lowering the dry-bulb temperature while raising humidity.",
  field_en: "Direct evaporative cooling works best in low-humidity climates and raises the supply air's moisture content — confirm the space's humidity tolerance (electronics, artifacts, sensitive finishes) before specifying it over a mechanical cooling system.",
  term_es: "Enfriamiento Evaporativo Directo",
  def_es: "Un proceso de enfriamiento donde el agua se evapora directamente en la corriente de aire, bajando la temperatura de bulbo seco mientras eleva la humedad.",
  field_es: "El enfriamiento evaporativo directo funciona mejor en climas de baja humedad y eleva el contenido de humedad del aire de suministro — confirme la tolerancia de humedad del espacio (electrónica, artefactos, acabados sensibles) antes de especificarlo en lugar de un sistema de enfriamiento mecánico."
},
{
  id: "direct-refrigeration-system",
  cat: "Refrigeration & Cooling",
  term_en: "Direct Refrigeration System",
  def_en: "A system in which the evaporator or condenser is in direct contact with the air or substance being cooled or heated, with no secondary coolant loop in between.",
  field_en: "Direct systems put refrigerant piping directly in occupied or storage spaces — check the refrigerant's safety group classification against the space's occupancy and volume before assuming a direct system is acceptable.",
  term_es: "Sistema de Refrigeración Directo",
  def_es: "Un sistema en el cual el evaporador o condensador está en contacto directo con el aire o la sustancia que se enfría o calienta, sin un circuito de refrigerante secundario de por medio.",
  field_es: "Los sistemas directos colocan la tubería de refrigerante directamente en espacios ocupados o de almacenamiento — verifique la clasificación de grupo de seguridad del refrigerante contra la ocupación y el volumen del espacio antes de asumir que un sistema directo es aceptable."
},
{
  id: "direct-solar-system",
  cat: "General",
  term_en: "Direct Solar System",
  def_en: "A solar thermal system in which the gas or liquid in the solar collector loop is not separated from the load it serves.",
  field_en: "Direct solar systems circulate the same fluid through the collector and the load — freeze protection and water quality of that shared fluid become a single coordinated design decision, not two separate ones.",
  term_es: "Sistema Solar Directo",
  def_es: "Un sistema térmico solar en el cual el gas o líquido en el circuito del colector solar no está separado de la carga a la que sirve.",
  field_es: "Los sistemas solares directos circulan el mismo fluido a través del colector y la carga — la protección contra congelamiento y la calidad del agua de ese fluido compartido se convierten en una sola decisión de diseño coordinada, no dos separadas."
},
{
  id: "direct-vent-appliances",
  cat: "Venting & Chimneys",
  term_en: "Direct-Vent Appliances",
  def_en: "Appliances built and installed so all combustion air comes from outdoors and all flue gases discharge outdoors, with no air exchange with the indoor space.",
  field_en: "A direct-vent appliance's sealed combustion system means indoor air quality and depressurization concerns that apply to naturally-vented appliances don't apply the same way — but the concentric or two-pipe vent termination clearances still need to be checked against doors, windows, and grade.",
  term_es: "Aparatos de Venteo Directo",
  def_es: "Aparatos construidos e instalados de modo que todo el aire de combustión proviene del exterior y todos los gases de combustión se descargan al exterior, sin intercambio de aire con el espacio interior.",
  field_es: "El sistema de combustión sellada de un aparato de venteo directo significa que las preocupaciones de calidad de aire interior y despresurización que aplican a aparatos con venteo natural no aplican de la misma forma — pero las separaciones de terminación del venteo concéntrico o de dos tubos todavía deben verificarse contra puertas, ventanas y el nivel del suelo."
},
{
  id: "discrete-product",
  cat: "General",
  term_en: "Discrete Product",
  def_en: "Noncontinuous, individual, distinct pieces — such as electrical, plumbing, and mechanical products, and duct straps, fittings, registers, and pipe hangers.",
  field_en: "This classification mostly shows up in manufacturing/labeling code sections — not a term field crews use day to day, but relevant when confirming a product's listing or labeling requirements.",
  term_es: "Producto Discreto",
  def_es: "Piezas individuales, distintas y no continuas — como productos eléctricos, de plomería y mecánicos, y abrazaderas de ductos, accesorios, rejillas y colgantes de tubería.",
  field_es: "Esta clasificación aparece principalmente en secciones de código sobre fabricación/etiquetado — no es un término que las cuadrillas de campo usen a diario, pero es relevante al confirmar los requisitos de listado o etiquetado de un producto."
},
{
  id: "draft",
  cat: "Venting & Chimneys",
  term_en: "Draft / Induced Draft / Natural Draft",
  def_en: "Draft: the pressure difference between an appliance and the atmosphere that drives combustion products through the vent to the outdoors. Induced Draft: that pressure difference created by a fan or blower between the appliance and the vent termination. Natural Draft: the pressure difference created by the vent's height and the temperature difference between flue gases and outdoor air, with no mechanical assist.",
  field_en: "Confirming whether an appliance relies on natural or induced draft changes the venting material, slope, and termination requirements — mixing the two draft types on the same vent run is a common and serious field error.",
  term_es: "Tiro / Tiro Inducido / Tiro Natural",
  def_es: "Tiro: la diferencia de presión entre un aparato y la atmósfera que impulsa los productos de combustión a través del venteo hacia el exterior. Tiro Inducido: esa diferencia de presión creada por un ventilador o soplador entre el aparato y la terminación del venteo. Tiro Natural: la diferencia de presión creada por la altura del venteo y la diferencia de temperatura entre los gases de combustión y el aire exterior, sin asistencia mecánica.",
  field_es: "Confirmar si un aparato depende de tiro natural o inducido cambia el material, la pendiente y los requisitos de terminación del venteo — mezclar los dos tipos de tiro en la misma corrida de venteo es un error de campo común y grave."
},
{
  id: "draftstop",
  cat: "General",
  term_en: "Draftstop",
  def_en: "A material, device, or construction installed to restrict air movement within concealed spaces in building components such as crawl spaces, floor/ceiling assemblies, and attics.",
  field_en: "Ductwork and piping routed through concealed spaces needs to preserve required draftstopping — a penetration through a draftstop that isn't properly sealed defeats the compartmentalization it was installed to provide.",
  term_es: "Cortafuego de Tiro (Draftstop)",
  def_es: "Un material, dispositivo o construcción instalado para restringir el movimiento de aire dentro de espacios ocultos en componentes del edificio como espacios de arrastre, ensambles de piso/techo y áticos.",
  field_es: "Los ductos y tuberías enrutados a través de espacios ocultos deben preservar el cortafuego de tiro requerido — una penetración a través de un cortafuego de tiro que no está sellada adecuadamente anula la compartimentación que se instaló para proporcionar."
},
{
  id: "drain-back-system",
  cat: "General",
  term_en: "Drain-Back System",
  def_en: "A solar thermal system in which the collector-loop fluid gravity-drains from the collector into a holding tank under prescribed conditions, protecting the system from freeze damage.",
  field_en: "Drain-back systems need a continuous downward slope back to the holding tank with no low points where fluid could pocket and freeze — verify the actual routed piping matches the design slope, not just the schematic.",
  term_es: "Sistema de Drenado por Gravedad",
  def_es: "Un sistema térmico solar en el cual el fluido del circuito del colector se drena por gravedad del colector a un tanque de retención bajo condiciones prescritas, protegiendo al sistema de daños por congelamiento.",
  field_es: "Los sistemas de drenado por gravedad necesitan una pendiente descendente continua de regreso al tanque de retención sin puntos bajos donde el fluido pueda acumularse y congelarse — verifique que la tubería realmente instalada coincida con la pendiente de diseño, no solo el esquemático."
},
{
  id: "drip",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Drip",
  def_en: "A container placed at a low point in a piping system to collect condensate, positioned so the collected condensate can be removed.",
  field_en: "A drip leg without an accessible removal point becomes a maintenance dead end — confirm the drip's location allows service access before the piping is enclosed.",
  term_es: "Trampa de Goteo (Drip)",
  def_es: "Un recipiente colocado en un punto bajo de un sistema de tubería para recolectar condensado, posicionado de forma que el condensado recolectado pueda ser removido.",
  field_es: "Una trampa de goteo sin un punto de remoción accesible se convierte en un callejón sin salida de mantenimiento — confirme que la ubicación de la trampa permita acceso de servicio antes de que la tubería quede encerrada."
},
{
  id: "dry-cleaning-systems",
  cat: "General",
  term_en: "Dry Cleaning Systems (Types I-V)",
  def_en: "Classified by solvent flammability: Type I uses Class I flammable liquid solvents; Type II uses Class II combustible solvents; Type III uses Class III combustible solvents; Types IV and V use Class IV nonflammable liquid solvents.",
  field_en: "The dry cleaning system type — driven entirely by the solvent's flash point classification — determines the ventilation, fire protection, and equipment room requirements; confirm the actual solvent in use, not just the equipment model name.",
  term_es: "Sistemas de Limpieza en Seco (Tipos I-V)",
  def_es: "Clasificados por la inflamabilidad del solvente: Tipo I usa solventes líquidos inflamables Clase I; Tipo II usa solventes combustibles Clase II; Tipo III usa solventes combustibles Clase III; Tipos IV y V usan solventes líquidos no inflamables Clase IV.",
  field_es: "El tipo de sistema de limpieza en seco — determinado enteramente por la clasificación de punto de inflamación del solvente — determina los requisitos de ventilación, protección contra incendios y cuarto de equipo; confirme el solvente realmente en uso, no solo el nombre del modelo del equipo."
},
{
  id: "duct",
  cat: "Air Systems & Ventilation",
  term_en: "Duct / Duct System",
  def_en: "Duct: a tube or conduit used to convey air (self-contained system air passages are not considered ducts). Duct System: the continuous air passageway that includes ducts plus duct fittings, dampers, plenums, fans, and accessory air-handling equipment.",
  field_en: "\"Duct\" and \"plenum\" are not interchangeable on a submittal — a return-air ceiling cavity labeled as a duct instead of a plenum can misapply material and rating requirements meant for the other classification.",
  term_es: "Ducto / Sistema de Ductos",
  def_es: "Ducto: un tubo o conducto usado para transportar aire (los pasos de aire de sistemas autónomos no se consideran ductos). Sistema de Ductos: el paso de aire continuo que incluye ductos más accesorios de ductos, compuertas, plenos, ventiladores y equipo auxiliar de manejo de aire.",
  field_es: "\"Ducto\" y \"plenum\" no son intercambiables en una presentación — una cavidad de cielo raso de retorno de aire etiquetada como ducto en lugar de plenum puede aplicar incorrectamente los requisitos de material y clasificación destinados a la otra clasificación."
},
{
  id: "duct-furnace",
  cat: "Air Systems & Ventilation",
  term_en: "Duct Furnace",
  def_en: "A warm-air furnace normally installed in an air distribution duct to supply heated air, relying on a blower not furnished as part of the furnace itself for air circulation.",
  field_en: "Because the duct furnace depends on an external blower, confirm the air-handling unit's airflow and static pressure actually match the furnace manufacturer's requirements — a mismatch here is a common commissioning failure.",
  term_es: "Horno de Ducto",
  def_es: "Un horno de aire caliente normalmente instalado en un ducto de distribución de aire para suministrar aire calentado, dependiendo de un soplador no suministrado como parte del horno mismo para la circulación de aire.",
  field_es: "Debido a que el horno de ducto depende de un soplador externo, confirme que el caudal de aire y la presión estática de la unidad manejadora realmente coincidan con los requisitos del fabricante del horno — un desajuste aquí es una falla común de puesta en marcha."
},
{
  id: "ductless-mini-split",
  cat: "Refrigeration & Cooling",
  term_en: "Ductless Mini-Split System",
  def_en: "A heating and cooling system with one or more indoor evaporator/air-handling units connected to an outdoor condensing unit by refrigerant piping and electrical wiring, capable of conditioning one or more rooms without ductwork.",
  field_en: "Mini-split refrigerant line sets have their own routing, penetration, and concealment rules separate from ductwork — don't apply duct-system submittal checklists to a mini-split scope by default.",
  term_es: "Sistema Ductless Mini-Split",
  def_es: "Un sistema de calefacción y enfriamiento con una o más unidades interiores evaporadoras/manejadoras conectadas a una unidad condensadora exterior mediante tubería de refrigerante y cableado eléctrico, capaz de acondicionar uno o más cuartos sin ductos.",
  field_es: "Las líneas de refrigerante de los mini-split tienen sus propias reglas de ruteo, penetración y ocultamiento separadas de los ductos — no aplique las listas de verificación de presentación de sistemas de ductos a un alcance de mini-split por defecto."
},
{
  id: "dwelling",
  cat: "General",
  term_en: "Dwelling / Dwelling Unit",
  def_en: "Dwelling: a building or portion containing not more than two dwelling units. Dwelling Unit: a single unit providing complete, independent living facilities, including permanent provisions for living, sleeping, eating, cooking, and sanitation.",
  field_en: "Occupancy classification as a dwelling unit changes which mechanical code provisions apply (ventilation rates, appliance clearances, exhaust requirements) compared to a commercial or institutional space — confirm the classification before applying residential-scale mechanical rules to a mixed-use project.",
  term_es: "Vivienda / Unidad de Vivienda",
  def_es: "Vivienda: un edificio o parte que contiene no más de dos unidades de vivienda. Unidad de Vivienda: una unidad única que proporciona instalaciones de vida independientes completas, incluyendo provisiones permanentes para vivir, dormir, comer, cocinar y saneamiento.",
  field_es: "La clasificación de ocupación como unidad de vivienda cambia qué disposiciones del código mecánico aplican (tasas de ventilación, separaciones de aparatos, requisitos de extracción) comparado con un espacio comercial o institucional — confirme la clasificación antes de aplicar reglas mecánicas de escala residencial a un proyecto de uso mixto."
},
{
  id: "electric-heating-appliance",
  cat: "Appliances & Combustion",
  term_en: "Electric Heating Appliance",
  def_en: "An appliance that produces heat energy by applying electric power to resistance elements, refrigerant compressors, or dissimilar-material junctions.",
  field_en: "Because electric heating appliances have no combustion products, several combustion-air and venting requirements that apply to fuel-fired appliances simply don't apply — but electrical load, disconnect, and clearance-to-combustible requirements still do.",
  term_es: "Aparato de Calefacción Eléctrico",
  def_es: "Un aparato que produce energía calorífica aplicando energía eléctrica a elementos resistivos, compresores de refrigerante, o uniones de materiales distintos.",
  field_es: "Debido a que los aparatos de calefacción eléctricos no tienen productos de combustión, varios requisitos de aire de combustión y venteo que aplican a aparatos de combustible simplemente no aplican — pero los requisitos de carga eléctrica, desconexión y separación a combustibles sí aplican."
},
{
  id: "energy-recovery-ventilation",
  cat: "Air Systems & Ventilation",
  term_en: "Energy Recovery Ventilation System",
  def_en: "A system using air-to-air heat exchangers to recover energy from, or reject energy to, exhaust air, in order to precondition (preheat, precool, humidify, or dehumidify) incoming outdoor ventilation air.",
  field_en: "ERV/HRV units transfer energy between two airstreams that must stay physically separated — a cross-contamination leak between the exhaust and supply sides is a common commissioning finding worth verifying during startup, not just trusting the manufacturer's rated leakage class.",
  term_es: "Sistema de Ventilación con Recuperación de Energía",
  def_es: "Un sistema que usa intercambiadores de calor aire-aire para recuperar energía de, o rechazar energía hacia, el aire de extracción, con el fin de preacondicionar (precalentar, preenfriar, humidificar o deshumidificar) el aire de ventilación exterior entrante.",
  field_es: "Las unidades ERV/HRV transfieren energía entre dos corrientes de aire que deben permanecer físicamente separadas — una fuga de contaminación cruzada entre los lados de extracción y suministro es un hallazgo común de puesta en marcha que vale la pena verificar durante el arranque, no solo confiar en la clase de fuga nominal del fabricante."
},
{
  id: "environmental-air",
  cat: "Air Systems & Ventilation",
  term_en: "Environmental Air",
  def_en: "Air conveyed to or from occupied areas through ducts that are not part of the heating or air-conditioning system — such as human-usage ventilation, domestic kitchen range exhaust, bathroom exhaust, clothes dryer exhaust, and parking garage exhaust.",
  field_en: "Environmental air ducts often have different fire/smoke damper and material requirements than conditioned-air ducts — don't assume the same duct construction standard applies just because both run through the same ceiling space.",
  term_es: "Aire Ambiental",
  def_es: "Aire transportado hacia o desde áreas ocupadas a través de ductos que no son parte del sistema de calefacción o aire acondicionado — como ventilación de uso humano, extracción de estufa de cocina doméstica, extracción de baño, extracción de secadora de ropa, y extracción de estacionamiento.",
  field_es: "Los ductos de aire ambiental a menudo tienen requisitos diferentes de compuertas contra incendio/humo y de material que los ductos de aire acondicionado — no asuma que aplica el mismo estándar de construcción de ducto solo porque ambos corren por el mismo espacio de cielo raso."
},
{
  id: "equipment",
  cat: "General",
  term_en: "Equipment / Equipment, Existing",
  def_en: "Equipment: piping, ducts, vents, control devices, and other permanently installed system components (other than appliances) that control environmental conditions in a building. Equipment, Existing: any code-regulated equipment legally installed before the code's effective date, or for which a permit was already issued.",
  field_en: "\"Equipment\" and \"appliance\" trigger different installation sections in the IMC — an equipment schedule that labels a listed heating unit as \"equipment\" instead of \"appliance\" points the reviewer to the wrong compliance path.",
  term_es: "Equipo / Equipo Existente",
  def_es: "Equipo: tubería, ductos, venteos, dispositivos de control y otros componentes de sistema instalados permanentemente (distintos de aparatos) que controlan las condiciones ambientales de un edificio. Equipo Existente: cualquier equipo regulado por el código legalmente instalado antes de la fecha de vigencia del código, o para el cual ya se emitió un permiso.",
  field_es: "\"Equipo\" y \"aparato\" activan secciones de instalación diferentes en el IMC — una cédula de equipos que etiqueta una unidad de calefacción listada como \"equipo\" en lugar de \"aparato\" dirige al revisor hacia la ruta de cumplimiento equivocada."
},
{
  id: "evaporative-cooler",
  cat: "Refrigeration & Cooling",
  term_en: "Evaporative Cooler / Evaporative Cooling System",
  def_en: "Evaporative Cooler: a device that reduces the sensible heat of air by evaporating water into the airstream. Evaporative Cooling System: the equipment and appliances providing environmental cooling by an evaporative cooler, with the conditioned air distributed through ducts or plenums.",
  field_en: "Evaporative cooling water quality and blowdown/drain routing are frequently under-specified — confirm the drain connection and backflow protection are shown on the plumbing plans, not just assumed as part of the mechanical scope.",
  term_es: "Enfriador Evaporativo / Sistema de Enfriamiento Evaporativo",
  def_es: "Enfriador Evaporativo: un dispositivo que reduce el calor sensible del aire evaporando agua en la corriente de aire. Sistema de Enfriamiento Evaporativo: el equipo y los aparatos que proporcionan enfriamiento ambiental mediante un enfriador evaporativo, con el aire acondicionado distribuido a través de ductos o plenos.",
  field_es: "La calidad del agua de enfriamiento evaporativo y el ruteo de purga/drenaje frecuentemente están sub-especificados — confirme que la conexión de drenaje y la protección contra retroflujo estén mostradas en los planos de plomería, no solo asumidas como parte del alcance mecánico."
},
{
  id: "evaporator",
  cat: "Refrigeration & Cooling",
  term_en: "Evaporator",
  def_en: "The part of a refrigeration system where liquid refrigerant is vaporized to produce cooling.",
  field_en: "Evaporator coil placement and condensate drainage go hand in hand — confirm the condensate drain pan, trap, and routing are coordinated with the evaporator's actual mounting orientation before installation.",
  term_es: "Evaporador",
  def_es: "La parte de un sistema de refrigeración en la cual el refrigerante líquido se vaporiza para producir enfriamiento.",
  field_es: "La ubicación de la serpentina evaporadora y el drenaje de condensado van de la mano — confirme que la bandeja de drenaje de condensado, la trampa y el ruteo estén coordinados con la orientación de montaje real del evaporador antes de la instalación."
},
{
  id: "excess-air",
  cat: "Appliances & Combustion",
  term_en: "Excess Air",
  def_en: "Air supplied beyond the theoretical amount needed for complete combustion, provided to prevent formation of dangerous combustion byproducts.",
  field_en: "Combustion tuning that runs with too little excess air risks incomplete combustion and CO production; too much wastes efficiency — a combustion analysis at startup, not just a visual flame check, is the reliable way to confirm this is set correctly.",
  term_es: "Exceso de Aire",
  def_es: "Aire suministrado más allá de la cantidad teórica necesaria para la combustión completa, proporcionado para prevenir la formación de subproductos de combustión peligrosos.",
  field_es: "El ajuste de combustión que opera con muy poco exceso de aire arriesga combustión incompleta y producción de CO; demasiado desperdicia eficiencia — un análisis de combustión en el arranque, no solo una revisión visual de la flama, es la forma confiable de confirmar que esto está ajustado correctamente."
},
{
  id: "exfiltration",
  cat: "Air Systems & Ventilation",
  term_en: "Exfiltration",
  def_en: "Uncontrolled outward air leakage from conditioned spaces through unintentional openings, caused by wind, stack effect, or imbalances between supply and exhaust airflow.",
  field_en: "Chronic exfiltration usually points to a supply/exhaust airflow imbalance somewhere in the design — before chasing envelope air-sealing as the fix, verify the mechanical system's own supply-vs-exhaust balance first.",
  term_es: "Exfiltración",
  def_es: "Fuga de aire hacia el exterior no controlada desde espacios acondicionados a través de aberturas no intencionales, causada por viento, efecto chimenea, o desequilibrios entre los caudales de suministro y extracción.",
  field_es: "La exfiltración crónica usualmente indica un desequilibrio de caudal de suministro/extracción en algún punto del diseño — antes de perseguir el sellado de aire de la envolvente como solución, verifique primero el balance de suministro contra extracción del propio sistema mecánico."
},
{
  id: "exhaust-system",
  cat: "Air Systems & Ventilation",
  term_en: "Exhaust System",
  def_en: "An assembly of connected ducts, plenums, fittings, registers, grilles, and hoods through which air is conducted from a space and discharged to the outdoors.",
  field_en: "General exhaust systems and grease exhaust (commercial kitchen) systems have very different construction and fire-protection rules — confirm which category an exhaust run falls into before applying a generic exhaust duct spec.",
  term_es: "Sistema de Extracción",
  def_es: "Un conjunto de ductos, plenos, accesorios, rejillas y campanas conectados a través de los cuales se conduce aire desde un espacio y se descarga al exterior.",
  field_es: "Los sistemas de extracción general y los sistemas de extracción de grasa (cocina comercial) tienen reglas de construcción y protección contra incendios muy diferentes — confirme en qué categoría cae una corrida de extracción antes de aplicar una especificación genérica de ducto de extracción."
},
{
  id: "extra-heavy-duty-cooking",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Extra-Heavy-Duty Cooking Appliance",
  def_en: "Appliances using open-flame combustion of solid fuel at any time — such as wood or charcoal-fired equipment.",
  field_en: "This duty-load classification drives the required hood type, exhaust airflow rate, and fire-suppression coverage — confirm any solid-fuel equipment is scheduled and hooded at the extra-heavy-duty level, not the standard heavy-duty level.",
  term_es: "Aparato de Cocción de Servicio Extra Pesado",
  def_es: "Aparatos que usan combustión de llama abierta de combustible sólido en cualquier momento — como equipo alimentado por leña o carbón.",
  field_es: "Esta clasificación de carga de servicio determina el tipo de campana requerida, la tasa de caudal de extracción y la cobertura de supresión de incendios — confirme que cualquier equipo de combustible sólido esté programado y con campana al nivel de servicio extra pesado, no al nivel de servicio pesado estándar."
},
{
  id: "fire-damper",
  cat: "Venting & Chimneys",
  term_en: "Fire Damper",
  def_en: "A listed device installed in ducts and air transfer openings that closes automatically on heat detection, restricting flame passage. Classified static (shuts down on fire) or dynamic (rated to close under active airflow).",
  field_en: "A dynamic fire damper is tested and rated for closure while air is actively flowing; a static one is not — confirm which classification the schedule requires before substituting one for the other.",
  term_es: "Compuerta Contra Incendio",
  def_es: "Un dispositivo listado instalado en ductos y aberturas de transferencia de aire que se cierra automáticamente al detectar calor, restringiendo el paso de la flama. Clasificada como estática (se cierra ante incendio) o dinámica (clasificada para cerrar bajo flujo de aire activo).",
  field_es: "Una compuerta contra incendio dinámica está probada y clasificada para cerrarse mientras el aire fluye activamente; una estática no lo está — confirme qué clasificación requiere la cédula antes de sustituir una por otra."
},
{
  id: "fireplace",
  cat: "Venting & Chimneys",
  term_en: "Fireplace / Factory-Built Fireplace / Masonry Fireplace / Fireplace Stove",
  def_en: "Fireplace: an assembly with a hearth and noncombustible fire chamber, provided with a chimney, for solid fuels. Factory-Built: a listed and labeled fireplace/chimney system of factory-made components. Masonry: field-constructed of solid masonry, brick, stone, or concrete. Fireplace Stove: a free-standing, chimney-connected solid-fuel heater operable with the fire chamber doors open or closed.",
  field_en: "A factory-built fireplace must be installed strictly per its listing and manufacturer instructions — field modifications that would be routine on a masonry fireplace (clearance changes, hearth extensions) can void the listing on a factory-built unit.",
  term_es: "Chimenea / Chimenea Prefabricada / Chimenea de Mampostería / Estufa de Chimenea",
  def_es: "Chimenea: un ensamble con hogar y cámara de combustión no combustible, provisto de un conducto, para combustibles sólidos. Prefabricada: un sistema de chimenea/conducto listado y etiquetado de componentes fabricados en planta. De Mampostería: construida en campo con mampostería sólida, ladrillo, piedra o concreto. Estufa de Chimenea: un calentador de combustible sólido independiente, conectado a chimenea, operable con las puertas de la cámara de combustión abiertas o cerradas.",
  field_es: "Una chimenea prefabricada debe instalarse estrictamente según su listado e instrucciones del fabricante — modificaciones de campo que serían rutinarias en una chimenea de mampostería (cambios de separación, extensiones de hogar) pueden anular el listado en una unidad prefabricada."
},
{
  id: "flame-safeguard",
  cat: "Appliances & Combustion",
  term_en: "Flame Safeguard",
  def_en: "A device that automatically shuts off fuel supply to a burner or group of burners when the ignition means fails or flame failure occurs.",
  field_en: "Flame safeguard controls are life-safety devices on fuel-fired equipment — verify they're tested and functioning during commissioning, not just present on the equipment cut sheet.",
  term_es: "Salvaguarda de Flama",
  def_es: "Un dispositivo que corta automáticamente el suministro de combustible a un quemador o grupo de quemadores cuando falla el medio de ignición o ocurre falla de flama.",
  field_es: "Los controles de salvaguarda de flama son dispositivos de seguridad de vida en equipo de combustible — verifique que estén probados y funcionando durante la puesta en marcha, no solo presentes en la hoja de datos del equipo."
},
{
  id: "flame-spread-index",
  cat: "General",
  term_en: "Flame Spread Index",
  def_en: "The numerical value assigned to a material tested under ASTM E84 or UL 723, describing how quickly flame spreads across its surface.",
  field_en: "Duct liner, insulation, and plenum-space materials all carry flame spread index limits — confirm the actual product submittal data sheet shows a tested value at or below the code limit, not just a general \"low flame spread\" marketing claim.",
  term_es: "Índice de Propagación de Llama",
  def_es: "El valor numérico asignado a un material probado bajo ASTM E84 o UL 723, que describe qué tan rápido se propaga la llama sobre su superficie.",
  field_es: "El revestimiento de ductos, el aislamiento y los materiales de espacio plenum llevan límites de índice de propagación de llama — confirme que la hoja de datos de presentación del producto real muestre un valor probado igual o por debajo del límite del código, no solo una afirmación de mercadeo general de \"baja propagación de llama\"."
},
{
  id: "flammable-liquids",
  cat: "General",
  term_en: "Flammable Liquids (Class I: IA, IB, IC)",
  def_en: "Liquids with a flash point below 100°F (38°C) and vapor pressure not exceeding 40 psia at 100°F, classified: IA (flash point below 73°F, boiling below 100°F), IB (flash point below 73°F, boiling at/above 100°F), IC (flash point 73-100°F).",
  field_en: "Flammable liquid class drives storage quantity limits, ventilation, and equipment room classification — confirm the actual product safety data sheet flash point, not an assumed class, before finalizing storage room ventilation design.",
  term_es: "Líquidos Inflamables (Clase I: IA, IB, IC)",
  def_es: "Líquidos con punto de inflamación menor a 100°F (38°C) y presión de vapor que no excede 40 psia a 100°F, clasificados: IA (punto de inflamación menor a 73°F, ebullición menor a 100°F), IB (punto de inflamación menor a 73°F, ebullición igual o mayor a 100°F), IC (punto de inflamación 73-100°F).",
  field_es: "La clase de líquido inflamable determina los límites de cantidad de almacenamiento, ventilación y clasificación del cuarto de equipo — confirme el punto de inflamación real de la hoja de datos de seguridad del producto, no una clase asumida, antes de finalizar el diseño de ventilación del cuarto de almacenamiento."
},
{
  id: "flammable-vapor",
  cat: "General",
  term_en: "Flammable Vapor or Fumes",
  def_en: "A mixture of gases in air at concentrations at or above the lower flammability limit and at or below the upper flammability limit.",
  field_en: "This is the concentration band where ignition is actually possible — ventilation design for hazardous storage/use rooms is meant to keep concentrations below this range entirely, not just reduce them.",
  term_es: "Vapor o Humos Inflamables",
  def_es: "Una mezcla de gases en el aire a concentraciones iguales o mayores al límite inferior de inflamabilidad y iguales o menores al límite superior de inflamabilidad.",
  field_es: "Esta es la banda de concentración donde realmente es posible la ignición — el diseño de ventilación para cuartos de almacenamiento/uso peligroso está pensado para mantener las concentraciones completamente por debajo de este rango, no solo reducirlas."
},
{
  id: "flash-point",
  cat: "General",
  term_en: "Flash Point",
  def_en: "The minimum temperature, corrected to 14.7 psia, at which a test flame causes a sample's vapors to ignite under specified test conditions, per ASTM D56, D93, or D3278.",
  field_en: "Flash point is the single number that sorts a liquid into combustible or flammable classification (and which subclass) — always pull it from the actual product's safety data sheet, never estimate it from a similar-sounding product.",
  term_es: "Punto de Inflamación",
  def_es: "La temperatura mínima, corregida a 14.7 psia, a la cual una flama de prueba causa que los vapores de una muestra se enciendan bajo condiciones de prueba específicas, según ASTM D56, D93, o D3278.",
  field_es: "El punto de inflamación es el número único que clasifica un líquido como combustible o inflamable (y en qué subclase) — siempre obténgalo de la hoja de datos de seguridad del producto real, nunca lo estime a partir de un producto de nombre similar."
},
{
  id: "flexible-air-connector",
  cat: "Air Systems & Ventilation",
  term_en: "Flexible Air Connector",
  def_en: "A conduit for transferring air between a duct or plenum and an air terminal unit or inlet/outlet, limited in permitted use, length, and location.",
  field_en: "Flexible connectors have strict length limits (typically a few feet) and cannot be used to route air long distances — a flex run that's been stretched to reach a diffuser is a common field deficiency that reduces airflow and fails inspection.",
  term_es: "Conector Flexible de Aire",
  def_es: "Un conducto para transferir aire entre un ducto o plenum y una unidad terminal de aire o entrada/salida, limitado en uso permitido, longitud y ubicación.",
  field_es: "Los conectores flexibles tienen límites estrictos de longitud (típicamente unos pocos pies) y no pueden usarse para enrutar aire largas distancias — una corrida flexible que se ha estirado para alcanzar un difusor es una deficiencia de campo común que reduce el caudal y falla la inspección."
},
{
  id: "floor-area-net",
  cat: "General",
  term_en: "Floor Area, Net",
  def_en: "The actual occupied area, not including unoccupied accessory areas or the thickness of walls.",
  field_en: "Net floor area (not gross) is typically what drives ventilation rate calculations under IMC Chapter 4 — using gross area instead of net can meaningfully overstate or understate the required outdoor air rate.",
  term_es: "Área de Piso Neta",
  def_es: "El área realmente ocupada, sin incluir áreas accesorias no ocupadas ni el espesor de los muros.",
  field_es: "El área de piso neta (no bruta) es típicamente lo que determina los cálculos de tasa de ventilación bajo el Capítulo 4 del IMC — usar área bruta en lugar de neta puede sobreestimar o subestimar significativamente la tasa de aire exterior requerida."
},
{
  id: "floor-furnace",
  cat: "Appliances & Combustion",
  term_en: "Floor Furnace",
  def_en: "A completely self-contained furnace suspended from the floor of the space it heats, drawing combustion air from outside that space, with provisions for observing flames and lighting from the space.",
  field_en: "Floor furnaces have specific floor-opening and clearance-to-combustible rules distinct from other furnace types — verify the register/grille location doesn't create a trip hazard or block required clearances before finalizing floor plan coordination.",
  term_es: "Horno de Piso",
  def_es: "Un horno completamente autónomo suspendido del piso del espacio que calienta, tomando aire de combustión desde fuera de ese espacio, con provisiones para observar las flamas y encenderlo desde el espacio.",
  field_es: "Los hornos de piso tienen reglas específicas de abertura de piso y separación a combustibles distintas de otros tipos de horno — verifique que la ubicación de la rejilla/registro no cree un riesgo de tropiezo ni bloquee las separaciones requeridas antes de finalizar la coordinación del plano de piso."
},
{
  id: "flue",
  cat: "Venting & Chimneys",
  term_en: "Flue / Flue Connection / Flue Gases / Flue Liner",
  def_en: "Flue: the passageway within a chimney or vent through which combustion products pass. Flue Connection: the passage (breeching) conducting combustion products from an appliance to the vent or chimney. Flue Gases: products of combustion plus excess air. Flue Liner: the material forming a flue's inside surface, protecting the surrounding structure and conveying combustion products without leakage.",
  field_en: "A missing or deteriorated flue liner is one of the most common findings in existing-chimney inspections — confirm liner condition and continuity for any renovation project reusing an existing masonry chimney.",
  term_es: "Conducto / Conexión de Conducto / Gases de Conducto / Revestimiento de Conducto",
  def_es: "Conducto: el paso dentro de una chimenea o venteo por el cual pasan los productos de combustión. Conexión de Conducto: el paso (empalme) que conduce los productos de combustión desde un aparato hasta el venteo o chimenea. Gases de Conducto: productos de combustión más exceso de aire. Revestimiento de Conducto: el material que forma la superficie interior de un conducto, protegiendo la estructura circundante y transportando los productos de combustión sin fugas.",
  field_es: "Un revestimiento de conducto faltante o deteriorado es uno de los hallazgos más comunes en inspecciones de chimeneas existentes — confirme la condición y continuidad del revestimiento para cualquier proyecto de renovación que reutilice una chimenea de mampostería existente."
},
{
  id: "food-grade-fluid",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Food-Grade Fluid",
  def_en: "Potable water or a fluid containing additives listed under 21 CFR Parts 174-186 (FDA Food and Drugs regulations).",
  field_en: "Any heat-transfer fluid in a system with potential contact with a food-service process needs to be confirmed as food-grade — a non-food-grade fluid substitution in that scope is a health code violation, not just a mechanical one.",
  term_es: "Fluido de Grado Alimenticio",
  def_es: "Agua potable o un fluido que contiene aditivos listados bajo 21 CFR Partes 174-186 (regulaciones de Alimentos y Medicamentos de la FDA).",
  field_es: "Cualquier fluido de transferencia de calor en un sistema con contacto potencial con un proceso de servicio de alimentos necesita confirmarse como de grado alimenticio — una sustitución de fluido que no es de grado alimenticio en ese alcance es una violación de código de salud, no solo mecánica."
},
{
  id: "fuel-gas",
  cat: "Appliances & Combustion",
  term_en: "Fuel Gas",
  def_en: "Natural gas, manufactured gas, liquefied petroleum gas, or a mixture of these.",
  field_en: "Fuel gas type (natural gas vs. LP) changes orifice sizing, regulator settings, and piping sizing — an appliance shipped set up for the wrong gas type is one of the most common startup failures on a new installation.",
  term_es: "Gas Combustible",
  def_es: "Gas natural, gas manufacturado, gas licuado de petróleo, o una mezcla de estos.",
  field_es: "El tipo de gas combustible (gas natural vs. LP) cambia el tamaño del orificio, los ajustes del regulador y el dimensionamiento de la tubería — un aparato enviado configurado para el tipo de gas equivocado es una de las fallas de arranque más comunes en una instalación nueva."
},
{
  id: "fuel-oil",
  cat: "Appliances & Combustion",
  term_en: "Fuel Oil",
  def_en: "Kerosene or any hydrocarbon oil with a flash point not less than 100°F (38°C).",
  field_en: "Fuel oil storage and piping carry different code requirements than fuel gas — a mechanical scope that assumes gas-fired equipment when the actual fuel is oil will miss the tank, piping, and spill-containment requirements entirely.",
  term_es: "Combustible Diesel/Fuel Oil",
  def_es: "Queroseno o cualquier aceite de hidrocarburo con un punto de inflamación no menor a 100°F (38°C).",
  field_es: "El almacenamiento y tubería de fuel oil llevan requisitos de código diferentes a los del gas combustible — un alcance mecánico que asume equipo a gas cuando el combustible real es aceite pasará por alto completamente los requisitos de tanque, tubería y contención de derrames."
},
{
  id: "fuel-oil-piping-system",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Fuel-Oil Piping System",
  def_en: "A closed piping system connecting a combustible liquid supply source to a fuel-oil-burning appliance.",
  field_en: "Fuel-oil piping needs leak detection, secondary containment, or specific material provisions depending on whether it's above- or below-grade — confirm which condition applies before specifying standard black-iron piping throughout.",
  term_es: "Sistema de Tubería de Fuel Oil",
  def_es: "Un sistema de tubería cerrado que conecta una fuente de suministro de líquido combustible a un aparato quemador de fuel oil.",
  field_es: "La tubería de fuel oil necesita detección de fugas, contención secundaria, o disposiciones de material específicas dependiendo de si está sobre o bajo nivel — confirme qué condición aplica antes de especificar tubería de hierro negro estándar en toda la corrida."
},
{
  id: "furnace",
  cat: "Appliances & Combustion",
  term_en: "Furnace / Furnace Room",
  def_en: "Furnace: a completely self-contained heating unit designed to supply heated air to spaces remote from or adjacent to its location. Furnace Room: a room primarily used to house fuel-burning, space-heating, and water-heating appliances (other than boilers).",
  field_en: "Furnace room combustion air, clearance, and fire-rating requirements scale with the total fuel input of everything installed in the room — a furnace room sized for one appliance that later gets a second appliance added often no longer meets combustion air requirements.",
  term_es: "Horno / Cuarto de Hornos",
  def_es: "Horno: una unidad de calefacción completamente autónoma diseñada para suministrar aire calentado a espacios remotos o adyacentes a su ubicación. Cuarto de Hornos: un cuarto usado principalmente para alojar aparatos de combustible, calefacción de espacio y calentamiento de agua (distintos de calderas).",
  field_es: "Los requisitos de aire de combustión, separación y clasificación contra incendio de un cuarto de hornos escalan con la entrada total de combustible de todo lo instalado en el cuarto — un cuarto de hornos dimensionado para un aparato al que luego se le agrega un segundo aparato frecuentemente ya no cumple los requisitos de aire de combustión."
},
{
  id: "fusible-plug",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Fusible Plug",
  def_en: "A device arranged to relieve pressure by operation of a fusible member at a predetermined temperature.",
  field_en: "Fusible plugs are a temperature-triggered, one-time-use safety device — unlike a pressure relief valve, a tripped fusible plug must be replaced, not reset, before the vessel returns to service.",
  term_es: "Tapón Fusible",
  def_es: "Un dispositivo dispuesto para aliviar presión mediante la operación de un elemento fusible a una temperatura predeterminada.",
  field_es: "Los tapones fusibles son un dispositivo de seguridad activado por temperatura y de un solo uso — a diferencia de una válvula de alivio de presión, un tapón fusible activado debe reemplazarse, no reiniciarse, antes de que el recipiente vuelva a servicio."
},
{
  id: "grease-duct",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Grease Duct",
  def_en: "A duct serving a Type I hood, or cooking appliances with integral downdraft exhaust, that conveys grease-laden air from the hood or appliance directly to the outdoors.",
  field_en: "Grease duct construction (welded seams, clearances, access panels, fire-rated enclosure where required) is one of the most heavily inspected mechanical scopes on a commercial kitchen project — confirm the duct fabricator's shop drawings match the listed hood's actual exhaust requirements before fabrication.",
  term_es: "Ducto de Grasa",
  def_es: "Un ducto que sirve a una campana Tipo I, o aparatos de cocción con extracción integral de tiro descendente, que transporta aire cargado de grasa desde la campana o aparato directamente al exterior.",
  field_es: "La construcción del ducto de grasa (costuras soldadas, separaciones, paneles de acceso, envolvente clasificada contra incendio donde se requiera) es uno de los alcances mecánicos más inspeccionados en un proyecto de cocina comercial — confirme que los planos de taller del fabricante del ducto coincidan con los requisitos de extracción reales de la campana listada antes de la fabricación."
},
{
  id: "ground-source-heat-pump-loop",
  cat: "Refrigeration & Cooling",
  term_en: "Ground Source Heat Pump Loop System",
  def_en: "Piping buried in horizontal or vertical excavations, or placed in a body of water, that transports heat-transfer liquid to and from a heat pump. Closed-loop systems recirculate the liquid; open-loop systems draw liquid from a well or other source.",
  field_en: "Closed-loop and open-loop geothermal systems have very different water-quality, permitting, and discharge considerations — confirm which configuration is actually specified before assuming well-water availability or discharge permits are in place.",
  term_es: "Sistema de Circuito de Bomba de Calor Geotérmica",
  def_es: "Tubería enterrada en excavaciones horizontales o verticales, o colocada en un cuerpo de agua, que transporta líquido de transferencia de calor hacia y desde una bomba de calor. Los sistemas de circuito cerrado recirculan el líquido; los sistemas de circuito abierto extraen líquido de un pozo u otra fuente.",
  field_es: "Los sistemas geotérmicos de circuito cerrado y circuito abierto tienen consideraciones muy diferentes de calidad de agua, permisos y descarga — confirme qué configuración está realmente especificada antes de asumir que hay disponibilidad de agua de pozo o permisos de descarga vigentes."
},
{
  id: "gypsum-board",
  cat: "General",
  term_en: "Gypsum Board / Gypsum Wallboard",
  def_en: "Gypsum Board: a panel product with a noncombustible gypsum core and paper surfacing. Gypsum Wallboard: gypsum board used primarily as interior surfacing for building structures.",
  field_en: "Gypsum board thickness and type (Type X, moisture-resistant, etc.) are frequently part of a mechanical room or shaft's fire-rating assembly — confirm the mechanical scope isn't cutting oversized penetrations that compromise the rated assembly's tested configuration.",
  term_es: "Tablero de Yeso / Tablero de Yeso para Muros",
  def_es: "Tablero de Yeso: un producto de panel con núcleo de yeso no combustible y superficie de papel. Tablero de Yeso para Muros: tablero de yeso usado principalmente como superficie interior para estructuras de edificios.",
  field_es: "El espesor y tipo de tablero de yeso (Tipo X, resistente a la humedad, etc.) frecuentemente son parte del ensamble de clasificación contra incendio de un cuarto de máquinas o hueco — confirme que el alcance mecánico no esté cortando penetraciones sobredimensionadas que comprometan la configuración probada del ensamble clasificado."
}
,
{
  id: "gas-convenience-outlet",
  cat: "General",
  term_en: "Gas Convenience Outlet",
  def_en: "A permanently mounted, manually operated device that provides a means for connecting and disconnecting an appliance or an appliance connector to a gas supply piping system.",
  field_en: "A convenience outlet must have its own shutoff and cannot be left uncapped when not connected to an appliance — an open, unused outlet is a common inspection deficiency.",
  term_es: "Salida de Conveniencia de Gas",
  def_es: "Un dispositivo montado permanentemente y operado manualmente que proporciona un medio para conectar y desconectar un aparato o un conector de aparato a un sistema de tubería de suministro de gas.",
  field_es: "Una salida de conveniencia debe tener su propia válvula de cierre y no puede dejarse sin tapa cuando no está conectada a un aparato — una salida abierta y sin uso es una deficiencia de inspección común."
},
{
  id: "gas-piping",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Gas Piping",
  def_en: "An installation of pipe, valves, or fittings used to convey fuel gas, but not including the piping within an appliance.",
  field_en: "Gas piping sizing depends on total connected load, pipe length, and allowable pressure drop — confirm the sizing calculation accounts for every appliance actually connected, including any added after initial design.",
  term_es: "Tubería de Gas",
  def_es: "Una instalación de tubo, válvulas o accesorios usada para transportar gas combustible, sin incluir la tubería dentro de un aparato.",
  field_es: "El dimensionamiento de la tubería de gas depende de la carga total conectada, la longitud de la tubería y la caída de presión permitida — confirme que el cálculo de dimensionamiento contemple cada aparato realmente conectado, incluyendo cualquiera agregado después del diseño inicial."
},
{
  id: "gas-pressure-regulator",
  cat: "Appliances & Combustion",
  term_en: "Gas Pressure Regulator",
  def_en: "A device that reduces, controls, and maintains the pressure of gas downstream of the device at a value lower than the supply pressure.",
  field_en: "A regulator's vent (where required) must terminate outdoors and stay clear of building openings — a blocked or missing regulator vent is a serious field deficiency, not a cosmetic one.",
  term_es: "Regulador de Presión de Gas",
  def_es: "Un dispositivo que reduce, controla y mantiene la presión del gas aguas abajo del dispositivo a un valor menor que la presión de suministro.",
  field_es: "El venteo de un regulador (donde se requiera) debe terminar al exterior y mantenerse alejado de aberturas del edificio — un venteo de regulador bloqueado o faltante es una deficiencia de campo grave, no cosmética."
},
{
  id: "gas-utilization-equipment",
  cat: "Appliances & Combustion",
  term_en: "Gas Utilization Equipment",
  def_en: "Equipment or an appliance that uses gas as a fuel or raw material to produce light, heat, power, refrigeration, or air conditioning.",
  field_en: "This broad classification captures process equipment as well as space-conditioning appliances — confirm which specific listing and installation standard applies to the actual equipment, since \"gas utilization equipment\" alone doesn't point to a single code section.",
  term_es: "Equipo de Utilización de Gas",
  def_es: "Equipo o un aparato que usa gas como combustible o materia prima para producir luz, calor, potencia, refrigeración o aire acondicionado.",
  field_es: "Esta clasificación amplia abarca tanto equipo de proceso como aparatos de acondicionamiento de espacio — confirme qué listado y norma de instalación específicos aplican al equipo real, ya que \"equipo de utilización de gas\" por sí solo no señala una sola sección de código."
},
{
  id: "grade",
  cat: "General",
  term_en: "Grade",
  def_en: "The finished ground level adjoining a building at all exterior walls.",
  field_en: "Clearance-to-grade dimensions for equipment, vent terminations, and combustion air openings are measured from finished grade, not from the grade at time of rough-in — confirm final landscaping/hardscape plans before locking in equipment elevations.",
  term_es: "Nivel de Terreno (Grade)",
  def_es: "El nivel de terreno terminado que colinda con un edificio en todos los muros exteriores.",
  field_es: "Las dimensiones de separación al nivel de terreno para equipo, terminaciones de venteo y aberturas de aire de combustión se miden desde el nivel de terreno terminado, no desde el nivel en la etapa de obra gris — confirme los planos finales de paisajismo/superficies duras antes de fijar las elevaciones del equipo."
},
{
  id: "grade-plane",
  cat: "General",
  term_en: "Grade Plane",
  def_en: "A reference plane representing the average finished ground level adjoining a building at all exterior walls, established per the applicable building code where required.",
  field_en: "Grade plane (an averaged reference) and grade (the actual finished ground level at a specific point) are not interchangeable — a site with significant slope needs the grade plane calculation confirmed with the structural/civil documents, not assumed from a single spot elevation.",
  term_es: "Plano de Nivel de Terreno (Grade Plane)",
  def_es: "Un plano de referencia que representa el nivel de terreno terminado promedio que colinda con un edificio en todos los muros exteriores, establecido según el código de construcción aplicable cuando se requiera.",
  field_es: "El plano de nivel de terreno (una referencia promediada) y el nivel de terreno (el nivel de terreno terminado real en un punto específico) no son intercambiables — un sitio con pendiente significativa necesita que el cálculo del plano de nivel de terreno se confirme con los documentos estructurales/civiles, no asumirse de una sola elevación puntual."
},
{
  id: "grease-duct-system",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Grease Duct System",
  def_en: "A grease duct, including all fittings, transitions, access panels, and appurtenances, extending from a hood's collar to the exhaust fan or termination point.",
  field_en: "Every joint, fitting, and access panel in the grease duct system falls under the same welded/liquid-tight and clearance requirements as the duct itself — confirm shop drawings show the complete system, not just straight duct runs.",
  term_es: "Sistema de Ducto de Grasa",
  def_es: "Un ducto de grasa, incluyendo todos los accesorios, transiciones, paneles de acceso y aditamentos, que se extiende desde el cuello de una campana hasta el ventilador de extracción o el punto de terminación.",
  field_es: "Cada junta, accesorio y panel de acceso en el sistema de ducto de grasa cae bajo los mismos requisitos de soldadura/hermeticidad y separación que el ducto mismo — confirme que los planos de taller muestren el sistema completo, no solo corridas rectas de ducto."
},
{
  id: "grease-removal-device",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Grease Removal Device, Listed",
  def_en: "A device listed for reducing grease carryover, typically installed in the duct or plenum ahead of the exhaust fan.",
  field_en: "A listed grease removal device can, in some code paths, reduce required grease duct enclosure clearances — but only when installed and maintained exactly per its listing; confirm this before relying on it to relax a clearance elsewhere in the design.",
  term_es: "Dispositivo Listado de Remoción de Grasa",
  def_es: "Un dispositivo listado para reducir el arrastre de grasa, típicamente instalado en el ducto o plenum antes del ventilador de extracción.",
  field_es: "Un dispositivo listado de remoción de grasa puede, en algunas rutas de código, reducir las separaciones de envolvente requeridas para el ducto de grasa — pero solo cuando se instala y mantiene exactamente según su listado; confirme esto antes de depender de él para relajar una separación en otra parte del diseño."
},
{
  id: "grease-reservoir",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Grease Reservoir",
  def_en: "A device or system designed to collect grease at a hood, grease removal device, or exhaust duct termination.",
  field_en: "Grease reservoirs need a routine cleaning schedule — an overflowing or neglected reservoir is a fire-load and cross-contamination problem that shows up quickly in health and fire inspections.",
  term_es: "Reservorio de Grasa",
  def_es: "Un dispositivo o sistema diseñado para recolectar grasa en una campana, dispositivo de remoción de grasa, o terminación de ducto de extracción.",
  field_es: "Los reservorios de grasa necesitan un programa de limpieza rutinario — un reservorio desbordado o descuidado es un problema de carga de fuego y contaminación cruzada que aparece rápidamente en inspecciones de salud y de bomberos."
},
{
  id: "hazardous-location",
  cat: "General",
  term_en: "Hazardous Location",
  def_en: "A location where fire or explosion hazards may exist due to flammable gases, vapors, liquids, combustible dusts, or fibers being present, or likely to be present, in quantities sufficient to produce ignitable mixtures.",
  field_en: "Equipment installed in a hazardous location needs an electrical/mechanical classification (not just a general listing) matched to the specific hazard class and division present — treating a hazardous location as a standard mechanical room is a serious life-safety miss.",
  term_es: "Ubicación Peligrosa",
  def_es: "Una ubicación donde pueden existir riesgos de incendio o explosión debido a la presencia, o probable presencia, de gases inflamables, vapores, líquidos, polvos combustibles o fibras en cantidades suficientes para producir mezclas ignitables.",
  field_es: "El equipo instalado en una ubicación peligrosa necesita una clasificación eléctrica/mecánica (no solo un listado general) que coincida con la clase y división de riesgo específica presente — tratar una ubicación peligrosa como un cuarto mecánico estándar es un descuido grave de seguridad de vida."
},
{
  id: "header",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Header",
  def_en: "A pipe or manifold to which two or more branch pipes are connected, typically distributing flow from a single source to multiple circuits or collecting flow from multiple circuits into one.",
  field_en: "Header sizing controls flow balance across every branch it feeds — an undersized header is a common root cause of uneven hydronic or piping performance across a multi-zone system, even when each individual branch is correctly sized.",
  term_es: "Colector (Header)",
  def_es: "Una tubería o múltiple a la cual se conectan dos o más tuberías ramales, típicamente distribuyendo flujo desde una fuente única hacia múltiples circuitos o recolectando flujo de múltiples circuitos en uno.",
  field_es: "El dimensionamiento del colector controla el balance de flujo en cada ramal que alimenta — un colector subdimensionado es una causa raíz común de desempeño hidrónico o de tubería desigual en un sistema multi-zona, incluso cuando cada ramal individual está correctamente dimensionado."
},
{
  id: "heat-exchanger",
  cat: "General",
  term_en: "Heat Exchanger",
  def_en: "A device manufactured for transferring heat between two physically separated fluids or between a fluid and a heat-producing element, without direct mixing of the media.",
  field_en: "A cracked or leaking heat exchanger that allows combustion products to mix with circulated air is a life-safety emergency, not a routine repair item — this is a top-priority inspection point on any furnace or boiler service call.",
  term_es: "Intercambiador de Calor",
  def_es: "Un dispositivo fabricado para transferir calor entre dos fluidos físicamente separados o entre un fluido y un elemento que produce calor, sin mezcla directa de los medios.",
  field_es: "Un intercambiador de calor agrietado o con fuga que permite que los productos de combustión se mezclen con el aire circulado es una emergencia de seguridad de vida, no un artículo de reparación rutinaria — este es un punto de inspección de máxima prioridad en cualquier servicio de horno o caldera."
},
{
  id: "heat-pump",
  cat: "Refrigeration & Cooling",
  term_en: "Heat Pump",
  def_en: "A refrigeration system able to transfer heat into or out of a space or process, by reversing the refrigeration cycle to provide either heating or cooling.",
  field_en: "A heat pump's rated heating capacity drops as outdoor temperature drops — confirm the equipment's capacity at the actual regional design temperature, not just its nameplate rating at standard test conditions, before sizing supplemental heat.",
  term_es: "Bomba de Calor",
  def_es: "Un sistema de refrigeración capaz de transferir calor hacia dentro o fuera de un espacio o proceso, invirtiendo el ciclo de refrigeración para proporcionar calefacción o enfriamiento.",
  field_es: "La capacidad de calefacción nominal de una bomba de calor disminuye al bajar la temperatura exterior — confirme la capacidad del equipo a la temperatura de diseño regional real, no solo su capacidad de placa a condiciones de prueba estándar, antes de dimensionar el calor suplementario."
},
{
  id: "heating-and-cooling-system",
  cat: "General",
  term_en: "Heating and Cooling System",
  def_en: "The equipment, distribution system, and terminal units that provide either collectively or individually the process of heating or cooling a building.",
  field_en: "Treating heating and cooling as one integrated system (not two independently designed scopes) is what catches shared-ductwork or shared-controls conflicts before installation instead of during commissioning.",
  term_es: "Sistema de Calefacción y Enfriamiento",
  def_es: "El equipo, sistema de distribución y unidades terminales que proporcionan, colectiva o individualmente, el proceso de calentar o enfriar un edificio.",
  field_es: "Tratar la calefacción y el enfriamiento como un sistema integrado (no dos alcances diseñados independientemente) es lo que detecta conflictos de ductería o controles compartidos antes de la instalación en lugar de durante la puesta en marcha."
},
{
  id: "high-probability-refrigerant-system",
  cat: "Refrigeration & Cooling",
  term_en: "High-Probability System",
  def_en: "A refrigeration system in which a failure of a refrigerant-containing part that is either in contact with, forms part of, or is exposed to an occupied space, would allow refrigerant to enter that space.",
  field_en: "High-probability system classification (versus low-probability) tightens refrigerant quantity limits and ventilation requirements for the space — a system reclassified during a scope change can silently push a room past its allowable refrigerant charge.",
  term_es: "Sistema de Alta Probabilidad",
  def_es: "Un sistema de refrigeración en el cual una falla de una parte que contiene refrigerante, que está en contacto con, forma parte de, o está expuesta a un espacio ocupado, permitiría que el refrigerante entre a ese espacio.",
  field_es: "La clasificación de sistema de alta probabilidad (frente a baja probabilidad) endurece los límites de cantidad de refrigerante y los requisitos de ventilación del espacio — un sistema reclasificado durante un cambio de alcance puede empujar silenciosamente un cuarto más allá de su carga de refrigerante permitida."
},
{
  id: "hood-type-i",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Hood, Type I",
  def_en: "A kitchen hood for collecting and removing grease-laden vapors and smoke, required over appliances that produce grease-laden vapors from griddling, frying, broiling, or similar processes.",
  field_en: "Type I hood coverage and capture velocity are engineered to the specific appliances beneath it — swapping a hood-covered appliance lineup after the hood is designed and installed is one of the most common commercial kitchen compliance failures.",
  term_es: "Campana, Tipo I",
  def_es: "Una campana de cocina para recolectar y remover vapores cargados de grasa y humo, requerida sobre aparatos que producen vapores cargados de grasa por procesos de planchado, freído, asado o similares.",
  field_es: "La cobertura y velocidad de captura de una campana Tipo I están diseñadas para los aparatos específicos debajo de ella — cambiar la línea de aparatos cubiertos por la campana después de que ésta ha sido diseñada e instalada es una de las fallas de cumplimiento más comunes en cocinas comerciales."
},
{
  id: "hood-type-ii",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Hood, Type II",
  def_en: "A hood for collecting and removing steam, vapor, heat, or odors, not required to meet grease-hood construction standards, used over appliances that don't produce grease-laden vapors (dishwashers, steamers, ovens without grease-producing cooking).",
  field_en: "A Type II hood cannot be substituted for a Type I hood over grease-producing equipment just because it's physically present — confirm the actual cooking process under a hood before relying on its listing.",
  term_es: "Campana, Tipo II",
  def_es: "Una campana para recolectar y remover vapor, calor u olores, que no está obligada a cumplir las normas de construcción de campanas de grasa, usada sobre aparatos que no producen vapores cargados de grasa (lavaplatos, vaporeras, hornos sin cocción que produzca grasa).",
  field_es: "Una campana Tipo II no puede sustituir a una campana Tipo I sobre equipo que produce grasa solo porque está físicamente presente — confirme el proceso de cocción real bajo una campana antes de depender de su listado."
},
{
  id: "hot-water-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Hot Water Boiler",
  def_en: "A closed vessel in which water is heated for uses other than potable water heating, by the combustion of fuel or by electric heating elements.",
  field_en: "Hot water (hydronic) boilers and potable water heaters are governed by different code paths even when the equipment looks similar — confirm the actual intended use before applying the wrong installation standard.",
  term_es: "Caldera de Agua Caliente",
  def_es: "Un recipiente cerrado en el cual se calienta agua para usos distintos al calentamiento de agua potable, mediante la combustión de combustible o mediante elementos de calefacción eléctrica.",
  field_es: "Las calderas de agua caliente (hidrónicas) y los calentadores de agua potable se rigen por rutas de código distintas aunque el equipo se vea similar — confirme el uso previsto real antes de aplicar la norma de instalación equivocada."
},
{
  id: "humidifier",
  cat: "Air Systems & Ventilation",
  term_en: "Humidifier",
  def_en: "A device or assembly used to add moisture to air.",
  field_en: "Humidifiers add a maintenance and microbial-growth risk to a duct system if not properly drained and serviced — confirm the drain and scale-management provisions are part of the installation scope, not an afterthought.",
  term_es: "Humidificador",
  def_es: "Un dispositivo o ensamble usado para agregar humedad al aire.",
  field_es: "Los humidificadores agregan un riesgo de mantenimiento y crecimiento microbiano a un sistema de ductos si no se drenan y dan servicio adecuadamente — confirme que las provisiones de drenaje y manejo de sarro sean parte del alcance de instalación, no una idea tardía."
},
{
  id: "hydronic-piping",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Hydronic Piping",
  def_en: "Piping used to convey liquid used for heat transfer in heating or cooling systems.",
  field_en: "Hydronic piping material and pressure/temperature ratings must match the actual system design conditions, including any glycol additive's effect on flow and heat transfer — verify against the actual specified fluid, not just water.",
  term_es: "Tubería Hidrónica",
  def_es: "Tubería usada para transportar líquido usado para transferencia de calor en sistemas de calefacción o enfriamiento.",
  field_es: "El material y las clasificaciones de presión/temperatura de la tubería hidrónica deben coincidir con las condiciones de diseño reales del sistema, incluyendo el efecto de cualquier aditivo de glicol sobre el flujo y la transferencia de calor — verifique contra el fluido realmente especificado, no solo agua."
},
{
  id: "ignition-source",
  cat: "Appliances & Combustion",
  term_en: "Ignition Source",
  def_en: "A flame, spark, or hot surface capable of igniting flammable vapors or fumes.",
  field_en: "Equipment with a potential ignition source (pilot light, relay contact, motor) needs specific clearance from any area where flammable vapors could accumulate — this drives much of the equipment room location logic in hazardous-use occupancies.",
  term_es: "Fuente de Ignición",
  def_es: "Una flama, chispa, o superficie caliente capaz de encender vapores o humos inflamables.",
  field_es: "El equipo con una fuente de ignición potencial (piloto, contacto de relevador, motor) necesita una separación específica de cualquier área donde puedan acumularse vapores inflamables — esto determina gran parte de la lógica de ubicación del cuarto de equipo en ocupaciones de uso peligroso."
},
{
  id: "indirect-refrigeration-system",
  cat: "Refrigeration & Cooling",
  term_en: "Indirect Refrigeration System",
  def_en: "A system in which a secondary coolant, cooled or heated by the refrigerant, is circulated to the space or process being cooled or heated, keeping the refrigerant itself out of the occupied space.",
  field_en: "Indirect systems trade refrigerant-in-occupied-space risk for a secondary loop that needs its own fluid, freeze, and leak-monitoring plan — confirm which risk the design is actually managing before assuming \"indirect\" means no further review is needed.",
  term_es: "Sistema de Refrigeración Indirecto",
  def_es: "Un sistema en el cual un refrigerante secundario, enfriado o calentado por el refrigerante principal, se circula hacia el espacio o proceso que se enfría o calienta, manteniendo el refrigerante mismo fuera del espacio ocupado.",
  field_es: "Los sistemas indirectos cambian el riesgo de refrigerante en espacio ocupado por un circuito secundario que necesita su propio plan de fluido, congelamiento y monitoreo de fugas — confirme qué riesgo está realmente gestionando el diseño antes de asumir que \"indirecto\" significa que no se necesita más revisión."
},
{
  id: "indirect-waste-pipe",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Indirect Waste Pipe",
  def_en: "A waste pipe (such as a condensate line) that does not connect directly to the sanitary drainage system, instead discharging through an air gap into a trapped fixture, receptor, or equivalent.",
  field_en: "Condensate lines routed as indirect waste need a verified air gap or approved receptor — a direct tie-in to the sanitary line bypasses the cross-connection protection this classification exists to provide.",
  term_es: "Tubería de Desagüe Indirecto",
  def_es: "Una tubería de desagüe (como una línea de condensado) que no se conecta directamente al sistema de drenaje sanitario, sino que descarga a través de un espacio de aire hacia un accesorio, receptor o equivalente con trampa.",
  field_es: "Las líneas de condensado enrutadas como desagüe indirecto necesitan un espacio de aire verificado o un receptor aprobado — una conexión directa a la línea sanitaria evade la protección contra conexión cruzada que esta clasificación existe para proporcionar."
},
{
  id: "infiltration",
  cat: "Air Systems & Ventilation",
  term_en: "Infiltration",
  def_en: "Air leakage into a building through unintentional openings, driven by wind, stack effect, or mechanical system pressure imbalances.",
  field_en: "Persistent infiltration complaints in a specific zone often trace back to that zone's exhaust exceeding its supply — check the mechanical air balance before assuming the building envelope itself is the problem.",
  term_es: "Infiltración",
  def_es: "Fuga de aire hacia el interior de un edificio a través de aberturas no intencionales, impulsada por viento, efecto chimenea, o desequilibrios de presión del sistema mecánico.",
  field_es: "Las quejas persistentes de infiltración en una zona específica frecuentemente se remontan a que la extracción de esa zona excede su suministro — revise el balance de aire mecánico antes de asumir que la envolvente del edificio misma es el problema."
},
{
  id: "insulation",
  cat: "General",
  term_en: "Insulation",
  def_en: "A material used to reduce the transfer of heat, applied to piping, ductwork, or equipment.",
  field_en: "Insulation type, thickness, and vapor-barrier integrity all carry separate code and energy-code requirements — confirm the insulation spec addresses condensation control on cold surfaces, not just thermal performance.",
  term_es: "Aislamiento",
  def_es: "Un material usado para reducir la transferencia de calor, aplicado a tubería, ductos o equipo.",
  field_es: "El tipo de aislamiento, el espesor y la integridad de la barrera de vapor llevan requisitos separados de código y de código energético — confirme que la especificación de aislamiento aborde el control de condensación en superficies frías, no solo el desempeño térmico."
},
{
  id: "interlock",
  cat: "General",
  term_en: "Interlock",
  def_en: "A device or control arrangement that requires the state of one component to be verified before allowing another component to operate.",
  field_en: "Fan/damper interlocks, exhaust/makeup-air interlocks, and fire-alarm shutdown interlocks are all safety-critical control logic — confirm interlock wiring is tested and functioning at commissioning, not just shown correctly on the controls diagram.",
  term_es: "Enclavamiento (Interlock)",
  def_es: "Un dispositivo o arreglo de control que requiere que se verifique el estado de un componente antes de permitir que otro componente opere.",
  field_es: "Los enclavamientos de ventilador/compuerta, extracción/aire de reposición, y apagado por alarma de incendio son lógica de control crítica para la seguridad — confirme que el cableado del enclavamiento esté probado y funcionando en la puesta en marcha, no solo mostrado correctamente en el diagrama de controles."
},
{
  id: "kitchen-commercial",
  cat: "Commercial Kitchen & Exhaust",
  term_en: "Kitchen, Commercial",
  def_en: "A room or space intended for the preparation of food, containing one or more pieces of commercial cooking equipment.",
  field_en: "Once a space is classified as a commercial kitchen, the full Type I/Type II hood, fire suppression, and makeup air package applies regardless of the operation's size — confirm the classification early, since it drives the entire mechanical scope, not just the hood.",
  term_es: "Cocina Comercial",
  def_es: "Un cuarto o espacio destinado a la preparación de alimentos, que contiene una o más piezas de equipo de cocción comercial.",
  field_es: "Una vez que un espacio se clasifica como cocina comercial, aplica el paquete completo de campana Tipo I/Tipo II, supresión de incendios y aire de reposición sin importar el tamaño de la operación — confirme la clasificación temprano, ya que determina todo el alcance mecánico, no solo la campana."
},
{
  id: "labeled",
  cat: "General",
  term_en: "Labeled",
  def_en: "Equipment or materials bearing a label, symbol, or identifying mark of an approved agency that conducts periodic inspection of production, and attests to compliance with applicable standards.",
  field_en: "\"Labeled\" and \"listed\" are related but distinct terms with slightly different testing/inspection implications — confirm which one a submittal actually claims before treating them as interchangeable during plan review.",
  term_es: "Etiquetado (Labeled)",
  def_es: "Equipo o materiales que llevan una etiqueta, símbolo, o marca de identificación de una agencia aprobada que realiza inspección periódica de producción, y que atestigua el cumplimiento con las normas aplicables.",
  field_es: "\"Etiquetado\" y \"listado\" son términos relacionados pero distintos con implicaciones de prueba/inspección ligeramente diferentes — confirme cuál de los dos reclama realmente una presentación antes de tratarlos como intercambiables durante la revisión de planos."
},
{
  id: "limit-control",
  cat: "General",
  term_en: "Limit Control",
  def_en: "A device responsive to changes in pressure, temperature, or liquid level, used to keep the supervised condition within a predetermined range by shutting down or altering equipment operation.",
  field_en: "A limit control is a safety backstop, not the primary operating control — confirm during startup that the limit actually trips at the correct setpoint, since a limit control that never gets tested in the field is a latent life-safety gap.",
  term_es: "Control de Límite",
  def_es: "Un dispositivo sensible a cambios en presión, temperatura, o nivel de líquido, usado para mantener la condición supervisada dentro de un rango predeterminado, apagando o alterando la operación del equipo.",
  field_es: "Un control de límite es un respaldo de seguridad, no el control de operación principal — confirme durante el arranque que el límite realmente se activa en el punto de ajuste correcto, ya que un control de límite que nunca se prueba en campo es una brecha de seguridad de vida latente."
},
{
  id: "liquefied-petroleum-gas",
  cat: "Appliances & Combustion",
  term_en: "Liquefied Petroleum Gas (LP-Gas)",
  def_en: "Any material composed predominantly of propane, propylene, butane, or butylenes (or mixtures of these), that exists in the gaseous state under normal atmospheric conditions but is stored and transported as a liquid under pressure.",
  field_en: "LP-gas is heavier than air and settles in low areas when it leaks — this single fact drives most of the appliance location, venting, and equipment room requirements that differ between LP-gas and natural gas installations.",
  term_es: "Gas Licuado de Petróleo (LP-Gas)",
  def_es: "Cualquier material compuesto predominantemente de propano, propileno, butano, o butilenos (o mezclas de estos), que existe en estado gaseoso bajo condiciones atmosféricas normales pero se almacena y transporta como líquido bajo presión.",
  field_es: "El LP-gas es más pesado que el aire y se asienta en áreas bajas cuando hay una fuga — este único hecho determina la mayoría de los requisitos de ubicación de aparatos, venteo y cuarto de equipo que difieren entre instalaciones de LP-gas y gas natural."
},
{
  id: "listed",
  cat: "General",
  term_en: "Listed",
  def_en: "Equipment, materials, or services included in a list published by an organization acceptable to the code official, that maintains periodic inspection of production and whose listing states either suitability for a specified purpose or conformance to specified standards.",
  field_en: "An appliance can only be installed per its listing — field modifications that seem minor but aren't covered by the listing (relocating a control, changing venting configuration) can void the listing and the installation's code compliance with it.",
  term_es: "Listado (Listed)",
  def_es: "Equipo, materiales, o servicios incluidos en una lista publicada por una organización aceptable para el oficial de código, que mantiene inspección periódica de producción y cuyo listado declara ya sea idoneidad para un propósito específico o conformidad con normas específicas.",
  field_es: "Un aparato solo puede instalarse según su listado — modificaciones de campo que parecen menores pero no están cubiertas por el listado (reubicar un control, cambiar la configuración de venteo) pueden anular el listado y, con él, el cumplimiento de código de la instalación."
},
{
  id: "living-space",
  cat: "General",
  term_en: "Living Space",
  def_en: "Space within a dwelling unit used for living, sleeping, eating, or cooking, but not including bathrooms, toilet rooms, closets, halls, storage or utility spaces, or similar areas.",
  field_en: "Living-space classification changes ventilation rate calculations and appliance location restrictions compared to non-living spaces in the same dwelling unit — confirm which rooms actually count before finalizing a residential ventilation calculation.",
  term_es: "Espacio Habitable",
  def_es: "Espacio dentro de una unidad de vivienda usado para vivir, dormir, comer, o cocinar, sin incluir baños, cuartos de aseo, closets, pasillos, espacios de almacenamiento o de servicio, o áreas similares.",
  field_es: "La clasificación de espacio habitable cambia los cálculos de tasa de ventilación y las restricciones de ubicación de aparatos en comparación con espacios no habitables en la misma unidad de vivienda — confirme qué cuartos realmente cuentan antes de finalizar un cálculo de ventilación residencial."
},
{
  id: "makeup-air",
  cat: "Air Systems & Ventilation",
  term_en: "Makeup Air",
  def_en: "Air provided to replace air being exhausted from a space, ensuring balanced pressure between supply and exhaust.",
  field_en: "Commercial kitchen exhaust hoods with no dedicated makeup air source commonly depressurize the building and pull conditioned air (or worse, combustion gases) back through vents and doors — verify makeup air is actually commissioned to balance the hood's exhaust rate, not just present on paper.",
  term_es: "Aire de Reposición (Makeup Air)",
  def_es: "Aire proporcionado para reemplazar el aire que se extrae de un espacio, asegurando una presión balanceada entre suministro y extracción.",
  field_es: "Las campanas de extracción de cocina comercial sin una fuente dedicada de aire de reposición comúnmente despresurizan el edificio y jalan de regreso aire acondicionado (o peor, gases de combustión) a través de venteos y puertas — verifique que el aire de reposición esté realmente puesto en marcha para balancear la tasa de extracción de la campana, no solo presente en papel."
},
{
  id: "mechanical-draft",
  cat: "Venting & Chimneys",
  term_en: "Mechanical Draft System",
  def_en: "A venting system using a fan or blower to induce draft, classified forced draft (fan on the inlet side, positive pressure) or induced draft (fan on the outlet side, negative pressure through the appliance).",
  field_en: "Forced-draft and induced-draft venting have different pressure profiles along the vent run, which changes joint-sealing requirements — confirm which type is actually installed before assuming standard atmospheric venting joint practices apply.",
  term_es: "Sistema de Tiro Mecánico",
  def_es: "Un sistema de venteo que usa un ventilador o soplador para inducir tiro, clasificado como tiro forzado (ventilador en el lado de entrada, presión positiva) o tiro inducido (ventilador en el lado de salida, presión negativa a través del aparato).",
  field_es: "El venteo de tiro forzado y de tiro inducido tienen perfiles de presión diferentes a lo largo de la corrida de venteo, lo cual cambia los requisitos de sellado de juntas — confirme qué tipo está realmente instalado antes de asumir que aplican las prácticas de sellado de juntas de venteo atmosférico estándar."
},
{
  id: "mechanical-exhaust-system",
  cat: "Air Systems & Ventilation",
  term_en: "Mechanical Exhaust System",
  def_en: "A power-driven device (such as a fan or blower) with associated ducts and equipment used to remove air from a portion of a building.",
  field_en: "A mechanical exhaust system's rated capacity needs field verification against actual measured airflow at startup — a fan that's correctly specified but poorly ducted often delivers far less than its rated exhaust rate.",
  term_es: "Sistema de Extracción Mecánica",
  def_es: "Un dispositivo motorizado (como un ventilador o soplador) con los ductos y equipo asociados usado para remover aire de una porción de un edificio.",
  field_es: "La capacidad nominal de un sistema de extracción mecánica necesita verificación de campo contra el caudal medido real en el arranque — un ventilador correctamente especificado pero mal conducido frecuentemente entrega mucho menos que su tasa de extracción nominal."
},
{
  id: "mechanical-joint",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Mechanical Joint",
  def_en: "A joint between pipe and fittings that is not welded, soldered, brazed, or solvent-cemented; assembled by compression, threading, grooving, or a similar mechanical means.",
  field_en: "Where welded or soldered joints are required for a piping application (grease duct systems, certain fuel piping), a mechanical joint may not be an approved substitute — confirm the material and joint standard together, not the material alone.",
  term_es: "Junta Mecánica",
  def_es: "Una junta entre tubería y accesorios que no está soldada, soldada con estaño, soldada fuerte, o cementada con solvente; ensamblada por compresión, roscado, ranurado, o un medio mecánico similar.",
  field_es: "Donde se requieren juntas soldadas o estañadas para una aplicación de tubería (sistemas de ducto de grasa, cierta tubería de combustible), una junta mecánica puede no ser un sustituto aprobado — confirme el material y la norma de junta juntos, no el material solo."
},
{
  id: "mechanical-system",
  cat: "General",
  term_en: "Mechanical System",
  def_en: "A system specifically addressed and regulated by the mechanical code, including equipment, appliances, fixtures, fittings, and appurtenances (excluding electrical wiring and equipment).",
  field_en: "\"Mechanical system\" is the umbrella term the code uses to scope its own jurisdiction — useful when arguing whether a specific piece of equipment falls under mechanical, electrical, or plumbing code review during a scope dispute.",
  term_es: "Sistema Mecánico",
  def_es: "Un sistema específicamente abordado y regulado por el código mecánico, incluyendo equipo, aparatos, accesorios, conexiones y aditamentos (excluyendo el cableado y equipo eléctrico).",
  field_es: "\"Sistema mecánico\" es el término general que usa el código para delimitar su propia jurisdicción — útil al argumentar si una pieza de equipo específica cae bajo revisión de código mecánico, eléctrico, o de plomería durante una disputa de alcance."
},
{
  id: "medium-heat-appliance",
  cat: "Appliances & Combustion",
  term_en: "Medium-Heat Appliance",
  def_en: "A fuel-burning appliance capable of maintaining refractory-chamber temperatures higher than 2,000°F (1,093°C) but not exceeding 2,500°F (1,371°C), measured at the point of entry into the flue.",
  field_en: "Medium-heat appliances need chimney/vent materials rated for their specific temperature class — a chimney sized correctly for a low-heat appliance is not automatically adequate if the appliance is later upgraded or replaced with a medium-heat unit.",
  term_es: "Aparato de Calor Medio",
  def_es: "Un aparato de combustión capaz de mantener temperaturas de cámara refractaria mayores a 2,000°F (1,093°C) pero que no exceden 2,500°F (1,371°C), medidas en el punto de entrada al conducto.",
  field_es: "Los aparatos de calor medio necesitan materiales de chimenea/venteo clasificados para su clase de temperatura específica — una chimenea correctamente dimensionada para un aparato de calor bajo no es automáticamente adecuada si el aparato se actualiza o reemplaza después por una unidad de calor medio."
},
{
  id: "modular-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Modular Boiler",
  def_en: "A boiler composed of two or more separately fired sections, factory-assembled and shipped as a unit, with a single control acting as the operating control for the group.",
  field_en: "A modular boiler's staged sections let a facility match output to actual demand more efficiently than one large boiler — but each section's own venting and combustion air needs to be individually verified, not assumed proportional to the group total.",
  term_es: "Caldera Modular",
  def_es: "Una caldera compuesta de dos o más secciones encendidas por separado, ensambladas en fábrica y enviadas como una unidad, con un solo control actuando como el control de operación del grupo.",
  field_es: "Las secciones escalonadas de una caldera modular permiten que una instalación ajuste la salida a la demanda real de forma más eficiente que una caldera grande única — pero el venteo y aire de combustión de cada sección necesita verificarse individualmente, no asumirse proporcional al total del grupo."
},
{
  id: "motor",
  cat: "General",
  term_en: "Motor",
  def_en: "A device that converts electrical energy into rotating mechanical energy to drive equipment such as fans, pumps, and compressors.",
  field_en: "Motor overload and disconnect requirements are governed jointly with electrical code provisions — a mechanical scope that specifies motor horsepower without coordinating the electrical disconnect and overload protection leaves a compliance gap between trades.",
  term_es: "Motor",
  def_es: "Un dispositivo que convierte energía eléctrica en energía mecánica rotacional para impulsar equipo como ventiladores, bombas y compresores.",
  field_es: "Los requisitos de sobrecarga y desconexión de motores se rigen conjuntamente con las disposiciones del código eléctrico — un alcance mecánico que especifica la potencia del motor sin coordinar la desconexión eléctrica y la protección de sobrecarga deja una brecha de cumplimiento entre oficios."
},
{
  id: "negative-pressure",
  cat: "Air Systems & Ventilation",
  term_en: "Negative Pressure",
  def_en: "A condition where the air pressure within a space is lower than the pressure of the surrounding area, typically because exhaust airflow exceeds supply airflow.",
  field_en: "A negatively pressurized building can backdraft naturally-vented combustion appliances, pulling flue gases back into the occupied space — this is one of the most serious and under-diagnosed field hazards on buildings with strong exhaust systems and weak makeup air.",
  term_es: "Presión Negativa",
  def_es: "Una condición donde la presión de aire dentro de un espacio es menor que la presión del área circundante, típicamente porque el caudal de extracción excede el caudal de suministro.",
  field_es: "Un edificio presurizado negativamente puede causar retroceso de tiro en aparatos de combustión con venteo natural, jalando los gases de combustión de regreso al espacio ocupado — este es uno de los riesgos de campo más graves y sub-diagnosticados en edificios con sistemas de extracción fuertes y aire de reposición débil."
},
{
  id: "noncombustible-material",
  cat: "General",
  term_en: "Noncombustible Material",
  def_en: "A material that, when tested per the applicable standard, does not ignite, burn, support combustion, or release flammable vapors when subjected to fire or heat.",
  field_en: "\"Noncombustible\" describes the material only, not a full assembly — a noncombustible material used with combustible fasteners, coatings, or backing may not preserve the assembly's overall noncombustible rating.",
  term_es: "Material No Combustible",
  def_es: "Un material que, al probarse según la norma aplicable, no se enciende, arde, soporta combustión, o libera vapores inflamables al someterse a fuego o calor.",
  field_es: "\"No combustible\" describe solo el material, no un ensamble completo — un material no combustible usado con sujetadores, recubrimientos, o respaldo combustibles puede no preservar la clasificación general de no combustible del ensamble."
},
{
  id: "occupiable-space",
  cat: "General",
  term_en: "Occupiable Space",
  def_en: "A room or enclosed space designed for human occupancy in which occupants perform work or other activities, including associated accessory areas.",
  field_en: "Ventilation rate calculations under IMC Chapter 4 are driven by occupiable space classification and its associated occupant density — spaces that are only intermittently occupied still typically require ventilation sized for their design occupancy, not their average occupancy.",
  term_es: "Espacio Ocupable",
  def_es: "Un cuarto o espacio cerrado diseñado para ocupación humana en el cual los ocupantes realizan trabajo u otras actividades, incluyendo áreas accesorias asociadas.",
  field_es: "Los cálculos de tasa de ventilación bajo el Capítulo 4 del IMC se determinan por la clasificación de espacio ocupable y su densidad de ocupantes asociada — los espacios ocupados solo intermitentemente típicamente aún requieren ventilación dimensionada para su ocupación de diseño, no su ocupación promedio."
},
{
  id: "offset-vent",
  cat: "Venting & Chimneys",
  term_en: "Offset",
  def_en: "A vent or chimney configuration that changes direction, deviating from a straight vertical run.",
  field_en: "Every offset in a vent run adds equivalent resistance that must be accounted for in the vent's overall sizing calculation — a vent that was sized assuming a straight run will underperform if offsets get added during installation without re-checking the sizing.",
  term_es: "Desviación (Offset)",
  def_es: "Una configuración de venteo o chimenea que cambia de dirección, desviándose de una corrida vertical recta.",
  field_es: "Cada desviación en una corrida de venteo agrega resistencia equivalente que debe contabilizarse en el cálculo de dimensionamiento general del venteo — un venteo dimensionado asumiendo una corrida recta tendrá bajo desempeño si se agregan desviaciones durante la instalación sin volver a verificar el dimensionamiento."
},
{
  id: "outdoor-air",
  cat: "Air Systems & Ventilation",
  term_en: "Outdoor Air",
  def_en: "Air taken from the outdoors, not previously circulated within a building.",
  field_en: "Outdoor air intake location relative to exhaust outlets, plumbing vents, and other contamination sources is code-regulated by minimum separation distances — a well-sized outdoor air system located too close to an exhaust outlet still fails ventilation intent.",
  term_es: "Aire Exterior",
  def_es: "Aire tomado del exterior, no circulado previamente dentro de un edificio.",
  field_es: "La ubicación de la toma de aire exterior en relación con salidas de extracción, venteos de plomería, y otras fuentes de contaminación está regulada por código mediante distancias mínimas de separación — un sistema de aire exterior bien dimensionado pero ubicado demasiado cerca de una salida de extracción de todos modos falla en la intención de ventilación."
},
{
  id: "outdoor-opening",
  cat: "Air Systems & Ventilation",
  term_en: "Outdoor Opening",
  def_en: "An opening in a building's exterior envelope through which outdoor air can enter or be discharged, including louvers, grilles, and combustion air openings.",
  field_en: "Every outdoor opening's free area (not just its rough dimension) must be confirmed against the manufacturer's louver-blade or grille factor — a louver's nominal size overstates its actual free area, often by 40-50%.",
  term_es: "Abertura Exterior",
  def_es: "Una abertura en la envolvente exterior de un edificio a través de la cual el aire exterior puede entrar o descargarse, incluyendo persianas, rejillas, y aberturas de aire de combustión.",
  field_es: "El área libre de cada abertura exterior (no solo su dimensión bruta) debe confirmarse contra el factor de persiana o rejilla del fabricante — el tamaño nominal de una persiana sobreestima su área libre real, frecuentemente en un 40-50%."
},
{
  id: "piping-system",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Piping System",
  def_en: "Pipe, tubing, fittings, valves, and other components assembled to convey a fluid, gas, or vapor.",
  field_en: "A piping system's design working pressure is set by its weakest-rated component — confirm every fitting and valve in the run, not just the pipe material, before certifying a system's pressure rating.",
  term_es: "Sistema de Tubería",
  def_es: "Tubo, tubería, accesorios, válvulas, y otros componentes ensamblados para transportar un fluido, gas, o vapor.",
  field_es: "La presión de trabajo de diseño de un sistema de tubería la establece su componente con menor clasificación — confirme cada accesorio y válvula en la corrida, no solo el material del tubo, antes de certificar la clasificación de presión de un sistema."
},
{
  id: "plenum",
  cat: "Air Systems & Ventilation",
  term_en: "Plenum",
  def_en: "An enclosed portion of the building structure, other than an occupiable space, designed to allow air movement and thereby serve as part of an air distribution system.",
  field_en: "Materials, wiring, and cable installed within a plenum must be plenum-rated (low smoke/flame spread) — this is a frequent coordination gap between mechanical and low-voltage/data trades sharing the same ceiling cavity.",
  term_es: "Plenum",
  def_es: "Una porción cerrada de la estructura del edificio, distinta a un espacio ocupable, diseñada para permitir el movimiento de aire y así servir como parte de un sistema de distribución de aire.",
  field_es: "Los materiales, cableado, y cables instalados dentro de un plenum deben estar clasificados para plenum (bajo humo/propagación de llama) — esta es una brecha de coordinación frecuente entre los oficios mecánico y de baja tensión/datos que comparten la misma cavidad de cielo raso."
},
{
  id: "plume",
  cat: "Venting & Chimneys",
  term_en: "Plume",
  def_en: "The visible or invisible column of flue gases discharged from a vent or chimney termination into the outdoor atmosphere.",
  field_en: "Plume behavior (visible condensation, odor, staining) at a vent termination is a useful field diagnostic — a plume that hugs the building facade instead of rising away from it often signals a termination location or vent sizing problem, not just weather.",
  term_es: "Penacho (Plume)",
  def_es: "La columna visible o invisible de gases de conducto descargados desde una terminación de venteo o chimenea hacia la atmósfera exterior.",
  field_es: "El comportamiento del penacho (condensación visible, olor, manchado) en una terminación de venteo es un diagnóstico de campo útil — un penacho que se pega a la fachada del edificio en lugar de elevarse lejos de ella frecuentemente indica un problema de ubicación de terminación o dimensionamiento de venteo, no solo el clima."
},
{
  id: "pneumatic-piping",
  cat: "General",
  term_en: "Pneumatic Piping",
  def_en: "Piping used to convey compressed air for control or power purposes.",
  field_en: "Pneumatic control piping is often overlooked during fire/smoke damper coordination since it doesn't carry conditioned air itself — confirm penetrations through rated assemblies for control piping are sealed to the same standard as the ductwork it controls.",
  term_es: "Tubería Neumática",
  def_es: "Tubería usada para transportar aire comprimido con fines de control o potencia.",
  field_es: "La tubería de control neumático frecuentemente se pasa por alto durante la coordinación de compuertas contra incendio/humo ya que no transporta aire acondicionado en sí — confirme que las penetraciones a través de ensambles clasificados para tubería de control estén selladas al mismo estándar que la ductería que controlan."
},
{
  id: "positive-pressure",
  cat: "Air Systems & Ventilation",
  term_en: "Positive Pressure",
  def_en: "A condition where the air pressure within a space is higher than the pressure of the surrounding area, typically because supply airflow exceeds exhaust airflow.",
  field_en: "Positive pressure is often intentionally designed into cleanrooms, operating rooms, and similar spaces to keep contaminants out — verify the pressure relationship direction matches the space's actual function before treating a pressure imbalance as a defect.",
  term_es: "Presión Positiva",
  def_es: "Una condición donde la presión de aire dentro de un espacio es mayor que la presión del área circundante, típicamente porque el caudal de suministro excede el caudal de extracción.",
  field_es: "La presión positiva frecuentemente se diseña intencionalmente en cuartos limpios, quirófanos, y espacios similares para mantener contaminantes fuera — verifique que la dirección de la relación de presión coincida con la función real del espacio antes de tratar un desequilibrio de presión como un defecto."
},
{
  id: "potable-water",
  cat: "General",
  term_en: "Potable Water",
  def_en: "Water free from impurities present in amounts sufficient to cause disease or harmful physiological effects, meeting the quality requirements of the applicable public health authority.",
  field_en: "Any mechanical system with a potable water connection (humidifiers, evaporative coolers, boiler makeup water) needs backflow protection appropriate to its cross-connection hazard level — confirm this is coordinated with the plumbing scope, not assumed to be someone else's problem.",
  term_es: "Agua Potable",
  def_es: "Agua libre de impurezas presentes en cantidades suficientes para causar enfermedad o efectos fisiológicos dañinos, que cumple con los requisitos de calidad de la autoridad de salud pública aplicable.",
  field_es: "Cualquier sistema mecánico con una conexión de agua potable (humidificadores, enfriadores evaporativos, agua de reposición de caldera) necesita protección contra retroflujo apropiada a su nivel de riesgo de conexión cruzada — confirme que esto esté coordinado con el alcance de plomería, no asumido como problema de alguien más."
},
{
  id: "pressure-relief-device",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Pressure-Relief Device",
  def_en: "A device designed to open automatically and relieve excess pressure, protecting a vessel or system from overpressure conditions, and reseat (or, for fusible-type devices, be replaced) once normal conditions are restored.",
  field_en: "A relief device's discharge must be piped to a safe location per code (not blocked, capped, or reduced in size) — a relief valve with an obstructed discharge provides zero actual protection despite being physically present and correctly rated.",
  term_es: "Dispositivo de Alivio de Presión",
  def_es: "Un dispositivo diseñado para abrir automáticamente y aliviar el exceso de presión, protegiendo un recipiente o sistema de condiciones de sobrepresión, y volver a asentar (o, para dispositivos tipo fusible, ser reemplazado) una vez restauradas las condiciones normales.",
  field_es: "La descarga de un dispositivo de alivio debe tener tubería hacia una ubicación segura según el código (sin bloquear, tapar, o reducir de tamaño) — una válvula de alivio con descarga obstruida no proporciona protección real alguna a pesar de estar físicamente presente y correctamente clasificada."
},
{
  id: "pressure-vessel",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Pressure Vessel",
  def_en: "A closed container designed to hold gases or liquids at a pressure substantially different from ambient pressure.",
  field_en: "Pressure vessels above certain size/pressure thresholds require third-party inspection and stamping (ASME) — confirm whether a given tank or receiver actually falls under this jurisdiction before assuming it's exempt as \"just a tank.\"",
  term_es: "Recipiente a Presión",
  def_es: "Un contenedor cerrado diseñado para contener gases o líquidos a una presión sustancialmente diferente de la presión ambiental.",
  field_es: "Los recipientes a presión por encima de ciertos umbrales de tamaño/presión requieren inspección y sello de un tercero (ASME) — confirme si un tanque o recibidor dado realmente cae bajo esta jurisdicción antes de asumir que está exento por ser \"solo un tanque.\""
},
{
  id: "process-fluids",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Process Fluids",
  def_en: "Any liquid or gas used in a research, commercial, or industrial process, distinct from water or fluids used solely for space heating or cooling.",
  field_en: "Process fluid piping frequently falls under different material compatibility, labeling, and containment requirements than standard HVAC piping — confirm the fluid's actual chemistry against the piping material's compatibility rating before assuming standard hydronic pipe is acceptable.",
  term_es: "Fluidos de Proceso",
  def_es: "Cualquier líquido o gas usado en un proceso de investigación, comercial, o industrial, distinto del agua o fluidos usados únicamente para calefacción o enfriamiento de espacio.",
  field_es: "La tubería de fluidos de proceso frecuentemente cae bajo requisitos de compatibilidad de material, etiquetado, y contención distintos a la tubería HVAC estándar — confirme la química real del fluido contra la clasificación de compatibilidad del material de tubería antes de asumir que la tubería hidrónica estándar es aceptable."
},
{
  id: "public-space",
  cat: "General",
  term_en: "Public Space",
  def_en: "A space accessible to the general public, as distinguished from spaces restricted to employees, tenants, or authorized personnel.",
  field_en: "Public-space classification can affect accessibility, egress, and ventilation requirements differently than back-of-house or restricted-access mechanical rooms serving the same building — confirm classification before applying restricted-space assumptions to a public-facing area.",
  term_es: "Espacio Público",
  def_es: "Un espacio accesible al público en general, en contraste con espacios restringidos a empleados, inquilinos, o personal autorizado.",
  field_es: "La clasificación de espacio público puede afectar los requisitos de accesibilidad, salida, y ventilación de forma diferente a los cuartos mecánicos de trastienda o de acceso restringido que sirven al mismo edificio — confirme la clasificación antes de aplicar suposiciones de espacio restringido a un área de cara al público."
},
{
  id: "purge",
  cat: "Appliances & Combustion",
  term_en: "Purge",
  def_en: "To clear a piping system, combustion chamber, or vent of air, gas, or combustion products before startup or after shutdown, typically by displacing them with an inert gas or fresh air.",
  field_en: "Pre-ignition purge cycles on modern burners are a programmed safety step, not an optional delay — a purge cycle that's been bypassed or shortened in the field to speed up startup is a documented cause of ignition-related incidents.",
  term_es: "Purga",
  def_es: "Despejar un sistema de tubería, cámara de combustión, o venteo de aire, gas, o productos de combustión antes del arranque o después del apagado, típicamente desplazándolos con un gas inerte o aire fresco.",
  field_es: "Los ciclos de purga previos a la ignición en quemadores modernos son un paso de seguridad programado, no una demora opcional — un ciclo de purga que ha sido evadido o acortado en campo para acelerar el arranque es una causa documentada de incidentes relacionados con la ignición."
}
,
{
  id: "qualified-agency",
  cat: "General",
  term_en: "Qualified Agency",
  def_en: "A person, firm, or corporation approved by the code official to inspect, test, adjust, or install a specific piece of equipment or system, based on demonstrated competence.",
  field_en: "The code official's approval of a qualified agency is project- and scope-specific — a firm qualified for one type of equipment isn't automatically qualified for every mechanical scope on a job.",
  term_es: "Agencia Calificada",
  def_es: "Una persona, empresa, o corporación aprobada por el oficial de código para inspeccionar, probar, ajustar, o instalar una pieza específica de equipo o sistema, con base en competencia demostrada.",
  field_es: "La aprobación de una agencia calificada por el oficial de código es específica al proyecto y al alcance — una empresa calificada para un tipo de equipo no está automáticamente calificada para todo alcance mecánico de una obra."
},
{
  id: "radiant-heater",
  cat: "Appliances & Combustion",
  term_en: "Radiant Heater",
  def_en: "A heater designed to transfer heat primarily by radiation to objects and occupants in a space, rather than by heating the air directly.",
  field_en: "Radiant heaters have clearance-to-combustible requirements measured from the radiating surface, not the appliance cabinet — confirm the actual radiating element location before locating combustible materials nearby.",
  term_es: "Calentador Radiante",
  def_es: "Un calentador diseñado para transferir calor principalmente por radiación a objetos y ocupantes en un espacio, en lugar de calentar el aire directamente.",
  field_es: "Los calentadores radiantes tienen requisitos de separación a combustibles medidos desde la superficie radiante, no desde el gabinete del aparato — confirme la ubicación real del elemento radiante antes de ubicar materiales combustibles cerca."
},
{
  id: "ready-access",
  cat: "General",
  term_en: "Ready Access (To)",
  def_en: "Access that does not require the removal or movement of any panel, door, or similar obstruction, and does not require the use of a portable ladder or similar equipment.",
  field_en: "\"Ready access\" is a stricter standard than \"access\" alone — equipment specified as needing ready access cannot be buried behind a removable panel, even one that's easy to take off.",
  term_es: "Acceso Inmediato (Ready Access)",
  def_es: "Acceso que no requiere la remoción o movimiento de ningún panel, puerta, u obstrucción similar, y que no requiere el uso de una escalera portátil o equipo similar.",
  field_es: "\"Acceso inmediato\" es un estándar más estricto que \"acceso\" solo — el equipo especificado como que necesita acceso inmediato no puede quedar enterrado detrás de un panel removible, aunque sea fácil de quitar."
},
{
  id: "receiver-refrigerant",
  cat: "Refrigeration & Cooling",
  term_en: "Receiver",
  def_en: "A vessel permanently connected to a refrigeration system by piping, used to store liquid refrigerant.",
  field_en: "A receiver's storage capacity and the system's total refrigerant charge both factor into occupancy classification and ventilation requirements — confirm the actual receiver size specified matches the charge calculation, not just a generic component list.",
  term_es: "Recibidor",
  def_es: "Un recipiente conectado permanentemente a un sistema de refrigeración mediante tubería, usado para almacenar refrigerante líquido.",
  field_es: "La capacidad de almacenamiento de un recibidor y la carga total de refrigerante del sistema factorizan en la clasificación de ocupación y los requisitos de ventilación — confirme que el tamaño real del recibidor especificado coincida con el cálculo de carga, no solo con una lista genérica de componentes."
},
{
  id: "refrigerant",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigerant",
  def_en: "A substance used to produce refrigeration by absorbing heat as it expands or evaporates.",
  field_en: "Refrigerant type (not just quantity) drives the safety group classification (toxicity/flammability) that sets the equipment room and ventilation requirements — confirm the actual refrigerant charged into the system matches the design documents before final inspection.",
  term_es: "Refrigerante",
  def_es: "Una sustancia usada para producir refrigeración absorbiendo calor al expandirse o evaporarse.",
  field_es: "El tipo de refrigerante (no solo la cantidad) determina la clasificación de grupo de seguridad (toxicidad/inflamabilidad) que establece los requisitos de cuarto de equipo y ventilación — confirme que el refrigerante realmente cargado en el sistema coincida con los documentos de diseño antes de la inspección final."
},
{
  id: "refrigerant-compressor",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigerant Compressor",
  def_en: "A specific machine, with or without accessories, for compressing a given refrigerant vapor.",
  field_en: "Compressor location and ventilation requirements scale with the refrigerant's safety classification, not just the compressor's physical size — a compact compressor handling a higher-hazard refrigerant may need more clearance than a larger unit on a lower-hazard refrigerant.",
  term_es: "Compresor de Refrigerante",
  def_es: "Una máquina específica, con o sin accesorios, para comprimir un vapor de refrigerante dado.",
  field_es: "La ubicación del compresor y los requisitos de ventilación escalan con la clasificación de seguridad del refrigerante, no solo con el tamaño físico del compresor — un compresor compacto que maneja un refrigerante de mayor riesgo puede necesitar más separación que una unidad más grande con un refrigerante de menor riesgo."
},
{
  id: "refrigerant-piping",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigerant Piping (Refrigerant Distribution Piping)",
  def_en: "Piping used to convey refrigerant from one component of a refrigerating system to another.",
  field_en: "Refrigerant line set sizing and routing directly affect system charge, oil return, and capacity — a line set that's been lengthened or rerouted in the field beyond the manufacturer's published limits needs the charge and capacity recalculated, not assumed unchanged.",
  term_es: "Tubería de Refrigerante (Tubería de Distribución de Refrigerante)",
  def_es: "Tubería usada para transportar refrigerante de un componente de un sistema de refrigeración a otro.",
  field_es: "El dimensionamiento y ruteo del juego de líneas de refrigerante afectan directamente la carga del sistema, el retorno de aceite, y la capacidad — un juego de líneas que ha sido alargado o reenrutado en campo más allá de los límites publicados por el fabricante necesita que se recalculen la carga y la capacidad, no que se asuman sin cambio."
},
{
  id: "refrigerant-safety-classification",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigerant Safety Classification",
  def_en: "A two-part classification (toxicity Class A or B; flammability Class 1, 2, or 3) assigned to a refrigerant based on standardized toxicity and flammability testing.",
  field_en: "This classification — not the refrigerant's trade name — is what actually drives the applicable equipment room, ventilation, and quantity-limit provisions; always confirm the safety group from the manufacturer's data, not from assumptions based on a similar-sounding refrigerant.",
  term_es: "Clasificación de Seguridad de Refrigerante",
  def_es: "Una clasificación de dos partes (toxicidad Clase A o B; inflamabilidad Clase 1, 2, o 3) asignada a un refrigerante con base en pruebas estandarizadas de toxicidad e inflamabilidad.",
  field_es: "Esta clasificación — no el nombre comercial del refrigerante — es lo que realmente determina las disposiciones aplicables de cuarto de equipo, ventilación, y límite de cantidad; confirme siempre el grupo de seguridad a partir de los datos del fabricante, no de suposiciones basadas en un refrigerante de nombre similar."
},
{
  id: "refrigerated-room",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigerated Room",
  def_en: "A room or space cooled below the ambient temperature by refrigeration equipment as part of its intended use.",
  field_en: "Refrigerated rooms need a documented means of emergency egress and, in some cases, an internal alarm — confirm these life-safety provisions are addressed in the mechanical design, not treated as purely an architectural item.",
  term_es: "Cuarto Refrigerado",
  def_es: "Un cuarto o espacio enfriado por debajo de la temperatura ambiental mediante equipo de refrigeración como parte de su uso previsto.",
  field_es: "Los cuartos refrigerados necesitan un medio documentado de salida de emergencia y, en algunos casos, una alarma interna — confirme que estas disposiciones de seguridad de vida se aborden en el diseño mecánico, no se traten como un asunto puramente arquitectónico."
},
{
  id: "refrigeration-system",
  cat: "Refrigeration & Cooling",
  term_en: "Refrigeration System",
  def_en: "A combination of interconnected refrigerant-containing parts constituting one closed refrigerant circuit in which a refrigerant is circulated to absorb and reject heat.",
  field_en: "Every component added to or removed from a refrigeration circuit changes its total refrigerant charge — recalculate the charge and re-check occupancy/ventilation limits any time the circuit is modified, not just at original design.",
  term_es: "Sistema de Refrigeración",
  def_es: "Una combinación de partes interconectadas que contienen refrigerante y que constituyen un circuito de refrigerante cerrado en el cual se circula un refrigerante para absorber y rechazar calor.",
  field_es: "Cada componente agregado o removido de un circuito de refrigeración cambia su carga total de refrigerante — recalcule la carga y vuelva a verificar los límites de ocupación/ventilación cada vez que se modifique el circuito, no solo en el diseño original."
},
{
  id: "registered-design-professional",
  cat: "General",
  term_en: "Registered Design Professional",
  def_en: "An individual legally registered or licensed to practice their respective design profession, as defined by the statutory requirements of the jurisdiction where the project is located.",
  field_en: "The registered design professional's stamp is what gives a mechanical submittal legal standing before a code official — confirm the actual jurisdiction's licensing requirements, since a license valid in one state doesn't automatically carry over to a project in another.",
  term_es: "Profesional de Diseño Registrado",
  def_es: "Una persona legalmente registrada o licenciada para ejercer su respectiva profesión de diseño, según lo definan los requisitos estatutarios de la jurisdicción donde se ubica el proyecto.",
  field_es: "El sello del profesional de diseño registrado es lo que le da validez legal a una presentación mecánica ante un oficial de código — confirme los requisitos de licencia de la jurisdicción real, ya que una licencia válida en un estado no se traslada automáticamente a un proyecto en otro."
},
{
  id: "relief-valve",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Relief Valve, Pressure",
  def_en: "A pressure-actuated valve held closed by a spring or other means, designed to relieve excess pressure automatically and reseat once normal pressure is restored.",
  field_en: "A pressure relief valve must be set to open at or below the vessel's maximum allowable working pressure and must never be field-adjusted upward to stop nuisance discharge — a relief valve that's been throttled or capped defeats its entire safety function.",
  term_es: "Válvula de Alivio de Presión",
  def_es: "Una válvula accionada por presión que se mantiene cerrada mediante un resorte u otro medio, diseñada para aliviar automáticamente el exceso de presión y volver a asentar una vez restaurada la presión normal.",
  field_es: "Una válvula de alivio de presión debe ajustarse para abrir en o por debajo de la presión de trabajo máxima permitida del recipiente y nunca debe ajustarse en campo hacia arriba para detener una descarga molesta — una válvula de alivio que ha sido estrangulada o tapada anula por completo su función de seguridad."
},
{
  id: "return-air",
  cat: "Air Systems & Ventilation",
  term_en: "Return Air",
  def_en: "Air removed from a conditioned space and returned to a heating, cooling, or ventilating system for reconditioning or exhaust.",
  field_en: "Return air pulled from a contaminated or hazardous space (a garage, a space with fuel-fired equipment) needs a separate ducted return, never a shared plenum return — a shared plenum return in these conditions is a common and serious code violation.",
  term_es: "Aire de Retorno",
  def_es: "Aire removido de un espacio acondicionado y devuelto a un sistema de calefacción, enfriamiento, o ventilación para reacondicionamiento o extracción.",
  field_es: "El aire de retorno tomado de un espacio contaminado o peligroso (un garaje, un espacio con equipo de combustible) necesita un retorno ducteado separado, nunca un retorno de plenum compartido — un retorno de plenum compartido en estas condiciones es una violación de código común y grave."
},
{
  id: "riser",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Riser",
  def_en: "A vertical pipe or run of piping that conveys fluid, gas, or vapor upward from one level of a building to another.",
  field_en: "Riser expansion and support requirements grow with building height — confirm anchor points and expansion joints/loops are actually detailed for a riser serving more than a couple of floors, not just extrapolated from a single-story branch detail.",
  term_es: "Montante (Riser)",
  def_es: "Una tubería vertical o corrida de tubería que transporta fluido, gas, o vapor hacia arriba de un nivel de un edificio a otro.",
  field_es: "Los requisitos de expansión y soporte de un montante crecen con la altura del edificio — confirme que los puntos de anclaje y las juntas/lazos de expansión estén realmente detallados para un montante que sirve más de un par de pisos, no solo extrapolados de un detalle de ramal de un solo piso."
},
{
  id: "roof-mounted-equipment",
  cat: "General",
  term_en: "Roof-Mounted Equipment",
  def_en: "Equipment installed on a roof, typically requiring a curb, structural support, and weatherproofing appropriate to the roof assembly and equipment weight/wind loading.",
  field_en: "Roof-mounted equipment placement affects required setbacks from roof edges, parapets, and skylights, along with structural load coordination — verify the roof structure was actually designed for the equipment's weight before it's set, not after.",
  term_es: "Equipo Montado en Techo",
  def_es: "Equipo instalado en un techo, típicamente requiriendo un brocal, soporte estructural, e impermeabilización apropiada al ensamble del techo y al peso/carga de viento del equipo.",
  field_es: "La ubicación del equipo montado en techo afecta las separaciones requeridas desde bordes de techo, parapetos, y tragaluces, junto con la coordinación de carga estructural — verifique que la estructura del techo realmente se haya diseñado para el peso del equipo antes de que se instale, no después."
},
{
  id: "room-air-conditioner",
  cat: "Refrigeration & Cooling",
  term_en: "Room Air Conditioner",
  def_en: "An encased, self-contained assembly designed as a unit for mounting in a window, through a wall, or as a console, providing complete cooling (and often heating) for a single room without ductwork.",
  field_en: "Room air conditioners are typically plug-and-cord listed appliances outside the scope of hardwired mechanical permitting — but structural wall penetrations and electrical circuit loading still need to be confirmed for through-wall installations.",
  term_es: "Aire Acondicionado de Cuarto",
  def_es: "Un ensamble encerrado y autónomo diseñado como unidad para montarse en una ventana, a través de un muro, o como consola, proporcionando enfriamiento completo (y frecuentemente calefacción) para un solo cuarto sin ductos.",
  field_es: "Los aires acondicionados de cuarto son típicamente aparatos listados de enchufe y cable fuera del alcance del permiso mecánico cableado fijo — pero las penetraciones estructurales de muro y la carga del circuito eléctrico todavía necesitan confirmarse para instalaciones a través del muro."
},
{
  id: "safety-controls",
  cat: "General",
  term_en: "Safety Controls",
  def_en: "Devices designed to protect against unsafe conditions by shutting down or limiting equipment operation, distinct from operating controls that regulate normal function.",
  field_en: "Safety controls (high-limit switches, flame safeguards, low-water cutoffs) should never be bypassed to work around a nuisance trip — the correct response to a repeated safety trip is diagnosing the underlying cause, not defeating the control.",
  term_es: "Controles de Seguridad",
  def_es: "Dispositivos diseñados para proteger contra condiciones inseguras apagando o limitando la operación del equipo, distintos de los controles de operación que regulan la función normal.",
  field_es: "Los controles de seguridad (interruptores de límite alto, salvaguardas de flama, cortes de bajo nivel de agua) nunca deben evadirse para sortear un disparo molesto — la respuesta correcta a un disparo de seguridad repetido es diagnosticar la causa subyacente, no anular el control."
},
{
  id: "sealed-combustion-system",
  cat: "Appliances & Combustion",
  term_en: "Sealed Combustion System",
  def_en: "A combustion system in which all combustion air is piped directly from outdoors and all flue gases are discharged directly outdoors, sealed from the appliance's surrounding space.",
  field_en: "Sealed combustion appliances aren't affected by indoor depressurization the way naturally-aspirated appliances are — this makes them a common corrective solution when a building's exhaust-heavy air balance is causing backdrafting on other equipment.",
  term_es: "Sistema de Combustión Sellada",
  def_es: "Un sistema de combustión en el cual todo el aire de combustión se conduce directamente desde el exterior y todos los gases de combustión se descargan directamente al exterior, sellado del espacio circundante del aparato.",
  field_es: "Los aparatos de combustión sellada no se ven afectados por la despresurización interior de la forma en que lo son los aparatos de aspiración natural — esto los convierte en una solución correctiva común cuando el balance de aire de extracción pesada de un edificio está causando retroceso de tiro en otro equipo."
},
{
  id: "sediment-trap",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Sediment Trap",
  def_en: "A device installed in fuel gas piping ahead of an appliance's gas controls, designed to trap dirt, scale, and other foreign material carried in the gas stream before it reaches the appliance.",
  field_en: "A missing sediment trap is one of the most common gas-appliance installation deficiencies caught on inspection — it's a small, inexpensive fitting that's easy to omit but not optional at most listed appliance connections.",
  term_es: "Trampa de Sedimento",
  def_es: "Un dispositivo instalado en la tubería de gas combustible antes de los controles de gas de un aparato, diseñado para atrapar suciedad, incrustaciones, y otro material extraño transportado en la corriente de gas antes de que llegue al aparato.",
  field_es: "Una trampa de sedimento faltante es una de las deficiencias de instalación de aparatos de gas más comunes detectadas en inspección — es un accesorio pequeño y económico que es fácil de omitir pero no opcional en la mayoría de las conexiones de aparatos listados."
},
{
  id: "sensible-heat",
  cat: "General",
  term_en: "Sensible Heat",
  def_en: "Heat that results in a measurable temperature change, as distinguished from latent heat, which changes a substance's moisture content or state without changing its temperature.",
  field_en: "Load calculations separate sensible and latent heat because equipment is selected and sized against both independently — a system with adequate total capacity can still fail to control humidity if its sensible/latent split doesn't match the space's actual load profile.",
  term_es: "Calor Sensible",
  def_es: "Calor que resulta en un cambio de temperatura medible, en contraste con el calor latente, que cambia el contenido de humedad o el estado de una sustancia sin cambiar su temperatura.",
  field_es: "Los cálculos de carga separan el calor sensible y latente porque el equipo se selecciona y dimensiona contra ambos de forma independiente — un sistema con capacidad total adecuada de todos modos puede fallar en controlar la humedad si su relación sensible/latente no coincide con el perfil de carga real del espacio."
},
{
  id: "shaft",
  cat: "General",
  term_en: "Shaft",
  def_en: "An enclosed space extending through one or more stories of a building, connecting openings on successive floors, or between a floor and the roof.",
  field_en: "Mechanical penetrations through a rated shaft enclosure need fire/smoke damper protection or an approved through-penetration firestop system — confirm the shaft's fire-resistance rating before finalizing duct or pipe routing through it.",
  term_es: "Hueco (Shaft)",
  def_es: "Un espacio cerrado que se extiende a través de uno o más pisos de un edificio, conectando aberturas en pisos sucesivos, o entre un piso y el techo.",
  field_es: "Las penetraciones mecánicas a través de un hueco clasificado contra incendio necesitan protección de compuerta contra incendio/humo o un sistema aprobado de sellado contra fuego de penetración pasante — confirme la clasificación de resistencia al fuego del hueco antes de finalizar el ruteo de ducto o tubería a través de él."
},
{
  id: "single-duct-system",
  cat: "Air Systems & Ventilation",
  term_en: "Single Duct System",
  def_en: "An air distribution system using one duct system to convey either heated or cooled air, but not both simultaneously, to the spaces served.",
  field_en: "Single duct systems are simpler to install and commission than dual-duct systems, but they can't independently condition zones with conflicting simultaneous heating/cooling demand — confirm the zoning strategy actually matches this system's single-airstream limitation.",
  term_es: "Sistema de Ducto Único",
  def_es: "Un sistema de distribución de aire que usa un solo sistema de ductos para transportar aire calentado o enfriado, pero no ambos simultáneamente, a los espacios servidos.",
  field_es: "Los sistemas de ducto único son más simples de instalar y poner en marcha que los sistemas de ducto dual, pero no pueden acondicionar zonas de forma independiente con demanda simultánea conflictiva de calefacción/enfriamiento — confirme que la estrategia de zonificación realmente coincida con la limitación de una sola corriente de aire de este sistema."
},
{
  id: "smoke-damper",
  cat: "Venting & Chimneys",
  term_en: "Smoke Damper",
  def_en: "A listed device installed in ducts and air transfer openings, designed to resist the passage of air and smoke, that operates automatically and is controlled by a smoke detection system.",
  field_en: "A smoke damper's actuation is tied to the building's smoke detection and fire alarm system, not a standalone thermal element like a fire damper — confirm the controls contractor's wiring interface is actually tested with the damper during commissioning, not just the damper's mechanical operation alone.",
  term_es: "Compuerta de Humo",
  def_es: "Un dispositivo listado instalado en ductos y aberturas de transferencia de aire, diseñado para resistir el paso de aire y humo, que opera automáticamente y es controlado por un sistema de detección de humo.",
  field_es: "La activación de una compuerta de humo está ligada al sistema de detección de humo y alarma de incendio del edificio, no a un elemento térmico autónomo como una compuerta contra incendio — confirme que la interfaz de cableado del contratista de controles realmente se pruebe con la compuerta durante la puesta en marcha, no solo la operación mecánica de la compuerta sola."
},
{
  id: "smoke-detector",
  cat: "General",
  term_en: "Smoke Detector",
  def_en: "A listed device that detects the visible or invisible products of combustion, used within air distribution systems to shut down fan operation and/or actuate smoke dampers upon smoke detection.",
  field_en: "Duct-mounted smoke detectors have specific placement requirements relative to duct size, airflow, and turns — a duct smoke detector installed too close to a fitting or turbulent zone can produce nuisance trips or fail to sample air representatively.",
  term_es: "Detector de Humo",
  def_es: "Un dispositivo listado que detecta los productos visibles o invisibles de combustión, usado dentro de sistemas de distribución de aire para apagar la operación de ventiladores y/o activar compuertas de humo al detectar humo.",
  field_es: "Los detectores de humo montados en ducto tienen requisitos de ubicación específicos en relación con el tamaño del ducto, el flujo de aire, y las vueltas — un detector de humo de ducto instalado demasiado cerca de un accesorio o zona turbulenta puede producir disparos molestos o no muestrear el aire de forma representativa."
},
{
  id: "solar-thermal-collector",
  cat: "General",
  term_en: "Solar Thermal Collector",
  def_en: "A device designed to absorb solar radiation and convert it into thermal energy for use in heating water, air, or other fluids.",
  field_en: "Collector mounting must account for roof structural loading, wind uplift, and roof penetration waterproofing in addition to solar orientation — a collector oriented perfectly for solar gain but improperly flashed is a guaranteed future leak.",
  term_es: "Colector Térmico Solar",
  def_es: "Un dispositivo diseñado para absorber radiación solar y convertirla en energía térmica para uso en calentar agua, aire, u otros fluidos.",
  field_es: "El montaje del colector debe considerar la carga estructural del techo, el levantamiento por viento, y la impermeabilización de la penetración de techo además de la orientación solar — un colector orientado perfectamente para ganancia solar pero mal impermeabilizado es una fuga futura garantizada."
},
{
  id: "solvent-cementing",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Solvent Cementing",
  def_en: "A joining method for certain plastic piping materials using a solvent cement that chemically fuses the pipe and fitting surfaces together.",
  field_en: "Solvent-cemented joints require the correct primer/cement combination matched to the specific pipe material (PVC, CPVC, ABS are not interchangeable) and a manufacturer-specified cure time before pressure testing — rushing either step is a common cause of joint failure.",
  term_es: "Cementado con Solvente",
  def_es: "Un método de unión para ciertos materiales de tubería plástica usando un cemento solvente que fusiona químicamente las superficies del tubo y el accesorio.",
  field_es: "Las juntas cementadas con solvente requieren la combinación correcta de imprimador/cemento correspondiente al material de tubería específico (PVC, CPVC, ABS no son intercambiables) y un tiempo de curado especificado por el fabricante antes de la prueba de presión — apresurar cualquiera de los dos pasos es una causa común de falla de junta."
},
{
  id: "spillage",
  cat: "Venting & Chimneys",
  term_en: "Spillage",
  def_en: "The escape of combustion products from an appliance's draft hood, barometric draft regulator, or vent connector into the room rather than up the vent or chimney.",
  field_en: "Spillage at a draft hood during startup (often visible with a smoke match or mirror test) signals a venting or combustion air problem that needs correction before the appliance is returned to service, not a condition to monitor and hope resolves itself.",
  term_es: "Derrame (Spillage)",
  def_es: "El escape de productos de combustión desde la campana de tiro, regulador de tiro barométrico, o conector de venteo de un aparato hacia el cuarto en lugar de hacia el venteo o chimenea.",
  field_es: "El derrame en una campana de tiro durante el arranque (frecuentemente visible con una prueba de cerillo de humo o espejo) señala un problema de venteo o aire de combustión que necesita corregirse antes de regresar el aparato a servicio, no una condición para monitorear y esperar que se resuelva sola."
},
{
  id: "split-system-air-conditioner",
  cat: "Refrigeration & Cooling",
  term_en: "Split-System Air Conditioner",
  def_en: "A factory-matched central air conditioning system consisting of an outdoor condensing unit and an indoor evaporator coil or air handler, connected by refrigerant piping.",
  field_en: "\"Factory-matched\" is the operative word — mixing an outdoor unit and indoor coil from different manufacturers or model lines outside the listed matched pairs can void the equipment's listing and rated efficiency.",
  term_es: "Aire Acondicionado de Sistema Dividido (Split)",
  def_es: "Un sistema de aire acondicionado central emparejado de fábrica que consiste en una unidad condensadora exterior y una serpentina evaporadora interior o manejadora de aire, conectadas por tubería de refrigerante.",
  field_es: "\"Emparejado de fábrica\" es la palabra clave — mezclar una unidad exterior y una serpentina interior de diferentes fabricantes o líneas de modelo fuera de los pares listados coincidentes puede anular el listado del equipo y su eficiencia nominal."
},
{
  id: "standby-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Standby Boiler",
  def_en: "A boiler not normally in service, maintained ready for use to supplement or replace another boiler.",
  field_en: "A standby boiler still needs to be exercised and tested on a regular schedule — a boiler left dormant for extended periods can fail to start reliably exactly when it's needed most, during a primary boiler outage.",
  term_es: "Caldera de Respaldo",
  def_es: "Una caldera que normalmente no está en servicio, mantenida lista para uso para complementar o reemplazar otra caldera.",
  field_es: "Una caldera de respaldo todavía necesita ejercitarse y probarse en un programa regular — una caldera dejada inactiva por períodos prolongados puede fallar en arrancar de forma confiable justo cuando más se necesita, durante una falla de la caldera principal."
},
{
  id: "steam",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Steam",
  def_en: "Water in its vaporous phase, converted from liquid water by the addition of heat.",
  field_en: "Steam systems require condensate return provisions and dedicated safety/pressure-relief design distinct from hydronic hot-water systems — never assume hydronic piping practices transfer directly to a steam scope.",
  term_es: "Vapor (Steam)",
  def_es: "Agua en su fase vaporosa, convertida de agua líquida mediante la adición de calor.",
  field_es: "Los sistemas de vapor requieren provisiones de retorno de condensado y un diseño dedicado de seguridad/alivio de presión distinto de los sistemas hidrónicos de agua caliente — nunca asuma que las prácticas de tubería hidrónica se trasladan directamente a un alcance de vapor."
},
{
  id: "steam-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Steam Boiler",
  def_en: "A closed vessel in which steam is generated by the combustion of fuel or by electric heating elements, for use external to itself.",
  field_en: "Low-pressure and high-pressure steam boiler classifications carry substantially different safety-device, piping, and inspection requirements — confirm which classification applies before assuming standard hot-water boiler practices carry over.",
  term_es: "Caldera de Vapor",
  def_es: "Un recipiente cerrado en el cual se genera vapor mediante la combustión de combustible o mediante elementos de calefacción eléctrica, para uso externo a sí misma.",
  field_es: "Las clasificaciones de caldera de vapor de baja y alta presión llevan requisitos sustancialmente diferentes de dispositivos de seguridad, tubería, e inspección — confirme qué clasificación aplica antes de asumir que las prácticas estándar de caldera de agua caliente se trasladan."
},
{
  id: "supply-air",
  cat: "Air Systems & Ventilation",
  term_en: "Supply Air",
  def_en: "Air delivered to a conditioned space through ductwork or a distribution system, either from an outdoor air intake or recirculated from a return air system.",
  field_en: "Supply air quantity and diffuser throw pattern both need to match the room's actual layout — a correctly calculated supply airflow delivered through a poorly located diffuser can still leave dead zones or drafts.",
  term_es: "Aire de Suministro",
  def_es: "Aire entregado a un espacio acondicionado a través de ductos o un sistema de distribución, ya sea desde una toma de aire exterior o recirculado de un sistema de aire de retorno.",
  field_es: "La cantidad de aire de suministro y el patrón de alcance del difusor deben coincidir con la disposición real del cuarto — un caudal de suministro correctamente calculado pero entregado a través de un difusor mal ubicado todavía puede dejar zonas muertas o corrientes de aire."
},
{
  id: "tank",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Tank",
  def_en: "A vessel used for the storage of liquids, distinguished from a pressure vessel by not being designed to hold contents at a pressure substantially above ambient.",
  field_en: "The line between \"tank\" and \"pressure vessel\" classification depends on actual design pressure, not appearance — a storage tank that's mistakenly pressurized beyond its design intent needs to be re-evaluated under pressure vessel requirements, not treated as a simple tank issue.",
  term_es: "Tanque",
  def_es: "Un recipiente usado para el almacenamiento de líquidos, distinguido de un recipiente a presión por no estar diseñado para contener su contenido a una presión sustancialmente por encima de la ambiental.",
  field_es: "La línea entre la clasificación de \"tanque\" y \"recipiente a presión\" depende de la presión de diseño real, no de la apariencia — un tanque de almacenamiento que por error se presuriza más allá de su intención de diseño necesita reevaluarse bajo los requisitos de recipiente a presión, no tratarse como un simple asunto de tanque."
},
{
  id: "temperature-relief-valve",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Temperature Relief Valve",
  def_en: "A temperature-actuated valve designed to open automatically at a predetermined temperature to protect a vessel or system from excessive temperature.",
  field_en: "Combined temperature-and-pressure relief valves are common on water heaters and boilers — verify both the temperature AND pressure ratings are correctly matched to the vessel, since a valve rated correctly for one but not the other still leaves a gap in protection.",
  term_es: "Válvula de Alivio de Temperatura",
  def_es: "Una válvula accionada por temperatura diseñada para abrir automáticamente a una temperatura predeterminada para proteger un recipiente o sistema de temperatura excesiva.",
  field_es: "Las válvulas combinadas de alivio de temperatura y presión son comunes en calentadores de agua y calderas — verifique que ambas clasificaciones, de temperatura Y de presión, coincidan correctamente con el recipiente, ya que una válvula correctamente clasificada para una pero no la otra de todos modos deja un vacío en la protección."
},
{
  id: "testing-agency",
  cat: "General",
  term_en: "Testing Agency",
  def_en: "An organization determined by the code official to possess the required equipment, staff qualifications, and experience to conduct tests specified by the applicable code.",
  field_en: "Confirming a testing agency's accreditation and scope of approval before a required field test (rather than after) avoids the scenario of a test result being rejected on procedural grounds even when the underlying result was fine.",
  term_es: "Agencia de Pruebas",
  def_es: "Una organización determinada por el oficial de código para poseer el equipo requerido, calificaciones de personal, y experiencia para realizar las pruebas especificadas por el código aplicable.",
  field_es: "Confirmar la acreditación y el alcance de aprobación de una agencia de pruebas antes de una prueba de campo requerida (en lugar de después) evita el escenario de que un resultado de prueba sea rechazado por motivos de procedimiento aunque el resultado subyacente estuviera bien."
},
{
  id: "thermostat",
  cat: "General",
  term_en: "Thermostat",
  def_en: "An automatic control device responsive to temperature, used to maintain a desired temperature by cycling heating or cooling equipment.",
  field_en: "Thermostat sensor location has an outsized effect on comfort and equipment cycling — a thermostat placed near a supply diffuser, in direct sun, or on an exterior wall will read unrepresentative temperatures and cause the equipment to short-cycle or under-condition the actual occupied space.",
  term_es: "Termostato",
  def_es: "Un dispositivo de control automático sensible a la temperatura, usado para mantener una temperatura deseada ciclando el equipo de calefacción o enfriamiento.",
  field_es: "La ubicación del sensor del termostato tiene un efecto desproporcionado sobre el confort y el ciclado del equipo — un termostato colocado cerca de un difusor de suministro, bajo sol directo, o en un muro exterior leerá temperaturas no representativas y hará que el equipo cicle en corto o subacondicione el espacio realmente ocupado."
},
{
  id: "toxic-gas",
  cat: "General",
  term_en: "Toxic Gas",
  def_en: "A gas classified as highly toxic or toxic based on standardized acute toxicity testing.",
  field_en: "Toxic gas piping and storage carry among the strictest code provisions in the mechanical code (continuous monitoring, emergency shutoff, dedicated exhaust) — confirm early in design whether any process gas actually meets this classification, since it reshapes the entire room's mechanical scope.",
  term_es: "Gas Tóxico",
  def_es: "Un gas clasificado como altamente tóxico o tóxico con base en pruebas estandarizadas de toxicidad aguda.",
  field_es: "La tubería y almacenamiento de gas tóxico llevan algunas de las disposiciones más estrictas del código mecánico (monitoreo continuo, corte de emergencia, extracción dedicada) — confirme desde el inicio del diseño si algún gas de proceso realmente cumple esta clasificación, ya que reconfigura todo el alcance mecánico del cuarto."
},
{
  id: "transfer-air",
  cat: "Air Systems & Ventilation",
  term_en: "Transfer Air",
  def_en: "Air moved from one interior space to another, typically through a transfer grille, duct, or undercut door, rather than being supplied directly from the air handling system.",
  field_en: "Transfer air paths need to be verified for actual open, unobstructed area — a transfer grille painted shut or a door undercut later carpeted over silently defeats the ventilation and pressure-relationship design that depended on it.",
  term_es: "Aire de Transferencia",
  def_es: "Aire movido de un espacio interior a otro, típicamente a través de una rejilla de transferencia, ducto, o corte bajo puerta, en lugar de ser suministrado directamente desde el sistema de manejo de aire.",
  field_es: "Las rutas de aire de transferencia necesitan verificarse por su área realmente abierta y sin obstrucciones — una rejilla de transferencia pintada y sellada o un corte bajo puerta cubierto después por alfombra anula silenciosamente el diseño de ventilación y relación de presión que dependía de ella."
},
{
  id: "type-l-vent",
  cat: "Venting & Chimneys",
  term_en: "Vent, Type L",
  def_en: "A listed and labeled factory-made vent, or a special material or type of vent, tested and identified for use with oil-burning appliances that are listed for use with this type of venting.",
  field_en: "A Type L vent cannot be substituted for a Type B gas vent, or vice versa — confirm the actual appliance's listed vent category and use the matching vent type, since mismatching them is a code violation and a safety hazard, not a minor substitution.",
  term_es: "Venteo, Tipo L",
  def_es: "Un venteo fabricado en fábrica, listado y etiquetado, o un material o tipo especial de venteo, probado e identificado para uso con aparatos de combustión de aceite que están listados para usarse con este tipo de venteo.",
  field_es: "Un venteo Tipo L no puede sustituirse por un venteo de gas Tipo B, ni viceversa — confirme la categoría de venteo listada del aparato real y use el tipo de venteo correspondiente, ya que combinarlos incorrectamente es una violación de código y un riesgo de seguridad, no una sustitución menor."
},
{
  id: "underfloor-air-distribution",
  cat: "Air Systems & Ventilation",
  term_en: "Underfloor Air Distribution System",
  def_en: "A ventilation and space-conditioning approach that uses the open cavity beneath a raised access floor as a supply air plenum, delivering air through floor-mounted diffusers.",
  field_en: "Underfloor plenums have their own airtightness, fire-rating, and cable-management coordination requirements distinct from an overhead ducted system — confirm floor-panel sealing and electrical/data cable routing don't compromise the plenum's static pressure or fire performance.",
  term_es: "Sistema de Distribución de Aire Bajo Piso",
  def_es: "Un enfoque de ventilación y acondicionamiento de espacio que usa la cavidad abierta debajo de un piso de acceso elevado como plenum de aire de suministro, entregando aire a través de difusores montados en el piso.",
  field_es: "Los plenums bajo piso tienen sus propios requisitos de hermeticidad, clasificación contra incendio, y coordinación de manejo de cables distintos a un sistema ducteado aéreo — confirme que el sellado de los paneles de piso y el ruteo de cables eléctricos/de datos no comprometan la presión estática o el desempeño contra incendio del plenum."
},
{
  id: "unit-heater",
  cat: "Appliances & Combustion",
  term_en: "Unit Heater",
  def_en: "A self-contained, fuel-burning or electric heating appliance with an integral fan, designed for suspended or floor mounting, that heats a space directly without ductwork.",
  field_en: "Unit heaters are typically installed high in warehouse or shop spaces — confirm mounting height and airflow throw pattern actually reach the occupied working level, since a unit heater mounted too high can leave the floor-level work zone under-heated despite adequate rated capacity.",
  term_es: "Calentador Unitario (Unit Heater)",
  def_es: "Un aparato de calefacción autónomo, de combustible o eléctrico, con un ventilador integral, diseñado para montaje suspendido o en piso, que calienta un espacio directamente sin ductos.",
  field_es: "Los calentadores unitarios típicamente se instalan en lo alto de bodegas o talleres — confirme que la altura de montaje y el patrón de alcance del flujo de aire realmente lleguen al nivel de trabajo ocupado, ya que un calentador unitario montado demasiado alto puede dejar la zona de trabajo a nivel de piso sub-calentada a pesar de tener capacidad nominal adecuada."
},
{
  id: "unusually-tight-construction",
  cat: "General",
  term_en: "Unusually Tight Construction",
  def_en: "Construction meeting specified air leakage and vapor retarder criteria, indicating a building envelope tight enough that combustion air and makeup air cannot be assumed to infiltrate naturally.",
  field_en: "Buildings meeting this classification cannot rely on incidental envelope leakage to supply combustion air to fuel-fired appliances — dedicated combustion air openings sized per code become mandatory, not optional, in these buildings.",
  term_es: "Construcción Inusualmente Hermética",
  def_es: "Construcción que cumple criterios específicos de fuga de aire y retardador de vapor, indicando una envolvente de edificio suficientemente hermética como para que no pueda asumirse que el aire de combustión y de reposición infiltren naturalmente.",
  field_es: "Los edificios que cumplen esta clasificación no pueden depender de fugas incidentales de la envolvente para suministrar aire de combustión a aparatos de combustible — las aberturas dedicadas de aire de combustión dimensionadas según código se vuelven obligatorias, no opcionales, en estos edificios."
},
{
  id: "vapor-barrier",
  cat: "General",
  term_en: "Vapor Barrier (Vapor Retarder)",
  def_en: "A material or assembly that adequately retards the transmission of water vapor, typically installed on the warm side of insulated piping, ductwork, or building assemblies.",
  field_en: "A punctured or discontinuous vapor barrier on cold-surface insulation (chilled water piping, refrigerant lines) is a leading cause of condensation and mold growth — confirm vapor barrier continuity at every support, hanger, and fitting, not just along straight runs.",
  term_es: "Barrera de Vapor (Retardador de Vapor)",
  def_es: "Un material o ensamble que retarda adecuadamente la transmisión de vapor de agua, típicamente instalado en el lado cálido de tubería, ductos, o ensambles de edificio aislados.",
  field_es: "Una barrera de vapor perforada o discontinua en aislamiento de superficie fría (tubería de agua enfriada, líneas de refrigerante) es una causa principal de condensación y crecimiento de moho — confirme la continuidad de la barrera de vapor en cada soporte, colgante, y accesorio, no solo a lo largo de corridas rectas."
},
{
  id: "vapor-recovery-system",
  cat: "General",
  term_en: "Vapor Recovery System",
  def_en: "A system designed to capture and recover vapors released during the storage, transfer, or dispensing of a volatile liquid, preventing their release to the atmosphere.",
  field_en: "Vapor recovery equipment is process-specific — confirm the system's design basis actually matches the volatile liquid in use, since a vapor recovery system sized for one liquid's vapor pressure characteristics won't perform correctly on a different one.",
  term_es: "Sistema de Recuperación de Vapor",
  def_es: "Un sistema diseñado para capturar y recuperar vapores liberados durante el almacenamiento, transferencia, o dispensado de un líquido volátil, previniendo su liberación a la atmósfera.",
  field_es: "El equipo de recuperación de vapor es específico al proceso — confirme que la base de diseño del sistema realmente coincida con el líquido volátil en uso, ya que un sistema de recuperación de vapor dimensionado para las características de presión de vapor de un líquido no funcionará correctamente con uno diferente."
},
{
  id: "variable-air-volume-system",
  cat: "Air Systems & Ventilation",
  term_en: "Variable Air Volume (VAV) System",
  def_en: "An air distribution system that varies the volume of supply air delivered to a space while maintaining a relatively constant supply air temperature, typically using terminal boxes with modulating dampers.",
  field_en: "VAV systems need minimum airflow setpoints maintained at each box to preserve ventilation rates even when the cooling/heating load is low — a VAV box that modulates all the way to zero can silently starve a zone's required outdoor air.",
  term_es: "Sistema de Volumen de Aire Variable (VAV)",
  def_es: "Un sistema de distribución de aire que varía el volumen de aire de suministro entregado a un espacio mientras mantiene una temperatura de aire de suministro relativamente constante, típicamente usando cajas terminales con compuertas moduladoras.",
  field_es: "Los sistemas VAV necesitan mantener puntos de ajuste de caudal mínimo en cada caja para preservar las tasas de ventilación incluso cuando la carga de enfriamiento/calefacción es baja — una caja VAV que modula hasta cero puede privar silenciosamente a una zona del aire exterior requerido."
},
{
  id: "vehicle-repair-garage",
  cat: "General",
  term_en: "Vehicle Repair Garage",
  def_en: "A building or portion of a building used for repair, servicing, or fueling of self-propelled vehicles, including associated storage of flammable/combustible liquids or gases.",
  field_en: "Vehicle repair garages typically require mechanical ventilation sized for vehicle exhaust and any flammable vapor sources, plus specific equipment-location and ignition-source clearances — confirm this classification early, since it drives ventilation rate and equipment room requirements well above a typical parking garage.",
  term_es: "Garaje de Reparación de Vehículos",
  def_es: "Un edificio o parte de un edificio usado para reparación, servicio, o abastecimiento de combustible de vehículos autopropulsados, incluyendo el almacenamiento asociado de líquidos o gases inflamables/combustibles.",
  field_es: "Los garajes de reparación de vehículos típicamente requieren ventilación mecánica dimensionada para el escape de vehículos y cualquier fuente de vapor inflamable, además de separaciones específicas de ubicación de equipo y fuente de ignición — confirme esta clasificación temprano, ya que determina la tasa de ventilación y los requisitos de cuarto de equipo muy por encima de un estacionamiento típico."
},
{
  id: "vent",
  cat: "Venting & Chimneys",
  term_en: "Vent",
  def_en: "A pipe or other conduit composed of factory-made components, listed and labeled for use in venting an appliance, conducting flue gases to the outdoor atmosphere.",
  field_en: "\"Vent\" (factory-made, listed venting) and \"chimney\" (typically field-built masonry or factory-built chimney system) are governed by different construction and clearance standards — confirm which classification actually applies to the installation in front of you before applying either standard.",
  term_es: "Venteo (Vent)",
  def_es: "Un tubo u otro conducto compuesto de componentes fabricados en fábrica, listado y etiquetado para uso en el venteo de un aparato, conduciendo los gases de combustión hacia la atmósfera exterior.",
  field_es: "\"Venteo\" (venteo fabricado en fábrica, listado) y \"chimenea\" (típicamente mampostería construida en campo o sistema de chimenea fabricado en fábrica) se rigen por normas de construcción y separación diferentes — confirme qué clasificación realmente aplica a la instalación frente a usted antes de aplicar cualquiera de las dos normas."
},
{
  id: "vent-connector",
  cat: "Venting & Chimneys",
  term_en: "Vent Connector",
  def_en: "The pipe or duct that connects a fuel-fired appliance to a vent or chimney.",
  field_en: "Vent connector slope, length, and support requirements are separate from the vent/chimney's own requirements — a correctly sized chimney can still fail to draft properly if the connector between the appliance and the chimney is undersized, oversized, or improperly sloped.",
  term_es: "Conector de Venteo",
  def_es: "El tubo o ducto que conecta un aparato de combustible a un venteo o chimenea.",
  field_es: "Los requisitos de pendiente, longitud, y soporte del conector de venteo son independientes de los requisitos del venteo/chimenea mismo — una chimenea correctamente dimensionada todavía puede fallar en tirar adecuadamente si el conector entre el aparato y la chimenea está sub o sobredimensionado, o mal inclinado."
},
{
  id: "vent-damper-device",
  cat: "Venting & Chimneys",
  term_en: "Vent Damper Device, Automatic",
  def_en: "A listed device installed in the venting system of an individual, automatically-operated, fuel-fired appliance, designed to automatically open the venting system when the appliance is in operation and close it when the appliance is off.",
  field_en: "Automatic vent dampers save standby heat loss but must be interlocked with the appliance's burner controls — a vent damper that fails closed while the burner fires is a carbon monoxide hazard, which is why these devices require listing and correct wiring, never a generic add-on damper.",
  term_es: "Dispositivo Automático de Compuerta de Venteo",
  def_es: "Un dispositivo listado instalado en el sistema de venteo de un aparato de combustible individual, de operación automática, diseñado para abrir automáticamente el sistema de venteo cuando el aparato está en operación y cerrarlo cuando el aparato está apagado.",
  field_es: "Las compuertas automáticas de venteo ahorran pérdida de calor en espera pero deben estar enclavadas con los controles del quemador del aparato — una compuerta de venteo que falla cerrada mientras el quemador enciende es un riesgo de monóxido de carbono, por lo cual estos dispositivos requieren listado y cableado correcto, nunca una compuerta genérica agregada."
},
{
  id: "vent-gases",
  cat: "Venting & Chimneys",
  term_en: "Vent Gases",
  def_en: "Products of combustion from fuel-fired appliances, plus excess air and dilution air, present in the venting system above the draft hood or draft regulator.",
  field_en: "Vent gas temperature and moisture content determine whether a venting material needs to be Category I (non-condensing) or Category II-IV (condensing-capable) rated — confirm the appliance's actual vent category before specifying vent material, since a mismatch here causes premature vent failure from condensate corrosion.",
  term_es: "Gases de Venteo",
  def_es: "Productos de combustión de aparatos de combustible, más aire en exceso y aire de dilución, presentes en el sistema de venteo por encima de la campana de tiro o el regulador de tiro.",
  field_es: "La temperatura y el contenido de humedad de los gases de venteo determinan si un material de venteo necesita clasificación Categoría I (no condensante) o Categoría II-IV (con capacidad de condensación) — confirme la categoría de venteo real del aparato antes de especificar el material de venteo, ya que un desajuste aquí causa falla prematura del venteo por corrosión de condensado."
},
{
  id: "ventilation",
  cat: "Air Systems & Ventilation",
  term_en: "Ventilation",
  def_en: "The process of supplying and removing air, by natural or mechanical means, to or from a space.",
  field_en: "Ventilation requirements are calculated separately for occupant-based (people) and area-based (floor area) components under IMC Chapter 4 — confirm both components are included in a calculation, since using only one systematically undersizes the required outdoor air rate.",
  term_es: "Ventilación",
  def_es: "El proceso de suministrar y remover aire, por medios naturales o mecánicos, hacia o desde un espacio.",
  field_es: "Los requisitos de ventilación se calculan por separado para los componentes basados en ocupantes (personas) y basados en área (área de piso) bajo el Capítulo 4 del IMC — confirme que ambos componentes estén incluidos en un cálculo, ya que usar solo uno subdimensiona sistemáticamente la tasa de aire exterior requerida."
},
{
  id: "ventilation-air",
  cat: "Air Systems & Ventilation",
  term_en: "Ventilation Air",
  def_en: "That portion of supply air consisting of outdoor air plus any recirculated air that has been treated to maintain acceptable indoor air quality.",
  field_en: "Ventilation air is a subset of total supply air, not the entire supply airflow — confirm a submittal's stated \"ventilation rate\" is actually outdoor air, not the full supply CFM, before using it to verify code compliance.",
  term_es: "Aire de Ventilación",
  def_es: "Esa porción del aire de suministro que consiste en aire exterior más cualquier aire recirculado que haya sido tratado para mantener una calidad de aire interior aceptable.",
  field_es: "El aire de ventilación es un subconjunto del aire de suministro total, no todo el caudal de suministro — confirme que la \"tasa de ventilación\" declarada en una presentación sea realmente aire exterior, no el CFM de suministro total, antes de usarla para verificar el cumplimiento de código."
},
{
  id: "waste-heat-boiler",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Waste Heat Boiler",
  def_en: "A boiler that derives its heat energy from the recovered exhaust gases or waste heat of another process, rather than from dedicated fuel combustion.",
  field_en: "Waste heat boiler output is tied to the availability and consistency of the source process — confirm the actual process operating schedule and heat availability before relying on it as a primary (rather than supplemental) heat source.",
  term_es: "Caldera de Calor Residual",
  def_es: "Una caldera que deriva su energía calorífica de los gases de escape recuperados o el calor residual de otro proceso, en lugar de la combustión de combustible dedicado.",
  field_es: "La salida de una caldera de calor residual está ligada a la disponibilidad y consistencia del proceso fuente — confirme el programa de operación real del proceso y la disponibilidad de calor antes de depender de ella como fuente de calor primaria (en lugar de suplementaria)."
},
{
  id: "water-heater",
  cat: "Boilers, Piping & Pressure Vessels",
  term_en: "Water Heater",
  def_en: "An appliance designed primarily to supply hot water for domestic or commercial purposes, distinct from a boiler used for space heating.",
  field_en: "Water heater and boiler code paths diverge even for similar-looking equipment — confirm the actual intended use (potable hot water vs. space heating) before applying installation, venting, and relief-valve provisions from the wrong category.",
  term_es: "Calentador de Agua",
  def_es: "Un aparato diseñado principalmente para suministrar agua caliente para propósitos domésticos o comerciales, distinto de una caldera usada para calefacción de espacio.",
  field_es: "Las rutas de código de calentador de agua y caldera divergen incluso para equipo de apariencia similar — confirme el uso previsto real (agua caliente potable vs. calefacción de espacio) antes de aplicar disposiciones de instalación, venteo, y válvula de alivio de la categoría equivocada."
},
{
  id: "zone",
  cat: "Air Systems & Ventilation",
  term_en: "Zone",
  def_en: "A space or group of spaces within a building with sufficiently similar heating and cooling requirements that a single controlling device can adequately control the conditions in that space or group of spaces.",
  field_en: "A zone's thermostat controls the whole zone, so grouping rooms with genuinely different load profiles (a sunny perimeter office with an interior conference room) into one zone is a common design shortcut that produces persistent comfort complaints.",
  term_es: "Zona",
  def_es: "Un espacio o grupo de espacios dentro de un edificio con requisitos de calefacción y enfriamiento suficientemente similares como para que un solo dispositivo de control pueda controlar adecuadamente las condiciones de ese espacio o grupo de espacios.",
  field_es: "El termostato de una zona controla toda la zona, así que agrupar cuartos con perfiles de carga genuinamente diferentes (una oficina perimetral soleada con una sala de conferencias interior) en una sola zona es un atajo de diseño común que produce quejas de confort persistentes."
}
];

window.IMC_GLOSSARY_META = { updated: "2026-08-17", batch: 4, count: 219 };
