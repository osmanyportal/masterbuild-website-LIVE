// mb-enhancements.jsx  -  FAQ, Comparison Strip, Floating Mobile CTA, useCountUp

// ─── useCountUp ────────────────────────────────────────────────────────────
// Usage: const [display, ref] = useCountUp("105+")
// Counts up when element scrolls into view.
function useCountUp(targetRaw, duration = 1400) {
  const [display, setDisplay] = React.useState(" - ");
  const ref = React.useRef(null);
  const hasRun = React.useRef(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const m = String(targetRaw).match(/^([\d.]+)(.*)/);
    if (!m) {
      setDisplay(String(targetRaw));
      return;
    }
    const numTarget = parseFloat(m[1]);
    const suffix = m[2] || "";
    const isInt = Number.isInteger(numTarget);
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting || hasRun.current) return;
      hasRun.current = true;
      let startTs = null;
      const step = ts => {
        if (!startTs) startTs = ts;
        const p = Math.min((ts - startTs) / duration, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        const cur = eased * numTarget;
        setDisplay((isInt ? Math.round(cur) : cur.toFixed(1)) + suffix);
        if (p < 1) requestAnimationFrame(step);else setDisplay(String(targetRaw));
      };
      requestAnimationFrame(step);
    }, {
      threshold: 0.35
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return [display, ref];
}
window.useCountUp = useCountUp;

// ─── FAQ Data ──────────────────────────────────────────────────────────────
const FAQ_DATA = {
  en: {
    eyebrow: "/ FAQ",
    headline: "Questions before the first call.",
    sub: "Answers to what most qualified prospects want to know before reaching out. General code or permitting questions are better answered in the free Daily Code Talk archive. If your question is project-specific, include it in the inquiry.",
    items: [{
      q: "Do commercial building permits require MEP drawings?",
      a: "In most jurisdictions, yes. Commercial projects, tenant improvements, and multifamily construction typically require coordinated HVAC, plumbing, and electrical drawings stamped by a licensed engineer. The required disciplines and documentation depth vary by project type and local building department. Masterbuild prepares permit-ready MEP sets built around specific jurisdiction expectations  -  not generic templates."
    }, {
      q: "What does 'PE-led' MEP consulting mean in practice?",
      a: "It means Osmany Portal, PE directly reviews and coordinates every drawing set, makes every technical call, and is the primary point of contact throughout the project. There is no project manager between you and the engineer. The PE on the drawings is the PE running the scope  -  and that matters for drawing quality, permit comment turnaround, and the reliability of answers you get."
    }, {
      q: "How does the fixed-fee model work?",
      a: "After reviewing your project background, Masterbuild issues a written proposal with a defined scope, deliverables, milestone structure, and a fixed fee. There is no hourly billing for standard permit scopes. If the scope changes materially, a written amendment is issued before additional work begins. The retainer paid at signing is applied to your first milestone."
    }, {
      q: "Can Masterbuild support existing-building feasibility reports?",
      a: "Yes. Masterbuild supports existing commercial-building feasibility assessments where MEP and plumbing-system judgment are needed before a client commits capital. Typical support includes existing-condition review, plumbing-system risk assessment, capacity questions, code-sensitive constraints, and clear path-forward notes that can fit into a larger feasibility report."
    }, {
      q: "Where is Masterbuild licensed and available for project support?",
      a: "Masterbuild is Florida-licensed and Miami-based. Project support in Texas, New Jersey, New York, and Pennsylvania is reviewed by request based on scope, licensure requirements, teaming needs, and jurisdiction expectations. Contact us to confirm whether your jurisdiction is available and what the right project path looks like for your scope."
    }, {
      q: "What's included in a permit-level MEP drawing set?",
      a: "A complete permit-level set typically includes equipment schedules, load calculations, floor-plan layouts for each discipline, specifications, code-compliance notes, and coordination details. The exact deliverables depend on project type, jurisdiction requirements, and the disciplines in scope. Masterbuild proposals define exactly what is and is not included."
    }, {
      q: "How long does MEP design take?",
      a: "Timeline depends on project type, scope complexity, queue position, and how complete the background information is at the start. A well-scoped tenant improvement with complete architectural drawings can move significantly faster than a complex new construction scope. Masterbuild provides a realistic schedule in every proposal  -  not an optimistic estimate."
    }, {
      q: "How fast can you start?",
      a: "Start timing depends on current queue position and how complete your project background is at the inquiry stage. Masterbuild provides a realistic start date in every proposal  -  not a placeholder to win the job. Projects with complete architectural drawings and a well-defined scope can typically be scheduled within a few weeks of signed agreement. Complex or larger scopes may require a longer lead time. The best way to confirm availability is to send a project inquiry."
    }, {
      q: "Do you work on residential and multifamily projects?",
      a: "Yes. High-end custom homes, premium residential renovations, condominium buildings, and mixed-use multifamily are active project types. The same PE-led, permit-minded model applies regardless of occupancy type or finish level."
    }, {
      q: "What is mission-critical MEP?",
      a: "Mission-critical MEP refers to mechanical, electrical, and plumbing design for environments where system downtime carries significant operational, safety, or financial consequences  -  data centers, server rooms, medical and ambulatory care facilities, clean rooms, and similar high-reliability spaces. These scopes require careful attention to redundancy, ventilation, pressurization, electrical distribution, controls interfaces, and code compliance well beyond standard permit documentation."
    }, {
      q: "Does Masterbuild carry professional liability insurance?",
      a: "Yes. Masterbuild Consulting maintains active professional liability (errors and omissions) coverage and general liability insurance appropriate for sealed MEP work. Certificates of Insurance with named additional insureds are issued on request once an engagement is active. Coverage limits and additional-insured endorsements can be confirmed during scope review for projects that require specific minimums."
    }, {
      q: "Can Masterbuild provide Miami-Dade private-provider plan review or inspections?",
      a: "Private-provider plan review and inspection are not currently offered. This service remains on hold until firm registration and the required professional liability coverage are verified and the owner authorizes its release. Project-specific eligibility and professional-responsibility checks would still apply."
    }, {
      q: "Can Masterbuild help with Electrical Building Recertification?",
      a: "Yes - Masterbuild provides Electrical Building Recertification readiness for owners and managers: defined electrical-system technical review, existing-record and field-documentation coordination, and a controlled scope path. Before any report work is accepted, we confirm the notice or case, jurisdiction, records, access, requested scope, and responsible electrical-discipline professional. The qualified responsible professional independently confirms authority before any County recertification report is offered, signed, sealed, or filed."
    }, {
      q: "How are revisions and change orders handled mid-project?",
      a: "Minor refinements within the agreed scope are part of the original fixed fee. If the project itself changes  -  added square footage, new disciplines, jurisdiction or occupancy change, scope additions during permit review  -  a written change-order amendment is issued before any additional work begins. The amendment defines the new scope, the additional fee, and any schedule impact."
    }, {
      q: "Is Spanish-language project communication available?",
      a: "Yes. Bilingual project communication  -  meetings, emails, redline reviews, and code-discussion documents in English or Spanish  -  is available as a premium service. The same PE handles both languages directly, which matters when nuanced code logic is being negotiated with an AHJ, owner, or architect. Available across all engagement types; confirmed at proposal."
    }, {
      q: "Do you offer free consultations or pre-proposal calls?",
      a: "The Daily Code Talk archive is free and covers code logic in depth  -  it answers most general questions without a call. For project-specific questions, the 30-minute scoping call is for fit and timing, not free engineering. If your project is real and you have background information to share, send a project inquiry directly  -  that moves faster than a call and produces a more accurate proposal."
    }, {
      q: "What makes a strong project inquiry?",
      a: "The best inquiries include: project address or jurisdiction, current design stage, disciplines needed, existing drawings or background files, the actual decision or question on the table, and any permit deadline or timeline constraint. The more specific the inquiry, the faster Masterbuild can respond with a real proposal path  -  not a round of back-and-forth."
    }],
    cta: "Send project background"
  },
  es: {
    eyebrow: "/ Preguntas Frecuentes",
    headline: "Preguntas antes de la primera llamada.",
    sub: "Respuestas a lo que la mayoría de los clientes calificados quieren saber antes de contactarnos. Las preguntas generales de código o permisos tienen mejor respuesta en el archivo gratuito de Daily Code Talk. Si su pregunta es específica al proyecto, inclúyala en la consulta.",
    items: [{
      q: "¿Los permisos de construcción comercial requieren planos MEP?",
      a: "En la mayoría de las jurisdicciones, sí. Los proyectos comerciales, las mejoras de inquilinos y la construcción multifamiliar generalmente requieren planos de diseño coordinados de HVAC, plomería, protección contra incendios y electricidad sellados por un ingeniero licenciado. Las disciplinas requeridas varían según el tipo de proyecto y el departamento local. Masterbuild prepara paquetes MEP listos para permisos en torno a las expectativas específicas de la jurisdicción, no plantillas genéricas."
    }, {
      q: "¿Qué significa consultoría MEP 'liderada por PE' en la práctica?",
      a: "Significa que Osmany Portal, PE revisa y coordina directamente cada conjunto de planos, toma cada decisión técnica y es el punto de contacto principal durante todo el proyecto. No hay gerente de proyecto entre usted y el ingeniero. El PE en los planos es el PE que gestiona el alcance  -  y eso importa para la calidad del plano, la respuesta a comentarios de permiso y la confiabilidad de las respuestas que recibe."
    }, {
      q: "¿Cómo funciona el modelo de precio fijo?",
      a: "Después de revisar los antecedentes de su proyecto, Masterbuild emite una propuesta escrita con un alcance definido, entregables, estructura de hitos y un honorario fijo. No hay facturación por hora para alcances de permisos estándar. Si el alcance cambia, se emite una enmienda escrita antes de iniciar trabajo adicional. El anticipo se aplica al primer hito."
    }, {
      q: "¿Puede Masterbuild apoyar informes de factibilidad para edificios existentes?",
      a: "Sí. Masterbuild apoya evaluaciones de factibilidad para edificios comerciales existentes cuando se necesita juicio MEP y de sistemas de plomería antes de comprometer capital. El soporte típico incluye revisión de condiciones existentes, evaluación de riesgo del sistema de plomería, preguntas de capacidad, restricciones sensibles al código y notas claras de camino a seguir para integrarse en un informe de factibilidad más amplio."
    }, {
      q: "¿Dónde está licenciado Masterbuild y dónde puede apoyar proyectos?",
      a: "Masterbuild tiene licencia de Florida y está ubicado en Miami. El apoyo en Texas, New Jersey, New York y Pennsylvania se revisa por solicitud según alcance, requisitos de licencia, necesidades de equipo y expectativas de la jurisdicción. Contáctenos para confirmar disponibilidad y la ruta adecuada para su alcance."
    }, {
      q: "¿Qué incluye un conjunto de planos MEP para permisos?",
      a: "Un conjunto completo generalmente incluye listas de equipos, cálculos de carga, diseños de planta por disciplina, especificaciones, notas de cumplimiento del código y detalles de coordinación. Los entregables exactos dependen del tipo de proyecto, requisitos de la jurisdicción y disciplinas en alcance. Las propuestas de Masterbuild definen exactamente qué está y qué no está incluido."
    }, {
      q: "¿Cuánto tiempo lleva el diseño MEP?",
      a: "El plazo depende del tipo de proyecto, la complejidad del alcance, la posición en la cola y qué tan completa esté la información al inicio. Una mejora de inquilino bien definida puede avanzar significativamente más rápido que un proyecto de nueva construcción complejo. Masterbuild proporciona un cronograma realista en cada propuesta."
    }, {
      q: "¿Qué tan rápido pueden comenzar?",
      a: "El tiempo de inicio depende de la posición actual en la cola y qué tan completa esté la información del proyecto al momento de la consulta. Masterbuild proporciona una fecha de inicio realista en cada propuesta  -  no un marcador de posición para ganar el trabajo. Los proyectos con planos arquitectónicos completos y un alcance bien definido generalmente pueden ser programados dentro de pocas semanas de la firma del contrato. Los proyectos complejos o de mayor alcance pueden requerir un tiempo de espera más largo. La mejor manera de confirmar disponibilidad es enviar una consulta de proyecto."
    }, {
      q: "¿Trabajan en proyectos residenciales y multifamiliares?",
      a: "Sí. Las casas personalizadas de alto nivel, las renovaciones residenciales premium, los edificios de condominios y el uso mixto multifamiliar son tipos de proyectos activos. El mismo modelo liderado por PE se aplica independientemente del tipo de ocupación."
    }, {
      q: "¿Qué es el MEP de misión crítica?",
      a: "El MEP de misión crítica se refiere al diseño para entornos donde el tiempo de inactividad tiene consecuencias operativas, de seguridad o financieras significativas: centros de datos, salas de servidores, instalaciones médicas, salas limpias. Estos alcances requieren atención cuidadosa a redundancia, ventilación, presurización y cumplimiento del código más allá de la documentación estándar."
    }, {
      q: "¿Masterbuild cuenta con seguro de responsabilidad profesional?",
      a: "Sí. Masterbuild Consulting mantiene cobertura activa de responsabilidad profesional (errores y omisiones) y seguro de responsabilidad general apropiado para trabajo MEP sellado. Los certificados de seguro con asegurados adicionales nombrados se emiten bajo solicitud una vez que el contrato está activo. Los límites de cobertura y los endosos de asegurado adicional se pueden confirmar durante la revisión del alcance para proyectos que requieran mínimos específicos."
    }, {
      q: "¿Puede Masterbuild proporcionar revisión de planos o inspecciones por proveedor privado en Miami-Dade?",
      a: "Actualmente no se ofrecen revisión de planos ni inspecciones por proveedor privado. Este servicio permanece en espera hasta verificar el registro de la empresa y la cobertura de responsabilidad profesional requerida, y contar con autorización del propietario de MasterBuild para ofrecerlo. También se requerirían verificaciones de elegibilidad y responsabilidad profesional específicas del proyecto."
    }, {
      q: "¿Puede Masterbuild ayudar con Recertificación Eléctrica de Edificios?",
      a: "Sí - Masterbuild ofrece preparación para Recertificación Eléctrica de Edificios: revisión técnica eléctrica definida, coordinación de registros existentes y documentación de campo, y una ruta de alcance controlada. Antes de aceptar trabajo de informe, confirmamos el aviso o caso, jurisdicción, registros, acceso, alcance solicitado y el profesional responsable de la disciplina eléctrica. El profesional responsable calificado confirma su autoridad de manera independiente antes de que se ofrezca, firme, selle o presente un informe de recertificación del Condado."
    }, {
      q: "¿Cómo se manejan las revisiones y órdenes de cambio durante el proyecto?",
      a: "Los ajustes menores dentro del alcance acordado son parte del honorario original. Si el proyecto cambia  -  área adicional, nuevas disciplinas, cambio de jurisdicción o uso, adiciones de alcance durante la revisión del permiso  -  se emite una enmienda escrita de cambio de orden antes de iniciar trabajo adicional. La enmienda define el nuevo alcance, el honorario adicional y cualquier impacto en el cronograma."
    }, {
      q: "¿Está disponible la comunicación del proyecto en español?",
      a: "Sí. La comunicación bilingüe del proyecto  -  reuniones, correos, revisiones de redlines y documentos de discusión de código en inglés o español  -  está disponible como servicio premium. El mismo PE maneja ambos idiomas directamente, lo que importa cuando se negocia lógica de código con un AHJ, propietario o arquitecto. Disponible en todos los tipos de contrato; se confirma en la propuesta."
    }, {
      q: "¿Ofrecen consultas gratuitas o llamadas previas a la propuesta?",
      a: "El archivo de Daily Code Talk es gratuito y cubre la lógica del código en profundidad  -  responde la mayoría de preguntas generales sin necesidad de una llamada. Para preguntas específicas al proyecto, la llamada de alcance de 30 minutos es para evaluar encaje y tiempos, no para ingeniería gratuita. Si su proyecto es real y tiene información de antecedentes para compartir, envíe una consulta directamente  -  eso avanza más rápido y produce una propuesta más precisa."
    }, {
      q: "¿Qué hace que una consulta de proyecto sea sólida?",
      a: "Las mejores consultas incluyen: dirección del proyecto o jurisdicción, etapa actual de diseño, disciplinas requeridas, planos existentes o archivos de antecedentes, la pregunta o decisión real en juego, y cualquier fecha límite de permiso. Cuanto más específica sea la consulta, más rápido puede Masterbuild responder con una ruta de propuesta real."
    }],
    cta: "Enviar antecedentes del proyecto"
  }
};

// ─── FAQ Section ───────────────────────────────────────────────────────────
function MBFAQ({
  lang,
  tweaks
}) {
  const t = FAQ_DATA[lang];
  const accent = tweaks.accent;
  const [open, setOpen] = React.useState(0);
  const [showAllFaq, setShowAllFaq] = React.useState(false);
  // Highest-intent questions shown first (indices into FAQ_DATA items —
  // EN and ES arrays are parallel, so one index list keeps bilingual parity):
  // fixed-fee model, PE-led meaning, start timing, licensure/reach, free-consult policy.
  const FAQ_TOP_INDICES = [2, 1, 7, 4, 13];
  const visibleFaqItems = showAllFaq ? t.items : FAQ_TOP_INDICES.map(ix => t.items[ix]);
  // One-shot per-question tracking so a user toggling the same FAQ open and shut
  // does not pollute the funnel with duplicate events.
  const trackedOpens = React.useRef(new Set());
  const handleToggle = (i, question) => {
    const next = open === i ? -1 : i;
    setOpen(next);
    if (next === i && !trackedOpens.current.has(question) && window.trackMBEvent) {
      trackedOpens.current.add(question);
      window.trackMBEvent("FAQ Open", {
        question,
        language: lang
      });
    }
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "faq",
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-faq-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1.8fr",
      gap: "40px 80px",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 100
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(26px, 3vw, 40px)",
      color: "#F0EDE8",
      margin: "0 0 20px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.5)",
      lineHeight: 1.75,
      margin: "0 0 32px"
    }
  }, t.sub), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    style: {
      display: "inline-block",
      padding: "12px 22px", whiteSpace: "nowrap",
      background: "transparent",
      border: `1px solid ${accent}`,
      color: accent,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3,
      transition: "all 0.2s"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = accent;
      e.currentTarget.style.color = "#0B0C0E";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "transparent";
      e.currentTarget.style.color = accent;
    }
  }, t.cta, " \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, visibleFaqItems.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#131417",
      borderLeft: open === i ? `3px solid ${accent}` : "3px solid transparent",
      transition: "border-color 0.2s"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => handleToggle(i, item.q),
    "aria-expanded": open === i,
    style: {
      width: "100%",
      padding: "22px 28px",
      background: "none",
      border: "none",
      cursor: "pointer",
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 20,
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 600,
      fontSize: 16,
      color: open === i ? "#F0EDE8" : "rgba(240,237,232,0.65)",
      lineHeight: 1.35,
      transition: "color 0.2s"
    }
  }, item.q), /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      fontSize: 22,
      flexShrink: 0,
      display: "block",
      lineHeight: 1,
      marginTop: 1,
      transform: open === i ? "rotate(45deg)" : "none",
      transition: "transform 0.25s ease"
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: open === i ? "500px" : "0",
      overflow: "hidden",
      transition: "max-height 0.32s ease"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      padding: "0 28px 26px 28px",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.58)",
      lineHeight: 1.85
    }
  }, item.a)))), !showAllFaq && t.items.length > 8 && /*#__PURE__*/React.createElement("button", {
    onClick: () => setShowAllFaq(true),
    style: {
      marginTop: 8,
      width: "100%",
      padding: "16px 28px",
      background: "transparent",
      border: "1px solid rgba(255,255,255,0.1)",
      cursor: "pointer",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      color: "rgba(240,237,232,0.45)",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      textAlign: "center",
      transition: "border-color 0.2s, color 0.2s"
    },
    onMouseEnter: e => { e.currentTarget.style.borderColor = accent; e.currentTarget.style.color = accent; },
    onMouseLeave: e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.color = "rgba(240,237,232,0.45)"; }
  }, lang === "en" ? "Show all " + t.items.length + " questions" : "Ver las " + t.items.length + " preguntas")))));
}

// ─── Comparison Strip ──────────────────────────────────────────────────────
const COMPARE_DATA = {
  en: {
    eyebrow: "/ The Difference",
    headline: "What direct PE access actually means.",
    typicalLabel: "Typical MEP Firm",
    mbLabel: "Masterbuild",
    rows: [{
      aspect: "Who makes technical decisions",
      typical: "Engineer of record signs; PM runs the project",
      mb: "PE directly  -  on every drawing, every call"
    }, {
      aspect: "Your primary contact",
      typical: "Account manager or project coordinator",
      mb: "Osmany Portal, PE"
    }, {
      aspect: "Drawing review process",
      typical: "Production team drafts; PE stamps at the end",
      mb: "PE reviews and coordinates every set"
    }, {
      aspect: "Billing model",
      typical: "Hourly or T&M  -  final cost rarely matches estimate",
      mb: "Fixed fee scoped before work begins"
    }, {
      aspect: "Permit comment response",
      typical: "May require a new SOW and additional billing",
      mb: "Included in the permit scope"
    }, {
      aspect: "Construction-phase field questions",
      typical: "Routed through project manager, then to engineer",
      mb: "Direct PE response"
    }, {
      aspect: "Bilingual capability",
      typical: "English only",
      mb: "English + Spanish"
    }],
    note: "The Masterbuild model is not for every project. It is for clients who need PE judgment close to the work  -  not a production shop.",
    cta: "Start a direct inquiry"
  },
  es: {
    eyebrow: "/ La Diferencia",
    headline: "Lo que significa el acceso directo al PE.",
    typicalLabel: "Firma MEP Típica",
    mbLabel: "Masterbuild",
    rows: [{
      aspect: "¿Quién toma decisiones técnicas?",
      typical: "El PE firma; un gerente gestiona el proyecto",
      mb: "PE directamente en cada plano y cada llamada"
    }, {
      aspect: "Su contacto principal",
      typical: "Coordinador de cuenta o gerente de proyecto",
      mb: "Osmany Portal, PE"
    }, {
      aspect: "Proceso de revisión de planos",
      typical: "Equipo de producción dibuja; PE sella al final",
      mb: "PE revisa y coordina cada conjunto"
    }, {
      aspect: "Modelo de facturación",
      typical: "Por hora o T&M  -  costo final impredecible",
      mb: "Precio fijo definido antes de iniciar"
    }, {
      aspect: "Respuesta a comentarios de permiso",
      typical: "Puede requerir nuevo SOW y cobro adicional",
      mb: "Incluida en el alcance del permiso"
    }, {
      aspect: "Preguntas de campo durante construcción",
      typical: "Pasan por el gerente, luego al ingeniero",
      mb: "Respuesta directa del PE"
    }, {
      aspect: "Capacidad bilingüe",
      typical: "Solo inglés",
      mb: "Inglés + español"
    }],
    note: "El modelo Masterbuild no es para todo proyecto. Es para clientes que necesitan juicio de PE cercano al trabajo, no una línea de producción.",
    cta: "Iniciar una consulta directa"
  }
};
function MBCompareStrip({
  lang,
  tweaks
}) {
  const t = COMPARE_DATA[lang];
  const accent = tweaks.accent;
  const sectionRef = React.useRef(null);
  const trackedView = React.useRef(false);
  React.useEffect(() => {
    const el = sectionRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !trackedView.current) {
        trackedView.current = true;
        if (window.trackMBEvent) window.trackMBEvent("Comparison Strip View", {
          language: lang
        });
      }
    }, {
      threshold: 0.3
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, [lang]);
  return /*#__PURE__*/React.createElement("section", {
    ref: sectionRef,
    style: {
      background: "#080909",
      padding: "56px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      flexWrap: "wrap",
      gap: 24,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(24px, 3vw, 38px)",
      color: "#F0EDE8",
      margin: 0,
      lineHeight: 1.1
    }
  }, t.headline))), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: "auto",
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "separate",
      borderSpacing: "0 2px",
      minWidth: 560
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 20px",
      background: "transparent",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "rgba(240,237,232,0.25)",
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      textAlign: "left",
      width: "30%"
    }
  }, lang === "en" ? "Aspect" : "Aspecto"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 20px",
      background: "#131417",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "rgba(240,237,232,0.3)",
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      textAlign: "left",
      width: "35%"
    }
  }, t.typicalLabel), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 20px",
      background: `rgba(196,120,58,0.1)`,
      borderTop: `2px solid ${accent}`,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      textAlign: "left",
      width: "35%"
    }
  }, t.mbLabel))), /*#__PURE__*/React.createElement("tbody", null, t.rows.map((row, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "15px 20px",
      background: "transparent",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.4)",
      lineHeight: 1.45,
      verticalAlign: "top"
    }
  }, row.aspect), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "15px 20px",
      background: "#131417",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.4)",
      lineHeight: 1.55,
      verticalAlign: "top"
    }
  }, row.typical), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "15px 20px",
      background: `rgba(196,120,58,0.06)`,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "#F0EDE8",
      fontWeight: 500,
      lineHeight: 1.55,
      verticalAlign: "top"
    }
  }, row.mb)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "wrap",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.35)",
      fontStyle: "italic",
      margin: 0,
      maxWidth: 540,
      lineHeight: 1.6
    }
  }, t.note), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent,
      textDecoration: "none",
      fontWeight: 600,
      borderBottom: `1px solid rgba(196,120,58,0.3)`,
      paddingBottom: 2,
      whiteSpace: "nowrap"
    }
  }, t.cta, " \u2192"))));
}

// ─── Floating Mobile CTA ───────────────────────────────────────────────────
const DCT_CALENDLY_URL = window.MB_CATALOG.scopingCall;
function MBFloatingCTA({
  lang,
  tweaks
}) {
  const [visible, setVisible] = React.useState(false);
  const [isMobile, setIsMobile] = React.useState(false);
  const [dismissed, setDismissed] = React.useState(false);
  const accent = tweaks.accent;
  React.useEffect(() => {
    const check = () => setIsMobile(window.innerWidth <= 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);
  React.useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 560);
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!isMobile || dismissed || !visible) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 300,
      background: "rgba(11,12,14,0.97)",
      backdropFilter: "blur(10px)",
      borderTop: `2px solid ${accent}`,
      padding: "12px 16px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      boxShadow: "0 -8px 32px rgba(0,0,0,0.5)",
      animation: "slideUpIn 0.3s ease both"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "tel:+17863986940",
    style: {
      flex: 1,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      color: "rgba(240,237,232,0.55)",
      textDecoration: "none",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, "+1 (786) 398-6940"), /*#__PURE__*/React.createElement("a", {
    href: DCT_CALENDLY_URL,
    target: "_blank",
    rel: "noopener noreferrer",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Floating CTA Click", {
      action: "scoping_call",
      language: lang
    }),
    style: {
      padding: "10px 16px",
      background: accent,
      color: "#0B0C0E",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3,
      whiteSpace: "nowrap",
      flexShrink: 0
    }
  }, lang === "en" ? "Book a Call" : "Llamada"), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Floating CTA Click", {
      action: "proposal",
      language: lang
    }),
    style: {
      padding: "10px 12px",
      background: "transparent",
      color: accent,
      border: `1px solid ${accent}`,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 12,
      textDecoration: "none",
      borderRadius: 3,
      whiteSpace: "nowrap",
      flexShrink: 0
    }
  }, lang === "en" ? "Proposal" : "Propuesta"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setDismissed(true),
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "rgba(240,237,232,0.25)",
      fontSize: 20,
      padding: "0 2px",
      flexShrink: 0,
      lineHeight: 1,
      fontFamily: "sans-serif"
    }
  }, "\xD7"));
}

// ─── Pricing / Typical Engagement Sizes ───────────────────────────────────
// Boutique-tone reference card. Numbers are intentionally framed as "starting at"
// or ranges so prospects self-qualify before reaching out. Final fees still come
// from the written proposal after scope review  -  these are not a price list.
const PRICING_DATA = {
  en: {
    eyebrow: "/ Engagement Sizes",
    headline: "Where Masterbuild engagements typically land.",
    sub: "Final fees are issued in writing after a scope review. The ranges below help prospective clients self-qualify on size and shape before requesting a proposal.",
    note: "Fixed-fee, scoped in writing, retainer applied to first milestone. Hourly billing is reserved for advisory retainer overruns and rare exceptions  -  never the default model.",
    items: [{
      tag: "Permit-Set MEP",
      name: "Tenant Improvement / Renovation",
      range: "$12k - $45k+",
      fit: "Single-jurisdiction commercial TI, restaurant, retail, or interior renovation requiring coordinated HVAC + plumbing + fire protection + electrical drawings stamped for permit submittal.",
      deliverables: ["Coordinated MEP drawing set", "Equipment schedules + load calcs", "Code-compliance notes", "Permit comment response (one round)"]
    }, {
      tag: "Permit-Set MEP",
      name: "New Construction & Mission-Critical",
      range: "$25k - $120k+",
      fit: "Ground-up commercial, multifamily, healthcare, lab, data-center, or other high-reliability scopes where redundancy, pressurization, and code coordination drive the design.",
      deliverables: ["Full MEP design + coordination", "Multi-discipline schedules", "Specifications", "Permit comment response", "Construction-phase support"]
    }, {
      tag: "Single Discipline",
      name: "PE Drawing Review or Stamp",
      range: "$1.5k - $7k",
      fit: "Architect-led permit work where the drawings are already produced and need PE-level review, coordination notes, and sealing  -  typical S&S engagement.",
      deliverables: ["Discipline review", "Red-line markups", "Code-compliance check", "PE seal on final issue"]
    }, {
      tag: "Assessment",
      name: "Feasibility / Capacity Study",
      range: "$3k - $18k",
      fit: "Existing-building plumbing-system risk, infrastructure capacity, ventilation deficiencies, deferred-maintenance triage, or due-diligence pre-acquisition reports.",
      deliverables: ["Existing-conditions narrative", "Plumbing-system risk review", "Capacity vs. demand math", "Issues + path-forward options"]
    }, {
      tag: "Retainer",
      name: "Monthly Design Advisory",
      range: "$1.5k - $6.5k / mo",
      fit: "Owners, architects, or contractors who need ongoing PE judgment without a separate proposal each time. Reserved time for drawing reviews, code questions, construction issues.",
      deliverables: ["Reserved monthly hours", "Drawing & code review", "Direct PE access (Q&A queue)", "Discounted scoping for new full engagements"]
    }, {
      tag: "Construction Phase",
      name: "Field Coordination & RFI Support",
      range: "Quoted by project",
      fit: "Construction-administration coverage: site visits, RFI responses, shop-drawing review, and field-condition coordination for projects already under construction.",
      deliverables: ["Site visits", "RFI responses", "Shop-drawing review", "Punch-list MEP support"]
    }],
    cta: "Get a written proposal",
    secondary: "Book a 30-minute scoping call"
  },
  es: {
    eyebrow: "/ Tamaños de Compromiso",
    headline: "Donde típicamente caen los compromisos de Masterbuild.",
    sub: "Los honorarios finales se emiten por escrito después de la revisión del alcance. Los rangos a continuación ayudan a los prospectos a calificarse por tamaño y forma antes de solicitar una propuesta.",
    note: "Honorario fijo, alcance por escrito, anticipo aplicado al primer hito. La facturación por hora se reserva para excedentes de retainer de asesoría y excepciones raras  -  nunca el modelo por defecto.",
    items: [{
      tag: "Paquete de Permiso MEP",
      name: "Mejora de Inquilino / Renovación",
      range: "$12k - $45k+",
      fit: "Mejora comercial de una sola jurisdicción, restaurante, comercio minorista o renovación interior que requiere planos coordinados de HVAC + plomería + protección contra incendios + electricidad sellados para presentación de permiso.",
      deliverables: ["Conjunto de planos MEP coordinados", "Listas de equipos + cálculos de carga", "Notas de cumplimiento del código", "Respuesta a comentarios de permiso (una ronda)"]
    }, {
      tag: "Paquete de Permiso MEP",
      name: "Nueva Construcción y Misión Crítica",
      range: "$25k - $120k+",
      fit: "Comercial nuevo desde cero, multifamiliar, salud, laboratorio, centro de datos u otros alcances de alta confiabilidad donde la redundancia, presurización y coordinación del código rigen el diseño.",
      deliverables: ["Diseño y coordinación MEP completos", "Listas multi-disciplina", "Especificaciones", "Respuesta a comentarios de permiso", "Soporte en fase de construcción"]
    }, {
      tag: "Disciplina Única",
      name: "Revisión o Sellado de Planos por PE",
      range: "$1.5k - $7k",
      fit: "Trabajo de permiso liderado por arquitecto donde los planos ya están producidos y necesitan revisión de PE, notas de coordinación y sellado  -  compromiso S&S típico.",
      deliverables: ["Revisión de disciplina", "Marcas de líneas rojas", "Verificación de cumplimiento del código", "Sello PE en emisión final"]
    }, {
      tag: "Evaluación",
      name: "Estudio de Factibilidad / Capacidad",
      range: "$3k - $18k",
      fit: "Riesgo de sistemas de plomería en edificios existentes, capacidad de infraestructura, deficiencias de ventilación, triaje de mantenimiento diferido o informes de debida diligencia previa a la adquisición.",
      deliverables: ["Narrativa de condiciones existentes", "Revisión de riesgo del sistema de plomería", "Matemática de capacidad vs. demanda", "Problemas + camino a seguir"]
    }, {
      tag: "Retainer",
      name: "Asesoría de Diseño Mensual",
      range: "$1.5k - $6.5k / mes",
      fit: "Propietarios, arquitectos o contratistas que necesitan juicio de PE continuo sin una propuesta separada cada vez. Tiempo reservado para revisión de planos, preguntas de código, problemas de construcción.",
      deliverables: ["Horas mensuales reservadas", "Revisión de planos y código", "Acceso directo al PE (cola Q&A)", "Alcance descontado para nuevos compromisos completos"]
    }, {
      tag: "Fase de Construcción",
      name: "Coordinación de Campo y Soporte RFI",
      range: "Cotizado por proyecto",
      fit: "Cobertura de administración de construcción: visitas al sitio, respuestas RFI, revisión de planos de taller y coordinación de condiciones de campo para proyectos ya en construcción.",
      deliverables: ["Visitas al sitio", "Respuestas RFI", "Revisión de planos de taller", "Soporte MEP de lista de pendientes"]
    }],
    cta: "Obtener propuesta escrita",
    secondary: "Reservar llamada de alcance de 30 min"
  }
};
function MBPricingBand({
  lang,
  tweaks
}) {
  const t = PRICING_DATA[lang];
  const accent = tweaks.accent;
  const sectionRef = React.useRef(null);
  const trackedView = React.useRef(false);

  // Plausible: fire a one-shot view event when the band scrolls into view.
  React.useEffect(() => {
    const el = sectionRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !trackedView.current) {
        trackedView.current = true;
        if (window.trackMBEvent) window.trackMBEvent("Pricing Band View", {
          language: lang
        });
      }
    }, {
      threshold: 0.25
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, [lang]);
  return /*#__PURE__*/React.createElement("section", {
    id: "pricing",
    ref: sectionRef,
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 32,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(26px, 3.4vw, 42px)",
      color: "#F0EDE8",
      margin: "0 0 16px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.75,
      margin: 0
    }
  }, t.sub)), /*#__PURE__*/React.createElement("div", {
    className: "mb-pricing-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
      gap: 2,
      marginBottom: 32
    }
  }, t.items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "20px 22px",
      background: "#131417",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      transition: "background 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.background = "#1A1C20",
    onMouseLeave: e => e.currentTarget.style.background = "#131417"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.08em",
      textTransform: "uppercase"
    }
  }, it.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 16,
      color: "#F0EDE8",
      margin: 0,
      lineHeight: 1.25
    }
  }, it.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 18,
      fontWeight: 500,
      color: accent,
      margin: 0
    }
  }, it.range), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.65,
      margin: 0
    }
  }, it.fit), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: "4px 0 0",
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, it.deliverables.map((d, di) => /*#__PURE__*/React.createElement("li", {
    key: di,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.45)",
      lineHeight: 1.5,
      paddingLeft: 14,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 7,
      width: 6,
      height: 1,
      background: accent
    }
  }), d)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 24px",
      background: "rgba(196,120,58,0.06)",
      borderLeft: `3px solid ${accent}`,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.7)",
      margin: 0,
      lineHeight: 1.65,
      fontStyle: "italic"
    }
  }, t.note)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Pricing CTA Click", {
      target: "proposal",
      language: lang
    }),
    style: {
      padding: "13px 26px",
      background: accent,
      color: "#0B0C0E",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      transition: "opacity 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.opacity = "0.85",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, t.cta, " \u2192"), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Pricing CTA Click", {
      target: "scoping-call",
      language: lang
    }),
    style: {
      padding: "13px 26px",
      background: "transparent",
      border: `1px solid rgba(240,237,232,0.2)`,
      color: "#F0EDE8",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 500,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      transition: "border-color 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = "rgba(240,237,232,0.5)",
    onMouseLeave: e => e.currentTarget.style.borderColor = "rgba(240,237,232,0.2)"
  }, t.secondary))));
}

// ─── Scroll-depth analytics ───────────────────────────────────────────────
// Fires Plausible events at 25 / 50 / 75 / 100 % depth. One firing per page load.
function MBScrollDepthTracker() {
  React.useEffect(() => {
    if (!window.trackMBEvent) return;
    const fired = new Set();
    const onScroll = () => {
      const doc = document.documentElement;
      const scrolled = window.scrollY + window.innerHeight;
      const pct = Math.round(scrolled / doc.scrollHeight * 100);
      [25, 50, 75, 100].forEach(mark => {
        if (pct >= mark && !fired.has(mark)) {
          fired.add(mark);
          window.trackMBEvent("Scroll Depth", {
            depth: `${mark}%`
          });
        }
      });
    };
    window.addEventListener("scroll", onScroll, {
      passive: true
    });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return null;
}
Object.assign(window, {
  useCountUp,
  MBFAQ,
  MBCompareStrip,
  MBFloatingCTA,
  MBPricingBand,
  MBScrollDepthTracker
});
