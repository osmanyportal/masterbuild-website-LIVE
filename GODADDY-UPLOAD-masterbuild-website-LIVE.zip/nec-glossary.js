// nec-glossary.js — NEC Article 100 Glossary page for Masterbuild Consulting.
// Reads window.NEC_GLOSSARY (nec-glossary-data.js). Plain-English paraphrase
// glossary, not verbatim NFPA 70 text — see nec-glossary-data.js header.
const ACCENT = "#C4783A";
const BG = "#0B0C0E";
const SURFACE = "#131417";
const SURFACE2 = "#1C1E23";
const BORDER = "rgba(255,255,255,0.07)";
const TEXT = "#F0EDE8";
const MUTED = "rgba(240,237,232,0.45)";

const CAT_LABELS = {
  en: {
    "All": "All Terms",
    "General": "General",
    "Grounding & Bonding": "Grounding & Bonding",
    "Circuits & Feeders": "Circuits & Feeders",
    "Overcurrent Protection": "Overcurrent Protection",
    "Occupancy": "Occupancy",
    "Service Equipment": "Service Equipment"
  },
  es: {
    "All": "Todos los Términos",
    "General": "General",
    "Grounding & Bonding": "Puesta a Tierra y Unión",
    "Circuits & Feeders": "Circuitos y Alimentadores",
    "Overcurrent Protection": "Protección de Sobrecorriente",
    "Occupancy": "Ocupación",
    "Service Equipment": "Equipo de Servicio"
  }
};

function LangToggle(props) {
  const lang = props.lang;
  const setLang = props.setLang;
  const buttons = ["en", "es"].map(function (l) {
    return React.createElement("button", {
      key: l,
      onClick: function () { setLang(l); },
      style: {
        padding: "5px 10px",
        background: lang === l ? ACCENT : "transparent",
        color: lang === l ? BG : MUTED,
        border: "none",
        cursor: "pointer",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: "0.06em",
        textTransform: "uppercase"
      }
    }, l);
  });
  return React.createElement("div", {
    style: { display: "flex", gap: 0, background: SURFACE, borderRadius: 3, overflow: "hidden", border: "1px solid " + BORDER }
  }, buttons);
}

function PageHeader(props) {
  const lang = props.lang;
  const setLang = props.setLang;
  const logo = React.createElement("a", {
    href: "/",
    style: { textDecoration: "none", display: "flex", alignItems: "center", gap: 8 }
  },
    React.createElement("img", {
      src: "/uploads/Master Build Logo- Revised.png",
      alt: "Masterbuild",
      style: { height: 26, width: 26, objectFit: "contain", filter: "invert(1)" }
    }),
    React.createElement("span", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: 13, color: TEXT, letterSpacing: "0.04em", textTransform: "uppercase" }
    }, "Masterbuild")
  );
  const separator = React.createElement("span", { style: { color: BORDER, fontSize: 16 } }, "|");
  const dctLink = React.createElement("a", {
    href: "/daily-code-talk/",
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", textDecoration: "none" }
  }, "Daily Code Talk");
  const imcLink = React.createElement("a", {
    href: "/imc-glossary/",
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, letterSpacing: "0.08em", textTransform: "uppercase", textDecoration: "none" }
  }, lang === "en" ? "IMC Glossary" : "Glosario IMC");
  const left = React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 20 } }, logo, separator, dctLink, imcLink);
  const resLink = React.createElement("a", {
    href: "/resources/",
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: MUTED, textDecoration: "none" }
  }, lang === "en" ? "Field Guides" : "Guías de Campo");
  const right = React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 16 } }, resLink, React.createElement(LangToggle, { lang: lang, setLang: setLang }));
  return React.createElement("header", {
    style: {
      position: "sticky", top: 0, background: "rgba(11,12,14,0.97)", borderBottom: "1px solid " + BORDER,
      padding: "0 40px", height: 56, display: "flex", alignItems: "center", justifyContent: "space-between",
      zIndex: 100, backdropFilter: "blur(8px)"
    }
  }, left, right);
}

function GlossaryHero(props) {
  const lang = props.lang;
  const count = props.count;
  const badgeDot = React.createElement("span", { style: { width: 6, height: 6, borderRadius: "50%", background: ACCENT, display: "block" } });
  const badgeLabel = React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase" }
  }, lang === "en" ? "/ Sparky Edition Reference" : "/ Referencia Sparky Edition");
  const badge = React.createElement("div", {
    style: { display: "inline-flex", alignItems: "center", gap: 8, padding: "5px 12px", background: "rgba(196,120,58,0.1)", border: "1px solid rgba(196,120,58,0.2)", borderRadius: 3, marginBottom: 20 }
  }, badgeDot, badgeLabel);
  const heading = React.createElement("h1", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(28px, 4vw, 48px)", color: TEXT, margin: "0 0 16px", letterSpacing: "-0.02em", lineHeight: 1.14 }
  }, lang === "en" ? "NEC Article 100 Glossary" : "Glosario del Artículo 100 del NEC");
  const intro = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 16, color: MUTED, margin: "0 0 6px", maxWidth: 680, lineHeight: 1.7 }
  }, lang === "en"
    ? "Plain-English explanations of the NEC's core definitions, with a field note under each one calling out where it actually bites on a permit set. Original wording, not a copy of the code text — built for fast lookup, not as a legal substitute for NFPA 70."
    : "Explicaciones en lenguaje claro de las definiciones centrales del NEC, con una nota de campo bajo cada una que indica dónde realmente afecta un juego de permiso. Redacción original, no una copia del texto del código — hecho para consulta rápida, no como sustituto legal de la NFPA 70.");
  const meta = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: "rgba(240,237,232,0.35)", margin: 0 }
  }, (lang === "en" ? count + " terms so far · growing archive" : count + " términos hasta ahora · archivo en crecimiento"));
  const bgGrid = React.createElement("div", {
    style: { position: "absolute", inset: 0, backgroundImage: "linear-gradient(to right, rgba(196,120,58,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(196,120,58,0.04) 1px, transparent 1px)", backgroundSize: "48px 48px" }
  });
  const inner = React.createElement("div", { style: { maxWidth: 900, margin: "0 auto", position: "relative", zIndex: 1 } }, badge, heading, intro, meta);
  return React.createElement("div", { style: { background: BG, position: "relative", overflow: "hidden", padding: "56px 40px 40px" } }, bgGrid, inner);
}

function SearchAndFilter(props) {
  const lang = props.lang, search = props.search, setSearch = props.setSearch;
  const cats = props.cats, activeCat = props.activeCat, setActiveCat = props.setActiveCat;
  const labels = CAT_LABELS[lang] || CAT_LABELS.en;
  const input = React.createElement("input", {
    type: "text",
    value: search,
    onChange: function (e) { setSearch(e.target.value); },
    placeholder: lang === "en" ? "Search a term (e.g. “bonding”, “service”)…" : "Buscar un término (p.ej. “unión”, “servicio”)…",
    style: {
      width: "100%", boxSizing: "border-box", padding: "12px 16px", background: SURFACE, border: "1px solid " + BORDER,
      borderRadius: 4, color: TEXT, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 15, outline: "none", marginBottom: 16
    }
  });
  const chips = ["All"].concat(cats).map(function (c) {
    const active = activeCat === c;
    return React.createElement("button", {
      key: c,
      onClick: function () { setActiveCat(c); },
      style: {
        padding: "6px 14px", borderRadius: 20, border: "1px solid " + (active ? ACCENT : BORDER),
        background: active ? "rgba(196,120,58,0.15)" : "transparent", color: active ? ACCENT : MUTED,
        fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, letterSpacing: "0.03em", cursor: "pointer", marginRight: 8, marginBottom: 8
      }
    }, labels[c] || c);
  });
  const chipRow = React.createElement("div", { style: { display: "flex", flexWrap: "wrap" } }, chips);
  return React.createElement("div", { style: { maxWidth: 900, margin: "0 auto", padding: "0 40px 8px" } }, input, chipRow);
}

function TermCard(props) {
  const t = props.term, lang = props.lang;
  const term = lang === "en" ? t.term_en : t.term_es;
  const def = lang === "en" ? t.def_en : t.def_es;
  const field = lang === "en" ? t.field_en : t.field_es;
  const fieldLabel = lang === "en" ? "Field Tip" : "Consejo de Campo";
  return React.createElement("div", {
    id: "term-" + t.id,
    style: { background: SURFACE, border: "1px solid " + BORDER, borderRadius: 6, padding: "20px 22px", marginBottom: 14, scrollMarginTop: 72 }
  },
    React.createElement("h3", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, fontSize: 18, color: TEXT, margin: "0 0 8px" }
    }, term),
    React.createElement("p", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14.5, color: "rgba(240,237,232,0.82)", lineHeight: 1.65, margin: "0 0 12px" }
    }, def),
    React.createElement("div", {
      style: { background: SURFACE2, borderLeft: "3px solid " + ACCENT, borderRadius: 3, padding: "10px 14px" }
    },
      React.createElement("span", {
        style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 4 }
      }, fieldLabel),
      React.createElement("p", {
        style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13.5, color: MUTED, lineHeight: 1.6, margin: 0 }
      }, field)
    )
  );
}

function ClosingCTA(props) {
  const lang = props.lang;
  const heading = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(22px, 3vw, 32px)", color: TEXT, margin: "0 0 14px" }
  }, lang === "en" ? "Need this checked against your actual project?" : "¿Necesita esto verificado contra su proyecto real?");
  const body = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 15, color: MUTED, margin: "0 0 24px", maxWidth: 620, marginLeft: "auto", marginRight: "auto", lineHeight: 1.7 }
  }, lang === "en"
    ? "This glossary is general reference. For a determination tied to your drawings, equipment schedule, or AHJ, send the project background and get a written scope."
    : "Este glosario es referencia general. Para una determinación vinculada a sus planos, programa de equipos o AHJ, envíe la información del proyecto y reciba un alcance por escrito.");
  const proposalBtn = React.createElement("a", {
    href: "mailto:osmany.portal@masterbuildconsulting.com?subject=" + encodeURIComponent(lang === "en" ? "Project inquiry - Masterbuild Consulting" : "Consulta de proyecto - Masterbuild Consulting"),
    style: { display: "inline-block", padding: "13px 26px", background: ACCENT, color: BG, fontFamily: "'IBM Plex Sans', sans-serif", fontWeight: 700, fontSize: 14, textDecoration: "none", borderRadius: 4, marginRight: 12 }
  }, lang === "en" ? "Request a Proposal" : "Solicitar una Propuesta");
  const listUrl = (window.MB_CATALOG && window.MB_CATALOG.subscribe && window.MB_CATALOG.subscribe.listPage) || "https://buttondown.com/masterbuild";
  const archiveBtn = React.createElement("a", {
    href: listUrl,
    style: { display: "inline-block", padding: "13px 26px", background: "transparent", color: TEXT, fontFamily: "'IBM Plex Sans', sans-serif", fontWeight: 700, fontSize: 14, textDecoration: "none", borderRadius: 4, border: "1px solid " + BORDER }
  }, lang === "en" ? "Join the Free Archive List" : "Unirse a la Lista Gratuita");
  const btnRow = React.createElement("div", { style: { display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" } }, proposalBtn, archiveBtn);
  const inner = React.createElement("div", { style: { maxWidth: 900, margin: "0 auto", textAlign: "center" } }, heading, body, btnRow);
  return React.createElement("div", { style: { background: BG, padding: "56px 40px 72px", borderTop: "1px solid " + BORDER } }, inner);
}

function GlossaryPage() {
  const initialLang = (function () { try { return localStorage.getItem("mb_lang") || "en"; } catch (err) { return "en"; } })();
  const langState = React.useState(initialLang);
  const lang = langState[0];
  const setLangState = langState[1];
  const setLang = function (l) { setLangState(l); try { localStorage.setItem("mb_lang", l); } catch (err) {} };
  React.useEffect(function () { document.documentElement.lang = lang; document.body.dataset.lang = lang; }, [lang]);

  const allTerms = window.NEC_GLOSSARY || [];
  const meta = window.NEC_GLOSSARY_META || { count: allTerms.length };
  const [search, setSearch] = React.useState("");
  const [activeCat, setActiveCat] = React.useState("All");

  const cats = React.useMemo(function () {
    const set = {};
    allTerms.forEach(function (t) { set[t.cat] = true; });
    return Object.keys(set).sort();
  }, [allTerms]);

  const filtered = React.useMemo(function () {
    const q = search.trim().toLowerCase();
    return allTerms.filter(function (t) {
      if (activeCat !== "All" && t.cat !== activeCat) return false;
      if (!q) return true;
      const hay = ((lang === "en" ? t.term_en + " " + t.def_en : t.term_es + " " + t.def_es)).toLowerCase();
      return hay.indexOf(q) !== -1;
    }).sort(function (a, b) {
      const an = lang === "en" ? a.term_en : a.term_es;
      const bn = lang === "en" ? b.term_en : b.term_es;
      return an.localeCompare(bn);
    });
  }, [allTerms, search, activeCat, lang]);

  const header = React.createElement(PageHeader, { lang: lang, setLang: setLang });
  const hero = React.createElement(GlossaryHero, { lang: lang, count: meta.count || allTerms.length });
  const searchBar = React.createElement(SearchAndFilter, { lang: lang, search: search, setSearch: setSearch, cats: cats, activeCat: activeCat, setActiveCat: setActiveCat });
  const resultCount = React.createElement("p", {
    style: { maxWidth: 900, margin: "0 auto", padding: "0 40px 8px", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "rgba(240,237,232,0.35)" }
  }, filtered.length + (lang === "en" ? " result" + (filtered.length === 1 ? "" : "s") : " resultado" + (filtered.length === 1 ? "" : "s")));
  const cards = filtered.length
    ? filtered.map(function (t) { return React.createElement(TermCard, { key: t.id, term: t, lang: lang }); })
    : [React.createElement("p", {
        key: "empty",
        style: { fontFamily: "'IBM Plex Sans', sans-serif", color: MUTED, fontSize: 14 }
      }, lang === "en" ? "No terms match that search." : "Ningún término coincide con esa búsqueda.")];
  const list = React.createElement("div", { style: { maxWidth: 900, margin: "0 auto", padding: "8px 40px 40px" } }, cards);
  const closing = React.createElement(ClosingCTA, { lang: lang });

  return React.createElement("div", { style: { minHeight: "100vh", background: BG } }, header, hero, searchBar, resultCount, list, closing);
}

const glossaryRoot = ReactDOM.createRoot(document.getElementById("root"));
glossaryRoot.render(React.createElement(GlossaryPage));
