/* Masterbuild Consulting — the chapter offer on Daily Code Talk article pages.

   The interactive archive has carried a chapter-aware guide CTA since it was
   built, but a deep link into an article redirects to the static shell, so in
   practice a reader coming from search or LinkedIn never saw it. These 231
   shells are the firm's largest organic surface and they were the only pages
   in the funnel with no product on them at all.

   The chapter is stamped on <main data-mb-chapter> at build time from the same
   dct-index.js field the archive uses, so this cannot drift from the article.
   NEC (Sparky Edition) posts are not stamped and are silently skipped — an NEC
   chapter number is not an IMC chapter number, and offering the Chapter 8
   venting guide on an article about communications circuits is worse than
   offering nothing. */
(function () {
  "use strict";
  var main = document.querySelector("main[data-mb-chapter]");
  if (!main) return;
  var ch = parseInt(main.getAttribute("data-mb-chapter"), 10);
  if (!ch) return;
  var ES = document.documentElement.lang === "es";

  var GUIDES = {
    1: ["imcChapter1Guide", "IMC Chapter 1 Permit Process Field Guide",
        "The whole permit-process series as one pre-submittal checklist, review kit and violation-response toolkit."],
    2: ["imcChapter2Guide", "IMC Chapter 2 Definitions & Redline Prevention Guide",
        "Every definition that changes a review outcome, as a redline-prevention pass you run before you submit."],
    3: ["imcChapter3Guide", "IMC Chapter 3 Installation Readiness Guide",
        "An equipment approval and location matrix you use before procurement, concealment or startup."],
    4: ["ventilationFieldGuide", "Ventilation & Outdoor Air Field Guide",
        "Rates, methods and the two-column problem, as one workflow a reviewer can follow."],
    5: ["imcChapter5Guide", "IMC Chapter 5 Exhaust Systems Field Guide",
        "Classify the exhaust before you size it — the whole chapter as one control system with nine working sheets."],
    6: ["imcChapter6Guide", "IMC Chapter 6 Duct Systems Field Guide",
        "The decisions that get expensive above ceilings and inside shafts, with four printable working tools."],
    7: ["imcChapter7Guide", "Combustion Air Field Guide",
        "Route the appliance, size the intake, prove the path — with the fuel-gas authority stated correctly."],
    8: ["imcChapter8Guide", "IMC Chapter 8 Chimneys and Vents Field Guide",
        "A routing map, a size basis a reviewer can verify, the four-gate existing-chimney acceptance, and eleven working tools."]
  };
  var g = GUIDES[ch];
  if (!g) return;

  var cat = window.MB_CATALOG;
  var offer = cat && cat.offers && cat.offers[g[0]];
  if (!offer || !offer.url) return;              /* inert until the product is live */
  var price = cat.price ? cat.price(g[0]) : "";

  /* The shells carry their own inline stylesheet and do not load mb-chrome.css,
     so the block brings its own styles. It uses the shells' own accent (#C4783A)
     rather than the static-page accent (#CA540A) so it matches the page it lands
     on — see the brand-accent note in the release file: the site currently runs
     two accents and unifying them is an owner decision, not a silent edit. */
  if (!document.getElementById("mb-offer-style")) {
    var st = document.createElement("style");
    st.id = "mb-offer-style";
    st.textContent =
      ".chapter-offer{margin:40px 0 0;padding:24px;background:linear-gradient(135deg,rgba(196,120,58,.16),rgba(19,20,23,.96));border:1px solid rgba(196,120,58,.36)}" +
      ".co-eyebrow{font-family:Consolas,'IBM Plex Mono',monospace;font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#C4783A;margin:0 0 8px}" +
      ".chapter-offer h2{margin:0 0 10px;font-size:21px;color:#F0EDE8}" +
      ".chapter-offer p{margin:0 0 14px}" +
      ".co-actions{display:flex;flex-wrap:wrap;gap:14px;align-items:center}" +
      ".co-buy{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:13px 24px;background:#C4783A;border:1px solid #C4783A;color:#0B0C0E;font-weight:700;border-radius:3px}" +
      ".co-buy:hover{text-decoration:none;background:#D4884A}" +
      ".co-alt{font-size:15px}" +
      ".co-note{font-size:13px;color:rgba(240,237,232,.5);margin:0!important}" +
      "@media(max-width:700px){.chapter-offer{padding:18px}.co-buy{width:100%}}";
    document.head.appendChild(st);
  }

  var sec = document.createElement("section");
  sec.className = "chapter-offer";
  sec.setAttribute("data-mb-offer", g[0]);
  sec.innerHTML =
    '<p class="co-eyebrow">' + (ES ? "De esta serie" : "From this series") + "</p>" +
    "<h2>" + g[1] + "</h2>" +
    "<p>" + g[2] + "</p>" +
    '<p class="co-actions">' +
      '<a class="co-buy" href="' + offer.url + '" rel="noopener">' +
        (ES ? "Obtener la guía" : "Get the guide") + (price ? " — " + price : "") +
      "</a>" +
      '<a class="co-alt" href="/resources/">' + (ES ? "Ver todas las guías" : "See every guide") + "</a>" +
    "</p>" +
    '<p class="co-note">' + (ES
      ? "Soporte educativo de decisión y un flujo de documentación. No es ingeniería sellada. El trabajo específico del proyecto requiere un alcance escrito."
      : "Educational decision support and a documentation workflow. Not sealed engineering. Project-specific work still requires a written scope.") + "</p>";

  /* Order of asks: the paid offer sits directly under the article, while the reader
     is still holding the technical argument; the free email ask follows it. The
     subscribe host is already in the markup before the closing CTA, so anchoring to
     it (when present) fixes the order deterministically instead of relying on which
     deferred script happens to run first. */
  var anchor = document.querySelector("main > [data-mb-subscribe], main > .mb-sub")
            || document.querySelector("main > section.cta");
  if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(sec, anchor);
  else main.appendChild(sec);

  var buy = sec.querySelector(".co-buy");
  if (buy) buy.addEventListener("click", function () {
    if (window.trackMBEvent) window.trackMBEvent("Article Guide Click", { chapter: ch, guide: g[0] });
  });
  if (window.trackMBEvent) window.trackMBEvent("Article Guide Shown", { chapter: ch, guide: g[0] });
})();
