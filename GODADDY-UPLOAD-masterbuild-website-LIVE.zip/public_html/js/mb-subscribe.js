/* Masterbuild Consulting — the one place the site asks for an email.

   Until now it asked nowhere. 690 pages, 117 free screens, 237 articles, four
   ungated PDFs, and the only way to stay in touch was a Buttondown link in a
   footer. Every visitor who read a guide and left was gone for good.

   The promise here is deliberately narrow, because the list has never received
   an issue and a promise you do not keep is worse than no promise: you hear from
   the firm when a new chapter guide or field tool ships. Not a newsletter, not a
   cadence. That is a promise the firm can actually keep from a standing start.

   Tags come from mb-catalog.js so list automations stay in one place. Posting
   straight to Buttondown's embed endpoint means no third party sees the address
   and no page has to carry an API key. */
(function () {
  "use strict";
  var host = document.querySelector("[data-mb-subscribe]");
  if (!host || host.querySelector("form")) return;

  var cat = window.MB_CATALOG || {};
  var sub = cat.subscribe || {};
  var endpoint = sub.endpoint || "https://buttondown.email/api/emails/embed-subscribe/masterbuild";
  var family = host.getAttribute("data-mb-subscribe") || "";     /* "IMC" | "NEC" | "" */
  var where = host.getAttribute("data-mb-source") || location.pathname;
  var tags = (typeof cat.subscribeTags === "function")
    ? cat.subscribeTags(family)
    : ["daily-code-talk"];
  var ES = document.documentElement.lang === "es";

  var T = ES ? {
    eyebrow: "Sin spam · cancele cuando quiera",
    head: "Le aviso cuando salga la próxima guía.",
    body: "Una guía de capítulo o una herramienta nueva. Nada más — no es un boletín y no hay cadencia semanal.",
    ph: "su@correo.com", cta: "Avíseme",
    ok: "Listo. Revise su correo para confirmar la suscripción.",
    err: "No se pudo enviar. Escriba a osmany.portal@masterbuildconsulting.com y lo agrego a mano."
  } : {
    eyebrow: "No spam · one click to leave",
    head: "I'll email you when the next guide ships.",
    body: "A new chapter guide or a new field tool. That is the whole list — it is not a newsletter and there is no weekly cadence.",
    ph: "you@company.com", cta: "Tell me",
    ok: "Done. Check your email to confirm the subscription.",
    err: "That did not send. Email osmany.portal@masterbuildconsulting.com and I will add you by hand."
  };

  if (!document.getElementById("mb-sub-style")) {
    var st = document.createElement("style");
    st.id = "mb-sub-style";
    st.textContent =
      ".mb-sub{margin:32px 0;padding:22px 24px;background:#131417;border:1px solid rgba(255,255,255,.10);border-left:3px solid var(--mb-sub-accent,#CA540A)}" +
      ".mb-sub-eyebrow{font-family:Consolas,'IBM Plex Mono',monospace;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--mb-sub-accent,#CA540A);margin:0 0 8px}" +
      ".mb-sub h3{margin:0 0 8px;font-size:18px;color:#F0EDE8}" +
      ".mb-sub p{margin:0 0 14px;font-size:15px;color:rgba(240,237,232,.7)}" +
      ".mb-sub form{display:flex;flex-wrap:wrap;gap:10px;margin:0}" +
      ".mb-sub input[type=email]{flex:1 1 240px;min-width:0;padding:12px 14px;margin:0;background:#1C1E23;border:1px solid rgba(255,255,255,.12);color:#F0EDE8;font:16px/1.4 Arial,Helvetica,sans-serif;border-radius:3px}" +
      ".mb-sub button{min-height:48px;padding:12px 22px;background:var(--mb-sub-accent,#CA540A);color:#0B0C0E;border:0;font-weight:700;font-size:15px;cursor:pointer;border-radius:3px}" +
      ".mb-sub button:hover{filter:brightness(1.1)}" +
      ".mb-sub-msg{margin:12px 0 0;font-size:14px}" +
      ".mb-sub-msg.is-ok{color:#8FBF6F}.mb-sub-msg.is-err{color:#D96B5A}" +
      /* the bot trap must be invisible wherever this block lands, including the
         article shells, which do not load mb-chrome.css and so have no .honey rule */
      ".mb-sub .mb-honey{position:absolute!important;left:-9999px!important;width:1px;height:0;overflow:hidden}" +
      "@media(max-width:700px){.mb-sub button{width:100%}}";
    document.head.appendChild(st);
  }

  host.className = (host.className ? host.className + " " : "") + "mb-sub";
  host.innerHTML =
    '<p class="mb-sub-eyebrow">' + T.eyebrow + "</p>" +
    "<h3>" + T.head + "</h3>" +
    "<p>" + T.body + "</p>" +
    '<form novalidate>' +
      '<label class="honey mb-honey" aria-hidden="true">Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>' +
      '<label for="mb-sub-email" style="position:absolute;left:-9999px">Email</label>' +
      '<input id="mb-sub-email" type="email" name="email" required autocomplete="email" placeholder="' + T.ph + '">' +
      "<button type=\"submit\">" + T.cta + "</button>" +
    "</form>" +
    '<p class="mb-sub-msg" role="status" aria-live="polite" hidden></p>';

  var form = host.querySelector("form");
  var msg = host.querySelector(".mb-sub-msg");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (form.website.value) return;                    /* bot */
    var email = (form.email.value || "").trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      form.email.focus();
      return;
    }
    var body = new URLSearchParams();
    body.append("email", email);
    tags.forEach(function (t) { body.append("tag", t); });
    body.append("metadata__source", where);

    var btn = form.querySelector("button");
    btn.disabled = true;
    function done(ok) {
      msg.hidden = false;
      msg.className = "mb-sub-msg " + (ok ? "is-ok" : "is-err");
      msg.textContent = ok ? T.ok : T.err;
      if (ok) form.hidden = true; else btn.disabled = false;
      if (window.trackMBEvent) {
        window.trackMBEvent(ok ? "Subscribe" : "Subscribe Failed", { source: where, family: family || "none" });
      }
    }
    /* no-cors: Buttondown's embed endpoint does not return CORS headers, so the
       response is opaque. A resolved fetch means the POST left the browser; a
       rejected one means it did not. Buttondown then sends its own confirmation
       email, which is the real receipt — hence "check your email to confirm". */
    fetch(endpoint, { method: "POST", mode: "no-cors", body: body })
      .then(function () { done(true); })
      .catch(function () { done(false); });
  });

  /* If this page also carries a chapter offer, let the paid offer sit directly under
     the article and put the free ask after it. mb-article-offer.js may run either
     before or after this file depending on tag order, so re-check on the next frame. */
  function order() {
    var offer = document.querySelector(".chapter-offer");
    if (offer && offer.parentNode === host.parentNode && offer.compareDocumentPosition(host) & Node.DOCUMENT_POSITION_PRECEDING) {
      offer.parentNode.insertBefore(host, offer.nextSibling);
    }
  }
  order();
  if (window.requestAnimationFrame) window.requestAnimationFrame(order);

  if (window.trackMBEvent) window.trackMBEvent("Subscribe Shown", { source: where });
})();
