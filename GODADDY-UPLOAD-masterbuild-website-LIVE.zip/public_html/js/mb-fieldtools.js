/* Masterbuild Consulting — field-tool library navigation.
   The library is 124 screens on one page. Without this layer the page is a
   200 KB scroll and the index is a wall of links; with it, the page behaves like
   a tool cabinet: a sticky category rail you can jump from anywhere, a search
   that narrows the index and the cards together, and per-category counts so a
   visitor can see the shape of the library before reading any of it.

   It owns the search box (mb-tools.js no longer does) so that filtering can hide
   category sections and index entries, not just tool cards. */
(function () {
  "use strict";
  var ES = document.documentElement.lang === "es";
  var cats = Array.prototype.slice.call(document.querySelectorAll(".tool-cat"));
  if (!cats.length) return;

  var T = ES ? {
    all: "Todas", found: " pantallas", one: " pantalla",
    none: "Ninguna pantalla coincide. Pruebe cocina, aire exterior, chimenea, compuerta, SCCR o permiso.",
    jump: "Ir a la categoría", top: "↑ Herramientas"
  } : {
    all: "All", found: " screens", one: " screen",
    none: "No screen matched. Try kitchen, outdoor air, chimney, damper, SCCR or permit.",
    jump: "Jump to category", top: "↑ Tools"
  };

  /* ── Sticky category rail ──────────────────────────────────────────────
     Built from the DOM, so adding a category to the HTML adds a chip here. */
  var rail = document.createElement("nav");
  rail.className = "cat-rail";
  rail.setAttribute("aria-label", T.jump);
  var inner = document.createElement("div");
  inner.className = "cat-rail-inner";
  rail.appendChild(inner);
  cats.forEach(function (sec) {
    var h = sec.querySelector(".cat-head h2");
    var count = sec.querySelectorAll(".tool").length;
    var a = document.createElement("a");
    a.href = "#" + sec.id;
    a.setAttribute("data-cat", sec.id);
    a.innerHTML = (h ? h.innerHTML : sec.id) + ' <span class="cat-count">' + count + "</span>";
    inner.appendChild(a);
  });
  var anchor = document.getElementById("tools-index");
  if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(rail, anchor);

  /* Mark the rail chip for whichever category is currently on screen. */
  var chips = Array.prototype.slice.call(inner.querySelectorAll("a"));
  if ("IntersectionObserver" in window) {
    var seen = {};
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { seen[en.target.id] = en.isIntersecting; });
      var active = null;
      for (var i = 0; i < cats.length; i++) { if (seen[cats[i].id]) { active = cats[i].id; break; } }
      chips.forEach(function (c) {
        c.classList.toggle("is-on", !!active && c.getAttribute("data-cat") === active);
      });
    }, { rootMargin: "-96px 0px -70% 0px" });
    cats.forEach(function (s) { io.observe(s); });
  }

  /* Keep the active chip scrolled into view inside the rail on narrow screens. */
  function centreChip() {
    var on = inner.querySelector("a.is-on");
    if (!on || inner.scrollWidth <= inner.clientWidth) return;
    var want = on.offsetLeft - (inner.clientWidth - on.offsetWidth) / 2;
    inner.scrollTo ? inner.scrollTo({ left: want, behavior: "smooth" }) : (inner.scrollLeft = want);
  }
  window.addEventListener("scroll", function () {
    if (centreChip.t) return;
    centreChip.t = setTimeout(function () { centreChip.t = null; centreChip(); }, 220);
  }, { passive: true });

  /* The rail's native scrollbar is hidden (it renders as a grey classic bar on
     Windows Chrome and sits on the accent border). Tell the CSS which side still
     has chips off-screen so the edge fades stand in for it. */
  function railOverflow() {
    var slack = inner.scrollWidth - inner.clientWidth;
    if (slack <= 2) { rail.removeAttribute("data-ov"); return; }
    var left = inner.scrollLeft;
    rail.setAttribute("data-ov", left <= 2 ? "start" : (left >= slack - 2 ? "end" : "mid"));
  }
  inner.addEventListener("scroll", function () {
    if (railOverflow.t) return;
    railOverflow.t = setTimeout(function () { railOverflow.t = null; railOverflow(); }, 60);
  }, { passive: true });
  window.addEventListener("resize", railOverflow, { passive: true });
  railOverflow();

  /* A hidden scrollbar also removes the drag affordance, so let the wheel scroll
     the rail horizontally while the pointer is over it. */
  inner.addEventListener("wheel", function (e) {
    if (e.deltaY === 0 || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    if (inner.scrollWidth <= inner.clientWidth) return;
    var before = inner.scrollLeft;
    inner.scrollLeft = before + e.deltaY;
    if (inner.scrollLeft !== before) e.preventDefault();
  }, { passive: false });

  /* ── Search over the whole library ─────────────────────────────────────
     Matches title, lede, kicker (so a section number finds its screen) and the
     index entry text. Hides empty categories and their index blocks so the page
     collapses to exactly what matched. */
  var filt = document.getElementById("tool-filter");
  var empty = document.getElementById("tool-filter-empty");
  var countOut = document.getElementById("tool-filter-count");
  var tools = Array.prototype.slice.call(document.querySelectorAll(".tool"));
  var hay = {};
  tools.forEach(function (el) {
    hay[el.id] = ((el.textContent || "") + " " + (el.getAttribute("data-keywords") || "")).toLowerCase();
  });
  var tocLinks = Array.prototype.slice.call(document.querySelectorAll(".tool-toc a"));

  function apply(raw) {
    var terms = (raw || "").toLowerCase().trim().split(/\s+/).filter(Boolean);
    var shown = 0;
    tools.forEach(function (el) {
      var h = hay[el.id] || "";
      var ok = terms.every(function (t) { return h.indexOf(t) !== -1; });
      el.hidden = !ok;
      if (ok) shown++;
    });
    cats.forEach(function (sec) {
      var live = sec.querySelectorAll(".tool:not([hidden])").length;
      sec.hidden = terms.length > 0 && live === 0;
    });
    tocLinks.forEach(function (a) {
      var id = (a.getAttribute("href") || "").replace("#", "");
      var el = document.getElementById(id);
      a.hidden = !!(el && el.hidden);
    });
    document.querySelectorAll(".toc-block").forEach(function (b) {
      b.hidden = terms.length > 0 && b.querySelectorAll(".tool-toc a:not([hidden])").length === 0;
    });
    chips.forEach(function (c) {
      var sec = document.getElementById(c.getAttribute("data-cat") || "");
      c.hidden = !!(sec && sec.hidden);
    });
    document.querySelectorAll(".cat-card").forEach(function (c) {
      var sec = document.getElementById((c.getAttribute("href") || "").replace("#", ""));
      c.hidden = !!(sec && sec.hidden);
    });
    if (empty) empty.hidden = !terms.length || shown > 0;
    if (countOut) {
      countOut.textContent = !terms.length ? "" : shown + (shown === 1 ? T.one : T.found);
    }
    if (terms.length && window.trackMBEvent && apply.t !== raw) {
      apply.t = raw;
      clearTimeout(apply.tt);
      apply.tt = setTimeout(function () {
        window.trackMBEvent("Field Tool Search", { q: raw.slice(0, 60), results: shown });
      }, 900);
    }
  }
  if (filt) {
    filt.addEventListener("input", function () { apply(filt.value); });
    if (filt.value) apply(filt.value);
  }

  /* A deep link into a hidden screen (someone shared #cclear while a filter was
     typed, or arrived from a chapter page) must always land on a visible card. */
  function revealHash() {
    var id = (location.hash || "").replace("#", "");
    if (!id) return;
    var el = document.getElementById(id);
    if (!el) return;
    if (filt && filt.value) { filt.value = ""; apply(""); }
    var sec = el.closest ? el.closest(".tool-cat") : null;
    if (sec) sec.hidden = false;
    el.hidden = false;
    /* content-visibility:auto gives offscreen cards an *estimated* height, so the
       browser's own anchor scroll lands in the wrong place and corrects itself only
       as cards materialise. Scroll again once layout has settled, twice, because the
       first correction can itself shift the target. Without this a shared tool link
       drops the reader near the right screen instead of on it. */
    /* content-visibility:auto is what keeps a 105-screen page cheap to paint, but it
       makes anchor scrolling unreliable: offscreen cards carry an *estimated* height,
       the real heights arrive as they materialise, and the page keeps growing under
       the scroll. Two things bite here - scrollIntoView is asynchronous, so reading
       the position immediately after it returns gives the old value, and the document
       is still 3kpx shorter than final at 1.5s. So aim at the goal repeatedly and
       measure a frame later, until the card is actually where it should be. */
    var GOAL = 76;            /* matches .tool scroll-margin-top */
    var tries = 0;
    (function aim() {
      el.scrollIntoView({ block: "start", behavior: "auto" });
      requestAnimationFrame(function () {
        var off = el.getBoundingClientRect().top - GOAL;
        if (Math.abs(off) <= 8 || ++tries >= 25) return;
        setTimeout(aim, 100);
      });
    })();
    if (window.trackMBEvent && el.classList.contains("tool")) {
      window.trackMBEvent("Field Tool Deep Link", { tool: id });
    }
  }
  window.addEventListener("hashchange", revealHash);
  revealHash();
})();

/* Search has to reach inside the collapsed per-category lists, otherwise a
   matching screen is hidden behind a closed <details> and reads as "no result".
   Open them while a query is active; restore the collapsed state when it clears. */
(function () {
  "use strict";
  var filt = document.getElementById("tool-filter");
  var lists = Array.prototype.slice.call(document.querySelectorAll("details.toc-block"));
  if (!filt || !lists.length) return;
  filt.addEventListener("input", function () {
    var on = !!filt.value.trim();
    lists.forEach(function (d) { d.open = on; });
  });
})();

/* The floating "back to tools" pill exists for pages with no rail. Here the rail
   is always on screen and does the same job better, so the pill is just another
   thing covering content on a phone. */
(function () {
  "use strict";
  if (!document.querySelector(".cat-rail")) return;
  function kill() {
    var b = document.getElementById("back-to-tools");
    if (b && b.parentNode) b.parentNode.removeChild(b);
  }
  kill();
  document.addEventListener("DOMContentLoaded", kill);
  setTimeout(kill, 0);
})();
