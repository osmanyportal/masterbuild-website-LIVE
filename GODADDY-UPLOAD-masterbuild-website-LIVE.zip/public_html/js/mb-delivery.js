/* Masterbuild Consulting — post-purchase delivery.
   Stripe redirects here after a completed Payment Link checkout and appends its
   own session id. The page shows nothing until that id is present, so the
   delivery block is not something a visitor reaches by typing the URL.

   This is deliberately light protection, not DRM: the files sit at an
   unguessable path and a buyer could share the link. That is the accepted
   trade for delivering a paid package in three seconds instead of whenever
   someone next checks email. Watermarked per-buyer delivery is the upgrade
   path if sharing ever becomes a real number. */
(function () {
  "use strict";
  var q = new URLSearchParams(location.search);
  var session = q.get("session_id") || "";
  var product = (q.get("p") || "").toLowerCase();

  var PACKS = {
    ch8: {
      name: "IMC 2024 Chapter 8 — Chimneys and Vents Field Guide",
      dir: "/library/d7f4a1c9e2b8/ch8/",
      zip: ["masterbuild-imc-2024-chapter-8-complete-package.zip", "Everything below, in one file"],
      files: [
        ["00-read-first.pdf", "Read First", "PDF · 4 pages · start here, three minutes"],
        ["masterbuild-imc-2024-chapter-8-chimneys-and-vents-field-guide.pdf", "The field guide", "PDF · 28 pages · 13 sections, 11 working tools"],
        ["masterbuild-imc-2024-chapter-8-chimneys-and-vents-field-guide.docx", "The field guide, editable", "DOCX · adopt it into your own QA process"],
        ["masterbuild-imc-2024-chapter-8-working-tools.xlsx", "Working tools workbook", "XLSX · 12 tabs · fillable on a laptop"]
      ]
    },
    ch7: {
      name: "IMC 2024 Chapter 7 — Combustion Air Field Guide",
      dir: "/library/d7f4a1c9e2b8/ch7/",
      zip: ["masterbuild-imc-2024-chapter-7-complete-package.zip", "Everything below, in one file"],
      files: [
        ["00-read-first.pdf", "Read First", "PDF · start here, three minutes"],
        ["masterbuild-imc-2024-chapter-7-combustion-air-field-guide.pdf", "The field guide", "PDF · 21 pages"],
        ["masterbuild-imc-2024-chapter-7-combustion-air-field-guide.docx", "The field guide, editable", "DOCX"]
      ]
    }
  };
  /* The bundle is both packs, in the order a job runs: air in, then air out. */
  var ORDERS = { ch8: ["ch8"], ch7: ["ch7"], ch78: ["ch7", "ch8"], ch788: ["ch7", "ch8"] };
  var packs = ORDERS[product] || null;

  function row(dir, f, primary) {
    var a = document.createElement("a");
    a.className = "dl" + (primary ? " dl-primary" : "");
    a.href = dir + f[0];
    a.setAttribute("download", "");
    a.innerHTML = '<span class="dl-name">' + f[1] + "</span><span class=\"dl-meta\">" + f[2] + "</span>";
    a.addEventListener("click", function () {
      if (window.trackMBEvent) window.trackMBEvent("Guide Download", { file: f[0] });
    });
    return a;
  }

  var box = document.getElementById("delivery");
  if (!box) return;

  if (!session || !packs) {
    /* No completed checkout in this URL. Say so plainly and give a way out. */
    document.getElementById("delivery-fallback").hidden = false;
    if (window.trackMBEvent) window.trackMBEvent("Delivery Page No Session", { p: product || "none" });
    return;
  }

  packs.forEach(function (key) {
    var pack = PACKS[key];
    if (!pack) return;
    var h = document.createElement("h3");
    h.className = "dl-head";
    h.textContent = pack.name;
    box.appendChild(h);
    box.appendChild(row(pack.dir, [pack.zip[0], "Download everything", "ZIP \u00b7 " + pack.zip[1]], true));
    pack.files.forEach(function (f) { box.appendChild(row(pack.dir, f, false)); });
  });
  box.hidden = false;
  document.getElementById("delivery-live").hidden = false;
  if (window.trackMBEvent) window.trackMBEvent("Guide Delivered", { p: product });
})();
