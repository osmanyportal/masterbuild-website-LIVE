/* Masterbuild Consulting — field-tool result layer.
   One script that upgrades every tool on the page at once: copy-to-clipboard,
   carry-into-intake, the adopted-code line, per-tool usage measurement, and
   shareable deep links. Adding a new tool to mb-tools.js requires no change here,
   as long as the result panel keeps the .tool-result / -title / -body convention. */
(function () {
  "use strict";
  var ES = document.documentElement.lang === "es";
  var T = ES ? {
    copy: "Copiar resultado", copied: "Copiado", link: "Copiar enlace", linked: "Enlace copiado",
    send: "Enviar esto a Masterbuild",
    boundary: "Estimación educativa de masterbuildconsulting.com/herramientas-de-campo/ — no es una determinación de código ni ingeniería sellada.",
    path: "Ruta adoptada: Miami-Dade revisa contra el Código de Construcción de Florida, Mecánico, 8.ª Edición (2023) — basado en el IMC 2021 — más enmiendas locales. La 9.ª Edición (2026) está programada para el 31 de diciembre de 2026; verifique en floridabuilding.org. Daily Code Talk enseña el IMC 2024 modelo, que no es lo que se revisa hoy."
  } : {
    copy: "Copy result", copied: "Copied", link: "Copy link", linked: "Link copied",
    send: "Send this to Masterbuild",
    boundary: "Educational estimate from masterbuildconsulting.com/field-tools/ — not a code determination, not sealed engineering.",
    path: "Adopted path: Miami-Dade reviews against the Florida Building Code, Mechanical, 8th Edition (2023) — based on IMC 2021 — plus local amendments. The 9th Edition (2026) is scheduled to take effect 31 December 2026; verify at floridabuilding.org. Daily Code Talk teaches the model IMC 2024, which is not what is reviewed today."
  };
  var INTAKE = ES ? "/contacto/" : "/send/";
  var CONTACT_LINE = "Masterbuild Consulting · (786) 398-6940 · masterbuildconsulting.com";

  function txt(el) {
    if (!el) return "";
    return (el.innerText || el.textContent || "").replace(/\s+\n/g, "\n").replace(/[ \t]{2,}/g, " ").trim();
  }
  function track(name, props) { if (window.trackMBEvent) window.trackMBEvent(name, props || {}); }

  /* The tool's own section id is the stable name for measurement and deep links. */
  function toolId(panel) {
    var sec = panel.closest ? panel.closest(".tool") : null;
    if (sec && sec.id) return sec.id;
    return (panel.id || "tool").replace(/-result$/, "");
  }
  function toolTitle(panel) {
    var sec = panel.closest ? panel.closest(".tool") : null;
    var h = sec && sec.querySelector("h2");
    return h ? txt(h) : toolId(panel);
  }

  /* Plain-text record of one run: the tool, what was entered, what came back. */
  function summarize(panel) {
    var id = toolId(panel);
    var lines = [toolTitle(panel)];
    var sec = panel.closest ? panel.closest(".tool") : null;
    var form = sec && sec.querySelector("form");
    if (form) {
      var inputs = form.querySelectorAll("input, select, textarea");
      var entered = [];
      Array.prototype.forEach.call(inputs, function (el) {
        if (el.type === "submit" || el.type === "button" || el.type === "hidden") return;
        if ((el.type === "checkbox" || el.type === "radio") && !el.checked) return;
        var v = el.type === "checkbox" || el.type === "radio"
          ? (el.value || "yes")
          : (el.value || "");
        if (!v) return;
        var lab = form.querySelector('label[for="' + el.id + '"]');
        var name = lab ? txt(lab).replace(/\s*\(.*$/, "") : (el.name || el.id || "input");
        if (el.tagName === "SELECT" && el.selectedIndex >= 0) v = el.options[el.selectedIndex].text;
        entered.push("  " + name + ": " + v);
      });
      if (entered.length) { lines.push(ES ? "Entradas:" : "Inputs:"); lines = lines.concat(entered); }
    }
    var t = txt(document.getElementById(panel.id + "-title"));
    var b = txt(document.getElementById(panel.id + "-body"));
    /* Some panels render into a textarea instead of a title/body pair. */
    if (!t && !b) {
      var ta = panel.querySelector("textarea.copy-out, textarea");
      if (ta && ta.value) b = ta.value.trim();
    }
    if (t) { lines.push(""); lines.push(ES ? "Resultado:" : "Result:"); lines.push("  " + t); }
    if (b) { lines.push(""); lines.push(b); }
    lines.push("");
    lines.push(T.path);
    lines.push(T.boundary);
    lines.push(CONTACT_LINE);
    lines.push(location.origin + location.pathname + "#" + id);
    return { id: id, text: lines.join("\n") };
  }

  function copy(btn, text, doneLabel) {
    if (!text) return;
    function ok() {
      var was = btn.textContent;
      btn.textContent = doneLabel;
      setTimeout(function () { btn.textContent = was; }, 2200);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(ok).catch(function () {});
      return;
    }
    try {
      var ta = document.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", "");
      ta.style.position = "fixed"; ta.style.left = "-9999px";
      document.body.appendChild(ta); ta.select();
      document.execCommand("copy"); document.body.removeChild(ta); ok();
    } catch (_e) { /* clipboard unavailable */ }
  }

  /* Stash for the intake form. Single use, two-hour expiry, private-mode safe. */
  function stash(id, title, text) {
    try {
      window.sessionStorage.setItem("mb_tool_result", JSON.stringify({
        tool: id, title: title, text: text, at: Date.now(),
        page: location.pathname + "#" + id
      }));
    } catch (_e) {}
  }


  /* ── Contextual guide match ─────────────────────────────────────────────
     A free tool answers "which path am I on." The chapter field guide answers
     "how do I prove it, and what do I hand the reviewer." Matching the two at the
     moment the visitor gets a result is the honest place to make that offer.
     Chapter is read from the tool's own kicker line, so a new tool inherits this
     with no change here. Prices come from MB_CATALOG, never typed. */
  var GUIDES = {
    1: { key: "imcChapter1Guide", en: "IMC Chapter 1 Permit Process Field Guide",
         es: "Gu\u00eda de Proceso de Permisos IMC Cap\u00edtulo 1" },
    2: { key: "imcChapter2Guide", en: "IMC Chapter 2 Definitions & Redline Prevention Guide",
         es: "Gu\u00eda de Definiciones y Prevenci\u00f3n de Redlines IMC Cap\u00edtulo 2" },
    3: { key: "imcChapter3Guide", en: "IMC Chapter 3 Installation Readiness Guide",
         es: "Gu\u00eda de Preparaci\u00f3n para Instalaci\u00f3n IMC Cap\u00edtulo 3" },
    4: { key: "ventilationFieldGuide", en: "Ventilation & Outdoor Air Field Guide",
         es: "Gu\u00eda de Campo de Ventilaci\u00f3n y Aire Exterior" },
    5: { key: "imcChapter5Guide", en: "IMC Chapter 5 Exhaust Systems Field Guide",
         es: "Gu\u00eda de Sistemas de Extracci\u00f3n IMC Cap\u00edtulo 5" },
    6: { key: "imcChapter6Guide", en: "IMC Chapter 6 Duct Systems Field Guide",
         es: "Gu\u00eda de Sistemas de Ductos IMC Cap\u00edtulo 6" },
    7: { key: "imcChapter7Guide", en: "Combustion Air Field Guide (IMC Chapter 7 series)",
         es: "Gu\u00eda de Campo de Aire de Combusti\u00f3n (serie Cap\u00edtulo 7)" },
    8: { key: "imcChapter8Guide", en: "IMC Chapter 8 Chimneys and Vents Field Guide",
         es: "Gu\u00eda de Chimeneas y Venteos IMC Cap\u00edtulo 8" }
  };

  /* Read the chapter from the kicker: "04 · IMC Chapter 7 ...", "02 · IMC Table 403...",
     "06 · IMC 607", "12 · IMC 506.3.13". NEC tools return null on purpose. */
  function chapterOf(sec) {
    if (!sec) return null;
    /* A wrong offer is worse than no offer, and the kicker regex guesses wrong on
       any screen whose governing document is not the mechanical code - the
       combustion-air screens cite fuel gas 304, which would read as chapter 3.
       Every tool therefore declares its own chapter, or "none" to stay silent. */
    var declared = sec.getAttribute("data-guide");
    if (declared) {
      if (declared === "none") return null;
      var d = parseInt(declared, 10);
      return isNaN(d) ? null : d;
    }
    var k = sec.querySelector(".tool-kicker");
    var s = k ? txt(k) : "";
    if (!s || /\bNEC\b/.test(s)) return null;
    s = s.replace(/^\s*\d+\s*[\u00b7|-]\s*/, ""); /* drop the "04 \u00b7 " index prefix */
    var m = s.match(/Chapter\s+(\d)/i);
    if (m) return parseInt(m[1], 10);
    /* Any bare section number 101-799 anywhere in the kicker: "IMC Table 403.3.1.1",
       "IMC 506.3.13", "IMC 401 vs 403". First match wins. */
    m = s.match(/\b([1-8])\d{2}(?:\.\d+)*\b/);
    if (m) return parseInt(m[1], 10);
    return null;
  }

  function guideFor(sec) {
    var ch = chapterOf(sec);
    var g = ch && GUIDES[ch];
    if (!g) return null;
    var cat = window.MB_CATALOG;
    var offer = cat && cat.offers && cat.offers[g.key];
    if (!offer || !offer.url) return null;
    return { url: offer.url, name: ES ? g.es : g.en, price: cat.price ? cat.price(g.key) : "" };
  }

  function augment(panel) {
    if (!panel || panel.hidden) return;
    var s = summarize(panel);
    var title = toolTitle(panel);
    stash(s.id, title, s.text);

    var bar = panel.querySelector(".tool-actions");
    if (!bar) {
      bar = document.createElement("p");
      bar.className = "tool-actions";

      var cbtn = document.createElement("button");
      cbtn.type = "button"; cbtn.className = "ghost-btn tool-copy"; cbtn.textContent = T.copy;
      cbtn.addEventListener("click", function () {
        copy(cbtn, bar.getAttribute("data-copy") || "", T.copied);
        track("Field Tool Copy", { tool: bar.getAttribute("data-tool") || "" });
      });
      bar.appendChild(cbtn);

      var lbtn = document.createElement("button");
      lbtn.type = "button"; lbtn.className = "ghost-btn tool-link"; lbtn.textContent = T.link;
      lbtn.addEventListener("click", function () {
        copy(lbtn, location.origin + location.pathname + "#" + (bar.getAttribute("data-tool") || ""), T.linked);
        track("Field Tool Share", { tool: bar.getAttribute("data-tool") || "" });
      });
      bar.appendChild(lbtn);

      var send = document.createElement("a");
      send.className = "cta-primary tool-send"; send.textContent = T.send;
      bar.appendChild(send);

      panel.appendChild(bar);
    }
    bar.setAttribute("data-tool", s.id);
    bar.setAttribute("data-copy", s.text);
    var sendLink = bar.querySelector(".tool-send");
    if (sendLink) sendLink.href = INTAKE + "?source=" + encodeURIComponent("field-tool:" + s.id);

    /* One adopted-code line per panel, appended after the body. */
    if (!panel.querySelector(".tool-codepath")) {
      var note = document.createElement("p");
      note.className = "note tool-codepath";
      note.textContent = T.path;
      var body = document.getElementById(panel.id + "-body");
      if (body && body.parentNode === panel) panel.insertBefore(note, body.nextSibling);
      else panel.insertBefore(note, bar);
    }

    /* The guide that covers this tool's chapter, priced from the catalog. */
    var sec = panel.closest ? panel.closest(".tool") : null;
    var g = guideFor(sec);
    var row = panel.querySelector(".tool-guide");
    if (g) {
      if (!row) {
        row = document.createElement("p");
        row.className = "note tool-guide";
        panel.insertBefore(row, panel.querySelector(".tool-actions"));
      }
      row.innerHTML = (ES
        ? "Esta herramienta clasifica la ruta. El m\u00e9todo completo, las hojas de trabajo imprimibles y lo que se entrega al revisor est\u00e1n en la "
        : "This tool classifies the path. The full method, the printable working sheets, and what you hand the reviewer are in the ")
        + '<a href="' + g.url + '" rel="noopener">' + g.name + (g.price ? " \u2014 " + g.price : "") + "</a>"
        + (ES ? ". El trabajo sellado sigue requiriendo un alcance escrito." : ". Sealed work still requires a written scope.");
      var a = row.querySelector("a");
      if (a) a.addEventListener("click", function () {
        track("Tool Guide Click", { tool: s.id, guide: g.name });
      });
    } else if (row) {
      row.parentNode.removeChild(row);
    }

    /* Shareable deep link without adding a history entry per run. */
    try {
      if (history && history.replaceState) {
        history.replaceState(null, "", location.pathname + location.search + "#" + s.id);
      }
    } catch (_e) {}

    track("Field Tool Used", { tool: s.id, title: title });
  }

  /* One delegated listener covers every form on the page, current and future.
     Capture phase so it is queued before the tool's own handler renders; the
     timeout then reads the finished DOM. */
  document.addEventListener("submit", function (e) {
    var form = e.target;
    if (!form || form.id === "mb-intake") return;
    var sec = form.closest ? form.closest(".tool") : null;
    if (!sec) return;
    setTimeout(function () {
      var panel = sec.querySelector(".tool-result");
      if (panel && !panel.hidden) augment(panel);
    }, 0);
  }, true);

  /* Tools that render on change rather than submit. */
  document.addEventListener("click", function (e) {
    var btn = e.target && e.target.closest ? e.target.closest(".tool button") : null;
    if (!btn || btn.type === "submit" || btn.classList.contains("ghost-btn")) return;
    var sec = btn.closest(".tool");
    if (!sec) return;
    setTimeout(function () {
      var panel = sec.querySelector(".tool-result");
      if (panel && !panel.hidden && !panel.querySelector(".tool-actions")) augment(panel);
    }, 0);
  }, true);
})();
