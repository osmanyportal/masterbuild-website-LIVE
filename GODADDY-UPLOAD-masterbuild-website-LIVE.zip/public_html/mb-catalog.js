// mb-catalog.js — single source of truth for every public commercial destination.
//
// Checkout links, the scheduling link, the subscribe endpoint, and each offer's
// published price are stated HERE and nowhere else in the JavaScript. Before this
// file the Calendly URL was written literally in five files and the Chapter 1
// checkout in three, so a price change or a relinked Stripe product meant editing
// several files and hoping none were missed.
//
// Loaded first by every shell (homepage, Daily Code Talk, Resources), so anything
// that renders an offer reads the same values.
//
// RULES
//   - URLs here are owner-approved production links. tools/qa_release.py holds the
//     same set in PROTECTED_URLS and fails the release if one goes missing.
//   - Keep every URL a complete string literal. The release gate greps for the
//     exact URL, and a value assembled by concatenation would not be found.
//   - noscript fallbacks in the shells still carry literal hrefs. Static HTML
//     cannot read this file, so those stay in sync by hand and are covered by the
//     same PROTECTED_URLS check.
const MB_CATALOG = {
  scopingCall: "https://calendly.com/osmany-portal-masterbuildconsulting/30min",

  subscribe: {
    username: "masterbuild",
    listPage: "https://buttondown.com/masterbuild",
    endpoint: "https://buttondown.email/api/emails/embed-subscribe/masterbuild",
    // Every subscriber keeps this tag. Series tags are added alongside it, never
    // instead of it, so existing list automations are unaffected.
    baseTag: "daily-code-talk",
    seriesTags: {
      IMC: "mechanical-edition",
      NEC: "sparky-edition"
    }
  },

  // price is the published USD figure. Formatted for display via MB_CATALOG.price().
  offers: {
    imcChapter1Guide: { url: "https://buy.stripe.com/9B6dR92A84LT9KPaTJ2Nq04", price: 57 },
    imcChapter2Guide: { url: "https://buy.stripe.com/7sY7sLgqY0vDf59e5V2Nq05", price: 57 },
    imcChapter3Guide: { url: "https://buy.stripe.com/6oU7sLb6E9294qv7Hx2Nq06", price: 57 },
    imcChapter5Guide: { url: "https://buy.stripe.com/dRm8wPa2A6U1e15f9Z2Nq07", price: 199 },
    imcChapter6Guide: { url: "https://buy.stripe.com/6oUaEX7Usa6d7CHbXN2Nq08", price: 149 },
    imcChapter7Guide: { url: "https://buy.stripe.com/3cIeVd5Mkbah9KP8LB2Nq09", price: 149 },
    imcChapter67Bundle: { url: "https://buy.stripe.com/fZu9ATdeM1zHg9d2nd2Nq0a", price: 249 },
    permitReadinessPack: { url: "https://buy.stripe.com/bJefZh5Mk4LTe151j92Nq00", price: 79 },
    ownerSideBundle: { url: "https://buy.stripe.com/aFa3cvdeM9290afd1R2Nq02", price: 99 },
    ventilationFieldGuide: { url: "https://buy.stripe.com/aFaeVd0s0a6d9KPf9Z2Nq01", price: 149 },

    // Chapter 8 is built and QA'd. It stays inert on the site until the owner creates the
    // Stripe Payment Link and approves the price: with no url, every offer surface skips it,
    // so nothing advertises a checkout that does not exist. Fill url and price to go live.
    // Activation is one command: tools/activate_offer.py imcChapter8Guide <url> <price>.
    imcChapter8Guide: { url: "https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b", price: 199 },

    // Combustion air and venting are the same appliance-room conversation: a buyer with a
    // gas appliance in a closet needs both books, and the 6+7 bundle already proved the
    // mechanic. Staged inert alongside Chapter 8 so one activation session lights up both.
    imcChapter78Bundle: { url: "https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c", price: 299 }
  },

  // Bundle arithmetic lives here so no page ever types a price the catalog
  // does not back, and so component price changes propagate automatically.
  listPrice: function (keys) {
    var total = 0;
    for (var i = 0; i < keys.length; i++) {
      var o = MB_CATALOG.offers[keys[i]];
      if (!o || typeof o.price !== "number") return "";
      total += o.price;
    }
    return "$" + total;
  },

  savings: function (bundleKey, componentKeys) {
    var b = MB_CATALOG.offers[bundleKey];
    if (!b) return "";
    var total = 0;
    for (var i = 0; i < componentKeys.length; i++) {
      var o = MB_CATALOG.offers[componentKeys[i]];
      if (!o || typeof o.price !== "number") return "";
      total += o.price;
    }
    return "$" + (total - b.price);
  },

  price: function (key) {
    var offer = MB_CATALOG.offers[key];
    if (!offer || typeof offer.price !== "number") return "";
    return "$" + offer.price;
  },

  // True only when the offer has an approved price and a live checkout.
  sellable: function (key) {
    var offer = MB_CATALOG.offers[key];
    return !!(offer && offer.url && typeof offer.price === "number");
  },

  // Subscribe tags for a given series. Pass "IMC" or "NEC"; omit for the plain
  // archive-wide signup.
  subscribeTags: function (codeFamily) {
    var tags = [MB_CATALOG.subscribe.baseTag];
    var seriesTag = MB_CATALOG.subscribe.seriesTags[codeFamily];
    if (seriesTag) tags.push(seriesTag);
    return tags;
  }
};

window.MB_CATALOG = MB_CATALOG;
