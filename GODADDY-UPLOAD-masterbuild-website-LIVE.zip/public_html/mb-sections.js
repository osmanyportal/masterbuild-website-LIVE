// mb-sections.jsx - Services, Mission-Critical, Markets, Daily Code Talk, Authority

// Owner-approved public resource checkouts. Keep these centralized so pricing,
// product cards, analytics, and release QA point to the same production links.
const CONFIG_LINK_PERMIT_READINESS_PACK = window.MB_CATALOG.offers.permitReadinessPack.url;
const CONFIG_LINK_VENTILATION_FIELD_GUIDE = window.MB_CATALOG.offers.ventilationFieldGuide.url;
const CONFIG_LINK_OWNER_SIDE_BUNDLE = window.MB_CATALOG.offers.ownerSideBundle.url;
const CONFIG_LINK_IMC_CHAPTER1_GUIDE = window.MB_CATALOG.offers.imcChapter1Guide.url;
const CONFIG_LINK_IMC_CHAPTER2_GUIDE = window.MB_CATALOG.offers.imcChapter2Guide.url;
const CONFIG_LINK_IMC_CHAPTER3_GUIDE = window.MB_CATALOG.offers.imcChapter3Guide.url;
const CONFIG_LINK_IMC_CHAPTER5_GUIDE = window.MB_CATALOG.offers.imcChapter5Guide.url;
const CONFIG_LINK_IMC_CHAPTER6_GUIDE = window.MB_CATALOG.offers.imcChapter6Guide.url;
const CONFIG_LINK_IMC_CHAPTER7_GUIDE = window.MB_CATALOG.offers.imcChapter7Guide.url;
const CONFIG_LINK_IMC_CHAPTER67_BUNDLE = window.MB_CATALOG.offers.imcChapter67Bundle.url;
const CONFIG_LINK_IMC_CHAPTER8_GUIDE = window.MB_CATALOG.offers.imcChapter8Guide.url;
const CONFIG_LINK_IMC_CHAPTER78_BUNDLE = window.MB_CATALOG.offers.imcChapter78Bundle.url;
const RESOURCE_LEAD_MAGNET_SAMPLE_CHECKLIST_PDF = "uploads/permit-readiness-sample-checklist.pdf";
const RESOURCE_PAYMENT_LINKS = {
  permitReadiness: CONFIG_LINK_PERMIT_READINESS_PACK,
  ventilationGuide: CONFIG_LINK_VENTILATION_FIELD_GUIDE,
  ownerSideBundle: CONFIG_LINK_OWNER_SIDE_BUNDLE,
  imcChapter1Guide: CONFIG_LINK_IMC_CHAPTER1_GUIDE,
  chapter2Guide: CONFIG_LINK_IMC_CHAPTER2_GUIDE,
  chapter3Guide: CONFIG_LINK_IMC_CHAPTER3_GUIDE,
  chapter5Guide: CONFIG_LINK_IMC_CHAPTER5_GUIDE,
  chapter6Guide: CONFIG_LINK_IMC_CHAPTER6_GUIDE,
  chapter7Guide: CONFIG_LINK_IMC_CHAPTER7_GUIDE,
  chapter67Bundle: CONFIG_LINK_IMC_CHAPTER67_BUNDLE,
  chapter8Guide: CONFIG_LINK_IMC_CHAPTER8_GUIDE,
  chapter78Bundle: CONFIG_LINK_IMC_CHAPTER78_BUNDLE
};

// Keep products in this set until the checkout destination is public and verified.
// All current cards resolve only through mb-catalog.js; an empty set means each listed offer has
// an approved public checkout destination rather than a dashboard, sandbox, or notify-me route.
const RESOURCE_COMING_SOON_PRODUCT_IDS = new Set();
// The homepage is not loaded with dct-data.js, so its published counts cannot be
// derived the way the archive derives its own. These three numbers are the only
// place the homepage states a post count - bump them when a batch publishes.
const DCT_COUNTS = {
  imc: 234,
  nec: 22,
  total: 256
};
const SECTIONS_CONTENT = {
  en: {
    services: {
      eyebrow: "/ Services",
      headline: "Six ways clients bring us in",
      sub: "Organized around outcomes - because most clients start with a business problem, not a mechanical or electrical label.",
      items: [{
        num: "01",
        tag: "Permit Design",
        title: "Permit-Level MEP Construction Documents",
        body: "Coordinated HVAC, plumbing, fire protection, and electrical design drawings built for permit submission. Code logic, interdisciplinary coordination, and comment-response support included.",
        bullets: ["Permit-ready CDs across all MEP disciplines", "Coordination with architect and structural", "Disciplined comment-response support", "Code-compliant, field-constructable drawings"],
        href: "/send/"
      }, {
        num: "02",
        tag: "Technical Review & QA/QC",
        title: "Independent MEP Review and Technical QA",
        body: "For teams that need stronger review, defensible engineering support, forensic second opinions, or technical oversight on complex scopes before permit or construction.",
        bullets: ["Plan review and peer check services", "Forensic and technical second opinions", "RFI and submittal technical support", "Owner-side QA/QC advisory"],
        href: "/send/"
      }, {
        num: "03",
        tag: "Existing Buildings",
        title: "Existing-Building MEP Assessments & Feasibility Studies",
        body: "MEP-focused feasibility support for existing commercial buildings  -  HVAC, plumbing, fire protection, and electrical condition screening, infrastructure capacity, code exposure under change-of-occupancy or renovation scope, and due-diligence issues screened before more money moves in the wrong direction.",
        bullets: ["MEP feasibility reports for existing buildings", "HVAC, plumbing, fire protection & electrical condition screening", "Utility and infrastructure capacity review", "Field verification against existing conditions"],
        href: "/existing-buildings/"
      }, {
        num: "04",
        tag: "Construction Advisory",
        title: "Construction-Phase Technical Advisory",
        body: "Direct PE judgment close to RFIs, submittals, field questions, and scope decisions after permit. Protects schedule, budget, and technical quality during construction.",
        bullets: ["RFI and submittal technical review", "Field inspection support", "Owner's representative advisory", "Inspection and closeout support"],
        href: "/send/"
      }, {
        num: "05",
        tag: "Electrical Building Recertification",
        title: "Electrical Building Recertification Readiness",
        body: "For Miami-Dade owners and managers facing a 30-year or legacy 40-year building-recertification matter, Masterbuild provides a defined Electrical Building Recertification readiness path: records, access, field observations, corrective-action priorities, and the responsible-professional route before report work begins.",
        bullets: ["Prior reports, permits, single-lines, and maintenance-record triage", "Defined-scope electrical field review and condition documentation", "Deficiency priorities, access planning, and corrective-action coordination", "Report signing and sealing only after the responsible electrical-discipline professional confirms authority and project eligibility"],
        href: "/electrical-building-recertification-miami/"
      }, {
        num: "06",
        tag: "Retainer",
        title: "Monthly Design Advisory",
        body: "A standing PE available to owners, architects, and contractors who need code and coordination judgment without opening a full permit-set engagement every time a question appears.",
        bullets: ["Written questions answered against the adopted code path", "Comment-triage before a resubmittal is burned", "Coordination calls with the architect and GC", "Scoped separately from sealed production"],
        href: "/send/"
      }],
      cta: "View All Services"
    },
    mission: {
      eyebrow: "/ Mission-Critical",
      headline: "MEP for spaces where downtime is not an option",
      body1: "Masterbuild Consulting supports MEP design for environments where system performance, uptime, coordination, and maintainability are critical. These projects require more than basic permit drawings.",
      body2: "Careful attention to HVAC loads, ventilation, redundancy, electrical design, equipment access, fire protection, plumbing reliability, controls, and code compliance - this is not a checkbox exercise.",
      note: "Where many MEP firms stop, Masterbuild has the technical depth to continue.",
      bullets: ["HVAC load analysis and redundancy coordination", "Hospital & ambulatory care ventilation (ASHRAE 170 / NFPA 99)", "Lab exhaust separation, pressurization, and chemical storage ventilation", "Clean room classifications and air change rate requirements", "Electrical design for critical systems, UPS, service, and distribution", "Ventilation, pressurization, and air quality", "Equipment access, clearance, and maintainability", "Fire protection and suppression coordination", "Code compliance for high-reliability environments"],
      cta: "Discuss a Mission-Critical Scope"
    },
    markets: {
      eyebrow: "/ Markets",
      headline: "Who we work with",
      sub: "Masterbuild serves a broad range of project types. The common thread is clients who need engineering judgment close to the work - not a production shop.",
      items: [{
        title: "Healthcare & Medical Facilities",
        desc: "Hospitals, ambulatory care centers, surgery centers, and medical offices - where ASHRAE 170, NFPA 99, pressure relationships, filtration, and infection control requirements are non-negotiable."
      }, {
        title: "Labs & Research Facilities",
        desc: "Wet labs, dry labs, clean rooms, and research environments requiring precise ventilation, exhaust separation, pressurization, chemical storage coordination, and code compliance beyond standard permit work."
      }, {
        title: "Data Centers & Server Rooms",
        desc: "Mission-critical cooling, redundancy, precise humidity control, electrical design, and power distribution coordination for environments where MEP system failure carries direct operational and financial consequences."
      }, {
        title: "Commercial & Office",
        desc: "Office buildings, retail, restaurants, and mixed-use spaces requiring coordinated MEP permit packages and code-compliant documentation."
      }, {
        title: "Tenant Improvements",
        desc: "Fit-outs and interior renovations for commercial tenants where speed, coordination, and permit clarity are critical."
      }, {
        title: "High-End Residential",
        desc: "Custom homes and premium residential projects where MEP quality, coordination, and attention to detail match the finish level."
      }, {
        title: "Multifamily & Mixed-Use",
        desc: "Apartment, condo, and mixed-use buildings requiring full MEP coordination across multiple units, disciplines, and occupancy types."
      }, {
        title: "Existing Building Renovations",
        desc: "Retrofits, conversions, and adaptive reuse projects where existing infrastructure, plumbing tie-ins, capacity limits, and code compliance define the scope."
      }, {
        title: "Assessments & Studies",
        desc: "Commercial existing-building feasibility reports, plumbing-system assessments, infrastructure capacity, ventilation deficiencies, and due diligence screened before more decisions get made in the wrong direction."
      }, {
        title: "High-Reliability Spaces",
        desc: "Environments where system uptime, redundancy, maintainability, and coordination require careful engineering attention from the start."
      }, {
        title: "Owner & Contractor Advisory",
        desc: "Technical support for owners, developers, GCs, and property managers navigating MEP decisions across design and construction phases."
      }]
    },
    trust: {
      eyebrow: "/ Trusted By",
      headline: "Selected working relationships",
      sub: "Confirmed partner and client relationships only. Masterbuild supports permit sets, energy-site work, and existing-building feasibility reports where direct MEP and plumbing judgment belongs.",
      logos: [{
        name: "Existing Building LLC",
        note: "Feasibility assessment partner",
        body: "Plumbing-system assessment support for existing commercial-building feasibility reports.",
        url: "https://www.existing-building.com/"
      }, {
        name: "MEPTECH Solutions",
        note: "Permit-set PE support",
        body: "PE-backed MEP permit support and signed/sealed delivery coordination where appropriate.",
        url: "https://www.meptechsolutions.com/"
      }, {
        name: "Roble Technologies",
        note: "179D site inspection",
        body: "Existing-building site verification support tied to energy and tax-incentive workflows.",
        url: "https://getroble.com/"
      }, {
        name: "Available on request",
        note: "Additional references",
        body: "References are shared directly when scope and confidentiality allow."
      }],
      sectorsLabel: "Sectors served",
      sectors: ["Architect-led permit work", "Commercial new construction & renovations", "Mid- & high-rise multifamily", "Hospital & healthcare design", "Mission-critical facilities", "Existing conditions & feasibility studies (MEP)", "High-end residential"]
    },
    existingBuildings: {
      eyebrow: "/ Existing Buildings",
      headline: "Existing Building MEP Assessment",
      sub: "For commercial properties in Miami and across Florida where the condition of existing mechanical, plumbing, fire protection, and electrical systems affects what the next scope can do — and what it will cost.",
      body: "Most feasibility reports answer the architecture question. Masterbuild adds the MEP layer: what systems are present, what code applies to the new occupancy or renovation scope under IMC 102 and the Florida Building Code, what stays as lawfully existing, what must be upgraded, and where the real cost exposure lives before drawings start.",
      bullets: [
        "Existing HVAC condition screening and ventilation deficiency review",
        "Plumbing-system capacity and tie-in assessment",
        "Utility and infrastructure service capacity review",
        "Code-compliance exposure under change of occupancy or renovation scope (IMC 102 / FBC)",
        "Fire protection system condition and coverage review",
        "Field verification against existing drawings or as-built conditions"
      ],
      note: "Assessments are scoped and priced per property. Deliverable is a written summary with cost-driver callouts — not a full stamped set. Fixed-fee. PE-direct.",
      cta: "Book a Scoping Call",
      ctaNote: "30-minute call to scope the property and confirm fit."
    },
    daily: {
      eyebrow: "/ Daily Code Talk",
      headline: "The Field-First Code Guide — Mechanical and Electrical.",
      sub: "A working library of drawing-based IMC (Mechanical Edition) and NEC (Sparky Edition) explanations for architects, MEP teams, GCs, owner-reps, and facilities teams who need decisions that survive permit review and field installation. Start free in the archive, then move into guide packs or PE-direct review when a real project is on the table.",
      badge: DCT_COUNTS.total + " public posts · Two series: IMC + NEC · Searchable archive · Clear next step",
      posts: [{
        tag: "Searchable archive",
        title: "Start with the exact code issue.",
        desc: "Search by section, chapter, topic, permit risk, or field coordination issue. No spreadsheet hunting and no scrolling through old LinkedIn posts.",
        href: "/daily-code-talk/"
      }, {
        tag: "Commercial kitchens · IMC 508",
        title: "Kitchen exhaust fails when makeup air is an afterthought.",
        desc: "Use this post to check hood capture, replacement air, kitchen pressure, comfort, controls, and startup risk before the shaft and ceiling are locked.",
        href: "/daily-code-talk/imc-508-commercial-kitchen-makeup-air/"
      }, {
        tag: "Duct openings · IMC 607",
        title: "A damper symbol is not a protection strategy.",
        desc: "Duct crossings need assembly type, damper basis, listing, access, smoke-control logic, and exception proof coordinated before permit or ceiling closure.",
        href: "/daily-code-talk/imc-607-part-1-607-1-607-2-1/"
      }, {
        tag: "Appliance rooms · IMC 701",
        title: "Combustion air needs a proof chain.",
        desc: "Appliance type, fuel path, actual free area, damper interlock, rated-route coordination, and startup verification have to line up.",
        href: "/daily-code-talk/imc-701-combustion-air-scope-dampered-openings/"
      }, {
        tag: "Sparky Edition · NEC Article 90",
        title: "Electrical scope decides mechanical outcomes.",
        desc: "The NEC series read from an MEP-coordination lens: where electrical scope starts and stops, and how that lands on mechanical equipment, disconnects, and field coordination.",
        href: "/daily-code-talk/sparky-edition-nec-90-1-90-2-scope-covered-installations/"
      }],
      cta: "Open Daily Code Talk →",
      ctaLink: "/daily-code-talk/",
      referral: "Forward this link to one engineer on your team who runs the permit set."
    },
    resources: {
      eyebrow: "/ IMC Field Guides",
      headline: "One practical path from code question to project decision.",
      sub: "Start free with the Daily Code Talk archive and Code Desk email list, plus a growing free library of Miami-Dade permit checklists, an HVAC load-calculation checklist, a Florida building-envelope compliance reference, and NEC/IMC glossaries — no email required, see the full Resources page. Use the Chapter 1 guide for process control, the Chapter 2 guide for definition and redline-prevention control, the Chapter 3 guide for installation readiness and field coordination, or the 19-page Permit Readiness Pack for cross-discipline pre-upload, resubmittal, and field-readiness QA/QC. Choose an owner-side or ventilation specialty guide when that is the real risk. Move to a written project-review scope when the decision depends on actual drawings, field conditions, or the adopted code. Each chapter guide is a complete standalone paid package.",
      ascensionLabel: "The lean Daily Code Talk value path.",
      ascension: [
        { step: "01", label: "Archive + Code Desk", price: "Free", desc: "Search the exact issue and receive useful code, field-QA, and resource updates when published.", href: "/daily-code-talk/" },
        { step: "02", label: "Free Checklist Library", price: "Free", desc: "Miami-Dade permit checklists, HVAC load-calculation checklist, Florida envelope compliance reference, and NEC/IMC glossaries — no email required.", href: "/resources/" },
        { step: "03", label: "Permit Workflow", price: "$57 / $79", desc: "Use the Chapter 1 or Chapter 2 guide for permit-process and definition control, or run the cross-discipline upload gate with the Permit Readiness Pack.", href: "#resources" },
        { step: "04", label: "Specialty Review", price: "$99 / $149 / $199", desc: "Use owner-side, ventilation, Chapter 5 exhaust, or Chapter 6 duct-system tools when maintainability, air paths, material selection, access, or field closeout is the risk.", href: "#resources" },
        { step: "05", label: "PE-Led Project Review", price: "Written scope", desc: "Bring actual drawings, jurisdiction, field conditions, and the decision deadline for project-specific review.", href: "/send/" }
      ],
      boundary: "Daily Code Talk and field guides use the 2024 IMC as model-code education. Verify the legally adopted code, local amendments, project scope, referenced standards, listings, manufacturer instructions, and AHJ path before project use. Project-specific engineering and sealed work require a separate written engagement.",
      stats: [{
        value: String(DCT_COUNTS.total),
        label: "Public Daily Code Talk articles",
        desc: "Free, bilingual, drawing-based IMC and NEC explanations organized by chapter, section, permit risk, and field coordination issue."
      }, {
        value: "Ch. 1–7",
        label: "Completed website content",
        desc: "Completed chapters stay searchable while Chapter 8 continues through the LinkedIn-to-website workflow."
      }, {
        value: "Ch. 3",
        label: "Installation field guide",
        desc: "A 19-page buyer-ready workflow for project basis, equipment approval, location, structural/rated-assembly coordination, installation readiness, and field-change control."
      }, {
        value: "7",
        label: "Available working guides",
        desc: "Seven focused resources cover permit process, definition control, installation readiness, duct-system coordination, cross-discipline pre-upload QA/QC, owner-side review, and ventilation / special exhaust."
      }],
      products: [{
        id: "permitReadiness",
        title: "Permit Readiness Review Pack",
        tag: "Cross-Discipline Permit QA/QC",
        audience: "Owners, owner representatives, architects, permit coordinators, MEP and structural teams, GCs, and preconstruction teams preparing an upload or resubmittal",
        price: window.MB_CATALOG.price("permitReadinessPack"),
        body: "A 19-page pre-upload, resubmittal, and field-readiness system for commercial and residential permit sets. Includes project-basis intake, authority routing, cross-discipline gates, building/MEP/structural/zoning/WASD controls, selective coordination, issue log, final upload gate, and a Miami-Dade / Florida source map. Decide: ready, ready with disclosed exceptions, or hold. Client-ready PDF; verify current AHJ requirements. No permit guarantee.",
        cta: "Get the Permit Readiness Pack - $79",
        notifySubject: "Masterbuild Permit Readiness Review Pack purchase interest",
        samplePdf: "uploads/permit-readiness-sample-checklist.pdf",
        samplePreview: "uploads/permit-readiness-sample-preview.png",
        sampleLabel: "Free sample — Permit Readiness cross-discipline workflow (PDF)"
      }, {
        id: "ownerSideBundle",
        title: "Owner-Side MEP Review Checklist Bundle",
        tag: "Owner Risk Control · Available Now",
        audience: "Owners, developers, owner-representatives, architects, facilities teams, and project executives",
        price: window.MB_CATALOG.price("ownerSideBundle"),
        body: "A 30-minute owner-side review system for maintainability, permit control, change-order exposure, inspection failure, cost and schedule guardrails, red-flag language, and issue tracking before decisions become expensive field conditions.",
        notifySubject: "Masterbuild Owner-Side MEP Review Checklist Bundle purchase interest",
        samplePdf: "uploads/owner-side-review-card-sample.pdf",
        samplePreview: "uploads/owner-side-review-card-sample-preview.png",
        sampleLabel: "Free sample — Owner-Side Review Card (PDF)"
      }, {
        id: "ventilationGuide",
        title: "Ventilation & Special Exhaust Field Guide",
        tag: "Technical Specialty · Available Now",
        audience: "MEP designers, architects, contractors, plan reviewers, commissioning teams, and facilities staff",
        price: window.MB_CATALOG.price("ventilationFieldGuide"),
        body: "A field-first review guide for rapid triage, room-by-room ventilation logic, outdoor-air evidence, special-exhaust classification, drawing-sheet proof, controls and coordination, and field closeout before airflow or containment problems reach inspection or occupancy.",
        notifySubject: "Masterbuild Ventilation and Special Exhaust Field Guide purchase interest",
        samplePdf: "uploads/ventilation-oa-math-sample.pdf",
        samplePreview: "uploads/ventilation-oa-math-sample-preview.png",
        sampleLabel: "Free sample — Outdoor-Air Math Review (PDF)"
      }, {
        id: "imcChapter1Guide",
        title: "IMC Chapter 1 Permit Process Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "Engineers, designers, architects, contractors, project managers, permit coordinators",
        price: window.MB_CATALOG.price("imcChapter1Guide"),
        body: "Working checklists, response playbooks, and editable worksheets built from IMC 101–115. Covers AHJ authority and interpretation rights, permit triggers and the no-permit list, construction document requirements, inspection sequencing and hold points, approval and revocation logic, stop-work response, and the formal appeals process. For anyone who loses time to process mistakes — not technical design errors.",
        notifySubject: "Masterbuild IMC Chapter 1 Permit Process Field Guide purchase interest",
        samplePdf: "uploads/ch1-sample.pdf",
        samplePreview: "uploads/ch1-sample-preview.png",
        sampleLabel: "Free sample — IMC 101 Code Path Guide (PDF)"
      }, {
        id: "chapter2Guide",
        title: "IMC 2024 Chapter 2 Definitions & Redline Prevention Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "Mechanical designers, engineers, and QA reviewers at lean MEP/architecture firms preparing or reviewing permit sets",
        price: window.MB_CATALOG.price("imcChapter2Guide"),
        body: "A 19-page PDF guide that turns Chapter 2 definitions into a practical control workflow: identify the definition-sensitive term, trace what it activates, show the proof, and stop unresolved red items before issue. Key terms and escalation-trigger language are highlighted throughout. Includes the guide plus a Definition Control Matrix, a 30-minute pre-submittal audit, and a field change/dispute record. PDF-only, single named-purchaser license.",
        notifySubject: "Masterbuild IMC 2024 Chapter 2 Definitions Field Guide purchase interest",
        samplePdf: "uploads/ch2-sample.pdf",
        samplePreview: "uploads/ch2-sample-preview.png",
        sampleLabel: "Free sample — Chapter 2 Definition Control Quick Guide (PDF)"
      }, {
        id: "chapter3Guide",
        title: "IMC 2024 Chapter 3 Installation Readiness & Field Coordination Guide",
        tag: "Chapter Release · Available Now",
        audience: "Mechanical designers, engineers, contractors, and QA reviewers coordinating IMC Chapter 3 General Regulations compliance across permit and installation work",
        price: window.MB_CATALOG.price("imcChapter3Guide"),
        body: "A 19-page PDF that turns Chapter 3 General Regulations into an installation-readiness and field-coordination workflow: establish the project basis, verify equipment approval and location, record structural or rated-assembly interfaces, and resolve installation, support, access, condensate, specialty, and load-escalation risks before procurement, concealment, or startup. Includes the Equipment Approval and Location Matrix, Structure and Rated-Assembly Coordination Record, 45-Minute Installation Readiness Audit, and Field Change Stop / Proceed Workflow. PDF-only, single named-purchaser license.",
        notifySubject: "Masterbuild IMC 2024 Chapter 3 General Regulations Field Guide purchase interest",
        samplePdf: "uploads/ch3-sample.pdf",
        samplePreview: "uploads/ch3-sample-preview.png",
        sampleLabel: "Free sample — IMC 301 Product-Proof Chain (PDF)"
      }, {
        id: "chapter4FreeGuide",
        title: "IMC 2024 Chapter 4 Ventilation Fundamentals - Free Field Guide",
        tag: "Free Chapter Resource · Available Now",
        audience: "Mechanical designers, engineers, architects, contractors, plan reviewers, commissioning teams, and facilities staff",
        price: "Free",
        body: "A 16-page field guide that turns IMC Chapter 4 ventilation review into a clear workflow: establish the project basis, identify each space's ventilation method, trace outdoor air to the breathing zone, verify intake protection and controls, and retain closeout evidence. Includes a working Compliance Matrix, 40-Minute Ventilation & IAQ Readiness Audit, and Field Change Stop / Proceed Workflow. Educational decision support; verify the adopted code and project conditions.",
        freePdf: "uploads/ch4-ventilation-fundamentals-free-guide.pdf",
        freeCta: "Download the free 16-page guide",
        samplePdf: "uploads/ch4-sample.pdf",
        samplePreview: "uploads/ch4-sample-preview.png",
        sampleLabel: "Free sample — Chapter 4 Ventilation Proof Chain (PDF)"
      }, {
        id: "chapter5Guide",
        title: "IMC 2024 Chapter 5 Exhaust Systems Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "MEP designers and engineers, plan reviewers, general and mechanical contractors, kitchen and process equipment vendors, owner representatives, facility and property managers, and permit coordinators",
        price: window.MB_CATALOG.price("imcChapter5Guide"),
        body: "A 31-page section-by-section Chapter 5 control system for classifying exhaust before sizing, then proving discharge, makeup air, materials, access, controls, acceptance testing, and closeout. Includes a 3-page Read First file and a companion workbook with nine working sheets plus a Read Me tab: project basis, Exhaust System Register, discharge/intake proof, kitchen and common-shaft coordination, hazardous-exhaust screening, responsibility matrix, 60-minute audit, and closeout record. Single-user license; firmwide use is separately scoped.",
        notifySubject: "Masterbuild IMC 2024 Chapter 5 Exhaust Systems Field Guide purchase interest",
        samplePdf: "uploads/ch5-exhaust-systems-sample.pdf",
        samplePreview: "uploads/ch5-exhaust-systems-sample-preview.png",
        sampleLabel: "Free sample — Chapter 5 Exhaust Proof Chain (PDF)"
      }, {
        id: "chapter6Guide",
        title: "IMC 2024 Chapter 6 Duct Systems Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "MEP designers and engineers, architects, contractors, plan reviewers, commissioning/TAB teams, owner representatives, facility and property managers, and permit coordinators",
        price: window.MB_CATALOG.price("imcChapter6Guide"),
        body: "A 22-page field-first Chapter 6 workflow for duct air paths, materials, insulation, sizing, pressure-loss screening, plenums, shaft coordination, protected openings, damper access, coastal salt-exposure durability, and pre-TAB readiness. Includes four printable working tools: duct-system/material register, plenum coordination pass, protected-opening/damper matrix, and 60-minute pre-TAB audit.",
        notifySubject: "Masterbuild IMC 2024 Chapter 6 Duct Systems Field Guide purchase interest",
        samplePdf: "uploads/ch6-duct-systems-sample.pdf",
        samplePreview: "uploads/ch6-duct-systems-sample-preview.png",
        sampleLabel: "Free sample — Chapter 6 Coastal & Shaft Coordination (PDF)"
      }, {
        id: "chapter7Guide",
        title: "IMC 2024 Chapter 7 Combustion Air Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "MEP designers and engineers, architects, mechanical contractors, controls providers, commissioning and startup teams, plan reviewers, and owner representatives",
        price: window.MB_CATALOG.price("imcChapter7Guide"),
        body: "A 21-page field-first Chapter 7 workflow: route each appliance to its governing source, size the combustion-air intake through an eight-line required-to-installed arithmetic chain, prove actual free area at the installed product, interlock dampers to firing, coordinate rated routes, survey existing conditions, and clear nine go / no-go gates before new scope is issued. Includes a 3-page Read First and eight printable working tools.",
        notifySubject: "Masterbuild IMC 2024 Chapter 7 Combustion Air Field Guide purchase interest",
        samplePdf: "uploads/ch7-combustion-air-sample.pdf",
        samplePreview: "uploads/ch7-combustion-air-sample-preview.png",
        sampleLabel: "Free sample — Chapter 7 Appliance Routing & Sanity Checks (PDF)"
      }, {
        id: "chapter67Bundle",
        title: "IMC 2024 Chapters 6 + 7 Bundle — Duct Systems and Combustion Air",
        tag: "Bundle · Save " + window.MB_CATALOG.savings("imcChapter67Bundle", ["imcChapter6Guide", "imcChapter7Guide"]),
        audience: "Teams working renovation and existing-building scopes where duct work and appliance rooms meet",
        price: window.MB_CATALOG.price("imcChapter67Bundle"),
        body: "Both field guides in one package. Chapter 6 governs the duct route - material, pressure, support, access, and rated boundaries. Chapter 7 governs the appliance room at the end of that route and the combustion air that has to reach it. In renovation work these two scopes fail each other constantly. 43 pages, two Read First files, twelve printable working tools, " + window.MB_CATALOG.price("imcChapter67Bundle") + " instead of " + window.MB_CATALOG.listPrice(["imcChapter6Guide", "imcChapter7Guide"]) + ".",
        notifySubject: "Masterbuild IMC 2024 Chapters 6 + 7 bundle purchase interest",
        samplePdf: "uploads/ch7-combustion-air-sample.pdf",
        samplePreview: "uploads/ch7-combustion-air-sample-preview.png",
        sampleLabel: "Free sample — Chapter 7 Appliance Routing & Sanity Checks (PDF)"
      }, {
        id: "chapter8Guide",
        title: "IMC 2024 Chapter 8 Chimneys and Vents Field Guide",
        tag: "Chapter Release · Available Now",
        audience: "MEP engineers and designers, architects coordinating chases and roofs, mechanical and fireplace contractors, plan reviewers, commissioning agents, and owners inheriting existing chimneys",
        price: window.MB_CATALOG.price("imcChapter8Guide"),
        body: "“Existing chimney to remain” is the most expensive four words on a renovation mechanical set, because it is not a decision — it is a decision deferred until the wall is closed. A 28-page proof system for venting: which document actually governs each appliance, a size basis a reviewer can verify, the four-gate existing-chimney acceptance, connector routing and clearance, termination geometry, and the closeout hold points. Thirteen risk-cluster sections, a Read First file, eleven printable working tools, and a fillable companion workbook no earlier chapter shipped.",
        notifySubject: "Masterbuild IMC 2024 Chapter 8 Chimneys and Vents Field Guide purchase interest",
        samplePdf: "uploads/ch8-chimneys-vents-sample.pdf",
        samplePreview: "uploads/ch8-chimneys-vents-sample-preview.png",
        sampleLabel: "Free sample — the complete four-gate existing-chimney acceptance (PDF)"
      }, {
        id: "chapter78Bundle",
        title: "Combustion Air + Venting Bundle — IMC 2024 Chapters 7 and 8",
        tag: "Bundle · Save " + window.MB_CATALOG.savings("imcChapter78Bundle", ["imcChapter7Guide", "imcChapter8Guide"]),
        audience: "Anyone with a gas appliance in a closet, a boiler room being renovated, or an existing chimney they are being asked to reuse",
        price: window.MB_CATALOG.price("imcChapter78Bundle"),
        body: "Both halves of the appliance-room conversation. Chapter 7 governs the air the appliance needs to burn — and routes it to the code that actually carries the criteria, which for gas-fired appliances is the fuel gas code, not the mechanical code. Chapter 8 governs the system that carries the products of combustion back out. A buyer with one and not the other has half an answer. 49 pages, two Read First files, nineteen working tools and the Chapter 8 fillable workbook, " + window.MB_CATALOG.price("imcChapter78Bundle") + " instead of " + window.MB_CATALOG.listPrice(["imcChapter7Guide", "imcChapter8Guide"]) + ".",
        notifySubject: "Masterbuild Combustion Air + Venting bundle purchase interest",
        samplePdf: "uploads/ch8-chimneys-vents-sample.pdf",
        samplePreview: "uploads/ch8-chimneys-vents-sample-preview.png",
        sampleLabel: "Free sample — the complete four-gate existing-chimney acceptance (PDF)"
      }],
      tiers: [{
        name: "Free",
        price: "$0",
        fit: "Search and diagnose",
        includes: ["Daily Code Talk archive", "Bilingual chapter navigation", "Free Chapter 1-7 samples", "Chapter 4 ventilation field guide", "Field-risk examples"]
      }, {
        name: "Permit Workflow",
        price: "$57 / $79",
        fit: "Process control and pre-submission QA",
        includes: ["IMC 101–115 permit-process guide", "Permit Readiness pressure test", "Document and inspection controls", "AHJ response and upload gates"]
      }, {
        name: "Specialty Guides",
        price: "$99 / $149 / $199",
        fit: "Owner risk or technical-system depth",
        includes: ["Owner-side MEP review", "Ventilation and outdoor-air evidence", "Chapter 5 exhaust control", "Chapter 6 duct-system coordination", "Field closeout and issue tracking"]
      }, {
        name: "Project Review",
        price: "Written proposal",
        fit: "Project-specific decisions",
        includes: ["Defined scope and deliverables", "Adopted-code and AHJ basis", "Drawing and field-condition review", "Clear assumptions, exclusions, and next actions"]
      }],
      cta: "Get the Chapter 1 guide",
      secondary: "Read Daily Code Talk",
      newsletterEyebrow: "Free — Code Desk email list",
      newsletterDesc: "Useful Daily Code Talk articles, field-QA notes, and resource releases when published. No daily-email promise. Unsubscribe anytime.",
      newsletterCta: "Subscribe",
      newsletterSuccess: "You're on the Code Desk list. Check your inbox to confirm if requested.",
      leadMagnet: {
        eyebrow: "Free sample",
        title: "Permit Readiness Sample Checklist",
        body: "Use the short checklist to spot missing scope, background files, and AHJ-sensitive items before engineering time starts.",
        cta: "Send me the sample",
        success: "Sample ready. Download the PDF now.",
        download: "Download sample checklist",
        subject: "Masterbuild Permit Readiness Sample Checklist download"
      },
      buyCta: "Buy",
      notifyCta: "Coming soon - get notified",
      requestLinkCta: "Get purchase link",
      notifySuccess: "Interest received. Osmany will see which product you asked for.",
      emailPlaceholder: "email@example.com",
      paymentNote: "Checkout is handled securely by Stripe. Use the purchaser email for delivery and support; save the receipt."
    },
    authority: {
      eyebrow: "/ Credentials",
      headline: "Direct PE involvement. Clear proof.",
      items: [{
        stat: "All MEP",
        label: "Four Disciplines In-House",
        desc: "HVAC, plumbing, fire protection, and electrical design - all reviewed and delivered by the same principal engineer. One point of contact for the complete package."
      }, {
        stat: "PE",
        label: "Licensed Professional Engineer",
        desc: "Led by Osmany Portal, PE. Every scope is reviewed and delivered with the direct involvement of a licensed engineer - not delegated."
      }, {
        stat: "Project-by-Project",
        label: "Licensure Confirmed Per Scope",
        desc: "Masterbuild confirms licensure, sealing authority, and delivery structure on a project-by-project basis. Contact us to discuss your jurisdiction."
      }, {
        stat: "EN / ES",
        label: "Bilingual Capability",
        desc: "Spanish-language technical content, drawing review, and bilingual project communication available as a premium service."
      }]
    }
  },
  es: {
    services: {
      eyebrow: "/ Servicios",
      headline: "Seis formas en que los clientes nos contratan",
      sub: "Organizados por resultados - porque la mayoría de los clientes comienzan con un problema de negocio, no con una etiqueta mecánica o eléctrica.",
      items: [{
        num: "01",
        tag: "Diseño de Permisos",
        title: "Documentos de Construcción MEP para Permisos",
        body: "Planos coordinados de HVAC, plomería, protección contra incendios y diseño eléctrico preparados para la presentación de permisos. Lógica de código, coordinación interdisciplinaria y soporte de respuesta a comentarios.",
        bullets: ["CDs listos para permisos en todas las disciplinas MEP", "Coordinación con arquitecto y estructura", "Soporte de respuesta a comentarios", "Planos conformes al código y construibles en campo"],
        href: "/contacto/"
      }, {
        num: "02",
        tag: "Revisión Técnica",
        title: "Revisión MEP Independiente y Control de Calidad",
        body: "Para equipos que necesitan revisión más sólida, soporte de ingeniería defendible, segundas opiniones forenses u supervisión técnica en alcances complejos.",
        bullets: ["Revisión de planos y verificación entre pares", "Segundas opiniones forenses y técnicas", "Soporte técnico de RFI y presentaciones", "Asesoramiento de control de calidad del propietario"],
        href: "/contacto/"
      }, {
        num: "03",
        tag: "Edificios Existentes",
        title: "Evaluaciones y Estudios de Factibilidad MEP en Edificios Existentes",
        body: "Soporte de factibilidad enfocado en MEP para edificios comerciales existentes  -  evaluación de condición de HVAC, plomería, protección contra incendios y sistemas eléctricos, capacidad de infraestructura, exposición de código bajo cambio de uso o alcance de renovación, y riesgos de debida diligencia antes de comprometer más recursos.",
        bullets: ["Informes de factibilidad MEP para edificios existentes", "Evaluación de condición de HVAC, plomería, protección contra incendios y electricidad", "Revisión de capacidad de servicios e infraestructura", "Verificación en campo de condiciones existentes"],
        href: "/existing-buildings/"
      }, {
        num: "04",
        tag: "Asesoría de Construcción",
        title: "Asesoría Técnica en Fase de Construcción",
        body: "Juicio PE directo en RFIs, presentaciones, preguntas de campo y decisiones de alcance después del permiso. Protege el cronograma, el presupuesto y la calidad técnica.",
        bullets: ["Revisión técnica de RFI y presentaciones", "Soporte de inspección en campo", "Asesoría de representante del propietario", "Soporte de inspección y cierre"],
        href: "/contacto/"
      }, {
        num: "05",
        tag: "Recertificación Eléctrica de Edificios",
        title: "Preparación para Recertificación Eléctrica de Edificios",
        body: "Para propietarios y administradores de Miami-Dade que enfrentan un asunto de recertificación de edificio de 30 años o 40 años heredada, Masterbuild ofrece una ruta definida de preparación para Recertificación Eléctrica de Edificios: registros, acceso, observaciones de campo, prioridades de corrección y la ruta al profesional responsable antes de iniciar trabajo de informe.",
        bullets: ["Triage de informes previos, permisos, diagramas unifilares y registros de mantenimiento", "Revisión de campo eléctrica y documentación de condición dentro de un alcance definido", "Prioridades de deficiencias, planificación de acceso y coordinación de acciones correctivas", "La firma y el sello del informe solo se ofrecen después de que el profesional responsable de la disciplina eléctrica confirme autoridad y elegibilidad del proyecto"],
        href: "/recertificacion-electrica-de-edificios-miami/"
      }, {
        num: "06",
        tag: "Retainer",
        title: "Asesoría de Diseño Mensual",
        body: "Un PE de plantilla para propietarios, arquitectos y contratistas que necesitan juicio de código y coordinación sin abrir un encargo de planos cada vez que aparece una pregunta.",
        bullets: ["Preguntas por escrito contra la ruta de código adoptada", "Triage de comentarios antes de quemar una reentrega", "Llamadas de coordinación con arquitecto y GC", "Alcance separado de la producción sellada"],
        href: "/contacto/"
      }],
      cta: "Ver Todos los Servicios"
    },
    mission: {
      eyebrow: "/ Misión Crítica",
      headline: "MEP para espacios donde el tiempo de inactividad no es una opción",
      body1: "Masterbuild Consulting apoya el diseño MEP para entornos donde el rendimiento del sistema, el tiempo de actividad, la coordinación y el mantenimiento son críticos.",
      body2: "Atención cuidadosa a las cargas de HVAC, ventilación, redundancia, diseño eléctrico, acceso a equipos, protección contra incendios, confiabilidad de plomería, controles y cumplimiento del código.",
      note: "Donde muchas empresas MEP se detienen, Masterbuild tiene la profundidad técnica para continuar.",
      bullets: ["Análisis de carga HVAC y coordinación de redundancia", "Ventilación hospitalaria y de atención ambulatoria (ASHRAE 170 / NFPA 99)", "Extracción de laboratorio, presurización y ventilación de almacenamiento químico", "Clasificaciones de sala limpia y requisitos de tasa de cambio de aire", "Diseño eléctrico para sistemas críticos, UPS, acometida y distribución", "Ventilación, presurización y calidad del aire", "Acceso a equipos, espacios libres y mantenibilidad", "Coordinación de protección contra incendios", "Cumplimiento del código para entornos de alta confiabilidad"],
      cta: "Consultar Alcance de Misión Crítica"
    },
    markets: {
      eyebrow: "/ Mercados",
      headline: "Con quién trabajamos",
      sub: "Masterbuild atiende una amplia gama de tipos de proyectos. El hilo común son los clientes que necesitan juicio de ingeniería cerca del trabajo, no una línea de producción.",
      items: [{
        title: "Centros de Salud e Instalaciones Médicas",
        desc: "Hospitales, centros de atención ambulatoria, quirófanos y consultorios médicos - donde ASHRAE 170, NFPA 99, relaciones de presión, filtración y control de infecciones son requisitos no negociables."
      }, {
        title: "Laboratorios e Instalaciones de Investigación",
        desc: "Laboratorios húmedos, secos, salas limpias y entornos de investigación que requieren ventilación precisa, separación de extracción, presurización, coordinación de almacenamiento químico y cumplimiento más allá del permiso estándar."
      }, {
        title: "Centros de Datos y Salas de Servidores",
        desc: "Enfriamiento de misión crítica, redundancia, control preciso de humedad, diseño eléctrico y coordinación de distribución de energía para entornos donde la falla MEP tiene consecuencias operativas y financieras directas."
      }, {
        title: "Comercial y Oficinas",
        desc: "Edificios de oficinas, comercios, restaurantes y espacios mixtos que requieren paquetes de permisos MEP coordinados y documentación conforme al código."
      }, {
        title: "Mejoras para Inquilinos",
        desc: "Habilitaciones y renovaciones interiores para inquilinos comerciales donde la velocidad, coordinación y claridad de permisos son críticas."
      }, {
        title: "Residencial de Alto Nivel",
        desc: "Casas personalizadas y proyectos residenciales premium donde la calidad MEP, coordinación y atención al detalle coinciden con el nivel de acabados."
      }, {
        title: "Multifamiliar y Uso Mixto",
        desc: "Edificios de apartamentos y condominios que requieren coordinación MEP completa en múltiples unidades, disciplinas y tipos de ocupación."
      }, {
        title: "Renovaciones de Edificios Existentes",
        desc: "Remodelaciones, conversiones y reutilización adaptativa donde la infraestructura existente, las conexiones de plomería, los límites de capacidad y el cumplimiento del código definen el alcance."
      }, {
        title: "Evaluaciones y Estudios",
        desc: "Informes de factibilidad para edificios comerciales existentes, evaluaciones de sistemas de plomería, capacidad de infraestructura, deficiencias de ventilación y debida diligencia antes de tomar decisiones en la dirección equivocada."
      }, {
        title: "Espacios de Alta Confiabilidad",
        desc: "Entornos donde el tiempo de actividad, redundancia, mantenibilidad y coordinación del sistema requieren atención de ingeniería cuidadosa desde el inicio."
      }, {
        title: "Asesoría a Propietarios y Contratistas",
        desc: "Soporte técnico para propietarios, promotores, contratistas generales y administradores de propiedades en decisiones MEP durante diseño y construcción."
      }]
    },
    trust: {
      eyebrow: "/ Confianza",
      headline: "Relaciones de trabajo seleccionadas",
      sub: "Solo relaciones confirmadas de socios y clientes. Masterbuild apoya permisos, trabajo de sitio energético e informes de factibilidad de edificios existentes donde se necesita juicio MEP y de plomería directo.",
      logos: [{
        name: "Existing Building LLC",
        note: "Socio de evaluación de factibilidad",
        body: "Soporte de evaluación de sistemas de plomería para informes de factibilidad de edificios comerciales existentes.",
        url: "https://www.existing-building.com/"
      }, {
        name: "MEPTECH Solutions",
        note: "Soporte PE para permisos",
        body: "Soporte MEP con PE y coordinación de entregables firmados y sellados cuando aplica.",
        url: "https://www.meptechsolutions.com/"
      }, {
        name: "Roble Technologies",
        note: "Inspección de sitio 179D",
        body: "Soporte de verificación en edificios existentes para flujos de energía e incentivos fiscales.",
        url: "https://getroble.com/"
      }, {
        name: "Disponibles a solicitud",
        note: "Referencias adicionales",
        body: "Las referencias se comparten directamente cuando el alcance y la confidencialidad lo permiten."
      }],
      sectorsLabel: "Sectores atendidos",
      sectors: ["Permisos liderados por arquitectos", "Nueva construcción y renovaciones comerciales", "Multifamiliar de altura media y alta", "Diseño hospitalario y de salud", "Instalaciones de misión crítica", "Condiciones existentes y estudios de factibilidad (MEP)", "Residencial de alto nivel"]
    },
    existingBuildings: {
      eyebrow: "/ Edificios Existentes",
      headline: "Evaluación MEP de Edificios Existentes",
      sub: "Para propiedades comerciales en Miami y toda Florida donde el estado de los sistemas mecánicos, plomería, protección contra incendios y eléctricos existentes afecta lo que puede hacer el próximo alcance — y cuánto costará.",
      body: "La mayoría de los informes de factibilidad responden la pregunta arquitectónica. Masterbuild agrega la capa MEP: qué sistemas están presentes, qué código aplica bajo el nuevo uso u ocupación según IMC 102 y el Código de Construcción de Florida, qué permanece como sistema existente legal, qué debe actualizarse, y dónde vive la exposición real de costo antes de que comiencen los planos.",
      bullets: [
        "Revisión de condición de HVAC existente y deficiencias de ventilación",
        "Evaluación de capacidad del sistema de plomería y puntos de conexión",
        "Revisión de capacidad de servicios públicos e infraestructura",
        "Exposición de cumplimiento del código bajo cambio de ocupación o alcance de renovación (IMC 102 / FBC)",
        "Revisión de condición y cobertura del sistema de protección contra incendios",
        "Verificación de campo contra planos existentes o condiciones reales"
      ],
      note: "Las evaluaciones se delimitan y cotizan por propiedad. El entregable es un resumen escrito con señalamientos de factores de costo — no un juego completo sellado. Precio fijo. PE directo.",
      cta: "Agendar una Llamada de Alcance",
      ctaNote: "Llamada de 30 minutos para delimitar la propiedad y confirmar encaje."
    },
    daily: {
      eyebrow: "/ Daily Code Talk",
      headline: "La Guía de Código Orientada al Campo — Mecánico y Eléctrico.",
      sub: "Una biblioteca activa de explicaciones IMC (Edición Mecánica) y NEC (Edición Sparky) basadas en planos para arquitectos, equipos MEP, contratistas, representantes de propietario y equipos de facilidades que necesitan decisiones que resistan la revisión de permiso y la instalación en campo. Empiece gratis en el archivo y avance a las guías o a revisión PE-directa cuando haya un proyecto real.",
      badge: DCT_COUNTS.total + " publicaciones públicas · Dos series: IMC + NEC · Archivo con búsqueda · Próximo paso claro",
      posts: [{
        tag: "Archivo con búsqueda",
        title: "Empiece con el problema exacto de código.",
        desc: "Busque por sección, capítulo, tema, riesgo de permiso o coordinación de campo. Sin revisar hojas de cálculo ni publicaciones viejas.",
        href: "/daily-code-talk/"
      }, {
        tag: "Cocinas comerciales · IMC 508",
        title: "La extracción de cocina falla cuando el aire de reposición llega tarde.",
        desc: "Revise captura de campana, aire de reposición, presión de cocina, confort, controles y arranque antes de cerrar shafts y plafones.",
        href: "/daily-code-talk/imc-508-commercial-kitchen-makeup-air/"
      }, {
        tag: "Aberturas de ductos · IMC 607",
        title: "Un símbolo de compuerta no es una estrategia de protección.",
        desc: "Los cruces de ductos necesitan ensamblaje, compuerta, listado, acceso, lógica de humo y excepción coordinados antes de permiso u obra.",
        href: "/daily-code-talk/imc-607-part-1-607-1-607-2-1/"
      }, {
        tag: "Cuartos de equipos · IMC 701",
        title: "El aire de combustión necesita cadena de evidencia.",
        desc: "Tipo de aparato, ruta de combustible, área libre real, enclavamiento, ruta clasificada y prueba de arranque deben alinearse.",
        href: "/daily-code-talk/imc-701-combustion-air-scope-dampered-openings/"
      }, {
        tag: "Edición Sparky · NEC Artículo 90",
        title: "El alcance eléctrico decide resultados mecánicos.",
        desc: "La serie NEC leída desde la coordinación MEP: dónde empieza y termina el alcance eléctrico, y cómo eso llega al equipo mecánico, desconexiones y coordinación de campo.",
        href: "/daily-code-talk/sparky-edition-nec-90-1-90-2-scope-covered-installations/"
      }],
      cta: "Abrir Daily Code Talk →",
      ctaLink: "/daily-code-talk/",
      referral: "Comparte este enlace con un ingeniero en tu equipo que maneje los permisos."
    },
    resources: {
      eyebrow: "/ Guías de Campo IMC",
      headline: "Un camino práctico desde la pregunta de código hasta la decisión del proyecto.",
      sub: "Comience gratis con el archivo Daily Code Talk y la lista de correo Code Desk, además de una biblioteca gratuita en crecimiento de listas de verificación de permisos de Miami-Dade, una lista de cálculo de cargas de HVAC, una referencia de cumplimiento de envolvente de Florida y los glosarios NEC/IMC — sin correo requerido, vea la página completa de Recursos. Use la guía del Capítulo 1 para controlar el proceso, la guía del Capítulo 2 para el control de definiciones y prevención de redlines, la guía del Capítulo 3 para preparación de instalación y coordinación de campo, o el paquete Permit Readiness de 19 páginas para QA/QC multidisciplinario antes de cargar, responder y llegar a inspección. Elija la guía para propietarios o la guía de ventilación cuando ese sea el riesgo real. Pase a una revisión con alcance escrito cuando la decisión dependa de planos reales, condiciones de campo o el código adoptado. Cada guía de capítulo es un paquete pago completo e independiente.",
      ascensionLabel: "La ruta simple de valor de Daily Code Talk.",
      ascension: [
        { step: "01", label: "Archivo + Code Desk", price: "Gratis", desc: "Busque el problema exacto y reciba notas útiles de código, QA de campo y recursos cuando se publiquen.", href: "/daily-code-talk/" },
        { step: "02", label: "Biblioteca Gratuita de Checklists", price: "Gratis", desc: "Listas de verificación de permisos de Miami-Dade, lista de cálculo de cargas de HVAC, referencia de cumplimiento de envolvente de Florida y glosarios NEC/IMC — sin correo requerido.", href: "/resources/" },
        { step: "03", label: "Flujo de Permiso", price: "$57 / $79", desc: "Use la guía del Capítulo 1 o del Capítulo 2 para controlar el proceso o las definiciones, o ejecute la compuerta multidisciplinaria con el paquete Permit Readiness.", href: "#resources" },
        { step: "04", label: "Revisión Especializada", price: "$99 / $149 / $199", desc: "Use herramientas para propietarios, ventilación, extracción del Capítulo 5 o ductos del Capítulo 6 cuando el riesgo sea mantenimiento, rutas de aire, materiales, acceso o cierre de obra.", href: "#resources" },
        { step: "05", label: "Revisión Liderada por PE", price: "Alcance escrito", desc: "Traiga planos, jurisdicción, condiciones de campo y fecha de decisión para una revisión específica.", href: "/contacto/" }
      ],
      boundary: "Daily Code Talk y las guías usan el IMC 2024 como educación sobre el código modelo. Antes de usarlo en un proyecto, verifique el código legalmente adoptado, enmiendas locales, alcance, normas referenciadas, listados, instrucciones del fabricante y ruta del AHJ. La ingeniería específica y el trabajo sellado requieren un compromiso escrito separado.",
      stats: [{
        value: String(DCT_COUNTS.total),
        label: "Artículos públicos Daily Code Talk",
        desc: "Explicaciones gratuitas, bilingües y orientadas a planos, organizadas por capítulo, sección, riesgo de permiso y coordinación de campo."
      }, {
        value: "Cap. 1–7",
        label: "Contenido web completado",
        desc: "Los capítulos completados siguen disponibles mientras el Capítulo 8 avanza con el flujo LinkedIn a sitio web."
      }, {
        value: "Cap. 3",
        label: "Guía de instalación en campo",
        desc: "Un flujo de trabajo listo para el comprador de 19 páginas para base de proyecto, aprobación de equipos, ubicación, coordinación estructural/de ensamblajes clasificados, preparación de instalación y control de cambios de campo."
      }, {
        value: "7",
        label: "Guías de trabajo disponibles",
        desc: "Siete recursos enfocados cubren proceso de permiso, control de definiciones, preparación de instalación, coordinación de ductos, QA/QC multidisciplinario antes de entrega, revisión del propietario y ventilación / extracción especial."
      }],
      products: [{
        id: "permitReadiness",
        title: "Paquete de Revisión Permit Readiness",
        tag: "QA/QC Multidisciplinario de Permisos",
        audience: "Propietarios, representantes, arquitectos, coordinadores de permisos, equipos MEP y estructurales, contratistas y preconstrucción antes de cargar o responder",
        price: window.MB_CATALOG.price("permitReadinessPack"),
        body: "Un sistema de 19 páginas para revisar juegos comerciales y residenciales antes de cargar, responder y llegar a inspección. Incluye base del proyecto, ruta de autoridades, controles multidisciplinarios, edificación/MEP/estructura/zonificación/WASD, coordinación selectiva, registro de asuntos, decisión final y mapa de fuentes de Miami-Dade / Florida. Decida: listo, listo con excepciones documentadas o en espera. Recurso de planificación y QA/QC; verifique requisitos vigentes del AHJ. No garantiza aprobación.",
        cta: "Obtener Permit Readiness - $79",
        notifySubject: "Masterbuild Permit Readiness Review Pack purchase interest",
        samplePdf: "uploads/permit-readiness-sample-checklist.pdf",
        samplePreview: "uploads/permit-readiness-sample-preview.png",
        sampleLabel: "Muestra gratis — Flujo multidisciplinario Permit Readiness (PDF)"
      }, {
        id: "ownerSideBundle",
        title: "Paquete de Checklists MEP para Propietarios",
        tag: "Control de Riesgo del Propietario · Disponible Ahora",
        audience: "Propietarios, desarrolladores, representantes, arquitectos, equipos de facilidades y ejecutivos de proyecto",
        price: window.MB_CATALOG.price("ownerSideBundle"),
        body: "Un sistema de revisión de 30 minutos para mantenimiento, control de permiso, exposición a órdenes de cambio, fallas de inspección, límites de costo y plazo, lenguaje de alerta y seguimiento de asuntos antes de que se conviertan en problemas de campo costosos.",
        notifySubject: "Masterbuild Owner-Side MEP Review Checklist Bundle purchase interest",
        samplePdf: "uploads/owner-side-review-card-sample.pdf",
        samplePreview: "uploads/owner-side-review-card-sample-preview.png",
        sampleLabel: "Muestra gratis — Tarjeta de Revisión del Propietario (PDF)"
      }, {
        id: "ventilationGuide",
        title: "Guía de Ventilación y Extracción Especial",
        tag: "Especialidad Técnica · Disponible Ahora",
        audience: "Diseñadores MEP, arquitectos, contratistas, revisores, equipos de commissioning y personal de facilidades",
        price: window.MB_CATALOG.price("ventilationFieldGuide"),
        body: "Una guía orientada al campo para triage rápido, lógica por recinto, evidencia de aire exterior, clasificación de extracción especial, prueba en planos, controles, coordinación y cierre de campo antes de que los problemas de flujo o contención lleguen a inspección u ocupación.",
        notifySubject: "Masterbuild Ventilation and Special Exhaust Field Guide purchase interest",
        samplePdf: "uploads/ventilation-oa-math-sample.pdf",
        samplePreview: "uploads/ventilation-oa-math-sample-preview.png",
        sampleLabel: "Muestra gratis — Revisión de Cálculo de Aire Exterior (PDF)"
      }, {
        id: "imcChapter1Guide",
        title: "Guía de Proceso de Permisos IMC Capítulo 1",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Ingenieros, diseñadores, arquitectos, contratistas, gerentes de proyecto, coordinadores de permisos",
        price: window.MB_CATALOG.price("imcChapter1Guide"),
        body: "Listas de verificación, playbooks de respuesta y hojas editables construidas desde el IMC 101–115. Cubre autoridad e interpretación del AHJ, disparadores de permisos y la lista de exenciones, requisitos de documentos de construcción, secuencia de inspecciones y puntos de retención, lógica de aprobación y revocación, respuesta a stop-work y el proceso formal de apelaciones. Para cualquiera que pierde tiempo en errores de proceso — no en errores de diseño técnico.",
        notifySubject: "Masterbuild IMC Chapter 1 Permit Process Field Guide purchase interest",
        samplePdf: "uploads/ch1-sample.pdf",
        samplePreview: "uploads/ch1-sample-preview.png",
        sampleLabel: "Muestra gratis — Guía IMC 101 Ruta de Código (PDF)"
      }, {
        id: "chapter2Guide",
        title: "Guía de Definiciones y Prevención de Redlines IMC 2024 Capítulo 2",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Diseñadores mecánicos, ingenieros y revisores de QA en firmas MEP/arquitectura que preparan o revisan paquetes de permiso",
        price: window.MB_CATALOG.price("imcChapter2Guide"),
        body: "Una guía en PDF de 19 páginas que convierte las definiciones del Capítulo 2 en un flujo de control práctico: identifique el término sensible a definición, rastree lo que activa, muestre la prueba y detenga los puntos rojos sin resolver antes de la entrega. Los términos clave y el lenguaje de escalamiento están resaltados en todo el documento. Incluye la guía más la Matriz de Control de Definiciones, la Auditoría de 30 Minutos Pre-Entrega y el Registro de Cambio de Campo y Disputa de Definición. Solo PDF, licencia de un solo comprador nombrado.",
        notifySubject: "Masterbuild IMC 2024 Chapter 2 Definitions Field Guide purchase interest",
        samplePdf: "uploads/ch2-sample.pdf",
        samplePreview: "uploads/ch2-sample-preview.png",
        sampleLabel: "Muestra gratis — Guía Rápida de Control de Definiciones Capítulo 2 (PDF)"
      }, {
        id: "chapter3Guide",
        title: "Guía de Preparación para Instalación y Coordinación de Campo IMC 2024 Capítulo 3",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Diseñadores mecánicos, ingenieros, contratistas y revisores de QA que coordinan el cumplimiento de las Regulaciones Generales del Capítulo 3 del IMC en trabajos de permiso e instalación",
        price: window.MB_CATALOG.price("imcChapter3Guide"),
        body: "Un PDF de 19 páginas que convierte las Regulaciones Generales del Capítulo 3 en un flujo de preparación para instalación y coordinación de campo: establezca la base del proyecto, verifique aprobación y ubicación de equipos, registre interfaces estructurales o de ensamblajes clasificados y resuelva riesgos de instalación, soportes, acceso, condensado, especialidades y escalamiento de carga antes de compra, cierre o arranque. Incluye la Matriz de Aprobación y Ubicación de Equipos, el Registro de Coordinación Estructural y de Ensamblajes Clasificados, la Auditoría de Preparación de 45 Minutos y el Flujo de Detener / Proceder para Cambios de Campo. Solo PDF, licencia de un solo comprador nombrado.",
        notifySubject: "Masterbuild IMC 2024 Chapter 3 General Regulations Field Guide purchase interest",
        samplePdf: "uploads/ch3-sample.pdf",
        samplePreview: "uploads/ch3-sample-preview.png",
        sampleLabel: "Muestra gratis — Cadena de Prueba de Producto IMC 301 (PDF)"
      }, {
        id: "chapter4FreeGuide",
        title: "Fundamentos de Ventilación IMC 2024 Capítulo 4 - Guía de Campo Gratis",
        tag: "Recurso Gratis por Capítulo · Disponible Ahora",
        audience: "Diseñadores mecánicos, ingenieros, arquitectos, contratistas, revisores de planos, equipos de commissioning y personal de facilidades",
        price: "Gratis",
        body: "Una guía de campo de 16 páginas que convierte la revisión de ventilación del Capítulo 4 del IMC en un flujo claro: establezca la base del proyecto, identifique el método de ventilación de cada recinto, rastree el aire exterior hasta la zona de respiración, verifique protección de toma y controles, y conserve evidencia de cierre. Incluye una Matriz de Cumplimiento, una Auditoría de Preparación de Ventilación e IAQ de 40 Minutos y un Flujo de Detener / Proceder para Cambios de Campo. Apoyo educativo para decisiones; verifique el código adoptado y las condiciones del proyecto.",
        freePdf: "uploads/ch4-ventilation-fundamentals-free-guide.pdf",
        freeCta: "Descargar la guía gratis de 16 páginas",
        samplePdf: "uploads/ch4-sample.pdf",
        samplePreview: "uploads/ch4-sample-preview.png",
        sampleLabel: "Muestra gratis — Cadena de Prueba de Ventilación Capítulo 4 (PDF)"
      }, {
        id: "chapter5Guide",
        title: "Guía de Campo de Sistemas de Extracción — IMC 2024 Capítulo 5",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Diseñadores e ingenieros MEP, revisores de planos, contratistas generales y mecánicos, proveedores de equipos de cocina y proceso, representantes del propietario, gerentes de facilidades y coordinadores de permisos",
        price: window.MB_CATALOG.price("imcChapter5Guide"),
        body: "Un sistema de control del Capítulo 5 de 31 páginas, sección por sección, para clasificar la extracción antes de dimensionar y luego probar descarga, aire de reposición, materiales, acceso, controles, pruebas de aceptación y cierre. Incluye archivo Read First de 3 páginas y libro de trabajo con nueve hojas más una pestaña Read Me: base del proyecto, Registro de Sistemas de Extracción, prueba de descarga/toma, coordinación de cocina y ductos comunes, análisis de extracción peligrosa, matriz de responsabilidades, auditoría de 60 minutos y registro de cierre. Licencia de usuario único; uso de firma se cotiza por separado.",
        notifySubject: "Interés de compra de la Guía de Campo de Sistemas de Extracción IMC 2024 Capítulo 5 de Masterbuild",
        samplePdf: "uploads/ch5-exhaust-systems-sample.pdf",
        samplePreview: "uploads/ch5-exhaust-systems-sample-preview.png",
        sampleLabel: "Muestra gratis — Cadena de Prueba de Extracción Capítulo 5 (PDF)"
      }, {
        id: "chapter6Guide",
        title: "Guía de Campo de Sistemas de Ductos — IMC 2024 Capítulo 6",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Diseñadores e ingenieros MEP, arquitectos, contratistas, revisores de planos, equipos de commissioning/TAB, representantes del propietario, gerentes de facilidades y coordinadores de permisos",
        price: window.MB_CATALOG.price("imcChapter6Guide"),
        body: "Un flujo de campo del Capítulo 6 de 22 páginas para rutas de aire, materiales, aislamiento, dimensionamiento, pérdidas de presión, plénums, coordinación de shafts, aberturas protegidas, acceso a dampers, durabilidad ante sal y preparación pre-TAB. Incluye cuatro herramientas imprimibles: registro de ductos/materiales, pase de coordinación de plénum, matriz de aberturas/dampers y auditoría pre-TAB de 60 minutos.",
        notifySubject: "Interés de compra de la Guía de Campo de Sistemas de Ductos IMC 2024 Capítulo 6 de Masterbuild",
        samplePdf: "uploads/ch6-duct-systems-sample.pdf",
        samplePreview: "uploads/ch6-duct-systems-sample-preview.png",
        sampleLabel: "Muestra gratis — Coordinación Costera y de Shafts Capítulo 6 (PDF)"
      }, {
        id: "chapter7Guide",
        title: "Guía de Campo de Aire de Combustión — IMC 2024 Capítulo 7",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Diseñadores e ingenieros MEP, arquitectos, contratistas mecánicos, proveedores de controles, equipos de commissioning y arranque, revisores de planos y representantes del propietario",
        price: window.MB_CATALOG.price("imcChapter7Guide"),
        body: "Un flujo de campo del Capítulo 7 de 21 páginas: enrute cada equipo a su fuente de control, dimensione la toma de aire de combustión con una cadena aritmética de ocho líneas, pruebe el área libre real del producto instalado, enclave los dampers con el encendido, coordine rutas clasificadas, levante condiciones existentes y libere nueve compuertas de avance o detención antes de emitir alcance nuevo. Incluye un Read First de 3 páginas y ocho herramientas imprimibles.",
        notifySubject: "Interés de compra de la Guía de Campo de Aire de Combustión IMC 2024 Capítulo 7 de Masterbuild",
        samplePdf: "uploads/ch7-combustion-air-sample.pdf",
        samplePreview: "uploads/ch7-combustion-air-sample-preview.png",
        sampleLabel: "Muestra gratis — Enrutamiento de Equipos y Verificaciones Capítulo 7 (PDF)"
      }, {
        id: "chapter67Bundle",
        title: "Paquete IMC 2024 Capítulos 6 + 7 — Sistemas de Ductos y Aire de Combustión",
        tag: "Paquete · Ahorre " + window.MB_CATALOG.savings("imcChapter67Bundle", ["imcChapter6Guide", "imcChapter7Guide"]),
        audience: "Equipos en remodelación y edificios existentes donde el trabajo de ductos y los cuartos de equipos se encuentran",
        price: window.MB_CATALOG.price("imcChapter67Bundle"),
        body: "Ambas guías de campo en un solo paquete. El Capítulo 6 gobierna la ruta del ducto - material, presión, soportes, acceso y barreras clasificadas. El Capítulo 7 gobierna el cuarto de equipos al final de esa ruta y el aire de combustión que debe llegar. En remodelación estos dos alcances se perjudican constantemente. 43 páginas, dos archivos Read First, doce herramientas imprimibles, " + window.MB_CATALOG.price("imcChapter67Bundle") + " en vez de " + window.MB_CATALOG.listPrice(["imcChapter6Guide", "imcChapter7Guide"]) + ".",
        notifySubject: "Interés de compra del paquete IMC 2024 Capítulos 6 + 7 de Masterbuild",
        samplePdf: "uploads/ch7-combustion-air-sample.pdf",
        samplePreview: "uploads/ch7-combustion-air-sample-preview.png",
        sampleLabel: "Muestra gratis — Enrutamiento de Equipos y Verificaciones Capítulo 7 (PDF)"
      }, {
        id: "chapter8Guide",
        title: "Guía de Campo de Chimeneas y Venteos — IMC 2024 Capítulo 8",
        tag: "Lanzamiento por Capítulo · Disponible Ahora",
        audience: "Ingenieros y diseñadores MEP, arquitectos que coordinan chases y techos, contratistas mecánicos y de chimeneas, revisores de planos, agentes de commissioning y propietarios que heredan chimeneas existentes",
        price: window.MB_CATALOG.price("imcChapter8Guide"),
        body: "“Chimenea existente a permanecer” son las cuatro palabras más caras en un juego mecánico de renovación, porque no son una decisión — son una decisión aplazada hasta que se cierra la pared. Un sistema de prueba de 28 páginas para el venteo: qué documento gobierna cada equipo, una base de tamaño verificable, la aceptación por cuatro compuertas, conectores y espacios libres, geometría de terminación y los puntos de retención de cierre. Trece secciones, un archivo Read First, once herramientas imprimibles y un libro de trabajo llenable.",
        notifySubject: "Interés de compra de la Guía de Chimeneas y Venteos IMC 2024 Capítulo 8 de Masterbuild",
        samplePdf: "uploads/ch8-chimneys-vents-sample.pdf",
        samplePreview: "uploads/ch8-chimneys-vents-sample-preview.png",
        sampleLabel: "Muestra gratis — la aceptación completa por cuatro compuertas (PDF)"
      }, {
        id: "chapter78Bundle",
        title: "Paquete Aire de Combustión + Venteo — IMC 2024 Capítulos 7 y 8",
        tag: "Paquete · Ahorre " + window.MB_CATALOG.savings("imcChapter78Bundle", ["imcChapter7Guide", "imcChapter8Guide"]),
        audience: "Quien tenga un equipo a gas en un closet, un cuarto de calderas en renovación, o una chimenea existente que le piden reutilizar",
        price: window.MB_CATALOG.price("imcChapter78Bundle"),
        body: "Ambas mitades de la conversación del cuarto de equipos. El Capítulo 7 gobierna el aire que el equipo necesita para quemar — y lo enruta al código que realmente carga los criterios, que para equipos a gas es el código de gas combustible, no el mecánico. El Capítulo 8 gobierna el sistema que saca los productos de la combustión. Quien tiene uno y no el otro tiene media respuesta. 49 páginas, dos archivos Read First, diecinueve herramientas y el libro de trabajo llenable, " + window.MB_CATALOG.price("imcChapter78Bundle") + " en vez de " + window.MB_CATALOG.listPrice(["imcChapter7Guide", "imcChapter8Guide"]) + ".",
        notifySubject: "Interés de compra del Paquete Aire de Combustión + Venteo de Masterbuild",
        samplePdf: "uploads/ch8-chimneys-vents-sample.pdf",
        samplePreview: "uploads/ch8-chimneys-vents-sample-preview.png",
        sampleLabel: "Muestra gratis — la aceptación completa por cuatro compuertas (PDF)"
      }],
      tiers: [{
        name: "Gratis",
        price: "$0",
        fit: "Buscar y diagnosticar",
        includes: ["Archivo Daily Code Talk", "Navegación bilingüe", "Muestras gratis de Capítulos 1-7", "Guía de campo de ventilación Capítulo 4", "Ejemplos de riesgo en campo"]
      }, {
        name: "Flujo de Permiso",
        price: "$57 / $79",
        fit: "Control del proceso y QA antes de entrega",
        includes: ["Guía IMC 101–115", "Revisión Permit Readiness", "Controles de documentos e inspección", "Cierre AHJ y compuerta de entrega"]
      }, {
        name: "Guías Especializadas",
        price: "$99 / $149 / $199",
        fit: "Riesgo del propietario o profundidad técnica",
        includes: ["Revisión MEP del propietario", "Ventilación y evidencia de aire exterior", "Control de extracción Capítulo 5", "Coordinación de ductos Capítulo 6", "Cierre de campo y seguimiento"]
      }, {
        name: "Revisión de Proyecto",
        price: "Propuesta escrita",
        fit: "Decisiones específicas",
        includes: ["Alcance y entregables definidos", "Base de código adoptado y AHJ", "Revisión de planos y campo", "Supuestos, exclusiones y próximos pasos claros"]
      }],
      cta: "Obtener la guía del Capítulo 1",
      secondary: "Leer Daily Code Talk",
      newsletterEyebrow: "Gratis — lista de correo Code Desk",
      newsletterDesc: "Artículos útiles de Daily Code Talk, notas de QA de campo y lanzamientos cuando se publiquen. Sin promesa de correo diario. Puede cancelar cuando quiera.",
      newsletterCta: "Suscribir",
      newsletterSuccess: "Está en la lista Code Desk. Revise su correo para confirmar si se solicita.",
      leadMagnet: {
        eyebrow: "Muestra gratis",
        title: "Checklist Muestra de Preparación para Permisos",
        body: "Use la lista corta para detectar alcance faltante, archivos base y puntos sensibles del AHJ antes de iniciar horas de ingeniería.",
        cta: "Enviar la muestra",
        success: "Muestra lista. Puede descargar el PDF ahora.",
        download: "Descargar checklist muestra",
        subject: "Masterbuild Permit Readiness Sample Checklist download"
      },
      buyCta: "Comprar",
      notifyCta: "Próximamente - avisarme",
      requestLinkCta: "Recibir enlace de compra",
      notifySuccess: "Interés recibido. Osmany verá qué producto solicitó.",
      emailPlaceholder: "correo@ejemplo.com",
      paymentNote: "El pago se procesa de forma segura en Stripe. Use el correo del comprador para entrega y soporte; guarde el recibo."
    },
    authority: {
      eyebrow: "/ Credenciales",
      headline: "Participación directa del PE. Prueba clara.",
      items: [{
        stat: "Todo MEP",
        label: "Cuatro Disciplinas Internas",
        desc: "HVAC, plomería, protección contra incendios y diseño eléctrico - todo revisado y entregado por el mismo ingeniero principal. Un solo punto de contacto para el paquete completo."
      }, {
        stat: "PE",
        label: "Ingeniero Profesional Licenciado",
        desc: "Liderado por Osmany Portal, PE. Cada alcance se revisa y entrega con la participación directa de un ingeniero licenciado - sin delegación."
      }, {
        stat: "Por Proyecto",
        label: "Licencia Confirmada por Alcance",
        desc: "Masterbuild confirma la licencia, la autoridad de sellado y la estructura de entrega proyecto por proyecto. Contáctenos para discutir su jurisdicción."
      }, {
        stat: "EN / ES",
        label: "Capacidad Bilingüe",
        desc: "Contenido técnico en español, revisión de planos y comunicación bilingüe de proyecto disponibles como servicio premium."
      }]
    }
  }
};
window.SECTIONS_CONTENT = SECTIONS_CONTENT;

// ─── Services ─────────────────────────────────────────────────────────────
function MBServices({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].services;
  const accent = tweaks.accent;
  const [active, setActive] = React.useState(0);
  return /*#__PURE__*/React.createElement("section", {
    id: "services",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 56
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 16px"
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 16,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      maxWidth: 560
    }
  }, t.sub)), /*#__PURE__*/React.createElement("div", {
    className: "mb-service-tabs",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
      gap: 3,
      marginBottom: 3
    }
  }, t.items.map((item, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActive(i),
    style: {
      minWidth: 0,
      minHeight: 48,
      padding: "10px 16px",
      background: active === i ? accent : "#131417",
      color: active === i ? "#0B0C0E" : "rgba(240,237,232,0.5)",
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: active === i ? 700 : 400,
      letterSpacing: "0.01em",
      lineHeight: 1.35,
      textAlign: "center",
      whiteSpace: "normal",
      transition: "all 0.2s",
      borderRadius: 2
    }
  }, item.num, " - ", item.tag))), t.items.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: active === i ? "grid" : "none",
      gridTemplateColumns: "1fr 1fr",
      gap: 0,
      background: "#131417",
      borderBottom: `3px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "48px 44px",
      borderRight: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(20px, 2.5vw, 28px)",
      color: "#F0EDE8",
      margin: "0 0 20px",
      lineHeight: 1.25
    }
  }, item.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      lineHeight: 1.75,
      color: "rgba(240,237,232,0.6)",
      margin: "0 0 28px"
    }
  }, item.body), /*#__PURE__*/React.createElement("a", {
    href: item.href,
    onClick: () => {
      try {
        window.sessionStorage.setItem("mb_service_interest", item.title);
      } catch (e) {}
      if (window.trackMBEvent) window.trackMBEvent("Service Learn More Click", { service: item.tag, lang, target: item.href });
    },
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent,
      textDecoration: "none",
      fontWeight: 600,
      letterSpacing: "0.03em",
      borderBottom: `1px solid rgba(196,120,58,0.3)`,
      paddingBottom: 2
    }
  }, lang === "en" ? "Learn more →" : "Más información →")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "48px 44px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 20
    }
  }, lang === "en" ? "Scope includes" : "El alcance incluye"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, item.bullets.map((b, bi) => /*#__PURE__*/React.createElement("li", {
    key: bi,
    style: {
      display: "flex",
      gap: 12,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      marginTop: 2,
      flexShrink: 0
    }
  }, " - "), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.65)",
      lineHeight: 1.5
    }
  }, b)))))))));
}

// ─── Mission Critical ─────────────────────────────────────────────────────
function MBMissionCritical({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].mission;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: accent
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "64px 80px",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(26px, 3vw, 40px)",
      color: "#F0EDE8",
      margin: "0 0 28px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      lineHeight: 1.75,
      color: "rgba(240,237,232,0.6)",
      margin: "0 0 20px"
    }
  }, t.body1), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      lineHeight: 1.75,
      color: "rgba(240,237,232,0.6)",
      margin: "0 0 32px"
    }
  }, t.body2), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 20px",
      background: `rgba(196,120,58,0.08)`,
      border: `1px solid rgba(196,120,58,0.2)`,
      borderRadius: 3,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: accent,
      margin: 0,
      fontStyle: "italic",
      lineHeight: 1.6
    }
  }, t.note)), /*#__PURE__*/React.createElement("a", {
    href: lang === "es" ? "/contacto/" : "/send/",
    style: {
      padding: "12px 24px",
      background: "transparent",
      border: `1px solid ${accent}`,
      color: accent,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      display: "inline-block",
      transition: "all 0.2s"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = accent;
      e.currentTarget.style.color = "#0B0C0E";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "transparent";
      e.currentTarget.style.color = accent;
    }
  }, t.cta)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: "rgba(240,237,232,0.3)",
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, lang === "en" ? "Technical focus areas" : "Áreas de enfoque técnico"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, t.bullets.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "16px 20px",
      background: "#131417",
      display: "flex",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      minWidth: 24,
      textAlign: "right"
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.7)",
      lineHeight: 1.4
    }
  }, b))))))));
}

// ─── Markets ──────────────────────────────────────────────────────────────
function MBMarkets({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].markets;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    id: "markets",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 16px"
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.5)",
      margin: "0 0 28px",
      maxWidth: 560
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 2
    }
  }, t.items.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "20px 22px",
      background: "#131417",
      transition: "background 0.2s",
      cursor: "default"
    },
    onMouseEnter: e => e.currentTarget.style.background = "#1C1E23",
    onMouseLeave: e => e.currentTarget.style.background = "#131417"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 20,
      height: 2,
      background: accent,
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 16,
      color: "#F0EDE8",
      margin: "0 0 10px"
    }
  }, item.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.6
    }
  }, item.desc))))));
}
function MBExistingBuildings({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].existingBuildings;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    id: "existing-buildings",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))",
      gap: "48px 64px",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(26px, 3vw, 40px)",
      color: "#F0EDE8",
      margin: "0 0 20px",
      lineHeight: 1.2
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.65)",
      margin: "0 0 24px",
      lineHeight: 1.7
    }
  }, t.sub), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.5)",
      margin: "0 0 32px",
      lineHeight: 1.7
    }
  }, t.body), /*#__PURE__*/React.createElement("a", {
    href: window.MB_CATALOG.scopingCall,
    target: "_blank",
    rel: "noopener noreferrer",
    style: {
      display: "inline-block",
      background: accent,
      color: "#fff",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 14,
      padding: "12px 24px",
      textDecoration: "none",
      letterSpacing: "0.02em"
    }
  }, t.cta), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: "rgba(240,237,232,0.3)",
      margin: "12px 0 0",
      letterSpacing: "0.03em"
    }
  }, t.ctaNote)), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 8
    }
  }, t.bullets.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 0",
      borderBottom: i < t.bullets.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      lineHeight: "24px",
      flexShrink: 0
    }
  }, "0" + (i + 1)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.7)",
      lineHeight: 1.6
    }
  }, b))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      padding: "20px 24px",
      background: "#131417",
      borderLeft: "3px solid " + accent
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.45)",
      margin: 0,
      lineHeight: 1.6
    }
  }, t.note)))));
}
function MBTrustBand({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].trust;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    "data-trust-band": "true",
    style: {
      background: "#0F1013",
      padding: "56px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      borderBottom: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-trust-grid": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "0.7fr 1.7fr",
      gap: "28px 48px",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 10
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(22px, 2.4vw, 32px)",
      color: "#F0EDE8",
      margin: "0 0 10px",
      lineHeight: 1.15
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      lineHeight: 1.6,
      margin: 0
    }
  }, t.sub)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    "data-trust-logos": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
      gap: 2,
      marginBottom: 18
    }
  }, t.logos.map(item => {
    const mutedCard = item.name.includes("request") || item.name.includes("solicitud");
    const cardStyle = {
      minHeight: 146,
      background: "#131417",
      padding: "18px 16px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: 18,
      borderTop: `2px solid ${mutedCard ? "rgba(255,255,255,0.08)" : accent}`,
      textDecoration: "none"
    };
    const cardBody = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 800,
        fontSize: 15,
        color: "#F0EDE8",
        lineHeight: 1.15
      }
    }, item.name), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9.5,
        color: "rgba(240,237,232,0.42)",
        letterSpacing: "0.06em",
        textTransform: "uppercase",
        lineHeight: 1.35,
        marginBottom: item.body ? 8 : 0
      }
    }, item.note), item.body && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 12,
        color: "rgba(240,237,232,0.55)",
        lineHeight: 1.45
      }
    }, item.body)));
    return item.url ? /*#__PURE__*/React.createElement("a", {
      key: item.name,
      href: item.url,
      target: "_blank",
      rel: "noopener",
      "aria-label": `${item.name} website`,
      style: cardStyle
    }, cardBody) : /*#__PURE__*/React.createElement("div", {
      key: item.name,
      style: cardStyle
    }, cardBody);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      marginRight: 4
    }
  }, t.sectorsLabel), t.sectors.map(sector => /*#__PURE__*/React.createElement("span", {
    key: sector,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.58)",
      padding: "5px 9px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: 2
    }
  }, sector)))))));
}

// ─── Daily Code Talk ──────────────────────────────────────────────────────
function MBDailyCodeTalk({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].daily;
  const accent = tweaks.accent;
  const [email, setEmail] = React.useState("");
  const [joined, setJoined] = React.useState(false);
  const [subscribeError, setSubscribeError] = React.useState("");

  // Map IMC section numbers (as rendered in chip labels) to DCT article IDs (dct-data.js ids).
  // Sections with multi-part articles deep-link to the first part; only sections that exist in
  // dct-data.js are mapped - others render as static chips (queued / future content).
  const IMC_SECTION_LINKS = {
    // Chapter 1 - Administration (each section is its own dct-data entry)
    "101": "imc-101",
    "102": "imc-102",
    "103": "imc-103",
    "104": "imc-104",
    "105": "imc-105",
    "106": "imc-106",
    "107": "imc-107",
    "108": "imc-108",
    "109": "imc-109",
    "110": "imc-110",
    "111": "imc-111",
    "112": "imc-112",
    "113": "imc-113",
    "114": "imc-114",
    "115": "imc-115",
    // Chapter 2 - Definitions
    "201": "imc-201",
    "202": "imc-202",
    // Chapter 3 - Installation (multi-part articles deep-link to Part 1)
    "301": "imc-301-p1",
    "302": "imc-302",
    "303": "imc-303",
    "304": "imc-304-p1",
    "305": "imc-305",
    "306": "imc-306-p1",
    "307": "imc-307",
    "308": "imc-308",
    "309": "imc-309",
    "310": "imc-310",
    "311": "imc-311",
    "312": "imc-312",
    // Chapter 4 - Ventilation
    "401": "imc-401-p1",
    "402": "imc-402",
    "403": "imc-403-p1",
    "404": "imc-404",
    "405": "imc-405",
    "406": "imc-406",
    "407": "imc-407",
    // Chapter 5 - Exhaust Systems (auto-imported 2026-05)
    "501": "imc-501-p1",
    "502": "imc-502-p1",
    "503": "imc-503",
    "504": "imc-504-p1",
    "505": "imc-505-p1",
    "506": "imc-506-p1",
    "507": "imc-507-p1",
    "508": "imc-508",
    "509": "imc-509-p1",
    "510": "imc-510-p1",
    "511": "imc-511",
    "512": "imc-512-p1",
    "513": "imc-513",
    // Chapter 6 - Duct Systems (auto-imported 2026-05)
    "601": "imc-601-p1",
    "602": "imc-602-p1",
    "603": "imc-603-p1",
    "604": "imc-604-p1",
    "605": "imc-605",
    "606": "imc-606-p1",
    "607": "imc-607-p1",
    "608": "imc-608",
    "701": "imc-701",
    // Sparky Edition (NEC) - published Article 90 series
    "90.1": "sparky-90-1",
    "90.2": "sparky-90-2",
    "90.3-90.6": "sparky-90-3",
    "90.7-90.9": "sparky-90-7"
    // Note: 604.13 is a subsection of 604 - direct deep-link still works at #imc-604-13,
    // but the chip strip surfaces 604 only (clicking it opens 604 Part 1; readers can
    // navigate to the 604.13 internal-insulation deep-dive from inside the article view).
  };
  const IMC_ARTICLE_HREFS = {
    "sparky-90-1": "/daily-code-talk/sparky-edition-nec-90-1-90-2-scope-covered-installations/",
    "sparky-90-2": "/daily-code-talk/sparky-edition-nec-90-2-a2-installations-not-covered/",
    "sparky-90-3": "/daily-code-talk/sparky-edition-nec-90-3-90-6-code-arrangement-ahj-authority/",
    "sparky-90-7": "/daily-code-talk/sparky-edition-nec-90-7-90-9-equipment-examination-wiring-planning/",
    "imc-101": "/daily-code-talk/imc-101-scope-and-general-requirements/",
    "imc-102": "/daily-code-talk/imc-102-applicability/",
    "imc-103": "/daily-code-talk/imc-103-code-compliance-agency/",
    "imc-104": "/daily-code-talk/imc-104-duties-and-powers-of-the-code-official/",
    "imc-105": "/daily-code-talk/imc-105-permits/",
    "imc-106": "/daily-code-talk/imc-106-construction-documents/",
    "imc-107": "/daily-code-talk/imc-107-notice-of-approval/",
    "imc-108": "/daily-code-talk/imc-108-fees/",
    "imc-109": "/daily-code-talk/imc-109-service-utilities/",
    "imc-110": "/daily-code-talk/imc-110-temporary-uses-equipment-and-systems/",
    "imc-111": "/daily-code-talk/imc-111-inspections-and-testing/",
    "imc-112": "/daily-code-talk/imc-112-means-of-appeals/",
    "imc-113": "/daily-code-talk/imc-113-board-of-appeals/",
    "imc-114": "/daily-code-talk/imc-114-violations/",
    "imc-115": "/daily-code-talk/imc-115-stop-work-order/",
    "imc-201": "/daily-code-talk/imc-201-scope-interchangeability-and-using-definitions/",
    "imc-202": "/daily-code-talk/imc-202-general-definitions-that-trigger-redlines/",
    "imc-301-p1": "/daily-code-talk/imc-301-part-1/",
    "imc-302": "/daily-code-talk/imc-302-protection-of-structure/",
    "imc-303": "/daily-code-talk/imc-303-equipment-and-appliance-location/",
    "imc-304-p1": "/daily-code-talk/imc-304-installation-part-1/",
    "imc-305": "/daily-code-talk/imc-305-piping-support/",
    "imc-306-p1": "/daily-code-talk/imc-306-access-and-service-space-part-1/",
    "imc-307": "/daily-code-talk/imc-307-condensate-disposal/",
    "imc-308": "/daily-code-talk/imc-308-clearance-reduction/",
    "imc-309": "/daily-code-talk/imc-309-temperature-control/",
    "imc-310": "/daily-code-talk/imc-310-explosion-control/",
    "imc-311": "/daily-code-talk/imc-311-smoke-and-heat-vents/",
    "imc-312": "/daily-code-talk/imc-312-heating-and-cooling-load-calculations/",
    "imc-401-p1": "/daily-code-talk/imc-401-part-1/",
    "imc-402": "/daily-code-talk/imc-402-natural-ventilation-402-1-402-4/",
    "imc-403-p1": "/daily-code-talk/imc-403-part-1/",
    "imc-404": "/daily-code-talk/imc-404-enclosed-parking-garages-404-1-404-2/",
    "imc-405": "/daily-code-talk/imc-405-systems-control-405-1/",
    "imc-406": "/daily-code-talk/imc-406-ventilation-of-uninhabited-spaces-406-1/",
    "imc-407": "/daily-code-talk/imc-407-ambulatory-care-and-group-i-2-407-1/",
    "imc-501-p1": "/daily-code-talk/imc-501-part-1/",
    "imc-502-p1": "/daily-code-talk/imc-502-part-1-general-exhaust-502-1-502-2/",
    "imc-503": "/daily-code-talk/imc-503-motors-and-fans-in-hazardous-exhaust/",
    "imc-504-p1": "/daily-code-talk/imc-504-part-1-basics-penetrations-terminations-504-1-504-4-2/",
    "imc-505-p1": "/daily-code-talk/imc-505-part-1-domestic-cooking-exhaust-basics-505-1-505-3/",
    "imc-506-p1": "/daily-code-talk/imc-506-part-1-grease-duct-basics-506-1-506-3-6/",
    "imc-507-p1": "/daily-code-talk/imc-507-part-1-507-1-general-operation-testing/",
    "imc-508": "/daily-code-talk/imc-508-commercial-kitchen-makeup-air/",
    "imc-509-p1": "/daily-code-talk/imc-509-part-1-509-1-509-2-2/",
    "imc-510-p1": "/daily-code-talk/imc-510-part-1-510-1-510-1-1-dust-stock-refuse-systems-collectors/",
    "imc-511": "/daily-code-talk/imc-511-subslab-soil-exhaust-systems/",
    "imc-512-p1": "/daily-code-talk/imc-512-part-1-scope-intent-and-documentation-512-1-512-3/",
    "imc-513": "/daily-code-talk/imc-513-energy-recovery-ventilation-systems/",
    "imc-601-p1": "/daily-code-talk/imc-601-part-1-601-1-601-2-1/",
    "imc-602-p1": "/daily-code-talk/imc-602-part-1-602-1-602-1-3/",
    "imc-603-p1": "/daily-code-talk/imc-603-part-1-603-1-603-5-2-duct-construction/",
    "imc-604-p1": "/daily-code-talk/imc-604-part-1-604-1-604-5-duct-insulation-basics/",
    "imc-605": "/daily-code-talk/imc-605-air-filters/",
    "imc-606-p1": "/daily-code-talk/imc-606-part-1-606-1-606-2-3-where-smoke-detection-is-required/",
    "imc-607-p1": "/daily-code-talk/imc-607-part-1-607-1-607-2-1/",
    "imc-608": "/daily-code-talk/imc-608-balancing-field-verified-airflow/",
    "imc-701": "/daily-code-talk/imc-701-combustion-air-scope-dampered-openings/"
  };
  const IMC_CHAPTERS = [{
    ch: "Ch. 1",
    label: lang === "en" ? "Administration" : "Administración",
    sections: ["101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115"]
  }, {
    ch: "Ch. 2",
    label: lang === "en" ? "Definitions" : "Definiciones",
    sections: ["201", "202"]
  }, {
    ch: "Ch. 3",
    label: lang === "en" ? "General Regulations" : "Reglamentos Generales",
    sections: ["301", "302", "303", "304", "305", "306", "307", "308", "309", "310", "311", "312"]
  }, {
    ch: "Ch. 4",
    label: lang === "en" ? "Ventilation" : "Ventilación",
    sections: ["401", "402", "403", "404", "405", "406", "407"]
  }, {
    ch: "Ch. 5",
    label: lang === "en" ? "Exhaust Systems" : "Sistemas de Extracción",
    sections: ["501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512", "513"]
  }, {
    ch: "Ch. 6",
    label: lang === "en" ? "Duct Systems" : "Sistemas de Ductos",
    sections: ["601", "602", "603", "604", "605", "606", "607", "608"]
  }, {
    ch: "Ch. 7",
    label: lang === "en" ? "Combustion Air" : "Aire de Combustión",
    sections: ["701"]
  }, {
    ch: "NEC",
    label: lang === "en" ? "Sparky Edition · Art. 90" : "Edición Sparky · Art. 90",
    sections: ["90.1", "90.2", "90.3-90.6", "90.7-90.9"]
  }];
  const PLATFORM = lang === "en" ? [{
    name: "Chapter 1 Permit Process Field Guide",
    status: "Permit workflow & field control · $57",
    href: window.MB_CATALOG.offers.imcChapter1Guide.url
  }, {
    name: "Chapter 2 Definitions & Redline Prevention Field Guide",
    status: "Definitions, triggers & redline control · $57",
    href: window.MB_CATALOG.offers.imcChapter2Guide.url
  }, {
    name: "Chapter 3 Installation Readiness & Field Coordination Guide",
    status: "Installation evidence & field coordination · $57",
    href: window.MB_CATALOG.offers.imcChapter3Guide.url
  }, {
    name: "Chapter 4 Ventilation Fundamentals — Free Field Guide",
    status: "Ventilation proof chain & readiness audit · Free",
    href: "/uploads/ch4-ventilation-fundamentals-free-guide.pdf"
  }, {
    name: "Chapter 5 Exhaust Systems Field Guide",
    status: "Exhaust classification, proof & closeout · $199",
    href: window.MB_CATALOG.offers.imcChapter5Guide.url
  }, {
    name: "Chapter 6 Duct Systems Field Guide",
    status: "Duct coordination, access & pre-TAB readiness · $149",
    href: window.MB_CATALOG.offers.imcChapter6Guide.url
  }, {
    name: "Browse the full resource library",
    status: "Samples, free tools & scoped review support",
    href: "/resources/"
  }] : [{
    name: "Guía de Permisos del Capítulo 1",
    status: "Flujo de permisos y control de campo · $57",
    href: window.MB_CATALOG.offers.imcChapter1Guide.url
  }, {
    name: "Guía del Capítulo 2: Definiciones y Prevención de Redlines",
    status: "Definiciones, activadores y control de redlines · $57",
    href: window.MB_CATALOG.offers.imcChapter2Guide.url
  }, {
    name: "Guía del Capítulo 3: Preparación de Instalación y Coordinación de Campo",
    status: "Evidencia de instalación y coordinación de campo · $57",
    href: window.MB_CATALOG.offers.imcChapter3Guide.url
  }, {
    name: "Capítulo 4: Fundamentos de Ventilación — Guía de Campo Gratuita",
    status: "Cadena de evidencia de ventilación y auditoría de preparación · Gratis",
    href: "/uploads/ch4-ventilation-fundamentals-free-guide.pdf"
  }, {
    name: "Guía de Campo del Capítulo 5: Sistemas de Extracción",
    status: "Clasificación, evidencia y cierre de extracción · $199",
    href: window.MB_CATALOG.offers.imcChapter5Guide.url
  }, {
    name: "Guía de Campo del Capítulo 6: Sistemas de Ductos",
    status: "Coordinación de ductos, acceso y preparación pre-TAB · $149",
    href: window.MB_CATALOG.offers.imcChapter6Guide.url
  }, {
    name: "Ver la biblioteca completa de recursos",
    status: "Muestras, herramientas gratuitas y apoyo de revisión por alcance",
    href: "/resources/"
  }];
  const handleWaitlist = () => {
    if (!email) return;
    setSubscribeError("");
    const fd = new FormData();
    fd.append("email", email.trim());
    fd.append("tag", "daily-code-talk");
    fetch(window.MB_CATALOG.subscribe.endpoint, {
      method: "POST",
      body: fd
    }).then(response => {
      if (!response.ok) throw new Error("Subscription request failed");
      if (window.trackMBEvent) window.trackMBEvent("Homepage Subscribe", { provider: "buttondown", source: "daily-code-talk-section", language: lang });
      setJoined(true);
    }).catch(() => setSubscribeError(lang === "en" ? "Could not subscribe. Please try again or use the direct list link." : "No se pudo suscribir. Intente de nuevo o use el enlace directo."));
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "dailycode",
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      flexWrap: "wrap",
      gap: 24,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(26px, 3vw, 40px)",
      color: "#F0EDE8",
      margin: "0 0 12px"
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      maxWidth: 520
    }
  }, t.sub)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      padding: "5px 12px",
      background: "rgba(196,120,58,0.1)",
      border: "1px solid rgba(196,120,58,0.25)",
      borderRadius: 2,
      letterSpacing: "0.08em",
      whiteSpace: "normal",
      maxWidth: "100%",
      lineHeight: 1.5
    }
  }, "\u25CF ", t.badge)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
      gap: 2,
      marginBottom: 2
    }
  }, t.posts.map((post, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: post.href,
    style: {
      padding: "32px 28px",
      background: "#131417",
      textDecoration: "none",
      display: "block",
      borderBottom: "2px solid transparent",
      transition: "border-color 0.2s, background 0.2s"
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderBottomColor = accent;
      e.currentTarget.style.background = "#1C1E23";
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderBottomColor = "transparent";
      e.currentTarget.style.background = "#131417";
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 14
    }
  }, post.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 600,
      fontSize: 17,
      color: "#F0EDE8",
      margin: "0 0 12px",
      lineHeight: 1.3
    }
  }, post.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.6
    }
  }, post.desc)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "32px 36px",
      background: "#131417",
      marginBottom: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 24
    }
  }, lang === "en" ? "Section Coverage" : "Cobertura de Secciones"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, IMC_CHAPTERS.map((chap, ci) => /*#__PURE__*/React.createElement("div", {
    key: ci,
    style: {
      display: "flex",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 96,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      marginBottom: 3
    }
  }, chap.ch), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      color: "rgba(240,237,232,0.35)"
    }
  }, chap.label)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 5
    }
  }, chap.sections.map((sec, si) => {
    const articleId = IMC_SECTION_LINKS[sec];
    const articleHref = articleId ? IMC_ARTICLE_HREFS[articleId] || "/daily-code-talk/" : "/daily-code-talk/";
    const isQueued = sec.includes("queued");
    if (articleId) {
      return /*#__PURE__*/React.createElement("a", {
        key: si,
        href: articleHref,
        style: {
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 10,
          color: accent,
          padding: "3px 8px",
          background: "rgba(196,120,58,0.1)",
          border: `1px solid rgba(196,120,58,0.3)`,
          borderRadius: 2,
          textDecoration: "none",
          transition: "background 0.15s, color 0.15s",
          cursor: "pointer"
        },
        onMouseEnter: e => {
          e.currentTarget.style.background = accent;
          e.currentTarget.style.color = "#0B0C0E";
        },
        onMouseLeave: e => {
          e.currentTarget.style.background = "rgba(196,120,58,0.1)";
          e.currentTarget.style.color = accent;
        },
        title: `${lang === "en" ? "Read IMC" : "Leer IMC"} ${sec}`
      }, sec);
    }
    return /*#__PURE__*/React.createElement("span", {
      key: si,
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: isQueued ? "rgba(240,237,232,0.25)" : "rgba(240,237,232,0.6)",
        padding: "3px 8px",
        background: "rgba(196,120,58,0.04)",
        border: "1px solid rgba(255,255,255,0.06)",
        borderRadius: 2,
        fontStyle: isQueued ? "italic" : "normal"
      }
    }, sec);
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "22px 36px",
      background: "rgba(196,120,58,0.04)",
      border: "1px solid rgba(196,120,58,0.12)",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 14
    }
  }, lang === "en" ? "Field Guides & Tools From the Same Source" : "Guías de Campo y Herramientas de la Misma Fuente"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.48)",
      lineHeight: 1.55,
      maxWidth: 760,
      margin: "0 0 16px"
    }
  }, lang === "en" ? "Move from a code article to the field tool that helps you organize the decision, evidence, and closeout work. Verify the adopted code and project conditions before use." : "Pase de un artículo de código a la herramienta de campo que ayuda a organizar la decisión, la evidencia y el cierre. Verifique el código adoptado y las condiciones del proyecto antes de usarla."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 10
    }
  }, PLATFORM.map((p, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: p.href,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "9px 11px",
      background: "rgba(255,255,255,0.02)",
      border: "1px solid rgba(196,120,58,0.2)",
      textDecoration: "none",
      transition: "border-color 0.15s, background 0.15s"
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = accent;
      e.currentTarget.style.background = "rgba(196,120,58,0.1)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = "rgba(196,120,58,0.2)";
      e.currentTarget.style.background = "rgba(255,255,255,0.02)";
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 4,
      height: 4,
      borderRadius: "50%",
      background: accent,
      flexShrink: 0,
      display: "inline-block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.7)"
    }
  }, p.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 9,
      color: "rgba(240,237,232,0.3)",
      letterSpacing: "0.06em",
      textTransform: "uppercase"
    }
  }, p.status), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      marginLeft: 2
    }
  }, "→"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "auto 1fr",
      gap: 2,
      alignItems: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 28px",
      background: "#131417",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: t.ctaLink,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent,
      textDecoration: "none",
      fontWeight: 600,
      letterSpacing: "0.04em",
      borderBottom: `1px solid rgba(196,120,58,0.3)`,
      paddingBottom: 2,
      whiteSpace: "nowrap"
    }
  }, t.cta)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 28px",
      background: "#131417"
    }
  }, joined ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent
    }
  }, "\u2713 ", lang === "en" ? "You're on the list." : "Estás en la lista.") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "rgba(240,237,232,0.3)",
      textTransform: "uppercase",
      letterSpacing: "0.06em",
      flexShrink: 0
    }
  }, lang === "en" ? "Get new posts" : "Recibir artículos"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: lang === "en" ? "email@example.com" : "correo@ejemplo.com",
    value: email,
    onChange: e => setEmail(e.target.value),
    onKeyDown: e => e.key === "Enter" && handleWaitlist(),
    style: {
      flex: 1,
      minWidth: 180,
      padding: "7px 12px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 2,
      fontSize: 13,
      outline: "none",
      fontFamily: "'IBM Plex Sans', sans-serif"
    },
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: handleWaitlist,
    style: {
      padding: "7px 18px",
      background: accent,
      color: "#0B0C0E",
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 12,
      borderRadius: 2,
      whiteSpace: "nowrap"
    }
  }, lang === "en" ? "Subscribe" : "Suscribir"), /*#__PURE__*/React.createElement("span", {
    style: { flexBasis: "100%", fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 10, color: subscribeError ? "#E5A5A5" : "rgba(240,237,232,0.36)", lineHeight: 1.4 }
  }, subscribeError || (lang === "en" ? "Free Code Desk email list. Unsubscribe anytime. Direct signup: buttondown.com/masterbuild" : "Lista gratuita Code Desk. Puede cancelar cuando quiera. Suscripción directa: buttondown.com/masterbuild")))))));
}

// ─── Authority ────────────────────────────────────────────────────────────
function MBResourceLibrary({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].resources;
  const accent = tweaks.accent;
  const [email, setEmail] = React.useState("");
  const [joined, setJoined] = React.useState(false);
  const [subscribeError, setSubscribeError] = React.useState("");
  const [productContacts, setProductContacts] = React.useState({});
  const [notifiedProducts, setNotifiedProducts] = React.useState({});
  const [sampleEmail, setSampleEmail] = React.useState("");
  const [sampleReady, setSampleReady] = React.useState(false);
  const trackResourceProductEvent = (eventName, product, source, extra = {}) => {
    if (!window.trackMBEvent) return;
    window.trackMBEvent(eventName, {
      product: product.id,
      productTitle: product.title,
      price: product.price,
      language: lang,
      source,
      ...extra
    });
  };
  const handleNewsletterSubscribe = () => {
    if (!email) return;
    setSubscribeError("");
    const fd = new FormData();
    fd.append("email", email.trim());
    fd.append("tag", "homepage");
    fetch(window.MB_CATALOG.subscribe.endpoint, {
      method: "POST",
      body: fd
    }).then(response => {
      if (!response.ok) throw new Error("Subscription request failed");
      if (window.trackMBEvent) window.trackMBEvent("Homepage Subscribe", { provider: "buttondown", source: "resources-section", language: lang });
      setJoined(true);
    }).catch(() => setSubscribeError(lang === "en" ? "Could not subscribe. Try again or use buttondown.com/masterbuild." : "No se pudo suscribir. Intente de nuevo o use buttondown.com/masterbuild."));
  };
  const handleProductNotify = product => {
    const productContact = productContacts[product.id] || {};
    const productName = (productContact.name || "").trim();
    const productEmail = (productContact.email || "").trim();
    const productPhone = (productContact.phone || "").trim();
    if (!productName || !productEmail || !productPhone) return;
    trackResourceProductEvent("Resource Product Interest Submit", product, "resource-card-interest-form", {
      hasName: true,
      hasPhone: true,
      hasEmail: true
    });
    fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        lead_type: "Paid resource interest",
        lead_intent: RESOURCE_COMING_SOON_PRODUCT_IDS.has(product.id) ? "Get notified when product is available" : "Request purchase link",
        follow_up_priority: product.id === "monthlyAdvisory" ? "High" : "Medium",
        source: "Resource Library product CTA",
        submission_route: window.location.pathname || "/",
        next_action: product.id === "monthlyAdvisory" ? "Review advisory-retainer fit and invite to scoping call if appropriate." : "Send purchase link, launch timing, or product availability note.",
        name: productName,
        email: productEmail,
        phone: productPhone,
        product: product.title,
        productId: product.id,
        product_price: product.price,
        language: lang,
        _subject: `${product.notifySubject} (${lang.toUpperCase()})`,
        _template: "table",
        _captcha: "false"
      })
    }).catch(() => {}).finally(() => {
      setNotifiedProducts(prev => ({
        ...prev,
        [product.id]: true
      }));
    });
  };
  const productContactInputStyle = {
    width: "100%",
    padding: "9px 11px",
    background: "#0B0C0E",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#F0EDE8",
    borderRadius: 2,
    outline: "none",
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: 12
  };
  const setProductContactField = (productId, field, value) => {
    setProductContacts(prev => ({
      ...prev,
      [productId]: {
        ...(prev[productId] || {}),
        [field]: value
      }
    }));
  };
  const handleSampleDownload = () => {
    const cleanEmail = sampleEmail.trim();
    if (!cleanEmail) return;
    if (window.trackMBEvent) window.trackMBEvent("Resource Lead Magnet Request", {
      asset: "Permit Readiness Sample Checklist",
      language: lang,
      source: "resource-library-lead-magnet",
      hasEmail: true
    });
    fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        lead_type: "Free sample PDF request",
        lead_intent: "Download permit readiness sample checklist",
        follow_up_priority: "Low",
        email: cleanEmail,
        source: "Resource Library lead magnet",
        submission_route: window.location.pathname || "/",
        asset: "Permit Readiness Sample Checklist",
        language: lang,
        next_action: "Send sample and optionally nurture toward paid guide or proposal workflow.",
        _subject: `${t.leadMagnet.subject} (${lang.toUpperCase()})`,
        _template: "table",
        _captcha: "false"
      })
    }).catch(() => {}).finally(() => setSampleReady(true));
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "resources",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      gap: "44px 72px",
      alignItems: "end",
      marginBottom: 44
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 18px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.75,
      margin: 0
    }
  }, t.sub)), /*#__PURE__*/React.createElement("div", {
    "data-resource-boundary": "true",
    style: {
      background: "#131417",
      padding: "24px 28px",
      borderTop: `3px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 12
    }
  }, lang === "en" ? "Where the line is" : "Donde está la línea"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.7)",
      lineHeight: 1.7,
      margin: "0 0 16px"
    }
  }, t.boundary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, (lang === "en" ? ["Free archive", "Chapter 1 guide", "Field-guide roadmap", "PE project review"] : ["Archivo gratis", "Guía Capítulo 1", "Ruta de guías", "Revisión PE"]).map(label => /*#__PURE__*/React.createElement("span", {
    key: label,
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "rgba(240,237,232,0.55)",
      padding: "4px 9px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: 2
    }
  }, label))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
      gap: 2,
      marginBottom: 34
    }
  }, t.stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "16px 20px",
      background: "#131417",
      borderTop: `2px solid ${i === 0 ? accent : "rgba(255,255,255,0.07)"}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 28,
      color: i === 0 ? accent : "#F0EDE8",
      marginBottom: 8
    }
  }, s.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 12,
      color: "#F0EDE8",
      textTransform: "uppercase",
      letterSpacing: "0.04em",
      marginBottom: 8
    }
  }, s.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.45)",
      lineHeight: 1.55,
      margin: 0
    }
  }, s.desc)))), /*#__PURE__*/React.createElement("div", {
    "data-lead-magnet": "permit-readiness-sample",
    style: {
      background: "rgba(196,120,58,0.08)",
      borderTop: `3px solid ${accent}`,
      padding: "24px 28px",
      marginBottom: 34,
      display: "grid",
      gridTemplateColumns: "1.2fr 1fr",
      gap: "20px 28px",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 8
    }
  }, t.leadMagnet.eyebrow), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 22,
      color: "#F0EDE8",
      lineHeight: 1.2,
      margin: "0 0 10px"
    }
  }, t.leadMagnet.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.58)",
      lineHeight: 1.65,
      margin: 0
    }
  }, t.leadMagnet.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, sampleReady ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent,
      lineHeight: 1.45
    }
  }, t.leadMagnet.success), /*#__PURE__*/React.createElement("a", {
    href: RESOURCE_LEAD_MAGNET_SAMPLE_CHECKLIST_PDF,
    download: true,
    onClick: () => window.trackMBEvent && window.trackMBEvent("Resource Lead Magnet Download", {
      asset: "Permit Readiness Sample Checklist",
      href: RESOURCE_LEAD_MAGNET_SAMPLE_CHECKLIST_PDF,
      language: lang,
      source: "resource-library-lead-magnet"
    }),
    "data-analytics": "lead-magnet-download",
    style: {
      width: "100%",
      display: "inline-flex",
      justifyContent: "center",
      padding: "11px 14px",
      background: accent,
      color: "#0B0C0E",
      textDecoration: "none",
      borderRadius: 2,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, t.leadMagnet.download)) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("input", {
    value: sampleEmail,
    onChange: e => setSampleEmail(e.target.value),
    onKeyDown: e => e.key === "Enter" && handleSampleDownload(),
    type: "email",
    placeholder: t.emailPlaceholder,
    style: {
      width: "100%",
      padding: "10px 12px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.1)",
      color: "#F0EDE8",
      borderRadius: 2,
      outline: "none",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13
    },
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: handleSampleDownload,
    "data-analytics": "lead-magnet-submit",
    style: {
      width: "100%",
      padding: "11px 14px",
      background: accent,
      color: "#0B0C0E",
      border: "none",
      borderRadius: 2,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, t.leadMagnet.cta)))), t.ascension && /*#__PURE__*/React.createElement("div", {
    style: { marginBottom: 28 }
  }, /*#__PURE__*/React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: "rgba(240,237,232,0.4)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 12 }
  }, t.ascensionLabel), /*#__PURE__*/React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 2 }
  }, t.ascension.map((s, i) => /*#__PURE__*/React.createElement("a", {
    key: i, href: s.href,
    target: s.href.startsWith("http") ? "_blank" : "_self",
    rel: s.href.startsWith("http") ? "noopener noreferrer" : undefined,
    style: { display: "block", padding: "16px 18px", background: i === t.ascension.length - 1 ? "rgba(196,120,58,0.08)" : "#131417", borderTop: i === t.ascension.length - 1 ? "2px solid #C4783A" : "2px solid rgba(255,255,255,0.07)", textDecoration: "none", transition: "background 0.2s" },
    onMouseEnter: e => e.currentTarget.style.background = "#1C1E23",
    onMouseLeave: e => e.currentTarget.style.background = i === t.ascension.length - 1 ? "rgba(196,120,58,0.08)" : "#131417"
  }, /*#__PURE__*/React.createElement("div", {
    style: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }
  }, /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: "rgba(240,237,232,0.3)", letterSpacing: "0.1em" }
  }, s.step), /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: i === t.ascension.length - 1 ? "#C4783A" : "#7CB87A", fontWeight: 600 }
  }, s.price)), /*#__PURE__*/React.createElement("div", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, fontSize: 14, color: "#F0EDE8", marginBottom: 6 }
  }, s.label), /*#__PURE__*/React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.45)", lineHeight: 1.5, margin: 0 }
  }, s.desc))))), /*#__PURE__*/React.createElement("div", {
    "data-resource-products": "true",
    style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 2, marginBottom: 34 }
  }, t.products.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "#131417",
      padding: "22px 24px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: 12,
      alignItems: "flex-start",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.08em",
      textTransform: "uppercase"
    }
  }, p.tag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "#7CB87A",
      whiteSpace: "nowrap"
    }
  }, p.price)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 18,
      color: "#F0EDE8",
      margin: "0 0 12px",
      lineHeight: 1.25
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.52)",
      lineHeight: 1.65,
      margin: "0 0 18px"
    }
  }, p.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.35)",
      lineHeight: 1.5
    }
  }, p.audience), p.samplePreview && p.samplePdf && /*#__PURE__*/React.createElement("a", {
    href: p.samplePdf,
    download: true,
    onClick: () => trackResourceProductEvent("Resource Sample Preview Click", p, "resource-card-thumbnail", {
      samplePdf: p.samplePdf,
      previewImage: p.samplePreview
    }),
    "data-resource-preview": p.id,
    "aria-label": `${p.sampleLabel || p.title} preview`,
    style: {
      display: "block",
      width: "100%",
      border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 4,
      overflow: "hidden",
      background: "#F4EFE7",
      textDecoration: "none",
      boxShadow: "0 14px 40px rgba(0,0,0,0.22)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: p.samplePreview,
    alt: `${p.title} sample PDF preview`,
    loading: "eager",
    decoding: "async",
    style: {
      display: "block",
      width: "100%",
      objectFit: "cover",
      objectPosition: "top center",
      background: "#F4EFE7",
      aspectRatio: "5 / 2"
    }
  })), p.samplePdf && /*#__PURE__*/React.createElement("a", {
    href: p.samplePdf,
    download: true,
    onClick: () => trackResourceProductEvent("Resource Sample Download", p, "resource-card-sample-link", {
      samplePdf: p.samplePdf,
      sampleLabel: p.sampleLabel || ""
    }),
    "data-analytics": "resource-sample-download",
    "data-product": p.id,
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      textDecoration: "none",
      letterSpacing: "0.04em",
      borderBottom: "1px dashed rgba(196,120,58,0.4)",
      paddingBottom: 2,
      alignSelf: "flex-start"
    },
    onMouseEnter: e => e.currentTarget.style.borderBottomColor = accent,
    onMouseLeave: e => e.currentTarget.style.borderBottomColor = "rgba(196,120,58,0.4)"
  }, "\u2193 ", p.sampleLabel || (lang === "en" ? "Free sample (PDF)" : "Muestra gratis (PDF)")), p.freePdf ? /*#__PURE__*/React.createElement("a", {
    href: p.freePdf,
    download: true,
    onClick: () => trackResourceProductEvent("Resource Free Guide Download", p, "resource-card-free-download", {
      freePdf: p.freePdf,
      freeCta: p.freeCta || ""
    }),
    "data-analytics": "resource-free-download",
    "data-product": p.id,
    style: {
      width: "100%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "10px 14px",
      background: accent,
      color: "#0B0C0E",
      textDecoration: "none",
      borderRadius: 2,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, p.freeCta || (lang === "en" ? "Download free guide" : "Descargar guía gratis")) : RESOURCE_PAYMENT_LINKS[p.id] && !RESOURCE_COMING_SOON_PRODUCT_IDS.has(p.id) ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("a", {
    href: RESOURCE_PAYMENT_LINKS[p.id],
    target: "_blank",
    rel: "noopener noreferrer",
    onClick: () => trackResourceProductEvent("Resource Buy Button Click", p, "resource-card-buy-link", {
      href: RESOURCE_PAYMENT_LINKS[p.id] || ""
    }),
    "data-analytics": "resource-buy-click",
    "data-product": p.id,
    style: {
      width: "100%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "10px 14px",
      background: accent,
      color: "#0B0C0E",
      textDecoration: "none",
      borderRadius: 2,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, p.cta || t.buyCta), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      color: "rgba(240,237,232,0.34)",
      lineHeight: 1.4
    }
  }, t.paymentNote)) : notifiedProducts[p.id] ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: accent,
      lineHeight: 1.45
    }
  }, t.notifySuccess) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: (productContacts[p.id] && productContacts[p.id].name) || "",
    onChange: e => setProductContactField(p.id, "name", e.target.value),
    type: "text",
    required: true,
    autoComplete: "name",
    placeholder: lang === "en" ? "Your name" : "Su nombre",
    "aria-label": `${p.title} ${lang === "en" ? "your name" : "su nombre"}`,
    style: productContactInputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("input", {
    value: (productContacts[p.id] && productContacts[p.id].email) || "",
    onChange: e => setProductContactField(p.id, "email", e.target.value),
    type: "email",
    required: true,
    autoComplete: "email",
    placeholder: t.emailPlaceholder,
    "aria-label": `${p.title} ${t.emailPlaceholder}`,
    style: productContactInputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("input", {
    value: (productContacts[p.id] && productContacts[p.id].phone) || "",
    onChange: e => setProductContactField(p.id, "phone", e.target.value),
    type: "tel",
    required: true,
    autoComplete: "tel",
    placeholder: lang === "en" ? "Phone number" : "Teléfono",
    "aria-label": `${p.title} ${lang === "en" ? "phone number" : "teléfono"}`,
    style: productContactInputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => handleProductNotify(p),
    "data-analytics": "resource-notify-click",
    "data-product": p.id,
    style: {
      width: "100%",
      padding: "10px 14px",
      background: RESOURCE_COMING_SOON_PRODUCT_IDS.has(p.id) ? "transparent" : accent,
      color: RESOURCE_COMING_SOON_PRODUCT_IDS.has(p.id) ? accent : "#0B0C0E",
      border: RESOURCE_COMING_SOON_PRODUCT_IDS.has(p.id) ? `1px solid ${accent}` : "none",
      borderRadius: 2,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, RESOURCE_COMING_SOON_PRODUCT_IDS.has(p.id) ? t.notifyCta : t.requestLinkCta), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      color: "rgba(240,237,232,0.46)",
      lineHeight: 1.45
    }
  }, lang === "en" ? "Used only for the requested resource follow-up." : "Solo se usa para dar seguimiento al recurso solicitado.")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
      gap: 2,
      alignItems: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#131417",
      padding: "20px 24px",
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, joined ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent,
      fontWeight: 600
    }
  }, "✓ ", t.newsletterSuccess)) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, t.newsletterEyebrow), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.55)",
      margin: 0,
      lineHeight: 1.5
    }
  }, t.newsletterDesc), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: email,
    onChange: e => setEmail(e.target.value),
    type: "email",
    placeholder: lang === "en" ? "email@example.com" : "correo@ejemplo.com",
    style: {
      flex: 1,
      minWidth: 220,
      padding: "9px 12px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.1)",
      color: "#F0EDE8",
      borderRadius: 2,
      outline: "none",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13
    },
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: handleNewsletterSubscribe,
    style: {
      padding: "9px 18px",
      background: accent,
      color: "#0B0C0E",
      border: "none",
      borderRadius: 2,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      whiteSpace: "nowrap"
    }
  }, t.newsletterCta)), /*#__PURE__*/React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 10, color: subscribeError ? "#E5A5A5" : "rgba(240,237,232,0.36)", margin: 0, lineHeight: 1.4 }
  }, subscribeError || (lang === "en" ? "Free email list. Unsubscribe anytime. We do not sell subscriber data." : "Lista gratuita. Puede cancelar cuando quiera. No vendemos datos de suscriptores.")))), /*#__PURE__*/React.createElement("a", {
    href: "/daily-code-talk/",
    style: {
      background: "#131417",
      padding: "18px 24px",
      color: accent,
      textDecoration: "none",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      whiteSpace: "nowrap"
    }
  }, t.secondary, " ->"))));
}
function MBAuthority({
  lang,
  tweaks
}) {
  const t = SECTIONS_CONTENT[lang].authority;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 56px"
    }
  }, t.headline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 2
    }
  }, t.items.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "36px 32px",
      background: "#131417"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(22px, 3vw, 34px)",
      color: accent,
      marginBottom: 8,
      letterSpacing: "-0.01em"
    }
  }, item.stat), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 13,
      color: "#F0EDE8",
      marginBottom: 10,
      textTransform: "uppercase",
      letterSpacing: "0.04em"
    }
  }, item.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.6
    }
  }, item.desc))))));
}

// ─── MBLeadMagnet ────────────────────────────────────────────────────────────
// Free PDF sample ladder - "Start here" section for lead generation
// Placed after MBDifferentiators, before MBCompareStrip
// PDF files + preview images are in /uploads/ on the server
const LEAD_MAGNET_CONTENT = {
  en: {
    eyebrow: "/ Start here · free",
    heading: "Three working samples.",
    subhead: "Skim them in 5 minutes.",
    intro: "Before you talk to anyone - these are the actual artifacts Masterbuild builds against. Same logic, same proof chain, same review-day discipline. Use them to size up the fit.",
    cards: [
      {
        tag: "01 · Permit Readiness",
        title: "Permit Readiness Sample",
        desc: "Cross-discipline pressure test, issue ownership, closure evidence, and a ready / exception / hold upload decision.",
        img: "/uploads/permit-readiness-sample-preview.png",
        imgAlt: "Permit Readiness cross-discipline sample preview",
        pdf: "/uploads/permit-readiness-sample-checklist.pdf",
        linkText: "Download PDF"
      },
      {
        tag: "02 · Owner-Side Review",
        title: "Owner-Side MEP Review Card",
        desc: "Plain-English questions for change orders, inspections, field changes, and risk decisions. Built for owners not steeped in MEP.",
        img: "/uploads/owner-side-review-card-sample-preview.png",
        imgAlt: "Owner-Side MEP Review Card sample preview",
        pdf: "/uploads/owner-side-review-card-sample.pdf",
        linkText: "Download PDF"
      },
      {
        tag: "03 · Ventilation Math",
        title: "OA-Math Sample Worksheet",
        desc: "Outdoor-air inputs, calculation path, and drawing tie-in for IMC 403 review. The math reviewers actually check for.",
        img: "/uploads/ventilation-oa-math-sample-preview.png",
        imgAlt: "OA-Math Sample Worksheet preview",
        pdf: "/uploads/ventilation-oa-math-sample.pdf",
        linkText: "Download PDF"
      }
    ],
    unlock: {
      heading: "Need one of these checks applied to a live project?",
      sub: "Send your contact information. Masterbuild will qualify the project, deadline, drawings, and decision needed before proposing a review scope.",
      namePlaceholder: "Your name",
      emailPlaceholder: "email@example.com",
      phonePlaceholder: "Phone number",
      placeholder: "email@example.com",
      cta: "Request project review"
    }
  },
  es: {
    eyebrow: "/ Empieza aquí · gratis",
    heading: "Tres ejemplos reales.",
    subhead: "En 5 minutos.",
    intro: "Antes de hablar con cualquier ingeniero - estos son los mismos artefactos que Masterbuild produce en proyectos reales. Misma lógica, misma cadena de demostración, misma disciplina de revisión. Úsalos para evaluar si hay afinidad.",
    cards: [
      {
        tag: "01 · Permiso",
        title: "Muestra Permit Readiness",
        desc: "Prueba multidisciplinaria, responsables, evidencia de cierre y decisión de carga: listo, excepción o en espera.",
        img: "/uploads/permit-readiness-sample-preview.png",
        imgAlt: "Vista previa multidisciplinaria Permit Readiness",
        pdf: "/uploads/permit-readiness-sample-checklist.pdf",
        linkText: "Descargar PDF"
      },
      {
        tag: "02 · Revisión del Dueño",
        title: "Tarjeta de revisión MEP del lado del dueño",
        desc: "Preguntas en lenguaje sencillo para órdenes de cambio, inspecciones, cambios de campo y decisiones de riesgo. Diseñada para dueños sin experiencia profunda en MEP.",
        img: "/uploads/owner-side-review-card-sample-preview.png",
        imgAlt: "Vista previa de tarjeta de revisión del lado del dueño",
        pdf: "/uploads/owner-side-review-card-sample.pdf",
        linkText: "Descargar PDF"
      },
      {
        tag: "03 · Ventilación",
        title: "Hoja de cálculo OA-Math",
        desc: "Entradas de aire exterior, ruta de cálculo y conexión con planos para revisión IMC 403. La matemática que los revisores realmente verifican.",
        img: "/uploads/ventilation-oa-math-sample-preview.png",
        imgAlt: "Vista previa de hoja de cálculo OA-Math",
        pdf: "/uploads/ventilation-oa-math-sample.pdf",
        linkText: "Descargar PDF"
      }
    ],
    unlock: {
      heading: "¿Necesita aplicar una de estas revisiones a un proyecto real?",
      sub: "Envíe su contacto. Masterbuild calificará el proyecto, fecha, planos y decisión necesaria antes de proponer un alcance de revisión.",
      namePlaceholder: "Su nombre",
      emailPlaceholder: "correo@ejemplo.com",
      phonePlaceholder: "Teléfono",
      placeholder: "correo@ejemplo.com",
      cta: "Solicitar revisión"
    }
  }
};

function MBLeadMagnet({ lang = "en", tweaks = {} }) {
  const accent = tweaks.accentColor || "#C4783A";
  const accentSoft = "rgba(196,120,58,0.09)";
  const accentLine = "rgba(196,120,58,0.26)";
  const c = LEAD_MAGNET_CONTENT[lang] || LEAD_MAGNET_CONTENT.en;
  const t = React.createElement;

  // Higher-intent project-review requests capture enough information for qualification.
  const [leadContact, setLeadContact] = React.useState({
    name: "",
    email: "",
    phone: ""
  });
  const [submitted, setSubmitted] = React.useState(false);
  const handleSubmit = (e) => {
    e.preventDefault();
    const name = leadContact.name.trim();
    const email = leadContact.email.trim();
    const phone = leadContact.phone.trim();
    if (!name || !email || !phone) return;
    fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        lead_type: "Project review interest",
        lead_intent: "Apply a permit, owner-side, or ventilation review check to a live project",
        follow_up_priority: "High",
        name,
        email,
        phone,
        source: "Homepage technical sample project-review request",
        submission_route: window.location.pathname || "/",
        asset: "Technical sample review applied to a live project",
        language: lang,
        next_action: "Qualify project type, jurisdiction, deadline, available drawings, decision needed, and written scope fit.",
        _subject: `Masterbuild Project Review Interest (${lang.toUpperCase()})`,
        _template: "table",
        _captcha: "false"
      })
    }).catch(() => {}).finally(() => {
      setSubmitted(true);
      if (typeof trackMBEvent === "function") trackMBEvent("Project Review Interest Submit", {
        lang,
        source: "homepage-lead-magnet-strip",
        hasName: true,
        hasEmail: true,
        hasPhone: true
      });
    });
  };
  const leadInputStyle = {
    flex: "1 1 155px",
    minWidth: 150,
    background: "#0B0C0E",
    border: "1px solid rgba(255,255,255,0.12)",
    color: "#F0EDE8",
    padding: "11px 14px",
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: 13,
    outline: "none",
    borderRadius: 2
  };

  const cardStyle = {
    background: "#131417",
    border: "1px solid rgba(255,255,255,0.07)",
    display: "flex",
    flexDirection: "column",
    transition: "border-color 0.2s, transform 0.2s",
    cursor: "default"
  };

  return t("section", {
    id: "leadmag",
    style: {
      background: "#0B0C0E",
      borderTop: "1px solid rgba(255,255,255,0.07)",
      padding: "52px 0"
    }
  },
    t("div", { style: { maxWidth: 1180, margin: "0 auto", padding: "0 40px" } },
      // Header
      t("div", { style: { marginBottom: 44 } },
        t("div", {
          style: {
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            color: accent,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            marginBottom: 14
          }
        }, c.eyebrow),
        t("h2", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 800,
            fontSize: "clamp(28px, 3.6vw, 46px)",
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
            marginBottom: 6,
            color: "#F0EDE8"
          }
        }, c.heading + " " + c.subhead),
        t("p", {
          style: {
            color: "rgba(240,237,232,0.62)",
            fontSize: 16,
            lineHeight: 1.65,
            maxWidth: 680,
            marginTop: 14
          }
        }, c.intro)
      ),

      // Cards grid
      t("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 18,
          marginBottom: 28
        }
      },
        ...c.cards.map((card, idx) =>
          t("article", {
            key: idx,
            style: cardStyle,
            onMouseEnter: (e) => {
              e.currentTarget.style.borderColor = accentLine;
              e.currentTarget.style.transform = "translateY(-2px)";
            },
            onMouseLeave: (e) => {
              e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)";
              e.currentTarget.style.transform = "translateY(0)";
            }
          },
            // Preview image
            t("div", {
              style: {
                aspectRatio: "4/3",
                background: "#F4F1EA",
                overflow: "hidden",
                borderBottom: "1px solid rgba(255,255,255,0.07)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
              }
            },
              t("img", {
                src: card.img,
                alt: card.imgAlt,
                style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: "top" },
                loading: "lazy",
                onError: (e) => { e.target.style.display = "none"; }
              })
            ),
            // Body
            t("div", {
              style: { padding: "22px 22px 24px", flex: 1, display: "flex", flexDirection: "column" }
            },
              t("div", {
                style: {
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontSize: 10,
                  color: accent,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  marginBottom: 10
                }
              }, card.tag),
              t("h3", {
                style: {
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  fontWeight: 700,
                  fontSize: 18,
                  marginBottom: 10,
                  lineHeight: 1.2,
                  color: "#F0EDE8"
                }
              }, card.title),
              t("p", {
                style: {
                  fontSize: 13,
                  color: "rgba(240,237,232,0.65)",
                  lineHeight: 1.58,
                  marginBottom: 18,
                  flex: 1
                }
              }, card.desc),
              t("a", {
                href: card.pdf,
                target: "_blank",
                rel: "noopener noreferrer",
                style: {
                  fontSize: 12,
                  color: accent,
                  fontWeight: 600,
                  fontFamily: "'IBM Plex Mono', monospace",
                  letterSpacing: "0.04em",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  textDecoration: "none"
                },
                onClick: () => {
                  if (typeof trackMBEvent === "function") trackMBEvent("Lead Magnet PDF Download", { doc: card.tag, lang });
                }
              }, card.linkText + " →")
            )
          )
        )
      ),

      // Guide pack interest capture strip
      t("div", {
        style: {
          background: "#131417",
          border: "1px solid rgba(255,255,255,0.07)",
          borderLeft: "3px solid " + accent,
          padding: "22px 28px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 24,
          flexWrap: "wrap"
        }
      },
        t("div", { style: { flex: "1 1 320px" } },
          t("h3", {
            style: {
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontWeight: 700,
              fontSize: 18,
              marginBottom: 4,
              color: "#F0EDE8"
            }
          }, c.unlock.heading),
          t("p", {
            style: { fontSize: 13, color: "rgba(240,237,232,0.6)", margin: 0 }
          }, c.unlock.sub)
        ),
        submitted
          ? t("div", {
              style: {
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 13,
                color: "#6F8F5C",
                letterSpacing: "0.04em"
              }
            }, "\u2713 " + (lang === "es" ? "Solicitud recibida" : "Request received"))
          : t("form", {
              onSubmit: handleSubmit,
              style: { display: "flex", gap: 8, minWidth: 300, flex: "1 1 560px", flexWrap: "wrap" }
            },
              t("input", {
                type: "text",
                required: true,
                autoComplete: "name",
                placeholder: c.unlock.namePlaceholder,
                value: leadContact.name,
                onChange: (e) => setLeadContact(prev => ({ ...prev, name: e.target.value })),
                style: leadInputStyle
              }),
              t("input", {
                type: "email",
                required: true,
                autoComplete: "email",
                placeholder: c.unlock.emailPlaceholder || c.unlock.placeholder,
                value: leadContact.email,
                onChange: (e) => setLeadContact(prev => ({ ...prev, email: e.target.value })),
                style: leadInputStyle
              }),
              t("input", {
                type: "tel",
                required: true,
                autoComplete: "tel",
                placeholder: c.unlock.phonePlaceholder,
                value: leadContact.phone,
                onChange: (e) => setLeadContact(prev => ({ ...prev, phone: e.target.value })),
                style: leadInputStyle
              }),
              t("button", {
                type: "submit",
                style: {
                  background: accent,
                  color: "#0B0C0E",
                  border: "none",
                  padding: "11px 18px",
                  fontFamily: "'IBM Plex Sans', sans-serif",
                  fontWeight: 700,
                  fontSize: 13,
                  cursor: "pointer",
                  borderRadius: 2,
                  whiteSpace: "nowrap"
                }
              }, c.unlock.cta)
            )
      )
    )
  );
}

// ─── MBTestimonials ───────────────────────────────────────────────────────────
// Social proof section - 1 confirmed quote + 2 reserved slots
// Placed after MBAbout, before MBFeeProcess
const TESTIMONIALS_CONTENT = {
  en: {
    eyebrow: "/ In their words",
    heading: "Working relationships, on the record.",
    intro: "Quotes from partners and clients. Where a name is held back, the relationship is confirmable on request.",
    quotes: [
      {
        text: "Osmany flagged a ventilation gap in our feasibility report before we put it in front of the owner. Saved a hard conversation later.",
        by: "Partner",
        role: "Existing-building feasibility",
        confirmed: true
      },
      {
        text: null,
        by: "Pending",
        role: "Multifamily permit set",
        confirmed: false,
        placeholder: "Reserved for first published client testimonial."
      },
      {
        text: null,
        by: "Pending",
        role: "Commercial TI",
        confirmed: false,
        placeholder: "Reserved for first published client testimonial."
      }
    ]
  },
  es: {
    eyebrow: "/ En sus palabras",
    heading: "Relaciones de trabajo, documentadas.",
    intro: "Citas de socios y clientes. Donde se omite el nombre, la relación es confirmable a solicitud.",
    quotes: [
      {
        text: "Osmany identificó una deficiencia de ventilación en nuestro informe de factibilidad antes de presentarlo al dueño. Evitó una conversación difícil después.",
        by: "Socio",
        role: "Factibilidad de edificios existentes",
        confirmed: true
      },
      {
        text: null,
        by: "Pendiente",
        role: "Permiso multifamiliar",
        confirmed: false,
        placeholder: "Reservado para primer testimonio de cliente publicado."
      },
      {
        text: null,
        by: "Pendiente",
        role: "Mejora comercial de inquilino",
        confirmed: false,
        placeholder: "Reservado para primer testimonio de cliente publicado."
      }
    ]
  }
};

function MBTestimonials({ lang = "en", tweaks = {} }) {
  const accent = tweaks.accentColor || "#C4783A";
  const c = TESTIMONIALS_CONTENT[lang] || TESTIMONIALS_CONTENT.en;
  const t = React.createElement;

  return t("section", {
    style: {
      background: "#0B0C0E",
      borderTop: "1px solid rgba(255,255,255,0.07)",
      padding: "52px 0"
    }
  },
    t("div", { style: { maxWidth: 1180, margin: "0 auto", padding: "0 40px" } },
      // Header
      t("div", { style: { marginBottom: 44 } },
        t("div", {
          style: {
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            color: accent,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            marginBottom: 14
          }
        }, c.eyebrow),
        t("h2", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 800,
            fontSize: "clamp(28px, 3.6vw, 46px)",
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
            marginBottom: 6,
            color: "#F0EDE8"
          }
        }, c.heading),
        t("p", {
          style: {
            color: "rgba(240,237,232,0.62)",
            fontSize: 15,
            lineHeight: 1.65,
            maxWidth: 640,
            marginTop: 14
          }
        }, c.intro)
      ),

      // Quotes grid
      t("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 420px))",
          gap: 18
        }
      },
        ...c.quotes.filter(q => q.confirmed).map((q, idx) =>
          t("blockquote", {
            key: idx,
            style: {
              background: "#131417",
              border: "1px solid rgba(255,255,255,0.07)",
              borderTop: "2px solid " + (q.confirmed ? accent : "rgba(255,255,255,0.12)"),
              padding: "28px 28px",
              margin: 0,
              opacity: q.confirmed ? 1 : 0.55
            }
          },
            t("div", {
              style: {
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontWeight: 800,
                fontSize: 48,
                color: q.confirmed ? accent : "rgba(240,237,232,0.3)",
                lineHeight: 0.8,
                marginBottom: 14
              }
            }, "“"),
            q.confirmed
              ? t("p", {
                  style: {
                    fontSize: 15,
                    lineHeight: 1.58,
                    color: "#F0EDE8",
                    marginBottom: 20,
                    fontStyle: "italic"
                  }
                }, q.text)
              : t("p", {
                  style: {
                    fontSize: 13,
                    lineHeight: 1.58,
                    color: "rgba(240,237,232,0.4)",
                    marginBottom: 20,
                    fontStyle: "italic"
                  }
                }, q.placeholder),
            t("div", {
              style: {
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 12,
                color: "rgba(240,237,232,0.45)"
              }
            },
              t("strong", {
                style: { color: q.confirmed ? "#F0EDE8" : "rgba(240,237,232,0.4)", fontWeight: 600, fontStyle: "normal" }
              }, q.by),
              " - " + q.role
            )
          )
        )
      )
    )
  );
}

const KNOWLEDGE_HUBS = {
  en: {
    eyebrow: "/ Field knowledge",
    headline: "Code, drawn the way a permit set is reviewed.",
    sub: "Hubs built from Daily Code Talk and the jobs that actually stall in Miami-Dade. Start free. Send the set when the decision is live.",
    items: [
      { title: "Ventilation & outdoor air", desc: "IMC Chapter 4 method, intakes, and the estimator.", href: "/ventilation/" },
      { title: "Kitchen exhaust", desc: "Type I / Type II, grease duct, makeup air.", href: "/commercial-kitchen-ventilation/" },
      { title: "Tenant improvements", desc: "Office, retail, and restaurant TIs on existing systems.", href: "/tenant-improvement-mep-miami/" },
      { title: "Permit comments", desc: "Send the letter. Get a written resubmittal path.", href: "/permit-comment-response/" },
      { title: "Healthcare ventilation", desc: "ASHRAE 170 / IMC 407 — not Table 403 with nicer diffusers.", href: "/healthcare-ventilation/" },
      { title: "Garage ventilation", desc: "IMC 404, CO control, podium garages.", href: "/parking-garage-ventilation/" },
      { title: "117 free field tools", desc: "Decision screens in 13 groups — no login, no email. Each names the document that governs and hands back a record.", href: "/field-tools/" },
      { title: "Miami-Dade permits", desc: "Checklists, septic, wells, recertification.", href: "/miami-dade-permit-resources/" },
      { title: "FBC vs IMC", desc: "8th Edition in force; 9th Edition scheduled Dec 31, 2026.", href: "/florida-building-code/" },
      { title: "Typical comments", desc: "What the drawings usually need to show.", href: "/typical-plan-review-comments/" },
      { title: "Plumbing", desc: "Isometrics, grease, septic/well path.", href: "/plumbing/" },
      { title: "Start here", desc: "Route the actual problem to the right intake.", href: "/start/" },
      { title: "From the PE", desc: "HVAC vs construction, IMC Ch. 1, plumbing VE.", href: "/from-the-pe/" },
      { title: "Hood + interceptor", desc: "Type I and grease waste are one job.", href: "/kitchen-plumbing-coordination/" },
      { title: "Makeup air (IMC 508)", desc: "Replacement air is part of the hood.", href: "/makeup-air/" },
      { title: "Change of occupancy", desc: "New use rewrites OA, exhaust, plumbing.", href: "/change-of-occupancy-mep/" },
      { title: "Condensate (IMC 307)", desc: "If the primary drain stops, where does the water go?", href: "/condensate/" },
      { title: "Equipment access (IMC 306)", desc: "30×30 drawn. Roof hatch on the roof plan.", href: "/equipment-access/" },
      { title: "Exhaust discharge (IMC 501.3)", desc: "Outdoors, not into the attic or the OA intake.", href: "/exhaust-discharge/" },
      { title: "Dryer exhaust (IMC 504)", desc: "No screens, no screws, no fire damper.", href: "/dryer-exhaust/" },
      { title: "Commercial / multistory dryer (IMC 504.10–504.11)", desc: "A damper in the common dryer shaft is not 504.11.", href: "/commercial-dryer-exhaust/" },
      { title: "Dry-cleaning exhaust (IMC 502.6)", desc: "A ceiling fan over a Type II plant is not 502.6.", href: "/dry-cleaning-exhaust/" },
      { title: "Tire-buffing exhaust (IMC 502.17)", desc: "A ceiling fan over a buffer is not 502.17.", href: "/tire-buffing-exhaust/" },
      { title: "Firing-range exhaust (IMC 502.18–502.19)", desc: "A restroom fan over the firing line is not 502.19.", href: "/firing-range-exhaust/" },
      { title: "Aircraft fueling exhaust (IMC 502.2)", desc: "A high grille over the hose reels is not 502.2.", href: "/aircraft-fueling-exhaust/" },
      { title: "Garage-pit exhaust (IMC 502.13–502.15)", desc: "A CO sensor on the parking floor is not the pit.", href: "/garage-pit-exhaust/" },
      { title: "Dip / powder exhaust (IMC 502.7.7)", desc: "A warehouse fan over a dip tank is not 502.7.", href: "/dip-powder-exhaust/" },
      { title: "Floor-resurfacing exhaust (IMC 502.7)", desc: "A box fan at the roll-up is not 502.7.", href: "/floor-resurfacing-exhaust/" },
      { title: "Garage appliance mounting (IMC 304.6–304.7)", desc: "A water heater on the garage slab is not 304.6.", href: "/garage-appliance-mounting/" },
      { title: "Roof-edge guards (IMC 304.11)", desc: "A parapet you never measured is not 304.11.", href: "/roof-edge-guards/" },
      { title: "Miami-Dade permit portals", desc: "The County home page is every department. This is the MEP door.", href: "/miami-dade-permit-portals/" },
      { title: "Miami-Dade mechanical review", desc: "The County guideline is a list of titles. The comment is specific.", href: "/miami-dade-mechanical-review/" },
      { title: "Miami-Dade field packets", desc: "Three free PE PDFs — pre-upload, inspection day, Approved as Noted.", href: "/miami-dade-field-packets/" },
      { title: "Pre-submittal checklist", desc: "Print it. Unchecked boxes are the comment letter.", href: "/pre-submittal/" },
      { title: "Factory-built chimneys (IMC 805)", desc: "Listed system, not a diameter.", href: "/factory-built-chimneys/" },
      { title: "Metal chimneys (IMC 806)", desc: "NFPA 211 is the path. Draw it.", href: "/metal-chimneys/" },
      { title: "Continuous load vs demand", desc: "3 hours or more. Nameplates are not demand.", href: "/continuous-load/" },
      { title: "Installation (IMC 304)", desc: "18 in in garages or FVIR. MI on site.", href: "/equipment-installation/" },
      { title: "Piping support (IMC 305)", desc: "Table 305.4 by material. Not gypsum.", href: "/piping-support/" },
      { title: "Transfer air (IMC 501.4)", desc: "Exhaust-only rooms need a makeup path.", href: "/transfer-air/" },
      { title: "Uninhabited spaces (IMC 406)", desc: "Attic/crawl: openings or 0.02 cfm/ft² + RH.", href: "/uninhabited-spaces/" },
      { title: "Fire/smoke dampers (IMC 607)", desc: "Name the assembly. Then pick the damper.", href: "/fire-smoke-dampers/" },
      { title: "Domestic vs commercial cooking", desc: "505 vs 507. 400 cfm makeup air.", href: "/domestic-cooking/" },
      { title: "Permit comment worksheet", desc: "Print it with the letter. Answer on the drawings.", href: "/permit-comment-worksheet/" },
      { title: "ASHRAE 170 rooms (IMC 407)", desc: "Map the room. Then pick the ACH.", href: "/ashrae-170-rooms/" },
      { title: "Miami-Dade vs Broward", desc: "One code. Two counties. Name the AHJ.", href: "/miami-dade-vs-broward/" },
      { title: "Ventilation controls (IMC 405)", desc: "Occupied means OA is on.", href: "/ventilation-controls/" },
      { title: "Clearance reduction (IMC 308)", desc: "Listing first. 1 inch minimum.", href: "/clearance-reduction/" },
      { title: "Occupancy heating (IMC 309)", desc: "68°F at 3 feet. Not a space heater.", href: "/occupancy-heating/" },
      { title: "Required exhaust (IMC 502)", desc: "Process/hazmat beyond Table 403.", href: "/required-exhaust/" },
      { title: "Explosion control (IMC 310)", desc: "IFC 911 — not an HVAC note.", href: "/explosion-control/" },
      { title: "Smoke/heat vents (IMC 311)", desc: "IFC trigger. RTUs can block them.", href: "/smoke-heat-vents/" },
      { title: "Hazardous exhaust (IMC 509)", desc: "Not general exhaust. Direct outdoors.", href: "/hazardous-exhaust/" },
      { title: "Smoke control (IMC 512)", desc: "If openings changed, the analysis is stale.", href: "/smoke-control/" },
      { title: "Dust conveying (IMC 510)", desc: "Dust collection is a fire-code system.", href: "/dust-conveying/" },
      { title: "Energy recovery (IMC 513)", desc: "Name the airstream before you recover it.", href: "/energy-recovery/" },
      { title: "Plenums (IMC 602)", desc: "If it is a plenum, list what is in it.", href: "/plenums/" },
      { title: "Duct insulation (IMC 604)", desc: "One R-value is not a spec. 24 in at the coil.", href: "/duct-insulation/" },
      { title: "Duct smoke detection (IMC 606)", desc: "Over 2,000 cfm, the return needs a detector.", href: "/duct-smoke-detection/" },
      { title: "Duct construction (IMC 603)", desc: "Flex through a wall is not a connector.", href: "/duct-construction/" },
      { title: "Air balancing (IMC 608)", desc: "Scheduled CFM is not installed performance.", href: "/air-balancing/" },
      { title: "Calculation support", desc: "Loads, ESP, pipe, 8760 HRC. Not a spreadsheet download.", href: "/calculation-support/" },
      { title: "Natural ventilation (IMC 402)", desc: "Windows are not ventilation until the 4% is on the sheet.", href: "/natural-ventilation/" },
      { title: "Listed vents (IMC 802)", desc: "Diameter is not a listing. 2 ft / 10 ft / 12 in door.", href: "/listed-vents/" },
      { title: "General venting (IMC 801)", desc: "Vent to exterior is not a design.", href: "/general-venting/" },
      { title: "Vent connectors (IMC 803)", desc: "The connector is not leftover pipe.", href: "/vent-connectors/" },
      { title: "Direct-vent (IMC 804)", desc: "Name the category before you copy the clearance.", href: "/direct-vent/" },
      { title: "Structure protection (IMC 302)", desc: "Do not cut the truss. Do not guess the firestop.", href: "/structure-protection/" },
      { title: "General regulations (IMC 301)", desc: "Listed is not installed.", href: "/general-regulations/" },
      { title: "Coil-discharge liner (IMC 604.13)", desc: "Do not line the wet coil discharge.", href: "/coil-discharge-liner/" },
      { title: "Return air (IMC 601)", desc: "A corridor is not a duct.", href: "/return-air/" },
      { title: "Temporary equipment (IMC 110)", desc: "Temporary is not unpermitted.", href: "/temporary-equipment/" },
      { title: "Construction documents (IMC 106)", desc: "If it is not to scale, it is not a construction document.", href: "/construction-documents/" },
      { title: "Flexible ducts (IMC 607.7)", desc: "Flex does not cross the rated line.", href: "/flexible-ducts/" },
      { title: "Mechanical inspections (IMC 111)", desc: "If you bury it first, you will open it later.", href: "/mechanical-inspections/" },
      { title: "Stop work (IMC 115)", desc: "A verbal lift is not a lift.", href: "/stop-work/" },
      { title: "Grounding vs bonding (NEC 100)", desc: "The ground rod is not the fault path.", href: "/grounding-bonding/" },
      { title: "SCCR vs fault current (NEC 100)", desc: "The breaker rating is not the package SCCR.", href: "/sccr-fault-current/" },
      { title: "Listed vs labeled (NEC 100)", desc: "A listing mark is not a blank check.", href: "/listed-labeled/" },
      { title: "Readily accessible (NEC 100)", desc: "A ladder to the disconnect is not readily accessible.", href: "/readily-accessible/" },
      { title: "Overcurrent (NEC 100)", desc: "A breaker trip is not a diagnosis.", href: "/overcurrent/" },
      { title: "Service boundaries (NEC 100)", desc: "A MAIN label is not the service point.", href: "/service-boundaries/" },
      { title: "Mechanical permits (IMC 105)", desc: "Exemption is not a code holiday.", href: "/mechanical-permits/" },
      { title: "Branch vs feeder (NEC 100)", desc: "Not every conductor leaving a panel is a feeder.", href: "/branch-circuit-vs-feeder/" },
      { title: "Voltage terminology (NEC 100)", desc: "208 volts is not a complete voltage description.", href: "/voltage-terminology/" },
      { title: "Violations (IMC 114)", desc: "A field substitution is a violation the moment it leaves the set.", href: "/violations/" },
      { title: "Utility connection (IMC 109)", desc: "The utility meter-set is not the AHJ’s yes.", href: "/utility-connection/" },
      { title: "Redline definitions (IMC 202)", desc: "The wrong word on the schedule is a first-cycle comment.", href: "/redline-definitions/" },
      { title: "Outlet vs receptacle (NEC 100)", desc: "Outlet and receptacle are not synonyms.", href: "/outlet-vs-receptacle/" },
      { title: "Neutral vs EGC (NEC 100)", desc: "It has a ground is not a connection spec.", href: "/neutral-vs-ground/" },
      { title: "Definition hierarchy (IMC 201)", desc: "Put the definition hierarchy on M-001.", href: "/definition-hierarchy/" },
      { title: "Type II hoods (IMC 507.3)", desc: "Type II is not general exhaust.", href: "/type-ii-hoods/" },
      { title: "Type II ducts (IMC 506.4)", desc: "Run the 3-10-10-10-30 termination check.", href: "/type-ii-ducts/" },
      { title: "NEC not covered (90.2(A)(2))", desc: "By utility is not an exclusion.", href: "/nec-not-covered/" },
      { title: "NEC covered (90.1 / 90.2(A)(1))", desc: "Scope does not stop at the exterior wall.", href: "/nec-covered/" },
      { title: "Code minimum is not a design (90.2(B)–(D))", desc: "Compliant is not the same as designed.", href: "/code-minimum-not-design/" },
      { title: "Dampered combustion air (IMC 701)", desc: "Prove the damper is open before fire.", href: "/dampered-combustion-air/" },
      { title: "NEC arrangement (90.3–90.6)", desc: "Finding the section is not the whole job.", href: "/nec-arrangement/" },
      { title: "Equipment examination (90.7–90.9)", desc: "The listing is for the equipment as evaluated.", href: "/equipment-examination/" },
      { title: "OA intake (IMC 401.4)", desc: "Measure from the nearest edge, not the centerline.", href: "/outdoor-air-intake/" },
      { title: "Intake protection (IMC 401.5)", desc: "The brochure mesh is not Table 401.5.", href: "/intake-protection/" },
      { title: "Notice of approval (IMC 107)", desc: "Passing underground does not approve rough-in.", href: "/notice-of-approval/" },
      { title: "Appeals (IMC 112)", desc: "The board cannot waive the code.", href: "/appeals/" },
      { title: "Dust recirc (IMC 510.1.3)", desc: "Missing one of the three → exhaust outdoors.", href: "/dust-exhaust-recirculation/" },
      { title: "Code official (IMC 104)", desc: "The official can interpret. The official cannot waive.", href: "/code-official/" },
      { title: "IMC applicability (102)", desc: "Grandfathered is not a drawing note.", href: "/imc-applicability/" },
      { title: "IMC scope (101)", desc: "Fuel gas is IFGC. Confirm IMC vs IRC.", href: "/imc-scope/" },
      { title: "Zone outdoor air (403.3.1.1)", desc: "Vbz is not Voz. Divide by Ez.", href: "/zone-outdoor-air/" },
      { title: "Permit fees (IMC 108)", desc: "No permit is valid until the fees are paid.", href: "/permit-fees/" },
      { title: "Miami-Dade permit exemptions (HB 803)", desc: "The $7,500 rule does not cover mechanical work.", href: "/miami-dade-permit-exemptions/" },
      { title: "How to apply (Miami-Dade folio 30)", desc: "Plans are not reviewed until upfront fees are paid.", href: "/miami-dade-how-to-apply/" },
      { title: "Ventilation path (IMC 401.2)", desc: "Tight dwellings do not get windows-only.", href: "/ventilation-path/" },
      { title: "Low-rise residential ventilation (403.3.2)", desc: "Townhouses use Equation 4-9, not the office table.", href: "/low-rise-residential-ventilation/" },
      { title: "Code compliance agency (IMC 103)", desc: "The reviewer is not the code official.", href: "/code-compliance-agency/" },
      { title: "Recirculation limits (IMC 403.2.1)", desc: "Return air is not outdoor air.", href: "/recirculation-limits/" },
      { title: "Temperature control (IMC 309)", desc: "Portable heaters are not the heating system.", href: "/temperature-control/" },
      { title: "Existing chimneys (IMC 801.18)", desc: "Existing chimney to remain is not a design.", href: "/existing-chimneys/" },
      { title: "Plenum contamination (IMC 601.4)", desc: "Above the ceiling is not an approved plenum path.", href: "/contamination-prevention/" },
      { title: "Abandoned vent openings (IMC 801.8)", desc: "Cap by contractor is not a detail.", href: "/abandoned-vent-openings/" },
      { title: "Mechanical draft (IMC 804.3)", desc: "A fan on the roof is not the interlock.", href: "/mechanical-draft/" },
      { title: "Vent termination height (IMC 802.5–802.6)", desc: "Two height checks. Clearing the roof is not both.", href: "/vent-termination-height/" },
      { title: "Plastic vent (IMC 801.20–801.21)", desc: "Plastic vent is not plumbing pipe.", href: "/plastic-vent/" },
      { title: "Connector pass-through (IMC 803.10.4)", desc: "A clearance number is not the wall assembly.", href: "/connector-pass-through/" },
      { title: "Vent insulation shield (IMC 802.7–802.8)", desc: "The appliance collar does not hold the vent.", href: "/vent-insulation-shield/" },
      { title: "Vent door swing (IMC 802.9)", desc: "A doorstop is not a 12-inch clearance.", href: "/vent-door-swing/" },
      { title: "Decorative shrouds (IMC 805.7)", desc: "Listed for that chimney system — not a look-alike.", href: "/decorative-shrouds/" },
      { title: "Chimney offsets (IMC 805.4–805.5)", desc: "30 degrees from vertical, four elbows, designed support.", href: "/chimney-offsets/" },
      { title: "Positive-pressure vent (IMC 801.9)", desc: "A leak pushes combustion products out.", href: "/positive-pressure-vent/" },
      { title: "Medium-heat chimneys (IMC 805.6)", desc: "Above 1,000°F at the entrance needs UL 959.", href: "/medium-heat-chimneys/" },
      { title: "Connector clearance (IMC 803.10.6)", desc: "18 inches is not every connector.", href: "/connector-clearance/" },
      { title: "Chimney insulation shield (IMC 805.8)", desc: "Insulation day can bury a clearance that already passed.", href: "/chimney-insulation-shield/" },
      { title: "Minimum vent size (IMC 801.6)", desc: "Check by area, not matching pipe sizes.", href: "/minimum-vent-size/" },
      { title: "Dedicated solid-fuel flue (IMC 801.11)", desc: "Looks unused is not a dedicated flue.", href: "/dedicated-solid-fuel-flue/" },
      { title: "Multistory common vent (IMC 801.19)", desc: "Two floors, one vent shaft is the comment.", href: "/multistory-common-vent/" },
      { title: "Chimney cleanouts (IMC 801.12–801.13)", desc: "Connect to existing is not an elevation.", href: "/chimney-cleanouts/" },
      { title: "Connector dampers (IMC 803.5–803.7)", desc: "Smaller connector enters higher.", href: "/connector-dampers/" },
      { title: "Fireplace flue connection (IMC 801.10)", desc: "A fireplace flue is not a spare vent connection.", href: "/fireplace-flue-connection/" },
      { title: "Power-exhauster termination (IMC 804.3.3–804.3.4)", desc: "A clear wall is not a clear termination.", href: "/power-exhauster-termination/" },
      { title: "Masonry flue lining (IMC 801.15–801.16)", desc: "Existing chimney to remain is not a liner.", href: "/masonry-flue-lining/" },
      { title: "Connector geometry (IMC 803.10)", desc: "Support, 75% length, inner face, 1/4 in per foot.", href: "/connector-geometry/" },
      { title: "Chimney annular space (IMC 801.17)", desc: "Leftover space is not a second flue.", href: "/chimney-annular-space/" },
      { title: "Manually fired mechanical draft (IMC 804.3.8)", desc: "Fuel is still burning when the draft fan stops.", href: "/manually-fired-draft/" },
      { title: "Solid-fuel flue size (IMC 801.7)", desc: "A larger chimney is not automatically better.", href: "/solid-fuel-flue-size/" },
      { title: "Connector construction (IMC 803.8–803.9)", desc: "Galvanized without a gage is not a spec.", href: "/connector-construction/" },
      { title: "Exhauster connection (IMC 801.14)", desc: "A fan symbol is not a pressure boundary.", href: "/exhauster-connection/" },
      { title: "Vertical mechanical-draft termination (IMC 804.3.5)", desc: "Height above this roof is not the whole check.", href: "/mechanical-draft-vertical/" },
      { title: "Exhauster sizing (IMC 804.3.6–804.3.7)", desc: "Nominal CFM is not the manufacturer’s method.", href: "/exhauster-sizing/" },
      { title: "Positive flow (IMC 801.4–801.5)", desc: "If you cannot say what creates the draft, it has been drawn.", href: "/positive-flow/" },
      { title: "Oil-fired venting (IMC 801.2 / NFPA 31)", desc: "Vent to exterior is not a venting design.", href: "/oil-fired-venting/" },
      { title: "Type L cap (IMC 802.3–802.4)", desc: "A generic cap is not the listed Type L system.", href: "/type-l-cap/" },
      { title: "Venting scope (IMC 801.1)", desc: "A perfectly drawn 801 detail is still wrong if the fuel is gas.", href: "/venting-scope/" },
      { title: "Masonry chimney IBC (IMC 801.3)", desc: "A masonry chimney is not a mechanical-only note.", href: "/masonry-chimney-ibc/" },
      { title: "Flue passageway (IMC 801.18.2)", desc: "A sweeping invoice is not a reuse decision.", href: "/flue-passageway/" },
      { title: "Existing chimney clearance (IMC 801.18.4)", desc: "Relining is not zero-clearance permission.", href: "/existing-chimney-clearance/" },
      { title: "Existing vent size (IMC 801.18.1)", desc: "Reusing the chimney is not keeping the same size.", href: "/existing-vent-size/" },
      { title: "Existing chimney cleanout (IMC 801.18.3)", desc: "New equipment often hides the 801.13 cleanout.", href: "/existing-chimney-cleanout/" },
      { title: "Registers and grilles (IMC 603.18)", desc: "Air devices are not finish items.", href: "/registers-grilles/" },
      { title: "Air dispersion (IMC 603.17)", desc: "Fabric duct above a ceiling is the usual redline.", href: "/air-dispersion/" },
      { title: "Vapor retarder (IMC 604.11–604.12)", desc: "R-value on paper is not a vapor retarder.", href: "/vapor-retarder/" },
      { title: "Roof equipment access (IMC 306.5)", desc: "A portable ladder is not 306.5 access.", href: "/roof-equipment-access/" },
      { title: "Exit enclosure ventilation (IMC 601.3)", desc: "A stair fan is not a toilet-exhaust tap.", href: "/exit-enclosure-ventilation/" },
      { title: "Fire-partition dampers (IMC 607.5.3)", desc: "Sprinklered is not a fire-partition exception.", href: "/fire-partition-dampers/" },
      { title: "Corridor / smoke dampers (IMC 607.5.4)", desc: "A CRD is not a smoke damper.", href: "/corridor-smoke-dampers/" },
      { title: "Shaft dampers (IMC 607.5.5)", desc: "A fire damper in a grease shaft is prohibited.", href: "/shaft-dampers/" },
      { title: "Horizontal assemblies (IMC 607.6)", desc: "A static CRD is not listed for a system that runs during a fire.", href: "/horizontal-assembly-dampers/" },
      { title: "Fire walls / barriers (IMC 607.5.1–607.5.2)", desc: "A fire damper alone is not enough at a horizontal exit.", href: "/fire-wall-dampers/" },
      { title: "Type I hoods (IMC 507.2)", desc: "Type I on the schedule is not the hood.", href: "/type-i-hoods/" },
      { title: "Damper access (IMC 607.4)", desc: "The right damper still has to be found and opened.", href: "/damper-access/" },
      { title: "Type I filters (IMC 507.2.8)", desc: "A charbroiler does not get a 6-inch filter.", href: "/type-i-filters/" },
      { title: "Damper installation (IMC 607.2)", desc: "The symbol is not the listing.", href: "/damper-installation/" },
      { title: "Grease duct construction (IMC 506.3)", desc: "Wrap it after the light test — not before.", href: "/grease-duct-construction/" },
      { title: "Damper ratings (IMC 607.3)", desc: "A generic FSD tag is not a schedule.", href: "/damper-ratings/" },
      { title: "Grease duct slope (IMC 506.3.7)", desc: "If grease can pool, it will.", href: "/grease-duct-slope-cleanouts/" },
      { title: "Grease duct enclosure (IMC 506.3.11)", desc: "Spot wrap is not an enclosure.", href: "/grease-duct-enclosure/" },
      { title: "Hood overhang (IMC 507.1.6)", desc: "CFM will not fix a hood that is too short.", href: "/hood-overhang/" },
      { title: "Type I exhaust fans (IMC 506.5)", desc: "An upblast without a hinge and a grease drain will fail inspection.", href: "/type-i-exhaust-fans/" },
      { title: "Hood exceptions (IMC 507.1)", desc: "“No hood required” is not a designer preference.", href: "/hood-exceptions/" },
      { title: "Hood interlocks (IMC 507.1.1)", desc: "A Type I fan that does not auto-start is not coordinated.", href: "/hood-interlocks/" },
      { title: "Underground ducts (IMC 603.8)", desc: "Bury it after the leak test — not before.", href: "/underground-ducts/" },
      { title: "Duct flood and weather (IMC 603.13)", desc: "A sized duct still fails for flood and weather.", href: "/duct-flood-weather/" },
      { title: "Hazardous exhaust shafts (IMC 509.4)", desc: "One header for everything is not 509.4.", href: "/hazardous-exhaust-shafts/" },
      { title: "Duct smoke installation (IMC 606.3)", desc: "A detector symbol is not a 606.3 installation.", href: "/duct-smoke-installation/" },
      { title: "Plenum materials (IMC 602.3)", desc: "Ordinary foam and PVC do not belong in a return plenum.", href: "/plenum-materials/" },
      { title: "Dust explosion control (IMC 510.1.5)", desc: "“Explosion vent by others” is not 510.1.5.", href: "/dust-explosion-control/" },
      { title: "Hydrogen ventilation (IMC 304.5)", desc: "Hydrogen does not wait at the floor like gasoline vapor.", href: "/hydrogen-ventilation/" },
      { title: "Battery room exhaust (IMC 502.4)", desc: "A battery room is not a storage closet.", href: "/battery-room-exhaust/" },
      { title: "High-temperature exhaust (IMC 510.2)", desc: "Over 600°F is not just another exhaust outlet.", href: "/high-temperature-exhaust/" },
      { title: "Plenum construction (IMC 602.2)", desc: "Supply air in the stud bay is not a plenum.", href: "/plenum-construction/" },
      { title: "Hazmat exhaust (IMC 502.8)", desc: "“Exhaust per code” is not a 502.8 design.", href: "/hazmat-exhaust/" },
      { title: "Plenum wiring (IMC 602.3)", desc: "CM cable and dry-pipe CPVC do not belong in a return plenum.", href: "/plenum-wiring/" },
      { title: "Field conversions (1.08 / 500 / 12,000)", desc: "A rule of thumb is not a load calculation.", href: "/field-conversions/" },
      { title: "Refrigerant safety (ASHRAE 34 / EPA 608)", desc: "A2L is not a drop-in note.", href: "/refrigerant-safety/" },
      { title: "Smoke control (IMC 512)", desc: "Calling atrium exhaust “smoke control” is how 512 stalls.", href: "/smoke-control/" },
      { title: "Salon exhaust (IMC 502.20)", desc: "A nail station is not a restroom with a ceiling grille.", href: "/salon-exhaust/" },
      { title: "Smoke-control methods (IMC 512.6)", desc: "Minimum ΔP that makes the stair door unopenable is a failed system.", href: "/smoke-control-methods/" },
      { title: "Fuel-dispensing exhaust (IMC 502.1.2)", desc: "Gasoline vapor does not wait at the canopy.", href: "/fuel-dispensing-exhaust/" },
      { title: "Dust recirculation (IMC 510.1.3)", desc: "A recirculating dust collector with no 99.9% note is not 510.1.3.", href: "/dust-recirculation/" },
      { title: "Smoke-control hardware (IMC 512.10)", desc: "A life-safety fan on a normal circuit is not 512.11.", href: "/smoke-control-hardware/" },
      { title: "Smoke barriers (IMC 512.5)", desc: "A transfer grille across a smoke barrier with no damper will not hold ΔP.", href: "/smoke-barriers/" },
      { title: "CNG / hydrogen repair (IMC 502.16)", desc: "Do not copy the gasoline 18-inch inlet onto a hydrogen bay.", href: "/cng-repair-exhaust/" },
      { title: "Projector exhaust (IMC 502.11)", desc: "A projector collar capped in the return is not 502.11.", href: "/projector-exhaust/" },
      { title: "Return / transfer openings (IMC 601.5)", desc: "A ¾-inch undercut is not a return-air design.", href: "/return-transfer-openings/" },
      { title: "Source-capture exhaust (IMC 502.14)", desc: "A ceiling fan over a running engine is not source capture.", href: "/source-capture-exhaust/" },
      { title: "Spray-finish exhaust (IMC 502.7)", desc: "If the spray gun still runs when the fan is off, it is not 502.7.", href: "/spray-finish-exhaust/" },
      { title: "Exhaust opening protection (501.3.2)", desc: "Insect cloth is not a 1/4-inch screen.", href: "/exhaust-opening-protection/" },
      { title: "Board of appeals (IMC 113)", desc: "Do not assume a five-member board.", href: "/board-of-appeals/" },
      { title: "Verify PE 95945", desc: "MyFloridaLicense / FBPE.", href: "/license/" },
      { title: "HVAC vs construction", desc: "Loads follow envelope and existing vs new.", href: "/hvac-construction-type/" },
      { title: "What to send", desc: "Share-link checklist by job type.", href: "/what-to-send/" }
    ]
  },
  es: {
    eyebrow: "/ Conocimiento de campo",
    headline: "Código, dibujado como se revisa un set de permiso.",
    sub: "Centros construidos desde Daily Code Talk y los trabajos que realmente se detienen en Miami-Dade. Empiece gratis. Envíe el set cuando la decisión sea real.",
    items: [
      { title: "Ventilación y aire exterior", desc: "IMC Capítulo 4, tomas y el estimador.", href: "/ventilation/" },
      { title: "Extracción de cocina", desc: "Tipo I / Tipo II, ducto de grasa, aire de reposición.", href: "/commercial-kitchen-ventilation/" },
      { title: "Mejoras de locales", desc: "Oficina, retail y restaurantes sobre sistemas existentes.", href: "/mejoras-de-locales-mep-miami/" },
      { title: "Comentarios de permiso", desc: "Envíe la carta. Reciba una ruta de reentrega.", href: "/permit-comment-response/" },
      { title: "Ventilación sanitaria", desc: "ASHRAE 170 / IMC 407.", href: "/healthcare-ventilation/" },
      { title: "Garajes", desc: "IMC 404, control de CO.", href: "/parking-garage-ventilation/" },
      { title: "117 herramientas gratuitas", desc: "Pantallas de decisión en 13 grupos — sin registro ni correo. Cada una nombra el documento que gobierna.", href: "/herramientas-de-campo/" },
      { title: "Permisos Miami-Dade", desc: "Listas, séptico, pozos, recertificación.", href: "/miami-dade-permit-resources/" },
      { title: "FBC vs IMC", desc: "8.ª edición vigente; 9.ª programada el 31 dic 2026.", href: "/florida-building-code/" },
      { title: "Comentarios típicos", desc: "Lo que los planos suelen tener que mostrar.", href: "/typical-plan-review-comments/" },
      { title: "Plomería", desc: "Isométricos, grasa, séptico/pozo.", href: "/plumbing/" },
      { title: "Empezar aquí", desc: "Lleve el problema al intake correcto.", href: "/empezar/" },
      { title: "Desde el PE", desc: "HVAC, Capítulo 1, plomería VE.", href: "/from-the-pe/" },
      { title: "Qué enviar", desc: "Lista por tipo de trabajo.", href: "/que-enviar/" }
    ]
  }
};
function MBKnowledgeHubs({ lang, tweaks }) {
  const t = KNOWLEDGE_HUBS[lang] || KNOWLEDGE_HUBS.en;
  const accent = tweaks.accent;
  return React.createElement("section", {
    id: "knowledge",
    style: { background: "#0B0C0E", padding: "60px 40px", borderTop: "1px solid rgba(255,255,255,0.06)" }
  }, React.createElement("div", { style: { maxWidth: 1200, margin: "0 auto" } },
    React.createElement("span", {
      style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: accent, letterSpacing: "0.1em", textTransform: "uppercase", display: "block", marginBottom: 12 }
    }, t.eyebrow),
    React.createElement("h2", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, fontSize: "clamp(28px, 3.5vw, 44px)", color: "#F0EDE8", margin: "0 0 16px" }
    }, t.headline),
    React.createElement("p", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 16, color: "rgba(240,237,232,0.5)", margin: "0 0 32px", maxWidth: 640 }
    }, t.sub),
    React.createElement("div", {
      style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12 }
    }, (function () {
      var more = lang === "es"
        ? { title: "Todo el conocimiento de campo", desc: "Permisos, ventilación, cocina, Miami-Dade — agrupado.", href: "/conocimiento-de-campo/" }
        : { title: "All field knowledge", desc: "Permits, ventilation, kitchen, NEC, Miami-Dade — grouped like a permit set.", href: "/field-knowledge/" };
      return t.items.slice(0, 12).concat([more]);
    })().map(function (item) {
      return React.createElement("a", {
        key: item.href,
        href: item.href,
        style: { display: "block", padding: 18, background: "#131417", border: "1px solid rgba(255,255,255,0.08)", textDecoration: "none", minHeight: 44 }
      },
        React.createElement("strong", {
          style: { display: "block", fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 16, color: "#F0EDE8", marginBottom: 8 }
        }, item.title),
        React.createElement("span", {
          style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.55)", lineHeight: 1.5 }
        }, item.desc)
      );
    }))
  ));
}

Object.assign(window, {
  SECTIONS_CONTENT,
  MBServices,
  MBKnowledgeHubs,
  MBMissionCritical,
  MBMarkets,
  MBExistingBuildings,
  MBTrustBand,
  MBDailyCodeTalk,
  MBResourceLibrary,
  MBAuthority,
  MBLeadMagnet,
  MBTestimonials,
  LEAD_MAGNET_CONTENT,
  TESTIMONIALS_CONTENT
});
// ─── Fit check ────────────────────────────────────────────────────────────
// A scope screen, not a sales pitch: it states what this practice takes on and
// what moves to a partner. It filters inquiries before either side spends time
// on a proposal, and every line restates scope already documented elsewhere in
// the source - no new capability, licensure, or performance claim.
const FIT_CONTENT = {
  en: {
    eyebrow: "/ Fit",
    headline: "Are we the right engineer for this project?",
    sub: "A short scope screen before anyone spends time on a proposal. If it is not a fit, Masterbuild says so early and points you toward a better path.",
    yesLabel: "Where Masterbuild is the right call",
    yes: [
      "Permit-level MEP construction documents - HVAC, plumbing, fire protection, and electrical coordinated for submission and comment response.",
      "Independent MEP review, peer check, and forensic second opinions on a set someone else produced.",
      "Existing commercial-building assessments and plumbing-system feasibility before more capital moves.",
      "Construction-phase RFIs, submittals, and field questions that need a PE answer rather than a guess.",
      "Owners, architects, and GCs who want the licensed engineer on the call instead of a project manager relaying.",
      "Bilingual EN / ES technical communication with owners, trades, and the AHJ."
    ],
    noLabel: "Where Masterbuild refers out or teams up",
    no: [
      "Architecture, structural, and civil / site design - coordinated with, not produced here.",
      "Permit expediting, runner services, and filing representation.",
      "Private-provider plan review and inspection are not currently offered.",
      "Sealed packages in disciplines outside the mechanical / MEP scope - electrical and other specialty disciplines move through licensed partners.",
      "Work outside Florida - TX, NJ, NY, and PA are reviewed by request based on scope, licensure requirements, teaming needs, and jurisdiction expectations.",
      "Means, methods, and construction execution - that stays with the contractor.",
      "Stamp-only requests with no scope review. Masterbuild does not seal work it did not review."
    ],
    note: "Licensure, sealing, and delivery structure confirmed per project scope and jurisdiction.",
    cta: "Request a Proposal ->",
    ctaNote: "Not sure which column you are in? Send the project background and it gets answered in the first reply."
  },
  es: {
    eyebrow: "/ Encaje",
    headline: "¿Somos el ingeniero correcto para este proyecto?",
    sub: "Una revisión corta de alcance antes de que alguien invierta tiempo en una propuesta. Si no hay encaje, Masterbuild lo dice temprano y le indica un mejor camino.",
    yesLabel: "Cuando Masterbuild es la opción correcta",
    yes: [
      "Documentos de construcción MEP a nivel de permiso - HVAC, plomería, protección contra incendios y eléctrico coordinados para presentación y respuesta a comentarios.",
      "Revisión MEP independiente, verificación entre pares y segundas opiniones forenses sobre un set producido por otros.",
      "Evaluaciones de edificios comerciales existentes y factibilidad de plomería antes de comprometer más capital.",
      "RFIs, submittals y preguntas de campo en construcción que requieren respuesta de un PE, no una suposición.",
      "Propietarios, arquitectos y contratistas que quieren al ingeniero licenciado en la llamada, no a un gerente de proyecto transmitiendo.",
      "Comunicación técnica bilingüe EN / ES con propietarios, oficios y el AHJ."
    ],
    noLabel: "Cuando Masterbuild refiere o trabaja en equipo",
    no: [
      "Arquitectura, estructural y civil / sitio - se coordina con ellos, no se produce aquí.",
      "Gestión de trámites de permiso, mensajería y representación ante la ventanilla.",
      "Actualmente no se ofrecen revisión de planos ni inspecciones por proveedor privado.",
      "Paquetes sellados en disciplinas fuera del alcance mecánico / MEP - eléctrico y otras especialidades se manejan con socios licenciados.",
      "Trabajo fuera de Florida - TX, NJ, NY y PA se revisan por solicitud según alcance, requisitos de licencia, necesidades de equipo y expectativas de la jurisdicción.",
      "Medios, métodos y ejecución de construcción - eso queda con el contratista.",
      "Solicitudes de solo sellar sin revisión de alcance. Masterbuild no sella trabajo que no revisó."
    ],
    note: "Licencia, sellado y estructura de entrega confirmados por alcance del proyecto y jurisdicción.",
    cta: "Solicitar Propuesta ->",
    ctaNote: "¿No sabe en cuál columna está? Envíe los antecedentes del proyecto y se responde en la primera respuesta."
  }
};
function MBFitCheck({
  lang,
  tweaks
}) {
  const t = FIT_CONTENT[lang] || FIT_CONTENT.en;
  const accent = tweaks.accent;
  const column = (label, items, tone) => /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#131417",
      padding: "30px 32px",
      borderTop: "3px solid " + (tone === "yes" ? accent : "rgba(255,255,255,0.18)")
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 18,
      color: tone === "yes" ? accent : "rgba(240,237,232,0.75)",
      margin: "0 0 18px",
      lineHeight: 1.25
    }
  }, label), /*#__PURE__*/React.createElement("ul", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      listStyle: "none",
      margin: 0,
      padding: 0
    }
  }, items.map((item, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "flex",
      gap: 10,
      alignItems: "flex-start",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      lineHeight: 1.65,
      color: "rgba(240,237,232,0.62)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: tone === "yes" ? accent : "rgba(240,237,232,0.3)",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 13,
      flexShrink: 0,
      lineHeight: 1.5
    }
  }, tone === "yes" ? "+" : "/"), item))));
  return /*#__PURE__*/React.createElement("section", {
    id: "fit",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 12
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(26px, 3vw, 40px)",
      color: "#F0EDE8",
      margin: "0 0 14px",
      lineHeight: 1.12
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      lineHeight: 1.7,
      color: "rgba(240,237,232,0.55)",
      margin: "0 0 30px",
      maxWidth: 620
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    className: "mb-fit-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
      gap: 2
    }
  }, column(t.yesLabel, t.yes, "yes"), column(t.noLabel, t.no, "no")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26,
      display: "flex",
      alignItems: "center",
      gap: 18,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: lang === "es" ? "/contacto/" : "/send/",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Fit Check CTA Click", {
      language: lang
    }),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 46,
      padding: "13px 26px",
      background: accent,
      color: "#0B0C0E",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 14,
      textDecoration: "none",
      borderRadius: 3,
      whiteSpace: "nowrap"
    }
  }, t.cta), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.45)",
      maxWidth: 520,
      lineHeight: 1.6
    }
  }, t.ctaNote)), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 22,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.32)",
      lineHeight: 1.6
    }
  }, t.note)));
}

// Fit check is defined after the main export block above; export it here so the
// homepage app and the release smoke render resolve it the same way as every
// other section component.
Object.assign(window, {
  FIT_CONTENT,
  MBFitCheck
});
