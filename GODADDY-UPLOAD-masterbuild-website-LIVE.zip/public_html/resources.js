const ACCENT = "#C4783A";
const BG = "#0B0C0E";
const SURFACE = "#131417";
const SURFACE2 = "#1C1E23";
const BORDER = "rgba(255,255,255,0.07)";
const TEXT = "#F0EDE8";
const MUTED = "rgba(240,237,232,0.45)";
// RES_OFFER_URL reads one checkout URL from the catalog without assuming the key exists.
//
// Why this guard: every constant below is evaluated at script load. Reading
// `window.MB_CATALOG.offers.someKey.url` directly throws a TypeError the moment a key is
// missing, and a throw here stops the whole file - the Resources page then renders nothing
// and EVERY checkout on it dies, not just the missing one. That happens whenever
// resources.js and mb-catalog.js are deployed out of sync, or a returning visitor holds a
// cached mb-catalog.js from before a new offer was added. Bumping the ?v= release tag on
// both files prevents it; this guard means a slip does not take the page down. A missing
// offer degrades to one inert button instead.
function RES_OFFER_URL(key) {
  var catalog = window.MB_CATALOG || {};
  var offer = (catalog.offers || {})[key];
  return (offer && offer.url) || "#";
}
function RES_SUBSCRIBE_PAGE() {
  var s = (window.MB_CATALOG || {}).subscribe;
  return (s && s.listPage) || "https://buttondown.com/masterbuild";
}
function RES_PRICE(key) {
  var c = window.MB_CATALOG;
  return (c && typeof c.price === "function") ? c.price(key) : "";
}
const RES_SCOPING_CALL_URL = (window.MB_CATALOG && window.MB_CATALOG.scopingCall) || "#";
const RES_IMC_CHAPTER1_GUIDE_URL = RES_OFFER_URL("imcChapter1Guide");
const RES_IMC_CHAPTER2_GUIDE_URL = RES_OFFER_URL("imcChapter2Guide");
const RES_IMC_CHAPTER3_GUIDE_URL = RES_OFFER_URL("imcChapter3Guide");
const RES_IMC_CHAPTER5_GUIDE_URL = RES_OFFER_URL("imcChapter5Guide");
const RES_IMC_CHAPTER6_GUIDE_URL = RES_OFFER_URL("imcChapter6Guide");
const RES_IMC_CHAPTER7_GUIDE_URL = RES_OFFER_URL("imcChapter7Guide");
const RES_IMC_CHAPTER67_BUNDLE_URL = RES_OFFER_URL("imcChapter67Bundle");
const RES_IMC_CHAPTER8_GUIDE_URL = RES_OFFER_URL("imcChapter8Guide");
const RES_IMC_CHAPTER78_BUNDLE_URL = RES_OFFER_URL("imcChapter78Bundle");
const CH78_COMPONENTS = ["imcChapter7Guide", "imcChapter8Guide"];
function RES_BUNDLE78_LIST() {
  var c = window.MB_CATALOG;
  return (c && typeof c.listPrice === "function") ? c.listPrice(CH78_COMPONENTS) : "";
}
function RES_BUNDLE78_SAVINGS() {
  var c = window.MB_CATALOG;
  return (c && typeof c.savings === "function") ? c.savings("imcChapter78Bundle", CH78_COMPONENTS) : "";
}
function RES_SELLABLE(key) {
  var c = window.MB_CATALOG;
  return !!(c && typeof c.sellable === "function" && c.sellable(key));
}
const CH67_COMPONENTS = ["imcChapter6Guide", "imcChapter7Guide"];
function RES_BUNDLE_LIST() {
  var c = window.MB_CATALOG;
  return (c && typeof c.listPrice === "function") ? c.listPrice(CH67_COMPONENTS) : "";
}
function RES_BUNDLE_SAVINGS() {
  var c = window.MB_CATALOG;
  return (c && typeof c.savings === "function") ? c.savings("imcChapter67Bundle", CH67_COMPONENTS) : "";
}
const RES_PERMIT_READINESS_PACK_URL = RES_OFFER_URL("permitReadinessPack");
const RES_OWNER_SIDE_BUNDLE_URL = RES_OFFER_URL("ownerSideBundle");
const RES_VENTILATION_FIELD_GUIDE_URL = RES_OFFER_URL("ventilationFieldGuide");

// Single authoritative catalog for this page. Prices, links, and included-items
// text are protected business facts (see _AI_FOLDER_GUIDE.md) - do not alter
// without verifying against the source of the original figures.
const RESOURCE_OFFERS = {
  en: [
    {
      title: "Free Archive + Code Desk Email List",
      price: "Free",
      body: "Search the bilingual Daily Code Talk archive (IMC + NEC), then join the free list for useful code, field-QA, and resource updates when published.",
      href: RES_SUBSCRIBE_PAGE(),
      cta: "Join the free email list"
    },
    {
      title: "NEC Article 100 Glossary",
      price: "Free",
      body: "Searchable, plain-English NEC Article 100 definitions with field notes on where each one bites on a permit set. Bilingual, growing archive.",
      href: "/glossary/",
      cta: "Browse the glossary"
    },
    {
      title: "NEC Glossary — Downloadable PDF",
      price: "Free",
      body: "All 209 NEC Article 100 definitions in one branded PDF — save it, print it, or keep it on the tablet in the field. English edition.",
      href: "/uploads/nec-glossary-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "IMC Section 202 Definitions Glossary",
      price: "Free",
      body: "All 219 IMC Section 202 definitions, searchable and plain-English, with field notes on where each one bites on a permit set. Bilingual.",
      href: "/imc-glossary/",
      cta: "Browse the glossary"
    },
    {
      title: "IMC Glossary — Downloadable PDF",
      price: "Free",
      body: "All 219 IMC Section 202 definitions in one branded PDF — save it, print it, or keep it on the tablet in the field. English edition.",
      href: "/uploads/imc-glossary-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Duct Leakage Packet",
      price: "Free",
      body: "Duct leakage is not a blower-door test. Rough-in or post-construction. Exceptions are written on the energy forms. EN + ES.",
      href: "/miami-dade-duct-leakage/",
      cta: "Open duct leakage"
    },
    {
      title: "Miami-Dade Notice of Commencement Packet",
      price: "Free",
      body: "A recording, not a permit. Owner signs. Two County documents have not always named the same HVAC exception. Confirm FBC 105.8 live.",
      href: "/miami-dade-notice-of-commencement/",
      cta: "Open the NOC packet"
    },
    {
      title: "Miami-Dade Mechanical Change-Out Final Packet",
      price: "Free",
      body: "The nameplate on the pad has to be the equipment that was calculated. Energy calcs on site. Condensate terminates. Return-air path exists.",
      href: "/miami-dade-mechanical-changeout/",
      cta: "Open change-out"
    },
    {
      title: "Miami-Dade Plumbing Inspection-Day Packet",
      price: "Free",
      body: "You inspect first. A filled shower pan is a test. Plumbing final looks for the water meter set by the purveyor. Gas is its own inspection. EN + ES.",
      href: "/miami-dade-plumbing-inspection/",
      cta: "Open inspection-day"
    },
    {
      title: "Miami-Dade Electrical Inspection-Day Packet",
      price: "Free",
      body: "Working space is shown. Directories filled. Unused openings closed. We do not invent Article 110 numbers. EN + ES.",
      href: "/miami-dade-electrical-inspection/",
      cta: "Open inspection-day"
    },
    {
      title: "Miami-Dade Fire Rescue — Second Desk Packet",
      price: "Free",
      body: "The mechanical permit does not pay the Fire bill. No dollar quotes. Hood, alarm, suppression, smoke control are not included in mechanical.",
      href: "/miami-dade-fire-desk/",
      cta: "Open the Fire desk"
    },
    {
      title: "Miami-Dade Electrical Work-With — FPL Disconnect Packet",
      price: "Free",
      body: "A work-with is not a new service. 30-day clock. Access every panel. Not for new construction. Meter tampering is a whole-building walk. EN + ES.",
      href: "/miami-dade-work-with/",
      cta: "Open the work-with packet"
    },
    {
      title: "Miami-Dade Code Relief — As-Built Certificate Packet",
      price: "Free",
      body: "Not amnesty. Work commenced before March 1, 2002. Current-code life-safety overlay. Methodology narrative. We do not seal structural soundness of unpermitted work.",
      href: "/miami-dade-code-relief/",
      cta: "Open Code Relief"
    },
    {
      title: "Miami-Dade Envelope Leakage — Blower-Door Packet",
      price: "Free",
      body: "ACH50 = CFM50 × 60 ÷ volume. Prescriptive Climate Zones 1–2: not more than 7 ACH50. Below 3, mechanical ventilation is verified by the building department.",
      href: "/miami-dade-blower-door/",
      cta: "Open the blower-door packet"
    },
    {
      title: "Miami-Dade 40-Year Recertification — Owner Clock Packet",
      price: "Free",
      body: "The envelope is two reports, a parking-lot certificate, and a 90-day clock. Published exemptions. We do not quote County filing fees or fines — they change. Not a County form. EN + ES.",
      href: "/miami-dade-40-year-notice/",
      cta: "Open the owner clock"
    },
    {
      title: "Miami-Dade Electrical Recertification — Field-Prep Packet",
      price: "Free",
      body: "28 County inspection rows plus thermography. Most rows want a photograph. A 1987 panel directory is not the report. We do not invent Article 110 numbers.",
      href: "/uploads/mb-md-electrical-recert-prep-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade MEP Fee Navigator",
      price: "Free",
      body: "Which application you are actually in — change-out, hood, temp power, interceptor. No dollar quotes; County rates change. Electrical Category 31 is not the mechanical permit. Folio 30. EN + ES.",
      href: "/miami-dade-mep-fees/",
      cta: "Open the navigator"
    },
    {
      title: "Miami-Dade Electrical Pre-Upload Packet",
      price: "Free",
      body: "Available fault current on the plan. Working space is shown — we do not invent Article 110 numbers. Exact AC change-out still needs a mechanical permit.",
      href: "/uploads/mb-md-electrical-preupload-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Plumbing Pre-Upload Packet",
      price: "Free",
      body: "A grease interceptor is not a P-trap. Isometrics, slope, backflow, water-heater change-out. Not a copy of the County plumbing guideline.",
      href: "/uploads/mb-md-plumbing-preupload-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Mechanical Pre-Upload Packet",
      price: "Free",
      body: "Original Masterbuild PE packet — not a County form. Occupancy and process first, then outdoor air, grease, garage height, and refrigerant class. The County guideline is a list of titles. This is the order before you upload. Folio 30. EN + ES.",
      href: "/miami-dade-field-packets/",
      cta: "Get the three packets"
    },
    {
      title: "Miami-Dade Mechanical Inspection-Day Packet",
      price: "Free",
      body: "Do not call it on a UP#. Stamped Job Copy on site. Pad 3 in above grade, 42-in guards within 10 ft of the edge, fixed access over 16 ft. Rough before concealment. Not a copy of the County inspection checklist.",
      href: "/uploads/mb-md-mechanical-inspection-day-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Approved as Noted — What Still Binds",
      price: "Free",
      body: "Approved as Noted is not “ignore the notes.” Minor outdoor-air corrections can be noted. Clearances, interlocks, dampers, and rated shafts get drawn. Send the comments PDF, not the County guideline.",
      href: "/uploads/mb-md-approved-as-noted-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Building Plan Review Checklist — Residential",
      price: "Free",
      body: "The county's own residential building review categories (2023 FBC) as a printable checkbox checklist, with PE field notes on the categories that draw the most redlines and a self-score guide before you submit.",
      href: "/uploads/miamidade-building-residential-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Building Plan Review Checklist — Commercial",
      price: "Free",
      body: "The county's own commercial building review categories (2023 FBC) — occupancy, fire protection, egress, accessibility — as a checkbox checklist with PE field notes on the highest-risk categories and a self-score guide.",
      href: "/uploads/miamidade-building-commercial-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Electrical Plan Review Checklist — Residential",
      price: "Free",
      body: "The county's residential electrical review categories (2023 FBC / NEC) as a printable checkbox checklist, with PE field notes on the categories that draw the most redlines and a self-score guide before you submit.",
      href: "/uploads/miamidade-electrical-residential-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Electrical Plan Review Checklist — Commercial",
      price: "Free",
      body: "The county's commercial electrical review categories (2023 FBC / NEC) — service, grounding, emergency/standby systems, fire alarm — as a checkbox checklist with PE field notes and a self-score guide.",
      href: "/uploads/miamidade-electrical-commercial-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Mechanical Plan Review Checklist — Residential",
      price: "Free",
      body: "The county's residential mechanical review categories (2023 FBC) as a printable checkbox checklist, with PE field notes on the categories that draw the most redlines and a self-score guide before you submit.",
      href: "/uploads/miamidade-mechanical-residential-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Mechanical Plan Review Checklist — Commercial",
      price: "Free",
      body: "The county's commercial mechanical review categories (2023 FBC) — ventilation, exhaust, commercial kitchen hoods, boilers, refrigeration — as a checkbox checklist with PE field notes and a self-score guide.",
      href: "/uploads/miamidade-mechanical-commercial-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Plumbing Plan Review Checklist — Residential",
      price: "Free",
      body: "The county's residential plumbing review categories (2023 FBC) as a printable checkbox checklist, with PE field notes on the categories that draw the most redlines and a self-score guide before you submit.",
      href: "/uploads/miamidade-plumbing-residential-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Plumbing Plan Review Checklist — Commercial",
      price: "Free",
      body: "The county's commercial plumbing review categories (2023 FBC) — fixtures, water supply, drainage, venting, fuel-gas piping — as a checkbox checklist with PE field notes and a self-score guide.",
      href: "/uploads/miamidade-plumbing-commercial-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Miami-Dade Septic (OSTDS) Compliance Brief — Type 1 Is Dead",
      price: "Free",
      body: "A dated four-page brief for anyone under contract on a Miami-Dade parcel with no sewer at the street. Conventional Type 1 septic systems are prohibited for new construction and complete replacement (Miami-Dade County Code Sec. 24-42.7(2)); the county also requires 36 inches of separation to the wet-season high water table, 100 feet to surface water and potable wells, and a 15,000 sf minimum land area for a single-family residence on public water. Every requirement is cited and tagged by authority layer — national reference, state rule, or local overlay — with the currency date on every page.",
      href: "/uploads/miamidade-ostds-type-1-is-dead-brief-2026-08-30.pdf",
      cta: "Download the free brief"
    },
    {
      title: "Miami-Dade Septic Parcel Screening Worksheet",
      price: "Free",
      body: "The companion to the brief: a printable three-page worksheet for a parcel with no sanitary sewer at the street. Five gates with write-in fields — sewer availability and feasible distance, minimum land area, the lot-loading test on gross roofed area, 36-inch separation to the wet-season high water table, and setback and reserve-area fit — each with the requirement, its source, and a meets / does not meet / not yet verified decision. Includes the state design-flow table and an evidence log. Fill it in before you call an engineer.",
      href: "/uploads/miamidade-ostds-parcel-screening-worksheet-en-2026-08-30.pdf",
      cta: "Download the free worksheet"
    },
    {
      title: "Miami-Dade Private-Well Record and Permit Readiness Checklist",
      price: "Free",
      body: "A printable record-gathering form for a proposed or existing private well: intended use, public-utility context, construction and completion records, permit-path questions, current laboratory and treatment evidence, and a missing-evidence action log. Use it before a final, sale, renovation, operating question, or scoped diagnostic. It does not determine permit, agency, design, or water-quality status.",
      href: "/uploads/miamidade-private-well-record-permit-readiness-checklist-en-2026-09-04.pdf",
      cta: "Download the free checklist"
    },
    {
      title: "HVAC Load Calculation Review Checklist",
      price: "Free",
      body: "22 load-calculation checkpoints across climate/site, envelope, internal loads, ventilation, and system design, plus a Florida-specific energy-code category, with PE field notes and a Field Diagnostic Quick-Reference for post-occupancy comfort complaints.",
      href: "/uploads/hvac-load-calculation-checklist-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "Home Performance Testing & Closeout Toolkit",
      price: "Free",
      body: "A 10-page field toolkit for homeowners, architects, contractors, and trade partners who need more than a generic pass/fail. Define the test purpose and boundary, compare provider scope, request decision-ready evidence, and document correction or retest closeout for blower-door, duct-leakage, airflow, TAB, or specialty testing.",
      href: "/uploads/home-performance-testing-closeout-toolkit.pdf",
      cta: "Download the free toolkit"
    },
    {
      title: "Florida Building Envelope Compliance Values Quick-Reference",
      price: "Free",
      body: "U-factor, R-value, and SHGC/VT compliance values for roofs, walls, floors, and fenestration across Florida's climate zones (1–3), from the 2024 IGCC Appendix E, which supersedes ASHRAE 90.1 Table 5.5. Organized by occupancy, with PE notes on confirming the adopted edition before an active submittal.",
      href: "/uploads/fl-envelope-compliance-reference-en.pdf",
      cta: "Download the PDF"
    },
    {
      title: "IMC Chapter 1 Permit Process Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 1,
      seriesLabel: "IMC Field Guide Series · Chapter 1 of 7",
      price: RES_PRICE("imcChapter1Guide"),
      body: "A repeatable toolkit for scope, permits, construction documents, inspection sequencing, appeals, violations, and stop-work response.",
      href: RES_IMC_CHAPTER1_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "Permit Readiness Review Pack",
      catalogGroup: "project-tools",
      price: RES_PRICE("permitReadinessPack"),
      body: "Pressure-test a permit set in 45–60 minutes with an evidence matrix, redline traps, issue log, AHJ closure workflow, and final upload gate.",
      href: RES_PERMIT_READINESS_PACK_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "Owner-Side MEP Review Checklist Bundle",
      catalogGroup: "project-tools",
      price: RES_PRICE("ownerSideBundle"),
      body: "Control maintainability, change-order, inspection, cost, schedule, and issue-tracking risk before design decisions become field problems.",
      href: RES_OWNER_SIDE_BUNDLE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapter 4 Ventilation Fundamentals — Free Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 4,
      seriesLabel: "IMC Field Guide Series · Chapter 4 of 7 · Free",
      price: "Free",
      body: "A 16-page field guide for turning Chapter 4 ventilation questions into a documented workflow: establish the project basis, verify ventilation method and outdoor-air delivery, protect intakes, confirm controls, and retain field closeout evidence. Includes a working Compliance Matrix and 40-minute readiness audit. Free to download; verify the adopted code and project conditions.",
      href: "/uploads/ch4-ventilation-fundamentals-free-guide.pdf",
      cta: "Download the free guide"
    },
    {
      title: "IMC 2024 Chapter 5 Exhaust Systems Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 5,
      seriesLabel: "IMC Field Guide Series · Chapter 5 of 7",
      price: RES_PRICE("imcChapter5Guide"),
      body: "Classify before sizing. A 31-page Chapter 5 control system with a Read First file and nine working sheets for exhaust classification, discharge proof, kitchen and common-shaft coordination, hazardous-exhaust screening, responsibility, readiness audit, and closeout.",
      href: RES_IMC_CHAPTER5_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapter 6 Duct Systems Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 6,
      seriesLabel: "IMC Field Guide Series · Chapter 6 of 7",
      price: RES_PRICE("imcChapter6Guide"),
      body: "A 22-page field-first workflow for duct air paths, materials, insulation, sizing, plenum coordination, shafts, protected openings, damper access, coastal salt exposure, and pre-TAB readiness. Includes four printable working tools.",
      href: RES_IMC_CHAPTER6_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapter 7 Combustion Air Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 7,
      seriesLabel: "IMC Field Guide Series · Chapter 7 of 7",
      price: RES_PRICE("imcChapter7Guide"),
      body: "A 21-page field-first workflow for appliance routing, intake sizing, free-area proof at the installed product, damper and firing interlock, rated-route coordination, existing-conditions survey, and new-scope integration gates. Includes a Read First file and eight printable working tools.",
      href: RES_IMC_CHAPTER7_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapters 6 + 7 Bundle — Duct Systems and Combustion Air",
      catalogGroup: "chapters",
      seriesOrder: 8,
      seriesLabel: "IMC Field Guide Series · Chapters 6 + 7 · Save " + RES_BUNDLE_SAVINGS(),
      price: RES_PRICE("imcChapter67Bundle"),
      body: "Both guides in one package: the duct route and the appliance room it serves. 43 pages, two Read First files, twelve printable working tools. " + RES_PRICE("imcChapter67Bundle") + " instead of " + RES_BUNDLE_LIST() + ".",
      href: RES_IMC_CHAPTER67_BUNDLE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapter 8 Chimneys and Vents Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 9,
      seriesLabel: "IMC Field Guide Series \u00b7 Chapter 8",
      price: RES_PRICE("imcChapter8Guide"),
      body: "A 28-page proof system for venting: which document actually governs each appliance, a size basis a reviewer can verify, the four-gate acceptance for an existing chimney, connectors, termination geometry and closeout. Includes a Read First file, eleven printable working tools and a fillable companion workbook.",
      href: RES_IMC_CHAPTER8_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "Combustion Air + Venting Bundle \u2014 IMC 2024 Chapters 7 and 8",
      catalogGroup: "chapters",
      seriesOrder: 10,
      seriesLabel: "IMC Field Guide Series \u00b7 Chapters 7 + 8 \u00b7 Save " + RES_BUNDLE78_SAVINGS(),
      price: RES_PRICE("imcChapter78Bundle"),
      body: "Both halves of the appliance-room conversation: the air the appliance needs to burn, and the system that carries the products of combustion back out. 49 pages, two Read First files, nineteen working tools and the Chapter 8 fillable workbook. " + RES_PRICE("imcChapter78Bundle") + " instead of " + RES_BUNDLE78_LIST() + ".",
      href: RES_IMC_CHAPTER78_BUNDLE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "Ventilation & Special Exhaust Field Guide",
      catalogGroup: "project-tools",
      price: RES_PRICE("ventilationFieldGuide"),
      body: "Review room-by-room ventilation, outdoor-air evidence, special-exhaust classification, drawing proof, controls, and field closeout.",
      href: RES_VENTILATION_FIELD_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC Chapter 2 Definitions & Redline Prevention Field Guide",
      catalogGroup: "chapters",
      seriesOrder: 2,
      seriesLabel: "IMC Field Guide Series · Chapter 2 of 7",
      price: RES_PRICE("imcChapter2Guide"),
      body: "Use the 19-page field guide, Definition Control Matrix, 30-minute pre-submittal audit, and field change/dispute record to identify definition-sensitive terms, trace what they activate, and close redline risk before issue.",
      href: RES_IMC_CHAPTER2_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "IMC 2024 Chapter 3 Installation Readiness & Field Coordination Guide",
      catalogGroup: "chapters",
      seriesOrder: 3,
      seriesLabel: "IMC Field Guide Series · Chapter 3 of 7",
      price: RES_PRICE("imcChapter3Guide"),
      body: "Use the 19-page field guide, Equipment Approval and Location Matrix, Structure and Rated-Assembly Coordination Record, 45-Minute Installation Readiness Audit, and Field Change Stop / Proceed Workflow to resolve material installation risk before procurement, concealment, or startup.",
      href: RES_IMC_CHAPTER3_GUIDE_URL,
      cta: "Buy securely with Stripe"
    },
    {
      title: "PE-Led Project Review",
      catalogGroup: "project-tools",
      price: "Written scope",
      body: "Use a separate consulting engagement when the decision depends on adopted code, project drawings, field conditions, listings, AHJ strategy, or sealed work.",
      href: "/send/",
      cta: "Send project background"
    }
  ],
  es: [
    {
      title: "Archivo Gratis + Lista Code Desk",
      price: "Gratis",
      body: "Busque el archivo bilingüe de Daily Code Talk (IMC + NEC) y únase a la lista gratuita para recibir notas útiles de código, QA de campo y recursos cuando se publiquen.",
      href: RES_SUBSCRIBE_PAGE(),
      cta: "Unirse a la lista gratuita"
    },
    {
      title: "Glosario del Artículo 100 del NEC",
      price: "Gratis",
      body: "Definiciones del Artículo 100 del NEC en lenguaje claro y buscable, con notas de campo sobre dónde afecta cada una un juego de permiso. Bilingüe, archivo en crecimiento.",
      href: "/glossary/",
      cta: "Ver el glosario"
    },
    {
      title: "Glosario del NEC — PDF Descargable",
      price: "Gratis",
      body: "Las 209 definiciones del Artículo 100 del NEC en un PDF con la marca de Masterbuild — guárdelo, imprímalo, o téngalo en la tablet en campo. Edición en español.",
      href: "/uploads/nec-glossary-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Glosario de Definiciones Sección 202 del IMC",
      price: "Gratis",
      body: "Las 219 definiciones de la Sección 202 del IMC, en lenguaje claro y buscable, con notas de campo sobre dónde afecta cada una un juego de permiso. Bilingüe.",
      href: "/imc-glossary/",
      cta: "Ver el glosario"
    },
    {
      title: "Glosario del IMC — PDF Descargable",
      price: "Gratis",
      body: "Las 219 definiciones de la Sección 202 del IMC en un PDF con la marca de Masterbuild — guárdelo, imprímalo, o téngalo en la tablet en campo. Edición en español.",
      href: "/uploads/imc-glossary-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Fuga de ductos Miami-Dade",
      price: "Gratis",
      body: "No es un blower-door. Rough-in o post-construcción. Las excepciones se escriben en los formularios de energía.",
      href: "/fuga-de-ductos-miami-dade/",
      cta: "Abrir fuga de ductos"
    },
    {
      title: "Aviso de Commencement Miami-Dade",
      price: "Gratis",
      body: "Es una grabación, no un permiso. Firma el dueño. Confirme FBC 105.8 vivo. No discuta con el inspector usando nuestro PDF.",
      href: "/aviso-de-commencement-miami-dade/",
      cta: "Abrir el NOC"
    },
    {
      title: "Change-out mecánico Miami-Dade — final",
      price: "Gratis",
      body: "La placa en la losa tiene que ser el equipo que se calculó. Condensado que termina. Retorno que existe.",
      href: "/change-out-mecanico-miami-dade/",
      cta: "Abrir change-out"
    },
    {
      title: "Inspección de plomería Miami-Dade — el día de",
      price: "Gratis",
      body: "Usted inspecciona primero. Un plato lleno es una prueba. Sin medidor no hay final.",
      href: "/inspeccion-de-plomeria-miami-dade/",
      cta: "Abrir el paquete"
    },
    {
      title: "Inspección eléctrica Miami-Dade — el día de",
      price: "Gratis",
      body: "El espacio de trabajo se muestra. El cuarto eléctrico no es un closet. No inventamos cotas del Artículo 110.",
      href: "/inspeccion-electrica-miami-dade/",
      cta: "Abrir el paquete"
    },
    {
      title: "Bomberos Miami-Dade — segundo escritorio",
      price: "Gratis",
      body: "El permiso mecánico no paga Bomberos. Sin cotizar dólares. Campana, alarma y supresión no van incluidos en mecánico.",
      href: "/escritorio-de-bomberos-miami-dade/",
      cta: "Abrir Bomberos"
    },
    {
      title: "Work-with eléctrico Miami-Dade",
      price: "Gratis",
      body: "Un work-with no es un servicio nuevo. Reloj de 30 días. Acceso a todos los paneles. No en obra nueva.",
      href: "/work-with-miami-dade/",
      cta: "Abrir el paquete"
    },
    {
      title: "Code Relief Miami-Dade — certificado as-built",
      price: "Gratis",
      body: "No es amnistía. Obra antes del 1 de marzo de 2002. Overlay de vida-seguridad vigente. No sellamos la solidez estructural de obra sin permiso.",
      href: "/code-relief-miami-dade/",
      cta: "Abrir Code Relief"
    },
    {
      title: "Blower-door Miami-Dade — ACH50",
      price: "Gratis",
      body: "ACH50 = CFM50 × 60 ÷ volumen. Prescriptivo zonas 1 y 2: no más de 7 ACH50. Menos de 3 pide ventilación mecánica.",
      href: "/blower-door-miami-dade/",
      cta: "Abrir el paquete"
    },
    {
      title: "Recertificación 40 años Miami-Dade — reloj del dueño",
      price: "Gratis",
      body: "El sobre son dos informes, un certificado de estacionamiento y 90 días. Exenciones publicadas. No cotizamos tarifas ni multas del Condado. No es un formulario del Condado.",
      href: "/aviso-40-anos-miami-dade/",
      cta: "Abrir el reloj"
    },
    {
      title: "Recertificación eléctrica Miami-Dade — preparación de campo",
      price: "Gratis",
      body: "28 filas del Condado más termografía. Un directorio de 1987 no es el informe. No inventamos cotas del Artículo 110.",
      href: "/uploads/mb-md-electrical-recert-prep-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Navegador de tarifas MEP Miami-Dade",
      price: "Gratis",
      body: "Qué solicitud es realmente — change-out, campana, temporal, interceptor. Sin cotizar dólares. La Categoría 31 eléctrica no es el permiso mecánico. Folio 30.",
      href: "/tarifas-mep-miami-dade/",
      cta: "Abrir el navegador"
    },
    {
      title: "Paquete eléctrico Miami-Dade — antes de subir",
      price: "Gratis",
      body: "Corriente de falla disponible en el plano. No inventamos las cotas del Artículo 110. El change-out de AC sigue pidiendo permiso mecánico.",
      href: "/uploads/mb-md-electrical-preupload-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Paquete de plomería Miami-Dade — antes de subir",
      price: "Gratis",
      body: "Un interceptor de grasa no es un P-trap. Isométricos, pendiente, backflow. No es una copia de la guía del Condado.",
      href: "/uploads/mb-md-plumbing-preupload-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Paquete mecánico Miami-Dade — antes de subir",
      price: "Gratis",
      body: "Paquete original Masterbuild — no es un formulario del Condado. Proceso primero, luego aire exterior, grasa, altura en garaje y clase de refrigerante. Folio 30. EN + ES.",
      href: "/paquetes-de-campo-miami-dade/",
      cta: "Obtener los tres paquetes"
    },
    {
      title: "Paquete de inspección mecánica Miami-Dade",
      price: "Gratis",
      body: "No llame con un UP#. Job Copy sellado en el sitio. Pad, barandas, acceso. No es una copia de la lista de inspección del Condado.",
      href: "/uploads/mb-md-mechanical-inspection-day-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Approved as Noted Miami-Dade — lo que sigue obligando",
      price: "Gratis",
      body: "Approved as Noted no es ignorar las notas. Holguras, interlocks y dampers se dibujan. Envíe el PDF de comentarios, no la guía del Condado.",
      href: "/uploads/mb-md-approved-as-noted-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación de Edificación de Miami-Dade — Residencial",
      price: "Gratis",
      body: "Las categorías de revisión de edificación residencial del condado (FBC 2023) como lista imprimible con casillas, con notas de campo de un PE sobre las categorías que más correcciones generan y una guía de autoevaluación antes de presentar.",
      href: "/uploads/miamidade-building-residential-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación de Edificación de Miami-Dade — Comercial",
      price: "Gratis",
      body: "Las categorías de revisión de edificación comercial del condado (FBC 2023) — ocupación, protección contra incendios, salida, accesibilidad — como lista con casillas, notas de campo de un PE sobre las categorías de mayor riesgo y guía de autoevaluación.",
      href: "/uploads/miamidade-building-commercial-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación Eléctrica de Miami-Dade — Residencial",
      price: "Gratis",
      body: "Las categorías de revisión eléctrica residencial del condado (FBC 2023 / NEC) como lista imprimible con casillas, con notas de campo de un PE sobre las categorías que más correcciones generan y una guía de autoevaluación antes de presentar.",
      href: "/uploads/miamidade-electrical-residential-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación Eléctrica de Miami-Dade — Comercial",
      price: "Gratis",
      body: "Las categorías de revisión eléctrica comercial del condado (FBC 2023 / NEC) — servicio, puesta a tierra, sistemas de emergencia/respaldo, alarma contra incendios — como lista con casillas, notas de campo de un PE y guía de autoevaluación.",
      href: "/uploads/miamidade-electrical-commercial-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación Mecánica de Miami-Dade — Residencial",
      price: "Gratis",
      body: "Las categorías de revisión mecánica residencial del condado (FBC 2023) como lista imprimible con casillas, con notas de campo de un PE sobre las categorías que más correcciones generan y una guía de autoevaluación antes de presentar.",
      href: "/uploads/miamidade-mechanical-residential-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación Mecánica de Miami-Dade — Comercial",
      price: "Gratis",
      body: "Las categorías de revisión mecánica comercial del condado (FBC 2023) — ventilación, extracción, campanas de cocina comercial, calderas, refrigeración — como lista con casillas, notas de campo de un PE y guía de autoevaluación.",
      href: "/uploads/miamidade-mechanical-commercial-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación de Plomería de Miami-Dade — Residencial",
      price: "Gratis",
      body: "Las categorías de revisión de plomería residencial del condado (FBC 2023) como lista imprimible con casillas, con notas de campo de un PE sobre las categorías que más correcciones generan y una guía de autoevaluación antes de presentar.",
      href: "/uploads/miamidade-plumbing-residential-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Lista de Verificación de Plomería de Miami-Dade — Comercial",
      price: "Gratis",
      body: "Las categorías de revisión de plomería comercial del condado (FBC 2023) — accesorios, suministro de agua, drenaje, venteo, tubería de gas combustible — como lista con casillas, notas de campo de un PE y guía de autoevaluación.",
      href: "/uploads/miamidade-plumbing-commercial-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Resumen de Cumplimiento Séptico (OSTDS) de Miami-Dade — Type 1 Is Dead",
      price: "Gratis",
      body: "Resumen fechado de cuatro páginas para quien esté bajo contrato en un lote de Miami-Dade sin alcantarillado en la calle. Los sistemas sépticos convencionales (Tipo 1) están prohibidos para obra nueva y reemplazo completo (Código del Condado de Miami-Dade Sec. 24-42.7(2)); el condado también exige 36 pulgadas de separación al nivel freático alto de temporada húmeda, 100 pies a aguas superficiales y pozos potables, y un área mínima de 15,000 pies cuadrados para una residencia unifamiliar con agua pública. Cada requisito está citado y etiquetado por capa de autoridad, con la fecha de vigencia en cada página. Edición en inglés.",
      href: "/uploads/miamidade-ostds-type-1-is-dead-brief-2026-08-30.pdf",
      cta: "Descargar el resumen gratuito (inglés)"
    },
    {
      title: "Hoja de Evaluación Séptica de Lote — Miami-Dade",
      price: "Gratis",
      body: "El complemento del resumen: una hoja imprimible de tres páginas para un lote sin alcantarillado sanitario en la calle. Cinco compuertas con campos para completar — disponibilidad de alcantarillado y distancia factible, área mínima de terreno, la prueba de carga sobre el área techada bruta, 36 pulgadas de separación al nivel freático alto, y el ajuste de retiros y área de reserva — cada una con el requisito, su fuente y una decisión de cumple / no cumple / sin verificar. Incluye la tabla estatal de flujo de diseño y un registro de evidencia. Edición en español.",
      href: "/uploads/miamidade-ostds-parcel-screening-worksheet-es-2026-08-30.pdf",
      cta: "Descargar la hoja gratuita"
    },
    {
      title: "Lista de Preparación de Registros y Permisos de Pozos Privados — Miami-Dade",
      price: "Gratis",
      body: "Formulario imprimible para reunir registros de un pozo privado propuesto o existente: uso previsto, contexto de servicios públicos, registros de construcción y terminación, preguntas de ruta de permisos, evidencia de laboratorio y tratamiento, y registro de acción para evidencia faltante. Úselo antes de un final, venta, remodelación, pregunta de operación o diagnóstico de alcance. No determina permiso, agencia, diseño ni estado de calidad de agua.",
      href: "/uploads/miamidade-private-well-record-permit-readiness-checklist-es-2026-09-04.pdf",
      cta: "Descargar la lista gratuita"
    },
    {
      title: "Lista de Revisión de Cálculo de Cargas de HVAC",
      price: "Gratis",
      body: "22 puntos de verificación de cálculo de cargas en clima/sitio, envolvente, cargas internas, ventilación y diseño del sistema, más una categoría de código de energía de Florida, con notas de campo de un PE y una Referencia Rápida de Diagnóstico de Campo para reclamos de confort posteriores a la ocupación.",
      href: "/uploads/hvac-load-calculation-checklist-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Kit de Pruebas y Cierre de Desempeño HVAC",
      price: "Gratis",
      body: "Kit de campo de 10 páginas para propietarios, arquitectos, contratistas y socios de oficio que necesitan más que un resultado genérico de aprobado/reprobado. Defina el propósito y límite de la prueba, compare el alcance del proveedor, solicite evidencia útil para decisiones y documente correcciones o repruebas para pruebas de blower-door, fugas de ductos, flujo de aire, TAB o sistemas especializados. Edición en inglés.",
      href: "/uploads/home-performance-testing-closeout-toolkit.pdf",
      cta: "Descargar el kit gratuito (inglés)"
    },
    {
      title: "Referencia Rápida de Valores de Cumplimiento de la Envolvente en Florida",
      price: "Gratis",
      body: "Valores de cumplimiento de factor U, valor R y SHGC/VT para techos, muros, pisos y fenestración en las zonas climáticas de Florida (1–3), del Apéndice E del IGCC 2024, que sustituye la Tabla 5.5 de ASHRAE 90.1. Organizado por ocupación, con notas de un PE sobre confirmar la edición vigente antes de una presentación activa.",
      href: "/uploads/fl-envelope-compliance-reference-es.pdf",
      cta: "Descargar el PDF"
    },
    {
      title: "Guía de Permisos IMC Capítulo 1",
      catalogGroup: "chapters",
      seriesOrder: 1,
      seriesLabel: "Serie de Guías IMC · Capítulo 1 de 7",
      price: RES_PRICE("imcChapter1Guide"),
      body: "Un sistema repetible para alcance, permisos, documentos, inspecciones, apelaciones, violaciones y respuesta a stop-work.",
      href: RES_IMC_CHAPTER1_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Paquete de Revisión Permit Readiness",
      catalogGroup: "project-tools",
      price: RES_PRICE("permitReadinessPack"),
      body: "Someta a presión un juego en 45–60 minutos con matriz de evidencia, trampas de comentarios, issue log, cierre AHJ y compuerta final de entrega.",
      href: RES_PERMIT_READINESS_PACK_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Paquete de Checklists MEP para Propietarios",
      catalogGroup: "project-tools",
      price: RES_PRICE("ownerSideBundle"),
      body: "Controle mantenimiento, órdenes de cambio, inspección, costo, plazo y seguimiento antes de que las decisiones se vuelvan problemas de campo.",
      href: RES_OWNER_SIDE_BUNDLE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Fundamentos de Ventilación IMC 2024 Capítulo 4 — Guía de Campo Gratis",
      catalogGroup: "chapters",
      seriesOrder: 4,
      seriesLabel: "Serie de Guías IMC · Capítulo 4 de 7 · Gratis",
      price: "Gratis",
      body: "Una guía de campo de 16 páginas para convertir preguntas de ventilación del Capítulo 4 en un flujo documentado: establezca la base del proyecto, verifique el método de ventilación y la entrega de aire exterior, proteja las tomas, confirme controles y conserve evidencia de cierre. Incluye una Matriz de Cumplimiento y una auditoría de preparación de 40 minutos. Descarga gratuita; verifique el código adoptado y las condiciones del proyecto.",
      href: "/uploads/ch4-ventilation-fundamentals-free-guide.pdf",
      cta: "Descargar la guía gratis"
    },
    {
      title: "Guía de Campo de Sistemas de Extracción — IMC 2024 Capítulo 5",
      catalogGroup: "chapters",
      seriesOrder: 5,
      seriesLabel: "Serie de Guías IMC · Capítulo 5 de 7",
      price: RES_PRICE("imcChapter5Guide"),
      body: "Clasifique antes de dimensionar. Un sistema de control del Capítulo 5 de 31 páginas, archivo Read First y nueve hojas de trabajo para clasificación, prueba de descarga, coordinación de cocina y ductos comunes, análisis de extracción peligrosa, responsabilidades, auditoría y cierre.",
      href: RES_IMC_CHAPTER5_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Guía de Campo de Sistemas de Ductos — IMC 2024 Capítulo 6",
      catalogGroup: "chapters",
      seriesOrder: 6,
      seriesLabel: "Serie de Guías IMC · Capítulo 6 de 7",
      price: RES_PRICE("imcChapter6Guide"),
      body: "Un flujo orientado al campo de 22 páginas para rutas de aire, materiales, aislamiento, dimensionamiento, plénums, shafts, aberturas protegidas, acceso a dampers, exposición costera a sal y preparación pre-TAB. Incluye cuatro herramientas imprimibles.",
      href: RES_IMC_CHAPTER6_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Guía de Campo de Aire de Combustión — IMC 2024 Capítulo 7",
      catalogGroup: "chapters",
      seriesOrder: 7,
      seriesLabel: "Serie de Guías IMC · Capítulo 7 de 7",
      price: RES_PRICE("imcChapter7Guide"),
      body: "Un flujo orientado al campo de 21 páginas para enrutamiento de equipos, dimensionamiento de la toma, prueba de área libre en el producto instalado, enclavamiento de dampers con el encendido, coordinación de rutas clasificadas, levantamiento de condiciones existentes y compuertas de integración de alcance nuevo. Incluye un archivo Read First y ocho herramientas imprimibles.",
      href: RES_IMC_CHAPTER7_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Paquete IMC 2024 Capítulos 6 + 7 — Ductos y Aire de Combustión",
      catalogGroup: "chapters",
      seriesOrder: 8,
      seriesLabel: "Serie de Guías IMC · Capítulos 6 + 7 · Ahorre " + RES_BUNDLE_SAVINGS(),
      price: RES_PRICE("imcChapter67Bundle"),
      body: "Ambas guías en un solo paquete: la ruta del ducto y el cuarto de equipos al que sirve. 43 páginas, dos archivos Read First, doce herramientas imprimibles. " + RES_PRICE("imcChapter67Bundle") + " en vez de " + RES_BUNDLE_LIST() + ".",
      href: RES_IMC_CHAPTER67_BUNDLE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Gu\u00eda de Campo de Chimeneas y Venteos \u2014 IMC 2024 Cap\u00edtulo 8",
      catalogGroup: "chapters",
      seriesOrder: 9,
      seriesLabel: "Serie de Gu\u00edas IMC \u00b7 Cap\u00edtulo 8",
      price: RES_PRICE("imcChapter8Guide"),
      body: "Un sistema de prueba de 28 p\u00e1ginas para el venteo: qu\u00e9 documento gobierna cada equipo, una base de tama\u00f1o verificable, la aceptaci\u00f3n por cuatro compuertas de una chimenea existente, conectores, geometr\u00eda de terminaci\u00f3n y cierre. Incluye archivo Read First, once herramientas imprimibles y un libro de trabajo llenable.",
      href: RES_IMC_CHAPTER8_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Paquete Aire de Combusti\u00f3n + Venteo \u2014 IMC 2024 Cap\u00edtulos 7 y 8",
      catalogGroup: "chapters",
      seriesOrder: 10,
      seriesLabel: "Serie de Gu\u00edas IMC \u00b7 Cap\u00edtulos 7 + 8 \u00b7 Ahorre " + RES_BUNDLE78_SAVINGS(),
      price: RES_PRICE("imcChapter78Bundle"),
      body: "Ambas mitades de la conversaci\u00f3n del cuarto de equipos: el aire que el equipo necesita para quemar, y el sistema que saca los productos de la combusti\u00f3n. 49 p\u00e1ginas, dos archivos Read First, diecinueve herramientas y el libro de trabajo llenable del Cap\u00edtulo 8. " + RES_PRICE("imcChapter78Bundle") + " en vez de " + RES_BUNDLE78_LIST() + ".",
      href: RES_IMC_CHAPTER78_BUNDLE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Guía de Ventilación y Extracción Especial",
      catalogGroup: "project-tools",
      price: RES_PRICE("ventilationFieldGuide"),
      body: "Revise ventilación por recinto, evidencia de aire exterior, clasificación de extracción, prueba en planos, controles y cierre de campo.",
      href: RES_VENTILATION_FIELD_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Guía de Definiciones y Prevención de Redlines IMC Capítulo 2",
      catalogGroup: "chapters",
      seriesOrder: 2,
      seriesLabel: "Serie de Guías IMC · Capítulo 2 de 7",
      price: RES_PRICE("imcChapter2Guide"),
      body: "Use la guía de campo de 19 páginas, la Matriz de Control de Definiciones, la auditoría previa de 30 minutos y el registro de cambios/disputas de campo para identificar términos sensibles, rastrear lo que activan y cerrar riesgos antes de emitir.",
      href: RES_IMC_CHAPTER2_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Guía de Preparación para Instalación y Coordinación de Campo IMC 2024 Capítulo 3",
      catalogGroup: "chapters",
      seriesOrder: 3,
      seriesLabel: "Serie de Guías IMC · Capítulo 3 de 7",
      price: RES_PRICE("imcChapter3Guide"),
      body: "Use la guía de campo de 19 páginas, la Matriz de Aprobación y Ubicación de Equipos, el Registro de Coordinación Estructural y de Ensamblajes Clasificados, la Auditoría de Preparación de 45 Minutos y el Flujo de Detener / Proceder para Cambios de Campo para resolver riesgos materiales de instalación antes de compra, cierre o arranque.",
      href: RES_IMC_CHAPTER3_GUIDE_URL,
      cta: "Comprar de forma segura con Stripe"
    },
    {
      title: "Revisión de Proyecto Liderada por PE",
      catalogGroup: "project-tools",
      price: "Alcance escrito",
      body: "Use un compromiso separado cuando la decisión dependa del código adoptado, planos, campo, listados, estrategia AHJ o trabajo sellado.",
      href: "/contacto/",
      cta: "Enviar información del proyecto"
    }
  ]
};

const CH1_INCLUDED_EN = [
  "Core Chapter 1 guide — plain-language breakdowns for all 15 sections",
  "Permit readiness checklist",
  "Construction document review kit with common redline triggers",
  "Inspection hold and test witness checklist",
  "Appeal prep outline and appeal brief template",
  "Violation response playbook with email template",
  "Stop-work response kit with correction log",
  "Utility energization and temporary systems checklists",
  "Permit fee and valuation worksheet",
  "Notice of approval closeout checklist"
];
const CH1_INCLUDED_ES = [
  "Guía central Capítulo 1 — explicaciones claras para las 15 secciones",
  "Checklist de preparación para permisos",
  "Kit de revisión de documentos con disparadores comunes de redline",
  "Checklist de parada de inspección y testigo de pruebas",
  "Esquema de apelación y plantilla de brief",
  "Manual de respuesta a violaciones con plantilla de email",
  "Kit de respuesta a paro de trabajo con registro de correcciones",
  "Checklists de energización y sistemas temporales",
  "Hoja de tarifas y valoración de permisos",
  "Checklist de cierre de aprobación"
];
const CH2_INCLUDED_EN = [
  "Core Chapter 2 guide — definition-sensitive terms across every IMC Chapter 2 risk cluster",
  "Definition Control Matrix",
  "30-Minute Pre-Submittal Definition Audit",
  "Field Change & Definition Dispute Record",
  "Duct, plenum, air distribution, and access classification coverage",
  "Fire and smoke device coordination coverage",
  "Commercial kitchen, combustion, and venting term coverage",
  "Hazardous/process exhaust and refrigeration/specialty systems coverage",
  "Key terms and escalation-trigger language highlighted throughout"
];
const CH2_INCLUDED_ES = [
  "Guía central del Capítulo 2 — términos sensibles a definición en cada grupo de riesgo del Capítulo 2 del IMC",
  "Matriz de Control de Definiciones",
  "Auditoría de Definiciones Pre-Entrega de 30 Minutos",
  "Registro de Cambio de Campo y Disputa de Definición",
  "Cobertura de ductos, plenums, distribución de aire y acceso",
  "Cobertura de coordinación de dispositivos de fuego y humo",
  "Cobertura de cocinas comerciales, combustión y venteo",
  "Cobertura de escape de proceso/peligroso y sistemas de refrigeración/especialidad",
  "Términos clave y lenguaje de disparadores de escalamiento resaltados en todo el documento"
];
const CH3_INCLUDED_EN = [
  "Core Chapter 3 guide — installation-readiness workflow across IMC Sections 301-312",
  "Equipment Approval and Location Matrix",
  "Structure and Rated-Assembly Coordination Record",
  "45-Minute Installation Readiness Audit",
  "Field Change Stop / Proceed Workflow",
  "Approval, identification, and interface proof-chain checklist (IMC 301)",
  "Structure and rated-assembly coordination checklist (IMC 302)",
  "Installation, clearance, and piping support checklists (IMC 304-305)",
  "Access, condensate, and specialty/load-escalation gate checklist (IMC 306-312)"
];
const CH3_INCLUDED_ES = [
  "Guía central del Capítulo 3 — flujo de preparación para instalación en las Secciones 301-312 del IMC",
  "Matriz de Aprobación y Ubicación de Equipos",
  "Registro de Coordinación Estructural y de Ensamblajes Clasificados",
  "Auditoría de Preparación de Instalación de 45 Minutos",
  "Flujo de Detener / Proceder para Cambios de Campo",
  "Checklist de cadena de prueba de aprobación, identificación e interfaces (IMC 301)",
  "Checklist de coordinación de estructura y ensamblajes clasificados (IMC 302)",
  "Checklists de instalación, holguras y soporte de tuberías (IMC 304-305)",
  "Checklist de acceso, condensado y compuerta de especialidad/escalamiento de carga (IMC 306-312)"
];

const PERMIT_INCLUDED_EN = [
  "Core Permit Readiness Review Pack \u2014 19-page pre-upload, resubmittal, and field-readiness system",
  "Project-basis intake and authority-routing workflow",
  "Cross-discipline gates: building, MEP, structural, zoning, and WASD controls",
  "Evidence matrix and redline-trap identification",
  "Selective coordination checklist across disciplines",
  "Issue log and AHJ closure workflow",
  "Final upload-gate decision framework: ready, ready with disclosed exceptions, or hold",
  "Miami-Dade / Florida source map",
  "Built for a 45\u201360 minute review of a typical permit set"
];
const PERMIT_INCLUDED_ES = [
  "Paquete Permit Readiness completo \u2014 sistema de 19 p\u00e1ginas para revisi\u00f3n antes de carga y reenv\u00edo",
  "Flujo de base de proyecto y ruta de autoridades",
  "Controles multidisciplinarios: edificaci\u00f3n, MEP, estructura, zonificaci\u00f3n y WASD",
  "Matriz de evidencia e identificaci\u00f3n de trampas de redline",
  "Checklist de coordinaci\u00f3n selectiva entre disciplinas",
  "Registro de asuntos y flujo de cierre con el AHJ",
  "Marco de decisi\u00f3n final: listo, listo con excepciones documentadas, o en espera",
  "Mapa de fuentes de Miami-Dade / Florida",
  "Dise\u00f1ado para revisar un juego de permisos t\u00edpico en 45\u201360 minutos"
];
const OWNER_INCLUDED_EN = [
  "Core Owner-Side MEP Review Checklist Bundle \u2014 30-minute owner-side review system",
  "Maintainability risk-control checklist",
  "Permit-control checkpoints",
  "Change-order exposure guardrails",
  "Inspection-failure risk checklist",
  "Cost and schedule guardrails",
  "Red-flag language reference for contracts and submittals",
  "Issue-tracking log",
  "Built for owners, developers, and project executives reviewing decisions before they become field problems"
];
const OWNER_INCLUDED_ES = [
  "Paquete Owner-Side MEP completo \u2014 sistema de revisi\u00f3n del propietario de 30 minutos",
  "Checklist de control de riesgo de mantenimiento",
  "Puntos de control de permiso",
  "L\u00edmites de exposici\u00f3n a \u00f3rdenes de cambio",
  "Checklist de riesgo de fallas de inspecci\u00f3n",
  "L\u00edmites de costo y plazo",
  "Referencia de lenguaje de alerta para contratos y entregas",
  "Registro de seguimiento de asuntos",
  "Dise\u00f1ado para propietarios, desarrolladores y ejecutivos de proyecto que revisan decisiones antes de que se conviertan en problemas de campo"
];
const CH4_INCLUDED_EN = [
  "Complete 16-page Chapter 4 ventilation field guide - free to download",
  "Project-basis gate for adopted-code, amendment, permit, and AHJ verification",
  "Sections 401-407 workflow: general, natural, mechanical, garage, controls, uninhabited-space, and healthcare escalation paths",
  "Outdoor-air and breathing-zone evidence prompts, including VAV, recirculation, and transfer-air checks",
  "Working Ventilation & Outdoor Air Compliance Matrix",
  "Pre-TAB / pre-occupancy Outdoor Air & Controls Verification Record",
  "40-Minute Ventilation & IAQ Readiness Audit and red-item stop list",
  "Field Change Stop / Proceed workflow for scope, evidence, and closeout control",
  "Clear boundary between free Chapter 4 guidance and the separate special-exhaust review guide"
];
const CH4_INCLUDED_ES = [
  "Guía de campo completa de 16 páginas del Capítulo 4 - descarga gratuita",
  "Compuerta de base del proyecto para verificar código adoptado, enmiendas, permiso y AHJ",
  "Flujo de las Secciones 401-407: ventilación general, natural y mecánica, garajes, controles, espacios no habitados y escalamiento de salud",
  "Indicadores de evidencia de aire exterior y zona de respiración, incluidos controles VAV, recirculación y aire de transferencia",
  "Matriz de Cumplimiento de Ventilación y Aire Exterior",
  "Registro de Verificación de Aire Exterior y Controles antes de TAB / ocupación",
  "Auditoría de Preparación de Ventilación e IAQ de 40 Minutos y lista de puntos rojos",
  "Flujo de Detener / Proceder para cambios de campo, evidencia y cierre",
  "Límite claro entre la guía gratis del Capítulo 4 y la guía separada de extracción especial"
];

const CH5_INCLUDED_EN = [
  "31-page IMC 2024 Chapter 5 Exhaust Systems Field Guide plus a 3-page Read First file",
  "Project-basis gate and thirteen-class Exhaust System Classification Gate",
  "Sections 501-513 workflow checks: control, proof location, failure mode, and escalation trigger",
  "Nine working sheets plus Read Me: register, discharge/intake proof, kitchen and common-shaft coordination, hazardous-exhaust screening, responsibility, audit, and closeout",
  "Existing-building, tenant-improvement, and change-of-use exhaust triage",
  "Who Owns What responsibility matrix for scope and fee protection",
  "60-Minute Exhaust Readiness Audit, red-item stop list, and field-change stop/proceed workflow",
  "Pre-occupancy closeout record for acceptance and retained evidence",
  "Single-user license; firmwide or multi-office use requires written scope",
  "Pairs with the Ventilation & Special Exhaust Field Guide for fast plan-review triage of someone else's submittal",
  "Pairs with the IMC 2024 Chapter 7 Combustion Air Field Guide when exhaust operation can pull an appliance room negative"
];
const CH5_INCLUDED_ES = [
  "Guía de campo de 31 páginas del Capítulo 5 IMC 2024 más archivo Read First de 3 páginas",
  "Compuerta de base del proyecto y Compuerta de Clasificación con trece clases de extracción",
  "Flujos de las Secciones 501-513: control, ubicación de prueba, modo de falla y disparador de escalamiento",
  "Nueve hojas de trabajo más Read Me: registro, prueba de descarga/toma, coordinación de cocina y ductos comunes, análisis de extracción peligrosa, responsabilidades, auditoría y cierre",
  "Triage para edificios existentes, mejoras de inquilino y cambio de uso",
  "Matriz Who Owns What para proteger alcance y honorarios",
  "Auditoría de Preparación de Extracción de 60 Minutos, lista de puntos rojos y flujo de Detener/Proceder",
  "Registro de cierre previo a ocupación para aceptación y evidencia retenida",
  "Licencia de usuario único; uso de firma o varias oficinas requiere alcance escrito",
  "Se complementa con la Gu\u00eda de Ventilaci\u00f3n y Extracci\u00f3n Especial para triage r\u00e1pido de revisi\u00f3n de planos de entregas de terceros",
  "Se complementa con la Gu\u00eda del Cap\u00edtulo 7 de Aire de Combusti\u00f3n cuando la extracci\u00f3n puede dejar en presi\u00f3n negativa un cuarto de equipos"
];
const CH6_INCLUDED_EN = [
  "22-page IMC 2024 Chapter 6 Duct Systems Field Guide",
  "Duct material, insulation, pressure, support, access, plenum, and shaft coordination screens",
  "Coastal and salt-exposure durability pass for corrosion, water paths, interfaces, and maintainability",
  "Four printable working tools: system/material register, plenum pass, protected-opening/damper matrix, and 60-minute pre-TAB audit",
  "Pairs with the Chapter 5 Exhaust Systems guide where duct runs carry exhaust, and with Chapter 3 for installation-readiness coordination",
  "Pairs with the IMC 2024 Chapter 7 Combustion Air Field Guide where a combustion-air duct crosses a rated boundary - available together as the Chapters 6 + 7 bundle"
];
const CH6_INCLUDED_ES = [
  "Guía de Campo de Sistemas de Ductos IMC 2024 Capítulo 6 de 22 páginas",
  "Filtros de coordinación para material, aislamiento, presión, soportes, acceso, plénums y shafts",
  "Pase de durabilidad costera y exposición a sal para corrosión, rutas de agua, interfaces y mantenibilidad",
  "Cuatro herramientas imprimibles: registro de sistema/material, pase de plénum, matriz de aberturas/dampers y auditoría pre-TAB de 60 minutos",
  "Se complementa con la gu\u00eda del Cap\u00edtulo 5 donde los ductos transportan extracci\u00f3n, y con el Cap\u00edtulo 3 para coordinaci\u00f3n de preparaci\u00f3n de instalaci\u00f3n",
  "Se complementa con la Gu\u00eda del Cap\u00edtulo 7 de Aire de Combusti\u00f3n donde un ducto de aire de combusti\u00f3n cruza una barrera clasificada - disponibles juntas en el paquete Cap\u00edtulos 6 + 7"
];

const CH7_INCLUDED_EN = [
  "21-page IMC 2024 Chapter 7 Combustion Air Field Guide plus a 3-page Read First",
  "Intake sizing method: the selection tree, the required inputs, and the eight-line required-to-installed arithmetic chain that survives plan review",
  "Recommendations and typical product behavior for louver blade type, screens, grilles, ducted routes, dampers and terminations",
  "Existing-conditions field survey protocol: what to confirm at every appliance and opening, what evidence to keep, and the as-found rule",
  "New-scope integration gates: the seven changes that force a re-evaluation, the rules for crediting an existing opening, and nine go / no-go gates",
  "Damper command, proof-of-open, firing permissive and loss-of-proof response - written so it can be tested, not just drawn",
  "Eight printable working tools including the intake sizing worksheet, existing-conditions survey record and integration go / no-go record",
  "Routes gas-fired, oil-fired, solid-fuel, fireplace and direct-vent appliances to their correct controlling source instead of one generic opening rule",
  "Single-user license; firmwide, multi-office and site-wide licensing available separately"
];
const CH7_INCLUDED_ES = [
  "Guía de Campo de Aire de Combustión IMC 2024 Capítulo 7 de 21 páginas más un Read First de 3 páginas",
  "Método de dimensionamiento de la toma: árbol de selección, insumos requeridos y la cadena aritmética de ocho líneas de lo requerido a lo instalado",
  "Recomendaciones y comportamiento típico de producto para tipo de aleta, mallas, rejillas, rutas con ducto, dampers y terminaciones",
  "Protocolo de levantamiento de condiciones existentes: qué confirmar en cada equipo y abertura, qué evidencia conservar y la regla de estado hallado",
  "Compuertas de integración de alcance nuevo: los siete cambios que obligan a reevaluar, las reglas para acreditar una abertura existente y nueve compuertas de avance o detención",
  "Comando de damper, prueba de apertura, permisivo de encendido y respuesta ante pérdida de prueba - redactado para poder probarse, no solo dibujarse",
  "Ocho herramientas imprimibles, incluidas la hoja de dimensionamiento de toma, el registro de levantamiento y el registro de integración",
  "Enruta equipos a gas, a aceite, de combustible sólido, chimeneas y de venteo directo a su fuente de control correcta en vez de una regla genérica de abertura",
  "Licencia de usuario único; licencia para firma completa, varias oficinas o sitio disponible por separado"
];

const VENT_INCLUDED_EN = [
  "Core Ventilation & Special Exhaust Field Guide \u2014 field-first rapid-triage workflow",
  "Room-by-room ventilation logic review",
  "Outdoor-air evidence and calculation checks",
  "Special-exhaust classification checklist",
  "Drawing-sheet proof verification",
  "Controls and coordination review",
  "Field closeout checklist",
  "Pairs with the free IMC Chapter 4 Ventilation Fundamentals guide for plan-review triage",
  "Built for MEP designers, architects, contractors, plan reviewers, and commissioning teams",
  "Steps up to the IMC 2024 Chapter 5 Exhaust Systems Field Guide when you need the full Sections 501-513 design, coordination and acceptance workflow"
];
const VENT_INCLUDED_ES = [
  "Gu\u00eda de Ventilaci\u00f3n y Extracci\u00f3n Especial completa \u2014 flujo de triage r\u00e1pido orientado al campo",
  "Revisi\u00f3n de l\u00f3gica de ventilaci\u00f3n por recinto",
  "Verificaci\u00f3n de evidencia y c\u00e1lculo de aire exterior",
  "Checklist de clasificaci\u00f3n de extracci\u00f3n especial",
  "Verificaci\u00f3n de prueba en hojas de planos",
  "Revisi\u00f3n de controles y coordinaci\u00f3n",
  "Checklist de cierre de campo",
  "Se complementa con la gu\u00eda gratuita de Fundamentos de Ventilaci\u00f3n Cap\u00edtulo 4 del IMC para triage en revisi\u00f3n de planos",
  "Dise\u00f1ado para dise\u00f1adores MEP, arquitectos, contratistas, revisores de planos y equipos de commissioning",
  "Escala a la Gu\u00eda de Campo de Sistemas de Extracci\u00f3n IMC 2024 Cap\u00edtulo 5 cuando necesite el flujo completo de dise\u00f1o, coordinaci\u00f3n y aceptaci\u00f3n de las Secciones 501-513"
];

function LangToggle(props) {
  const lang = props.lang;
  const setLang = props.setLang;
  const langs = ["en", "es"];
  const buttons = langs.map(function (l) {
    return React.createElement("button", {
      key: l,
      onClick: function () { setLang(l); },
      style: {
        padding: "5px 10px",
        background: lang === l ? ACCENT : "transparent",
        color: lang === l ? BG : MUTED,
        border: "none",
        cursor: "pointer",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: "0.06em",
        textTransform: "uppercase",
        transition: "all 0.2s"
      }
    }, l);
  });
  return React.createElement("div", {
    style: {
      display: "flex",
      gap: 0,
      background: SURFACE,
      borderRadius: 3,
      overflow: "hidden",
      border: "1px solid " + BORDER
    }
  }, buttons);
}

function PageHeader(props) {
  const lang = props.lang;
  const setLang = props.setLang;
  const logo = React.createElement("a", {
    href: "/",
    style: { textDecoration: "none", display: "flex", alignItems: "center", gap: 8 }
  },
    React.createElement("img", {
      src: "/uploads/Master Build Logo- Revised.png",
      alt: "Masterbuild",
      style: { height: 26, width: 26, objectFit: "contain", filter: "invert(1)" }
    }),
    React.createElement("span", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: 13, color: TEXT, letterSpacing: "0.04em", textTransform: "uppercase" }
    }, "Masterbuild")
  );
  const separator = React.createElement("span", {
    style: { color: BORDER, fontSize: 16 }
  }, "|");
  const dctLink = React.createElement("a", {
    href: "/daily-code-talk/",
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", textDecoration: "none" }
  }, "Daily Code Talk");
  const left = React.createElement("div", {
    style: { display: "flex", alignItems: "center", gap: 20 }
  }, logo, separator, dctLink);
  const backLink = React.createElement("a", {
    href: "/daily-code-talk/",
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: MUTED, textDecoration: "none" }
  }, lang === "en" ? "← Free Archive" : "← Archivo Gratis");
  const right = React.createElement("div", {
    style: { display: "flex", alignItems: "center", gap: 12 }
  }, backLink, React.createElement(LangToggle, { lang: lang, setLang: setLang }));
  return React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      background: "rgba(11,12,14,0.97)",
      borderBottom: "1px solid " + BORDER,
      padding: "0 40px",
      height: 56,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      zIndex: 100,
      backdropFilter: "blur(8px)"
    }
  }, left, right);
}

function PageHero(props) {
  const lang = props.lang;
  const badgeDot = React.createElement("span", {
    style: { width: 6, height: 6, borderRadius: "50%", background: ACCENT, display: "block" }
  });
  const badgeLabel = React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase" }
  }, lang === "en" ? "/ Field Guides & Working Tools" : "/ Guías de Campo y Herramientas");
  const badge = React.createElement("div", {
    style: { display: "inline-flex", alignItems: "center", gap: 8, padding: "5px 12px", background: "rgba(196,120,58,0.1)", border: "1px solid rgba(196,120,58,0.2)", borderRadius: 3, marginBottom: 20 }
  }, badgeDot, badgeLabel);
  const heading = React.createElement("h1", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(28px, 4vw, 48px)", color: TEXT, margin: "0 0 16px", letterSpacing: "-0.02em", lineHeight: 1.14, paddingBottom: "0.04em" }
  }, lang === "en" ? "Field Guides & Working Tools" : "Guías y Herramientas de Campo");
  const intro = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 16, color: MUTED, margin: 0, maxWidth: 620, lineHeight: 1.7 }
  }, lang === "en"
    ? "Chapter-ordered IMC field guides, focused project tools, and free references built from the Daily Code Talk archive. Use them to prepare, review, coordinate, and close out real project decisions."
    : "Guías IMC ordenadas por capítulo, herramientas enfocadas de proyecto y referencias gratuitas construidas a partir del archivo Daily Code Talk. Úselas para preparar, revisar, coordinar y cerrar decisiones de proyectos reales.");
  const bgGrid = React.createElement("div", {
    style: {
      position: "absolute", inset: 0,
      backgroundImage: "linear-gradient(to right, rgba(196,120,58,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(196,120,58,0.04) 1px, transparent 1px)",
      backgroundSize: "48px 48px"
    }
  });
  const inner = React.createElement("div", {
    style: { maxWidth: 900, margin: "0 auto", position: "relative", zIndex: 1 }
  }, badge, heading, intro);
  return React.createElement("div", {
    style: { background: "#0F1013", padding: "64px 40px 56px", borderBottom: "1px solid " + BORDER, position: "relative", overflow: "hidden" }
  }, bgGrid, inner);
}

function OfferCard(props) {
  const offer = props.offer;
  const isFirst = props.isFirst;
  const lang = props.lang;
  const isLink = !!offer.href;
  const seriesLabel = offer.seriesLabel ? React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.07em", textTransform: "uppercase", marginBottom: 10, lineHeight: 1.35 }
  }, offer.seriesLabel) : null;
  const titleRow = React.createElement("div", {
    style: { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "baseline", flexWrap: "wrap", marginBottom: 10 }
  },
    React.createElement("h3", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700, fontSize: 16, color: TEXT, margin: 0, minWidth: 0 }
    }, offer.title),
    React.createElement("span", {
      style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, whiteSpace: "normal", textAlign: "right" }
    }, offer.price)
  );
  const bodyP = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: MUTED, lineHeight: 1.6, margin: 0 }
  }, offer.body);
  const ctaSpan = offer.cta ? React.createElement("span", {
    style: { display: "inline-block", marginTop: "auto", paddingTop: 14, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, fontWeight: 700, color: ACCENT, borderBottom: "1px solid " + ACCENT, paddingBottom: 2, alignSelf: "flex-start" }
  }, offer.cta, " →") : null;
  const props2 = {
    key: offer.title,
    href: offer.href,
    target: offer.href && offer.href.indexOf("http") === 0 ? "_blank" : undefined,
    rel: offer.href && offer.href.indexOf("http") === 0 ? "noopener noreferrer" : undefined,
    onClick: function () {
      if (window.trackMBEvent) window.trackMBEvent("Resources Page Offer Click", { product: offer.title, price: offer.price, language: lang, href: offer.href || "" });
    },
    // flex column so the CTA anchors to the card's bottom edge instead of
    // trailing right after a short description -- grid's default
    // align-items:stretch already makes every card in a row match the
    // tallest card's height, this just uses that height instead of leaving
    // dead space under short descriptions.
    style: { background: SURFACE, padding: "22px 24px", borderTop: isFirst ? "3px solid " + ACCENT : "3px solid " + BORDER, textDecoration: "none", color: "inherit", display: "flex", flexDirection: "column" }
  };
  return React.createElement(isLink ? "a" : "div", props2, seriesLabel, titleRow, bodyP, ctaSpan);
}

function OfferGrid(props) {
  const lang = props.lang;
  const offers = props.offers;
  const chapters = offers.filter(function (offer) { return offer.catalogGroup === "chapters"; }).sort(function (a, b) { return a.seriesOrder - b.seriesOrder; });
  const projectTools = offers.filter(function (offer) { return offer.catalogGroup === "project-tools"; });
  const library = offers.filter(function (offer) { return offer.catalogGroup !== "chapters" && offer.catalogGroup !== "project-tools"; });
  const cardGrid = function (items) {
    const cards = items.map(function (offer, i) {
      return React.createElement(OfferCard, { key: offer.title, offer: offer, isFirst: i === 0, lang: lang });
    });
    return React.createElement("div", {
      style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 2 }
    }, cards);
  };
  const section = function (eyebrow, heading, body, items) {
    return React.createElement("section", {
      style: { marginBottom: 52 }
    }, React.createElement("div", {
      style: { maxWidth: 760, margin: "0 0 20px" }
    }, React.createElement("div", {
      style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }
    }, eyebrow), React.createElement("h2", {
      style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: "clamp(20px, 2.4vw, 28px)", fontWeight: 750, color: TEXT, margin: "0 0 8px", lineHeight: 1.2 }
    }, heading), React.createElement("p", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: MUTED, lineHeight: 1.6, margin: 0 }
    }, body)), cardGrid(items));
  };
  const seriesSection = section(
    lang === "en" ? "/ IMC Field Guide Series" : "/ Serie de Guías de Campo IMC",
    lang === "en" ? "Follow the IMC chapters in order" : "Siga los capítulos del IMC en orden",
    lang === "en" ? "Start with the permit path, then definitions, installation, ventilation, and exhaust. Chapter 4 is a free field-guide bridge; each paid guide stands on its own for a live project." : "Comience con la ruta de permisos, luego definiciones, instalación, ventilación y extracción. El Capítulo 4 es un puente gratuito; cada guía de pago funciona por sí sola en un proyecto real.",
    chapters
  );
  const toolsSection = section(
    lang === "en" ? "/ Project Tools & Advisory" : "/ Herramientas y Asesoría de Proyecto",
    lang === "en" ? "Use the right tool for the decision in front of you" : "Use la herramienta adecuada para la decisión actual",
    lang === "en" ? "Permit, owner-side, ventilation, and PE-led decision support for work that needs a focused workflow beyond one IMC chapter." : "Apoyo para permisos, propietarios, ventilación y decisiones lideradas por PE cuando el trabajo necesita un flujo enfocado más allá de un capítulo del IMC.",
    projectTools
  );
  const librarySection = section(
    lang === "en" ? "/ Free Reference Library" : "/ Biblioteca de Referencia Gratuita",
    lang === "en" ? "Downloadable checklists, glossaries, and field references" : "Checklists, glosarios y referencias de campo descargables",
    lang === "en" ? "Free tools for early project screening, plan-review preparation, and informed conversations with your project team. Verify the adopted code and project conditions before relying on any resource for a live decision." : "Herramientas gratuitas para revisión inicial, preparación de planos y conversaciones informadas con su equipo. Verifique el código adoptado y las condiciones del proyecto antes de usar un recurso para una decisión real.",
    library
  );
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto" }
  }, seriesSection, toolsSection, librarySection);
  return React.createElement("div", {
    style: { background: BG, borderBottom: "1px solid " + BORDER, padding: "24px 40px" }
  }, inner);
}

function Ch1GuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "IMC Chapter 1 Permit Process Field Guide" : "Guía de Proceso de Permisos IMC Capítulo 1");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$57");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en"
    ? "A working guide for owners, architects, GCs, designers, and permit coordinators who need mechanical permit process clarity before the review comments, inspection failures, and field conflicts get expensive."
    : "Una guía práctica para propietarios, arquitectos, contratistas generales, diseñadores y coordinadores de permisos que necesitan claridad sobre el proceso de permisos mecánicos antes de que los comentarios de revisión, las fallas de inspección y los conflictos de campo se vuelvan costosos.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en"
    ? "Covers all 15 sections of IMC Chapter 1: scope, applicability, permits, construction documents, approvals, fees, service utilities, temporary systems, inspections and testing, means of appeals, board of appeals, violations, and stop-work orders."
    : "Cubre las 15 secciones del Capítulo 1 del IMC: alcance, aplicabilidad, permisos, documentos de construcción, aprobaciones, tarifas, servicios públicos, sistemas temporales, inspecciones, apelaciones, violaciones y órdenes de paro de trabajo.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ch1-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch1 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — IMC 101 Code Path Guide (PDF)" : "Muestra gratis — Guía IMC 101 Ruta de Código (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_IMC_CHAPTER1_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch1 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $57" : "Obtener la Guía — $57");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "ch1-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingeniería sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function Ch1GuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? CH1_INCLUDED_EN : CH1_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qué incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "✓");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function Ch1GuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — IMC Permit Guide" : "/ Disponible Ahora — Guía de Permisos IMC");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(Ch1GuideLeftColumn, { lang: lang }), React.createElement(Ch1GuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function Ch2GuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "IMC 2024 Chapter 2 Definitions & Redline Prevention Field Guide" : "Guía de Definiciones y Prevención de Redlines IMC 2024 Capítulo 2");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$57");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en"
    ? "A working guide for mechanical designers, engineers, and QA reviewers at lean MEP/architecture firms who need definition-sensitive term control before redline risk and permit delay get expensive."
    : "Una guía práctica para diseñadores mecánicos, ingenieros y revisores de QA en firmas MEP/arquitectura que necesitan control de términos sensibles a definición antes de que el riesgo de redline y el retraso de permisos se vuelvan costosos.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en"
    ? "Covers every IMC Chapter 2 risk cluster: authority and evidence, existing work, air categories, duct/plenum/access, fire and smoke devices, commercial kitchens, combustion and venting, hazardous/process exhaust, and refrigeration/specialty systems."
    : "Cubre cada grupo de riesgo del Capítulo 2 del IMC: autoridad y evidencia, trabajo existente, categorías de aire, ductos/plenum/acceso, dispositivos de fuego y humo, cocinas comerciales, combustión y venteo, escape de proceso/peligroso y sistemas de refrigeración/especialidad.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ch2-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch2 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — Chapter 2 Definition Control Quick Guide (PDF)" : "Muestra gratis — Guía Rápida de Control de Definiciones Capítulo 2 (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_IMC_CHAPTER2_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch2 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $57" : "Obtener la Guía — $57");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "ch2-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingeniería sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function Ch2GuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? CH2_INCLUDED_EN : CH2_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qué incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "✓");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function Ch2GuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — IMC Chapter 2 Guide" : "/ Disponible Ahora — Guía IMC Capítulo 2");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(Ch2GuideLeftColumn, { lang: lang }), React.createElement(Ch2GuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function Ch3GuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "IMC 2024 Chapter 3 Installation Readiness & Field Coordination Guide" : "Guía de Preparación para Instalación y Coordinación de Campo IMC 2024 Capítulo 3");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$57");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en"
    ? "A working guide for mechanical designers, engineers, contractors, and QA reviewers who need installation-readiness control before procurement, concealment, or startup makes a Chapter 3 gap expensive to fix."
    : "Una guía práctica para diseñadores mecánicos, ingenieros, contratistas y revisores de QA que necesitan control de preparación para instalación antes de que la compra, el cierre o el arranque hagan costoso un vacío del Capítulo 3.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en"
    ? "Covers IMC Chapter 3 Sections 301-312: approval and identification, structure and rated-assembly coordination, equipment location, installation and clearance, piping support, access and service, condensate control, and the specialty/load-escalation gate."
    : "Cubre las Secciones 301-312 del Capítulo 3 del IMC: aprobación e identificación, coordinación de estructura y ensamblajes clasificados, ubicación de equipos, instalación y holguras, soporte de tuberías, acceso y servicio, control de condensado y la compuerta de especialidad/escalamiento de carga.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ch3-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch3 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — IMC 301 Product-Proof Chain (PDF)" : "Muestra gratis — Cadena de Prueba de Producto IMC 301 (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_IMC_CHAPTER3_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch3 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $57" : "Obtener la Guía — $57");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "ch3-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingeniería sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function Ch3GuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? CH3_INCLUDED_EN : CH3_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qué incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "✓");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function Ch3GuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — IMC Chapter 3 Guide" : "/ Disponible Ahora — Guía IMC Capítulo 3");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(Ch3GuideLeftColumn, { lang: lang }), React.createElement(Ch3GuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}


function Ch4GuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "IMC 2024 Chapter 4 Ventilation Fundamentals - Free Field Guide" : "Fundamentos de Ventilación IMC 2024 Capítulo 4 - Guía de Campo Gratis");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, lang === "en" ? "FREE" : "GRATIS");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en"
    ? "A practical 16-page Daily Code Talk field guide for mechanical designers, engineers, architects, contractors, plan reviewers, commissioning teams, and facilities staff who need a defensible path from a Chapter 4 question to design, permit, controls, and field-closeout evidence."
    : "Una guía de campo práctica de Daily Code Talk de 16 páginas para diseñadores mecánicos, ingenieros, arquitectos, contratistas, revisores de planos, equipos de commissioning y personal de facilidades que necesitan una ruta defendible desde una pregunta del Capítulo 4 hasta evidencia de diseño, permiso, controles y cierre de campo.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en"
    ? "Use it to establish the project basis, identify every ventilation path, trace outdoor air to the breathing zone, verify intake protection and controls, screen escalation triggers, and keep a closeout record. Download it directly - no email required."
    : "Úsela para establecer la base del proyecto, identificar cada ruta de ventilación, rastrear el aire exterior hasta la zona de respiración, verificar protección de tomas y controles, detectar disparadores de escalamiento y conservar un registro de cierre. Descárguela directamente; no requiere correo electrónico.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ch4-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch4 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample - Chapter 4 Ventilation Proof Chain (PDF)" : "Muestra gratis - Cadena de Prueba de Ventilación Capítulo 4 (PDF)");
  const downloadBtn = React.createElement("a", {
    href: "/uploads/ch4-ventilation-fundamentals-free-guide.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch4 Free Guide Download", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Download the Free Guide" : "Descargar la Guía Gratis");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "chapter4-free-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, downloadBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Verify adopted code, project conditions, responsible professional, and AHJ requirements." : "Apoyo educativo para tomar decisiones. Verifique el código adoptado, las condiciones del proyecto, el profesional responsable y los requisitos del AHJ.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function Ch4GuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? CH4_INCLUDED_EN : CH4_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qué incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "✓");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function Ch4GuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Start Here - Free IMC Chapter 4 Field Guide" : "/ Comience Aquí - Guía Gratis IMC Capítulo 4");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(Ch4GuideLeftColumn, { lang: lang }), React.createElement(Ch4GuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function Ch5GuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "IMC 2024 Chapter 5 Exhaust Systems Field Guide" : "Guía de Campo de Sistemas de Extracción — IMC 2024 Capítulo 5");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, RES_PRICE("imcChapter5Guide"));
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en"
    ? "A deep-control system for MEP designers and engineers, plan reviewers, general and mechanical contractors, kitchen and process equipment vendors, owner representatives, facilities teams, and permit coordinators working where exhaust failures become late, expensive field problems."
    : "Un sistema de control profundo para diseñadores e ingenieros MEP, revisores de planos, contratistas generales y mecánicos, proveedores de equipos de cocina y proceso, representantes del propietario, equipos de facilidades y coordinadores de permisos que enfrentan fallas de extracción tardías y costosas.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en"
    ? "Classify every system before sizing, then prove discharge, makeup air, materials, access, controls, acceptance testing, and closeout. This is a section-by-section Chapter 5 workflow with a required project register—not a generic exhaust checklist."
    : "Clasifique cada sistema antes de dimensionar y luego pruebe descarga, aire de reposición, materiales, acceso, controles, pruebas de aceptación y cierre. Es un flujo del Capítulo 5 sección por sección con un registro de proyecto requerido, no una lista genérica de extracción.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ch5-exhaust-systems-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch5 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — Chapter 5 Exhaust Proof Chain (PDF)" : "Muestra gratis — Cadena de Prueba de Extracción Capítulo 5 (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_IMC_CHAPTER5_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch5 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $199" : "Obtener la Guía — $199");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "chapter5-exhaust-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Verify adopted code, project conditions, listings, responsible professional, and AHJ requirements." : "Apoyo educativo para tomar decisiones. Verifique el código adoptado, las condiciones del proyecto, listados, profesional responsable y requisitos del AHJ.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function Ch5GuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? CH5_INCLUDED_EN : CH5_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What is included" : "Qué incluye");
  const rows = items.map(function (item, i) {
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, React.createElement("span", { style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 } }, "✓"), React.createElement("span", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 } }, item));
  });
  return React.createElement("div", { style: { padding: "32px 30px" } }, eyebrow, rows);
}

function Ch5GuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — IMC Chapter 5 Exhaust Systems" : "/ Disponible Ahora — Sistemas de Extracción IMC Capítulo 5");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(Ch5GuideLeftColumn, { lang: lang }), React.createElement(Ch5GuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", { style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" } }, eyebrow, card);
  return React.createElement("div", { style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" } }, inner);
}


const CH8_INCLUDED_EN = [
  "28-page IMC 2024 Chapter 8 Chimneys and Vents Field Guide plus a 4-page Read First",
  "Thirteen risk-cluster sections, each ending in a field action and a reusable record",
  "The routing map: which document actually governs this appliance's venting, and what each route changes on your set",
  "The four-gate existing-chimney acceptance - size, passageway, cleanout, clearance and fireblocking - with survey discipline and escalation triggers",
  "Pressure-regime reconciliation: why positive pressure reverses the consequence of every joint, and what has to be listed for it",
  "Connector route, construction, pass-through and three-dimensional clearance, including when the appliance listing overrides the table",
  "Mechanical-draft controls and the loss-of-draft sequence that crosses four disciplines and usually has no owner",
  "Factory-built chimneys as listed assemblies: classification, route limits, structural support, shrouds and insulation shields",
  "Termination geometry as a site problem - seven things it is checked against, and where each check is documented",
  "Eleven printable working tools, plus the same eleven as a fillable companion workbook",
  "No numeric code criteria by design: the guide names the governing parameter, the document that carries it and the failure mode, so it cannot go stale or be applied to the wrong route",
  "Single-user license; firmwide, multi-office and site-wide licensing available separately"
];

const CH8_INCLUDED_ES = [
  "Gu\u00eda de Campo de Chimeneas y Venteos IMC 2024 Cap\u00edtulo 8 de 28 p\u00e1ginas m\u00e1s un Lea Primero de 4 p\u00e1ginas",
  "Trece secciones por grupo de riesgo, cada una termina en una acci\u00f3n de campo y un registro reutilizable",
  "El mapa de enrutamiento: qu\u00e9 documento realmente gobierna el venteo de cada equipo",
  "La aceptaci\u00f3n de chimenea existente por cuatro compuertas - tama\u00f1o, conducto, limpieza y claros con fireblocking",
  "Reconciliaci\u00f3n del r\u00e9gimen de presi\u00f3n y de los materiales y juntas listados para esa condici\u00f3n",
  "Ruta, construcci\u00f3n, paso a trav\u00e9s y claros del conector en tres dimensiones",
  "Controles de tiro mec\u00e1nico y la secuencia ante p\u00e9rdida de tiro",
  "Chimeneas prefabricadas como ensamblajes listados: clasificaci\u00f3n, l\u00edmites de ruta, soporte, shrouds y escudos",
  "Geometr\u00eda de terminaci\u00f3n como problema de sitio",
  "Once herramientas de trabajo imprimibles, m\u00e1s el libro de trabajo editable",
  "Sin criterios num\u00e9ricos por dise\u00f1o: nombra el par\u00e1metro, el documento que lo contiene y el modo de falla",
  "Licencia de un usuario; licencias para firma, multi-oficina y sitio disponibles por separado"
];

function Ch6GuidePanel(props) {
  const lang = props.lang;
  const included = lang === "en" ? CH6_INCLUDED_EN : CH6_INCLUDED_ES;
  const title = lang === "en" ? "IMC 2024 Chapter 6 Duct Systems Field Guide" : "Guía de Campo de Sistemas de Ductos — IMC 2024 Capítulo 6";
  const summary = lang === "en"
    ? "A field-first duct coordination system for the decisions that get costly above ceilings and inside shafts: air paths, materials, insulation, pressure and fitting-loss screening, plenum evidence, access, protected openings, coastal durability, and pre-TAB readiness."
    : "Un sistema de coordinación de ductos orientado al campo para decisiones que se vuelven costosas sobre plafones y dentro de shafts: rutas de aire, materiales, aislamiento, evaluación de presión y pérdidas, evidencia de plénum, acceso, aberturas protegidas, durabilidad costera y preparación pre-TAB.";
  const sample = React.createElement("a", {
    href: "/uploads/ch6-duct-systems-sample.pdf", download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch6 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — Coastal & Shaft Coordination (PDF)" : "Muestra gratis — Coordinación Costera y de Shafts (PDF)");
  const buy = React.createElement("a", {
    href: RES_IMC_CHAPTER6_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch6 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $149" : "Obtener la Guía — $149");
  const call = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "chapter6-duct-systems-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const bundleUpsell = React.createElement("a", {
    href: RES_IMC_CHAPTER67_BUNDLE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch6Ch7 Bundle Click", { language: lang, source: "ch6-panel" }); },
    style: { display: "block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, textDecoration: "none", border: "1px dashed rgba(196,120,58,0.45)", borderRadius: 3, padding: "9px 12px", marginBottom: 18, lineHeight: 1.5 }
  }, lang === "en"
    ? "Need both? Chapters 6 + 7 together \u2014 " + RES_PRICE("imcChapter67Bundle") + " instead of " + RES_BUNDLE_LIST() + " \u2192"
    : "\u00bfNecesita ambas? Cap\u00edtulos 6 + 7 juntos \u2014 " + RES_PRICE("imcChapter67Bundle") + " en vez de " + RES_BUNDLE_LIST() + " \u2192");
  const rows = included.map(function (item, i) {
    return React.createElement("div", { key: i, style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 0", borderBottom: "1px solid " + BORDER } },
      React.createElement("span", { style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 } }, "✓"),
      React.createElement("span", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 } }, item));
  });
  const left = React.createElement("div", { style: { padding: "32px 36px", borderRight: "1px solid " + BORDER } },
    React.createElement("h2", { style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 } }, title),
    React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px" } }, RES_PRICE("imcChapter6Guide")),
    React.createElement("p", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 20px" } }, summary),
    sample,
    bundleUpsell,
    React.createElement("div", { style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 } }, buy, call),
    React.createElement("p", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 } }, lang === "en" ? "Educational decision support. Verify adopted code, project conditions, listings, responsible professional, and AHJ requirements." : "Apoyo educativo para tomar decisiones. Verifique el código adoptado, las condiciones del proyecto, listados, profesional responsable y requisitos del AHJ."));
  const right = React.createElement("div", { style: { padding: "32px 30px" } },
    React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 } }, lang === "en" ? "What's included" : "Qué incluye"), rows);
  return React.createElement("div", { style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" } },
    React.createElement("div", { style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" } },
      React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 } }, lang === "en" ? "/ Available Now — IMC Chapter 6 Duct Systems" : "/ Disponible Ahora — Sistemas de Ductos IMC Capítulo 6"),
      React.createElement("div", { style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER } }, left, right)));
}

function Ch7GuidePanel(props) {
  const lang = props.lang;
  const included = lang === "en" ? CH7_INCLUDED_EN : CH7_INCLUDED_ES;
  const title = lang === "en" ? "IMC 2024 Chapter 7 Combustion Air Field Guide" : "Guía de Campo de Aire de Combustión — IMC 2024 Capítulo 7";
  const summary = lang === "en"
    ? "An appliance room can look finished and still starve. This is the proof system for combustion air: route each appliance to its governing source, size the intake through an eight-line required-to-installed chain, prove actual free area at the installed product, interlock dampers to firing, and verify that new scope can live with what is already there."
    : "Un cuarto de equipos puede verse terminado y aun as\u00ed quedarse sin aire. Este es el sistema de prueba del aire de combusti\u00f3n: enrute cada equipo a su fuente de control, dimensione la toma con una cadena de ocho l\u00edneas, pruebe el \u00e1rea libre real del producto instalado, enclave los dampers con el encendido y verifique que el alcance nuevo puede convivir con lo existente.";
  const sample = React.createElement("a", {
    href: "/uploads/ch7-combustion-air-sample.pdf", download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch7 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "↓ ", lang === "en" ? "Free sample — Appliance Routing & Sanity Checks (PDF)" : "Muestra gratis — Enrutamiento de Equipos y Verificaciones (PDF)");
  const buy = React.createElement("a", {
    href: RES_IMC_CHAPTER7_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch7 Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $149" : "Obtener la Guía — $149");
  const call = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "chapter7-combustion-air-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const bundleUpsell = React.createElement("a", {
    href: RES_IMC_CHAPTER67_BUNDLE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch6Ch7 Bundle Click", { language: lang, source: "ch7-panel" }); },
    style: { display: "block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, textDecoration: "none", border: "1px dashed rgba(196,120,58,0.45)", borderRadius: 3, padding: "9px 12px", marginBottom: 18, lineHeight: 1.5 }
  }, lang === "en"
    ? "Need both? Chapters 6 + 7 together \u2014 " + RES_PRICE("imcChapter67Bundle") + " instead of " + RES_BUNDLE_LIST() + " \u2192"
    : "\u00bfNecesita ambas? Cap\u00edtulos 6 + 7 juntos \u2014 " + RES_PRICE("imcChapter67Bundle") + " en vez de " + RES_BUNDLE_LIST() + " \u2192");
  const rows = included.map(function (item, i) {
    return React.createElement("div", { key: i, style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 0", borderBottom: "1px solid " + BORDER } },
      React.createElement("span", { style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 } }, "✓"),
      React.createElement("span", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 } }, item));
  });
  const left = React.createElement("div", { style: { padding: "32px 36px", borderRight: "1px solid " + BORDER } },
    React.createElement("h2", { style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 } }, title),
    React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px" } }, RES_PRICE("imcChapter7Guide")),
    React.createElement("p", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 20px" } }, summary),
    sample,
    bundleUpsell,
    React.createElement("div", { style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 } }, buy, call),
    React.createElement("p", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 } }, lang === "en" ? "Educational decision support. Verify adopted code, project conditions, listings, responsible professional, and AHJ requirements." : "Apoyo educativo para tomar decisiones. Verifique el código adoptado, las condiciones del proyecto, listados, profesional responsable y requisitos del AHJ."));
  const right = React.createElement("div", { style: { padding: "32px 30px" } },
    React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 } }, lang === "en" ? "What's included" : "Qué incluye"), rows);
  return React.createElement("div", { style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" } },
    React.createElement("div", { style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" } },
      React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 } }, lang === "en" ? "/ Available Now — IMC Chapter 7 Combustion Air" : "/ Disponible Ahora — Aire de Combustión IMC Capítulo 7"),
      React.createElement("div", { style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER } }, left, right)));
}

function VentGuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "Ventilation & Special Exhaust Field Guide" : "Guía de Ventilación y Extracción Especial");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$149");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en" ? "A field-first guide for MEP designers, architects, contractors, plan reviewers, commissioning teams, and facilities staff who need fast, defensible ventilation and special-exhaust triage before problems reach inspection or occupancy." : "Una guía orientada al campo para diseñadores MEP, arquitectos, contratistas, revisores de planos, equipos de commissioning y personal de facilidades que necesitan un triage rápido y defendible de ventilación y extracción especial antes de que los problemas lleguen a inspección u ocupación.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en" ? "Covers room-by-room ventilation logic, outdoor-air evidence, special-exhaust classification, drawing-sheet proof, controls and coordination, and field closeout. Pairs with the free IMC Chapter 4 Ventilation Fundamentals guide." : "Cubre lógica de ventilación por recinto, evidencia de aire exterior, clasificación de extracción especial, prueba en hojas de planos, controles y coordinación, y cierre de campo. Se complementa con la guía gratuita de Fundamentos de Ventilación Capítulo 4 del IMC.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/ventilation-oa-math-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Vent Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "\u2193 ", lang === "en" ? "Free sample — Outdoor-Air Math Review (PDF)" : "Muestra gratis — Revisión de Cálculo de Aire Exterior (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_VENTILATION_FIELD_GUIDE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Vent Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Guide — $149" : "Obtener la Guía — $149");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "ventilation-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingenier\u00eda sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function VentGuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? VENT_INCLUDED_EN : VENT_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qu\u00e9 incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "\u2713");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}


function Ch8GuidePanel(props) {
  const lang = props.lang;
  const cat = (typeof window !== "undefined" && window.MB_CATALOG) || null;
  const live = !!(cat && cat.sellable && cat.sellable("imcChapter8Guide"));
  const included = lang === "en" ? CH8_INCLUDED_EN : CH8_INCLUDED_ES;
  const title = lang === "en"
    ? "IMC 2024 Chapter 8 Chimneys and Vents Field Guide"
    : "Gu\u00eda de Campo de Chimeneas y Venteos \u2014 IMC 2024 Cap\u00edtulo 8";
  const summary = lang === "en"
    ? "\u201cExisting chimney to remain\u201d is the most expensive four words on a renovation mechanical set. This is the proof system for venting: route each appliance to the document that actually governs it, state a size basis a reviewer can verify, run an existing chimney through four acceptance gates instead of a note, reconcile pressure regime with materials and joints, and witness the loss-of-draft response before the appliance is released to fire."
    : "\u201cChimenea existente a permanecer\u201d son las cuatro palabras m\u00e1s caras en un juego mec\u00e1nico de renovaci\u00f3n. Este es el sistema de prueba del venteo: enrute cada equipo al documento que realmente lo gobierna, declare una base de tama\u00f1o verificable, pase la chimenea existente por cuatro compuertas de aceptaci\u00f3n, reconcilie el r\u00e9gimen de presi\u00f3n con materiales y juntas, y presencie la respuesta ante p\u00e9rdida de tiro antes de encender.";
  const sample = React.createElement("a", {
    href: "/uploads/ch8-chimneys-vents-sample.pdf", download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch8 Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "\u2193 ", lang === "en"
    ? "Free sample \u2014 the four-gate existing-chimney acceptance, in full (PDF)"
    : "Muestra gratis \u2014 la aceptaci\u00f3n por cuatro compuertas, completa (PDF)");
  const buy = live
    ? React.createElement("a", {
        href: cat.offers.imcChapter8Guide.url,
        onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch8 Guide Purchase Click", { language: lang }); },
        style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
      }, (lang === "en" ? "Get the Guide \u2014 " : "Obtener la Gu\u00eda \u2014 ") + cat.price("imcChapter8Guide"))
    : React.createElement("a", {
        href: (lang === "es" ? "/contacto/" : "/send/") + "?type=combustion&source=" + encodeURIComponent("ch8-guide-interest"),
        onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch8 Interest Click", { language: lang }); },
        style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
      }, lang === "en" ? "Tell me what it has to answer" : "D\u00edgame qu\u00e9 debe responder");
  /* Combustion air and venting are one appliance-room conversation; the buyer who
     needs Chapter 8 usually needs Chapter 7 too. Inert until the bundle is live. */
  const bundle78 = RES_SELLABLE("imcChapter78Bundle") && RES_SELLABLE("imcChapter7Guide")
    ? React.createElement("a", {
        href: RES_IMC_CHAPTER78_BUNDLE_URL,
        onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Ch7Ch8 Bundle Click", { language: lang, source: "ch8-panel" }); },
        style: { display: "block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, textDecoration: "none", border: "1px dashed rgba(196,120,58,0.45)", borderRadius: 3, padding: "9px 12px", marginBottom: 18, lineHeight: 1.5 }
      }, lang === "en"
        ? "Need the air as well as the vent? Chapters 7 + 8 together \u2014 " + RES_PRICE("imcChapter78Bundle") + " instead of " + RES_BUNDLE78_LIST() + " \u2192"
        : "\u00bfNecesita el aire adem\u00e1s del venteo? Cap\u00edtulos 7 + 8 juntos \u2014 " + RES_PRICE("imcChapter78Bundle") + " en vez de " + RES_BUNDLE78_LIST() + " \u2192")
    : null;
  const call = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "chapter8-chimneys-vents-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const note = live ? null : React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: ACCENT, border: "1px dashed rgba(196,120,58,0.45)", borderRadius: 3, padding: "9px 12px", marginBottom: 18, lineHeight: 1.5 }
  }, lang === "en"
    ? "The guide is written and QA'd. The sample is the complete existing-chimney section \u2014 take it, use it on a real job, and tell me what the full edition has to answer before it goes on sale."
    : "La gu\u00eda est\u00e1 escrita y verificada. La muestra es la secci\u00f3n completa de chimenea existente \u2014 \u00fasela en un trabajo real y d\u00edgame qu\u00e9 debe responder la edici\u00f3n completa antes de salir a la venta.");
  const rows = included.map(function (item, i) {
    return React.createElement("div", { key: i, style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 0", borderBottom: "1px solid " + BORDER } },
      React.createElement("span", { style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 } }, "\u2713"),
      React.createElement("span", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 } }, item));
  });
  const priceLine = live
    ? React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px" } }, cat.price("imcChapter8Guide"))
    : React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 13, color: ACCENT, margin: "0 0 18px", letterSpacing: "0.06em" } },
        lang === "en" ? "FREE SAMPLE AVAILABLE NOW" : "MUESTRA GRATIS DISPONIBLE");
  const left = React.createElement("div", { style: { padding: "32px 36px", borderRight: "1px solid " + BORDER } },
    React.createElement("h2", { style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 } }, title),
    priceLine,
    React.createElement("p", { style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 20px" } }, summary),
    sample,
    note,
    bundle78,
    React.createElement("div", { style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 } }, buy, call),
    React.createElement("p", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 } }, lang === "en" ? "Educational decision support. Verify adopted code, project conditions, listings, responsible professional, and AHJ requirements." : "Apoyo educativo para tomar decisiones. Verifique el c\u00f3digo adoptado, las condiciones del proyecto, listados, profesional responsable y requisitos del AHJ."));
  const right = React.createElement("div", { style: { padding: "32px 30px" } },
    React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 } }, lang === "en" ? "What's included" : "Qu\u00e9 incluye"), rows);
  return React.createElement("div", { style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" } },
    React.createElement("div", { style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" } },
      React.createElement("div", { style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 } },
        live ? (lang === "en" ? "/ Available Now \u2014 IMC Chapter 8 Chimneys and Vents" : "/ Disponible Ahora \u2014 Chimeneas y Venteos IMC Cap\u00edtulo 8")
             : (lang === "en" ? "/ Free Sample \u2014 IMC Chapter 8 Chimneys and Vents" : "/ Muestra Gratis \u2014 Chimeneas y Venteos IMC Cap\u00edtulo 8")),
      React.createElement("div", { style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER } }, left, right)));
}

function VentGuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — Ventilation & Special Exhaust Guide" : "/ Disponible Ahora — Guía de Ventilación y Extracción Especial");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(VentGuideLeftColumn, { lang: lang }), React.createElement(VentGuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function OwnerGuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "Owner-Side MEP Review Checklist Bundle" : "Paquete de Checklists MEP para Propietarios");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$99");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en" ? "A working system for owners, developers, owner-representatives, architects, facilities teams, and project executives who need an independent read on design decisions before they become expensive field conditions." : "Un sistema de trabajo para propietarios, desarrolladores, representantes, arquitectos, equipos de facilidades y ejecutivos de proyecto que necesitan una lectura independiente de las decisiones de diseño antes de que se conviertan en condiciones de campo costosas.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en" ? "Covers maintainability, permit control, change-order exposure, inspection-failure risk, cost and schedule guardrails, red-flag contract language, and issue tracking — a 30-minute owner-side review system." : "Cubre mantenimiento, control de permiso, exposición a órdenes de cambio, riesgo de fallas de inspección, límites de costo y plazo, lenguaje de alerta contractual y seguimiento de asuntos — un sistema de revisión del propietario de 30 minutos.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/owner-side-review-card-sample.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Owner Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "\u2193 ", lang === "en" ? "Free sample — Owner-Side Review Card (PDF)" : "Muestra gratis — Tarjeta de Revisión del Propietario (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_OWNER_SIDE_BUNDLE_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Owner Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Bundle — $99" : "Obtener el Paquete — $99");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "owner-side-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingenier\u00eda sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function OwnerGuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? OWNER_INCLUDED_EN : OWNER_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qu\u00e9 incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "\u2713");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function OwnerGuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — Owner-Side MEP Review Bundle" : "/ Disponible Ahora — Paquete de Checklists para Propietarios");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(OwnerGuideLeftColumn, { lang: lang }), React.createElement(OwnerGuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function PermitGuideLeftColumn(props) {
  const lang = props.lang;
  const title = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.8vw, 30px)", color: TEXT, margin: "0 0 8px", lineHeight: 1.12 }
  }, lang === "en" ? "Permit Readiness Review Pack" : "Paquete de Revisión Permit Readiness");
  const price = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontWeight: 700, fontSize: 24, color: ACCENT, margin: "0 0 18px", lineHeight: 1 }
  }, "$79");
  const p1 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.68)", lineHeight: 1.75, margin: "0 0 14px" }
  }, lang === "en" ? "A working system for owners, owner representatives, architects, permit coordinators, MEP/structural teams, GCs, and preconstruction teams who need a cross-discipline pressure-test before a permit set gets uploaded or resubmitted." : "Un sistema de trabajo para propietarios, representantes, arquitectos, coordinadores de permisos, equipos MEP y estructurales, contratistas y preconstrucción que necesitan una revisión multidisciplinaria antes de cargar o responder un juego de permisos.");
  const p2 = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, color: "rgba(240,237,232,0.5)", lineHeight: 1.7, margin: "0 0 24px" }
  }, lang === "en" ? "Covers project-basis intake, authority routing, cross-discipline gates (building, MEP, structural, zoning, WASD), selective coordination, an issue log, the final upload-gate decision, and a Miami-Dade / Florida source map." : "Cubre base del proyecto, ruta de autoridades, controles multidisciplinarios (edificación, MEP, estructura, zonificación, WASD), coordinación selectiva, registro de asuntos, la decisión final de carga y un mapa de fuentes de Miami-Dade / Florida.");
  const sampleLink = React.createElement("a", {
    href: "/uploads/permit-readiness-sample-checklist.pdf",
    download: true,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Permit Sample Download", { language: lang }); },
    style: { display: "inline-block", fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: ACCENT, textDecoration: "none", borderBottom: "1px solid rgba(196,120,58,0.4)", paddingBottom: 1, marginBottom: 20 }
  }, "\u2193 ", lang === "en" ? "Free sample — Permit Readiness cross-discipline workflow (PDF)" : "Muestra gratis — Flujo multidisciplinario Permit Readiness (PDF)");
  const buyBtn = React.createElement("a", {
    href: RES_PERMIT_READINESS_PACK_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Permit Guide Purchase Click", { language: lang }); },
    style: { padding: "12px 22px", background: ACCENT, color: "#0B0C0E", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, display: "inline-block", textDecoration: "none" }
  }, lang === "en" ? "Get the Pack — $79" : "Obtener el Paquete — $79");
  const callBtn = React.createElement("a", {
    href: RES_SCOPING_CALL_URL,
    onClick: function () { if (window.trackMBEvent) window.trackMBEvent("Resources Scoping Call Click", { source: "permit-readiness-guide", language: lang }); },
    style: { padding: "12px 18px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, textDecoration: "none", borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, display: "inline-block" }
  }, lang === "en" ? "Book a Scoping Call" : "Reservar una Consulta");
  const buttonsRow = React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }
  }, buyBtn, callBtn);
  const disclaimer = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: MUTED, margin: 0, lineHeight: 1.5 }
  }, lang === "en" ? "Educational decision support. Not sealed engineering or AHJ approval." : "Apoyo educativo para tomar decisiones. No incluye ingenier\u00eda sellada.");
  return React.createElement("div", {
    style: { padding: "32px 36px", borderRight: "1px solid " + BORDER }
  }, title, price, p1, p2, sampleLink, buttonsRow, disclaimer);
}

function PermitGuideRightColumn(props) {
  const lang = props.lang;
  const items = lang === "en" ? PERMIT_INCLUDED_EN : PERMIT_INCLUDED_ES;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 16 }
  }, lang === "en" ? "What's included" : "Qu\u00e9 incluye");
  const rows = items.map(function (item, i) {
    const check = React.createElement("span", {
      style: { color: ACCENT, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }
    }, "\u2713");
    const label = React.createElement("span", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 12, color: "rgba(240,237,232,0.65)", lineHeight: 1.5 }
    }, item);
    return React.createElement("div", {
      key: i,
      style: { display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: "1px solid " + BORDER }
    }, check, label);
  });
  return React.createElement("div", {
    style: { padding: "32px 30px" }
  }, eyebrow, rows);
}

function PermitGuidePanel(props) {
  const lang = props.lang;
  const eyebrow = React.createElement("div", {
    style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: ACCENT, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }
  }, lang === "en" ? "/ Available Now — Permit Readiness Review Pack" : "/ Disponible Ahora — Paquete Permit Readiness");
  const card = React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "minmax(0, 1.1fr) minmax(260px, 0.9fr)", gap: 0, background: BG, border: "1px solid " + BORDER }
  }, React.createElement(PermitGuideLeftColumn, { lang: lang }), React.createElement(PermitGuideRightColumn, { lang: lang }));
  const inner = React.createElement("div", {
    style: { maxWidth: 1200, margin: "0 auto", padding: "36px 0 40px" }
  }, eyebrow, card);
  return React.createElement("div", {
    style: { background: SURFACE, borderTop: "3px solid " + ACCENT, borderBottom: "1px solid " + BORDER, padding: "0 40px" }
  }, inner);
}

function ClosingCTA(props) {
  const lang = props.lang;
  const heading = React.createElement("h2", {
    style: { fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800, fontSize: "clamp(20px, 2.6vw, 28px)", color: TEXT, margin: "0 0 12px" }
  }, lang === "en" ? "Need something project-specific instead?" : "¿Necesita algo específico de su proyecto?");
  const body = React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 15, color: MUTED, lineHeight: 1.7, margin: "0 0 28px", maxWidth: 620, marginLeft: "auto", marginRight: "auto" }
  }, lang === "en"
    ? "These guides are educational decision-support tools, not project-specific engineering. For sealed design, permit sets, or a project review, start with a written scope."
    : "Estas guías son herramientas educativas de apoyo a la decisión, no ingeniería específica del proyecto. Para diseño sellado, juegos de permisos o revisión de proyecto, comience con un alcance escrito.");
  const proposalBtn = React.createElement("a", {
    href: lang === "es" ? "/contacto/" : "/send/",
    style: { padding: "13px 24px", background: ACCENT, color: BG, borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 700, textDecoration: "none" }
  }, lang === "en" ? "Send Project Background →" : "Enviar antecedentes del proyecto →");
  const archiveBtn = React.createElement("a", {
    href: "/daily-code-talk/",
    style: { padding: "13px 24px", background: "transparent", color: ACCENT, border: "1px solid " + ACCENT, borderRadius: 3, fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, fontWeight: 600, textDecoration: "none" }
  }, lang === "en" ? "Browse the Free Archive" : "Ver el Archivo Gratis");
  const btnRow = React.createElement("div", {
    style: { display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }
  }, proposalBtn, archiveBtn);
  const inner = React.createElement("div", {
    style: { maxWidth: 900, margin: "0 auto", textAlign: "center" }
  }, heading, body, btnRow);
  return React.createElement("div", {
    style: { background: BG, padding: "56px 40px 72px" }
  }, inner);
}

function ResourcesPage() {
  const initialLang = (function () {
    try { return localStorage.getItem("mb_lang") || "en"; } catch (err) { return "en"; }
  })();
  const state = React.useState(initialLang);
  const lang = state[0];
  const setLangState = state[1];
  const setLang = function (l) {
    setLangState(l);
    try { localStorage.setItem("mb_lang", l); } catch (err) {}
  };
  React.useEffect(function () {
    document.documentElement.lang = lang;
    document.body.dataset.lang = lang;
  }, [lang]);
  const offers = RESOURCE_OFFERS[lang] || RESOURCE_OFFERS.en;

  const header = React.createElement(PageHeader, { lang: lang, setLang: setLang });
  const hero = React.createElement(PageHero, { lang: lang });
  const offerGrid = React.createElement(OfferGrid, { lang: lang, offers: offers });
  const ch4Panel = React.createElement(Ch4GuidePanel, { lang: lang });
  const ch5Panel = React.createElement(Ch5GuidePanel, { lang: lang });
  const ch6Panel = React.createElement(Ch6GuidePanel, { lang: lang });
  const ch7Panel = React.createElement(Ch7GuidePanel, { lang: lang });
  const ch8Panel = React.createElement(Ch8GuidePanel, { lang: lang });
  const ventPanel = React.createElement(VentGuidePanel, { lang: lang });
  const ownerPanel = React.createElement(OwnerGuidePanel, { lang: lang });
  const permitPanel = React.createElement(PermitGuidePanel, { lang: lang });
  const guidePanel = React.createElement(Ch1GuidePanel, { lang: lang });
  const ch2Panel = React.createElement(Ch2GuidePanel, { lang: lang });
  const ch3Panel = React.createElement(Ch3GuidePanel, { lang: lang });
  const closing = React.createElement(ClosingCTA, { lang: lang });

  return React.createElement("div", {
    style: { minHeight: "100vh", background: BG }
  }, header, hero, offerGrid, guidePanel, ch2Panel, ch3Panel, ch4Panel, ch5Panel, ch6Panel, ch7Panel, ch8Panel, ventPanel, ownerPanel, permitPanel, closing);
}

const resRoot = ReactDOM.createRoot(document.getElementById("root"));
resRoot.render(React.createElement(ResourcesPage));
