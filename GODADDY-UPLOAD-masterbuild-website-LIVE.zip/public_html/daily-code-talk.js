const ACCENT = "#C4783A";
const BG = "#0B0C0E";
const SURFACE = "#131417";
const SURFACE2 = "#1C1E23";
const BORDER = "rgba(255,255,255,0.07)";
const TEXT = "#F0EDE8";
const MUTED = "rgba(240,237,232,0.45)";
const ARTICLES = window.DCT_ARTICLES;
// Catalog reads are guarded: an out-of-sync or cached mb-catalog.js must degrade to a
// harmless fallback, never take the whole archive down at script load.
const DCT_CATALOG = window.MB_CATALOG || {};
const DCT_SCOPING_CALL_URL = DCT_CATALOG.scopingCall || "#";
const DCT_IMC_CHAPTER1_GUIDE_URL = ((DCT_CATALOG.offers || {}).imcChapter1Guide || {}).url || "#";

// Chapter -> live field guide for the in-article CTA. Chapters with no live guide
// (4 is the free lead magnet, 8 is still in progress) are absent on purpose and render
// no CTA. Price is read from the catalog so it can never drift from checkout.
const DCT_CHAPTER_GUIDES = {
  1: {
    key: "imcChapter1Guide",
    en: { headline: "Get all 15 Chapter 1 sections in one working guide.", body: "The IMC Chapter 1 Permit Process Field Guide turns this section-by-section series into a single pre-submittal checklist, review kit, and violation response toolkit." },
    es: { headline: "Obtenga las 15 secciones del Cap\u00edtulo 1 en una sola gu\u00eda pr\u00e1ctica.", body: "La Gu\u00eda de Proceso de Permisos IMC Cap\u00edtulo 1 convierte esta serie secci\u00f3n por secci\u00f3n en un solo checklist previo a la presentaci\u00f3n, kit de revisi\u00f3n y respuesta a violaciones." }
  },
  2: {
    key: "imcChapter2Guide",
    en: { headline: "Every Chapter 2 definition that changes a review outcome, in one guide.", body: "The IMC Chapter 2 Definitions & Redline Prevention Field Guide turns this series into a redline-prevention pass you can run before you submit." },
    es: { headline: "Cada definici\u00f3n del Cap\u00edtulo 2 que cambia el resultado de una revisi\u00f3n, en una sola gu\u00eda.", body: "La Gu\u00eda de Definiciones y Prevenci\u00f3n de Redlines IMC Cap\u00edtulo 2 convierte esta serie en un pase de prevenci\u00f3n que puede correr antes de presentar." }
  },
  3: {
    key: "imcChapter3Guide",
    en: { headline: "Chapter 3 installation readiness, as one field coordination workflow.", body: "The IMC 2024 Chapter 3 Installation Readiness & Field Coordination Guide turns this series into an equipment approval and location matrix you use before procurement, concealment, or startup." },
    es: { headline: "La preparaci\u00f3n de instalaci\u00f3n del Cap\u00edtulo 3, como un solo flujo de coordinaci\u00f3n de campo.", body: "La Gu\u00eda de Preparaci\u00f3n para Instalaci\u00f3n IMC 2024 Cap\u00edtulo 3 convierte esta serie en una matriz de aprobaci\u00f3n y ubicaci\u00f3n de equipos que usa antes de procurar, ocultar o arrancar." }
  },
  5: {
    key: "imcChapter5Guide",
    en: { headline: "Classify the exhaust before you size it - all of Chapter 5 in one control system.", body: "The IMC 2024 Chapter 5 Exhaust Systems Field Guide turns this series into a section-by-section workflow with a Read First file and nine working sheets." },
    es: { headline: "Clasifique la extracci\u00f3n antes de dimensionarla - todo el Cap\u00edtulo 5 en un sistema de control.", body: "La Gu\u00eda de Sistemas de Extracci\u00f3n IMC 2024 Cap\u00edtulo 5 convierte esta serie en un flujo secci\u00f3n por secci\u00f3n con archivo Read First y nueve hojas de trabajo." }
  },
  6: {
    key: "imcChapter6Guide",
    en: { headline: "The Chapter 6 decisions that get costly above ceilings and inside shafts.", body: "The IMC 2024 Chapter 6 Duct Systems Field Guide turns this series into a duct coordination system with four printable working tools and a coastal salt-exposure durability pass." },
    es: { headline: "Las decisiones del Cap\u00edtulo 6 que se vuelven costosas sobre plafones y dentro de shafts.", body: "La Gu\u00eda de Sistemas de Ductos IMC 2024 Cap\u00edtulo 6 convierte esta serie en un sistema de coordinaci\u00f3n con cuatro herramientas imprimibles y un pase de durabilidad costera." }
  },
  7: {
    key: "imcChapter7Guide",
    en: { headline: "Route the appliance, size the intake, prove the path - all of Chapter 7 in one workflow.", body: "The IMC 2024 Chapter 7 Combustion Air Field Guide turns this series into an intake sizing chain, an existing-conditions survey protocol, and nine go / no-go integration gates, with eight printable working tools." },
    es: { headline: "Enrute el equipo, dimensione la toma, pruebe la ruta - todo el Cap\u00edtulo 7 en un flujo.", body: "La Gu\u00eda de Campo de Aire de Combusti\u00f3n IMC 2024 Cap\u00edtulo 7 convierte esta serie en una cadena de dimensionamiento, un protocolo de levantamiento de condiciones existentes y nueve compuertas de integraci\u00f3n, con ocho herramientas imprimibles." }
  },
  8: {
    key: "imcChapter8Guide",
    en: { headline: "All of Chapter 8 as one venting proof system.", body: "The IMC 2024 Chapter 8 Chimneys and Vents Field Guide turns this series into a routing map, a size basis a reviewer can verify, the four-gate existing-chimney acceptance, and eleven printable working tools." },
    es: { headline: "Todo el Cap\u00edtulo 8 como un sistema de prueba del venteo.", body: "La Gu\u00eda de Chimeneas y Venteos IMC 2024 Cap\u00edtulo 8 convierte esta serie en un mapa de enrutamiento, una base de tama\u00f1o verificable, la aceptaci\u00f3n por cuatro compuertas y once herramientas de trabajo imprimibles." }
  }
};

function dctGuideFor(chapter, lang) {
  const entry = DCT_CHAPTER_GUIDES[chapter];
  const catalog = window.MB_CATALOG || {};
  const offer = entry && (catalog.offers || {})[entry.key];
  if (!entry || !offer || !offer.url) return null;
  const copy = entry[lang === "es" ? "es" : "en"] || entry.en;
  return {
    key: entry.key,
    url: offer.url,
    price: typeof catalog.price === "function" ? catalog.price(entry.key) : "",
    headline: copy.headline,
    body: copy.body
  };
}
const BUTTONDOWN_USERNAME = (DCT_CATALOG.subscribe || {}).username || "masterbuild";
const CHAPTER_NAV_LABELS = {
  en: {
    "Administration": "Admin",
    "Definitions": "Defs",
    "Installation": "General",
    "Ventilation": "Vent",
    "Exhaust Systems": "Exhaust",
    "Duct Systems": "Ducts",
    "Combustion Air": "Combustion",
    "Venting Systems": "Venting"
  },
  es: {
    "Administration": "Admin.",
    "Definitions": "Def.",
    "Installation": "General",
    "Ventilation": "Vent.",
    "Exhaust Systems": "Extracción",
    "Duct Systems": "Ductos",
    "Combustion Air": "Combustión",
    "Venting Systems": "Venteo"
  }
};
// All IMC chapters in the live corpus. Each card filters the article list on click
// (sets the active chapter key used by the filter strip and article list below).
const ALL_CHAPTERS = [{
  num: 1,
  discipline: "Administration",
  codeFamily: "IMC",
  en: {
    title: "Administration & Enforcement",
    body: "Permits, AHJ authority, construction documents, inspections, appeals, violations, and stop-work response. Where permit speed is decided."
  },
  es: {
    title: "Administración y Cumplimiento",
    body: "Permisos, autoridad del AHJ, documentos de construcción, inspecciones, apelaciones, violaciones y respuesta a stop-work. Aquí se decide la velocidad del permiso."
  }
}, {
  num: 2,
  discipline: "Definitions",
  codeFamily: "IMC",
  en: {
    title: "Definitions",
    body: "The vocabulary backbone - appliance vs. equipment, plenum, fire/smoke/combination/CRD dampers. Misused definitions drive avoidable redlines."
  },
  es: {
    title: "Definiciones",
    body: "La base del vocabulario - aparato vs. equipo, plenum, compuertas cortafuego/cortahumo/combinación/CRD. Las definiciones mal usadas generan redlines evitables."
  }
}, {
  num: 3,
  discipline: "Installation",
  codeFamily: "IMC",
  en: {
    title: "General Regulations",
    body: "The baseline permit and field rules: listings, location, structural protection, installation, piping support, access, condensate disposal, clearance reduction, heating, fire-code coordination, and load calculations."
  },
  es: {
    title: "Reglamentos Generales",
    body: "Las reglas base de permiso y campo: listados, ubicación, protección estructural, instalación, soporte, acceso, condensado, reducción de claros, calefacción, coordinación con incendio y cálculos de carga."
  }
}, {
  num: 4,
  discipline: "Ventilation",
  codeFamily: "IMC",
  en: {
    title: "Ventilation",
    body: "Where ventilation is required, intake siting, natural vs. mechanical, breathing-zone math, residential whole-house ventilation, and healthcare exceptions."
  },
  es: {
    title: "Ventilación",
    body: "Cuándo se requiere ventilación, ubicación de tomas, natural vs. mecánica, matemática de zona de respiración, ventilación residencial y excepciones de cuidado de salud."
  }
}, {
  num: 5,
  discipline: "Exhaust Systems",
  codeFamily: "IMC",
  en: {
    title: "Exhaust Systems",
    body: "Dryer, kitchen, hazardous, dust/stock/refuse, smoke control, and energy recovery - the largest chapter in the corpus and a major source for future standalone field-guide packages."
  },
  es: {
    title: "Sistemas de Extracción",
    body: "Secadora, cocina, peligrosa, polvo/stock/refuse, control de humo y recuperación de energía - el capítulo más grande del corpus y una fuente principal para futuros paquetes independientes de guías de campo."
  }
}, {
  num: 6,
  discipline: "Duct Systems",
  codeFamily: "IMC",
  en: {
    title: "Duct Systems",
    body: "Duct construction, insulation, vapor and weather control, internal liner, coil discharge zones, and field coordination traps that create real rework."
  },
  es: {
    title: "Sistemas de Ductos",
    body: "Construcción de ductos, aislamiento, vapor, intemperie, revestimiento interno, descarga de serpentines y coordinación de campo."
  }
}, {
  num: 7,
  discipline: "Combustion Air",
  codeFamily: "IMC",
  en: {
    title: "Combustion Air",
    body: "Appliance code paths, enclosure conditions, opening sizing, net free area, rated-construction coordination, dampers, interlocks, and field verification."
  },
  es: {
    title: "Aire de Combustión",
    body: "Rutas de código del aparato, condiciones del recinto, dimensionamiento, área libre neta, construcción clasificada, compuertas, enclavamientos y verificación."
  }
}, {
  num: 8,
  discipline: "Venting Systems",
  codeFamily: "IMC",
  en: {
    title: "Venting Systems",
    body: "Chimney and vent code path, masonry and factory-built chimney construction, sizing, positive-pressure venting, fireplace flue connections, connectors, and abandoned-opening closure. Sections 801 and 802 complete; Section 803 (connectors) now underway."
  },
  es: {
    title: "Sistemas de Venteo",
    body: "Ruta de código de chimeneas y venteos, construcción de chimeneas de mampostería y prefabricadas, dimensionamiento, venteo a presión positiva, conexiones a conducto de fireplace, conectores, y cierre de aberturas abandonadas. Secciones 801 y 802 completas; la Sección 803 (conectores) está en progreso."
  }
}, {
  num: 0,
  discipline: "Sparky Edition",
  codeFamily: "NEC",
  en: {
    title: "Sparky Edition (NEC)",
    body: "A new non-IMC series: the 2026 NEC studied from a mechanical engineer's MEP-coordination perspective - services, feeders, grounding, overcurrent protection, disconnects, emergency power, and how electrical decisions affect mechanical equipment and field coordination."
  },
  es: {
    title: "Edición Sparky (NEC)",
    body: "Una nueva serie no-IMC: el NEC 2026 estudiado desde la perspectiva de coordinación MEP de un ingeniero mecánico - servicios, alimentadores, puesta a tierra, protección contra sobrecorriente, desconexiones, energía de emergencia, y cómo las decisiones eléctricas afectan a los equipos mecánicos y la coordinación de campo."
  }
}];
// Self-healing: if dct-data.js ever ships articles for a chapter/discipline with no
// curated ALL_CHAPTERS entry (the exact bug that made Chapter 8 briefly invisible),
// auto-generate a fallback entry from the discipline name instead of silently
// dropping the chapter from every filter button, nav card, and count.
(function fillMissingChapterEntries() {
  const known = new Set(ALL_CHAPTERS.map(c => c.discipline));
  ARTICLES.forEach(article => {
    if (article.chapter > 0 && article.discipline && !known.has(article.discipline)) {
      known.add(article.discipline);
      if (window.console && console.warn) {
        console.warn(`Daily Code Talk: chapter ${article.chapter} discipline "${article.discipline}" has articles but no ALL_CHAPTERS entry - add curated copy in daily-code-talk.js. Using a generated fallback for now.`);
      }
      ALL_CHAPTERS.push({
        num: article.chapter,
        discipline: article.discipline,
        codeFamily: /nec|sparky/i.test(article.discipline) ? "NEC" : "IMC",
        en: { title: article.discipline, body: "" },
        es: { title: article.discipline, body: "" }
      });
    }
  });
  ALL_CHAPTERS.sort((a, b) => a.num - b.num);
})();
// ─── Two-series architecture (IMC + NEC), each scaling on its own ─────────
// Daily Code Talk publishes two independent code series: IMC (Mechanical
// Edition) and NEC (Sparky Edition, being built toward full NFPA 70 coverage).
// Chapter grouping, ordering, counts, prev/next, related posts, and every number
// shown on the page are DERIVED from the article data - there is no
// hand-maintained list keyed to the current article count. That is what lets the
// NEC series grow from a handful of posts to IMC scale without another special
// pass, and what keeps one series out of the other's navigation, sequence, and
// statistics.
const NEC_SERIES_KEY = "Sparky Edition";

// NFPA 70 numbers its articles so the leading digit is the chapter (Article 90 is
// the standalone Introduction). Cards are only created for groups that actually
// have published posts, so nothing is promised before it exists.
const NEC_CHAPTER_GROUPS = {
  intro: {
    en: { short: "Art. 90", title: "Introduction - Article 90", body: "Scope, covered and non-covered installations, code arrangement, AHJ authority, mandatory vs. informational language, and equipment examination - settled before any circuit is designed." },
    es: { short: "Art. 90", title: "Introducción - Artículo 90", body: "Alcance, instalaciones cubiertas y no cubiertas, organización del código, autoridad del AHJ, lenguaje obligatorio vs. informativo y examen de equipos - antes de diseñar cualquier circuito." }
  },
  1: {
    en: { short: "Ch. 1", title: "General (Art. 100-110)", body: "Definitions and general requirements: working space, clearances, identification, and equipment approval." },
    es: { short: "Cap. 1", title: "General (Art. 100-110)", body: "Definiciones y requisitos generales: espacio de trabajo, claros, identificación y aprobación de equipos." }
  },
  2: {
    en: { short: "Ch. 2", title: "Wiring and Protection", body: "Branch circuits, feeders, services, load calculations, grounding and bonding, and overcurrent protection." },
    es: { short: "Cap. 2", title: "Cableado y Protección", body: "Circuitos ramales, alimentadores, acometidas, cálculo de cargas, puesta a tierra y protección contra sobrecorriente." }
  },
  3: {
    en: { short: "Ch. 3", title: "Wiring Methods and Materials", body: "Conductors, raceways, cable assemblies, boxes, supports, and how wiring is actually routed through the building." },
    es: { short: "Cap. 3", title: "Métodos y Materiales de Cableado", body: "Conductores, canalizaciones, cables, cajas, soportes y cómo se rutea realmente el cableado en el edificio." }
  },
  4: {
    en: { short: "Ch. 4", title: "Equipment for General Use", body: "Cords, switches, luminaires, appliances, motors, transformers, and the circuits feeding mechanical equipment." },
    es: { short: "Cap. 4", title: "Equipos de Uso General", body: "Cordones, interruptores, luminarias, aparatos, motores, transformadores y circuitos que alimentan equipos mecánicos." }
  },
  5: {
    en: { short: "Ch. 5", title: "Special Occupancies", body: "Hazardous (classified) locations, health care facilities, assembly, garages, and similar occupancies." },
    es: { short: "Cap. 5", title: "Ocupaciones Especiales", body: "Ubicaciones peligrosas (clasificadas), instalaciones de salud, reunión, garajes y ocupaciones similares." }
  },
  6: {
    en: { short: "Ch. 6", title: "Special Equipment", body: "Signs, elevators, pools, industrial machinery, PV, fire pumps, and similar special equipment." },
    es: { short: "Cap. 6", title: "Equipos Especiales", body: "Letreros, elevadores, piscinas, maquinaria industrial, fotovoltaico, bombas contra incendio y equipos similares." }
  },
  7: {
    en: { short: "Ch. 7", title: "Special Conditions", body: "Emergency systems, legally required and optional standby, critical operations power, and fire alarm circuits." },
    es: { short: "Cap. 7", title: "Condiciones Especiales", body: "Sistemas de emergencia, respaldo requerido y opcional, energía de operaciones críticas y circuitos de alarma." }
  },
  8: {
    en: { short: "Ch. 8", title: "Communications Systems", body: "Communications circuits, antennas, network-powered broadband, and premises powering." },
    es: { short: "Cap. 8", title: "Sistemas de Comunicaciones", body: "Circuitos de comunicaciones, antenas, banda ancha alimentada por red y alimentación en sitio." }
  }
};
function articleCodeFamily(article) {
  if (!article) return "IMC";
  return /sparky|\bnec\b/i.test((article.discipline || "") + " " + (article.tag || "")) ? "NEC" : "IMC";
}
// Article number parsed from the post's own metadata, never a hardcoded map, so a
// new NEC post files itself into the right chapter the day it publishes. The word
// boundaries keep a code year ("NEC 2026") from being read as an article number.
function necArticleNumber(article) {
  const sources = [article.tag, article.id, (article.en || {}).title];
  for (const source of sources) {
    const text = String(source || "");
    const found = text.match(/\bnec\b[^0-9a-z]{0,10}(?:article\s*)?\b(\d{2,3})\b/i) || text.match(/(?:^|-)nec-(\d{2,3})(?:[-.]|$)/i) || text.match(/\barticle\s*(\d{2,3})\b/i);
    if (found) return Number(found[1]);
  }
  return null;
}
function necChapterKey(article) {
  const num = necArticleNumber(article);
  if (num === null || num < 100) return "NEC-intro";
  return "NEC-" + Math.min(8, Math.floor(num / 100));
}
function necChapterCopy(key, lang) {
  const id = key === "NEC-intro" ? "intro" : key.replace("NEC-", "");
  const group = NEC_CHAPTER_GROUPS[id] || NEC_CHAPTER_GROUPS.intro;
  return group[lang] || group.en;
}
// NEC chapter cards are built from what is actually published.
function necChapters() {
  const keys = [];
  ARTICLES.forEach(a => {
    if (articleCodeFamily(a) !== "NEC") return;
    const key = necChapterKey(a);
    if (keys.indexOf(key) === -1) keys.push(key);
  });
  const rank = k => (k === "NEC-intro" ? 0 : Number(k.replace("NEC-", "")));
  return keys.sort((a, b) => rank(a) - rank(b)).map(key => ({
    key: key,
    codeFamily: "NEC",
    en: necChapterCopy(key, "en"),
    es: necChapterCopy(key, "es")
  }));
}
function imcChapters() {
  return ALL_CHAPTERS.filter(ch => ch.codeFamily !== "NEC").map(ch => ({
    key: ch.discipline,
    num: ch.num,
    codeFamily: "IMC",
    en: { short: (CHAPTER_NAV_LABELS.en && CHAPTER_NAV_LABELS.en[ch.discipline]) || ch.en.title, title: ch.en.title, body: ch.en.body },
    es: { short: (CHAPTER_NAV_LABELS.es && CHAPTER_NAV_LABELS.es[ch.discipline]) || ch.es.title, title: ch.es.title, body: ch.es.body }
  }));
}
function chaptersForFamily(family) {
  return family === "NEC" ? necChapters() : imcChapters();
}
// One matcher behind every filter, count, and sequence in the archive.
function chapterMatches(article, key) {
  if (!key || key === "All") return true;
  if (key === NEC_SERIES_KEY) return articleCodeFamily(article) === "NEC";
  if (key.indexOf("NEC-") === 0) return articleCodeFamily(article) === "NEC" && necChapterKey(article) === key;
  return article.discipline === key;
}
// The unit a post belongs to for prev/next and related reading. A post is never
// sequenced against a post from the other series.
function articleGroupKey(article) {
  if (articleCodeFamily(article) === "NEC") return necChapterKey(article);
  if (article.chapter > 0 && article.discipline) return article.discipline;
  return "DCT-NOTES";
}
// Drill-down level inside a chapter: IMC section (403) or NEC article (Art. 90).
function articleSubGroup(article) {
  if (articleCodeFamily(article) === "NEC") {
    const num = necArticleNumber(article);
    return num === null ? null : { key: "art-" + num, label: "Art. " + num, sort: num };
  }
  const section = articleSectionNumber(article);
  return section >= 999 ? null : { key: "sec-" + section, label: String(section), sort: section };
}
function chapterArchiveHref(key) {
  const base = "/daily-code-talk/";
  if (!key || key === "All") return base + "#dct-archive";
  if (key.indexOf("NEC-") === 0) return base + "?series=NEC&chapter=" + encodeURIComponent(key) + "#dct-archive";
  return base + "?discipline=" + encodeURIComponent(key) + "#dct-archive";
}
// Legacy name: article cards, discipline pills, and every generated static shell
// still link with ?discipline=<name>. Those links keep working unchanged.
const categoryArchiveHref = chapterArchiveHref;
function initialFilterFromUrl() {
  const fallback = { family: "IMC", chapter: "All" };
  try {
    const params = new URLSearchParams(window.location.search);
    const chapter = params.get("chapter");
    if (chapter && chapter.indexOf("NEC-") === 0) return { family: "NEC", chapter: chapter };
    const requested = params.get("discipline");
    if (requested === NEC_SERIES_KEY) return { family: "NEC", chapter: "All" };
    if (requested && ALL_CHAPTERS.some(c => c.discipline === requested)) return { family: "IMC", chapter: requested };
    if ((params.get("series") || "").toUpperCase() === "NEC") return { family: "NEC", chapter: "All" };
    return fallback;
  } catch (_error) {
    return fallback;
  }
}
// Article bodies are authored with markdown-style bold markers. Anything not
// caught by a heading pattern below must never reach the page as raw "**".
function stripBoldMarkers(text) {
  return String(text == null ? "" : text).replace(/\*\*/g, "");
}
// Author-controlled Markdown links only. React escapes labels/text; never
// interpret HTML or allow script/data/protocol-relative link destinations.
function renderDctInline(value) {
  const text = stripBoldMarkers(value);
  const nodes = [];
  const pattern = /\[([^\]\n]+)\]\(([^\s)]+)\)/g;
  let start = 0;
  for (const match of text.matchAll(pattern)) {
    nodes.push(text.slice(start, match.index));
    const href = match[2];
    let safe = false;
    try {
      const url = new URL(href, "https://masterbuildconsulting.com");
      safe = !/[\\\u0000-\u0020]/.test(href) && !href.startsWith("//") &&
        (href.startsWith("/") || href.startsWith("https://")) &&
        url.protocol === "https:" && !url.username && !url.password;
    } catch (_error) { /* Render rejected destinations as plain text. */ }
    nodes.push(safe ? React.createElement("a", {
      key: "source-" + match.index, href, rel: "noopener noreferrer",
      style: { color: ACCENT, textDecoration: "underline", textUnderlineOffset: 3 }
    }, match[1]) : match[0]);
    start = match.index + match[0].length;
  }
  nodes.push(text.slice(start));
  return nodes;
}
// Every count rendered on this page comes from these three lines. Nothing is
// typed in by hand, so no published number can drift from the corpus.
const IMC_POST_COUNT = ARTICLES.filter(a => articleCodeFamily(a) === "IMC").length;
const NEC_POST_COUNT = ARTICLES.filter(a => articleCodeFamily(a) === "NEC").length;
const IMC_CHAPTER_SPAN = ARTICLES.reduce((max, a) => articleCodeFamily(a) === "IMC" && a.chapter > max ? a.chapter : max, 0);
const ARTICLE_SOURCE_ORDER = new Map(ARTICLES.map((article, index) => [article.id, index]));
function articlePostNumber(article) {
  const match = String(article.num || "").match(/\d+/);
  return match ? Number(match[0]) : Number.MAX_SAFE_INTEGER;
}
function articleSectionNumber(article) {
  const candidates = [article.tag, article.id, (article.en || {}).title];
  for (const candidate of candidates) {
    const match = String(candidate || "").match(/\b(\d{3})(?:\.\d+)?\b/);
    if (match) return Number(match[1]);
  }
  return 999;
}
// NEC posts are numbered 90.1, 90.2(A)(2), 210.8 - not by IMC three-digit
// section - so they need their own sort key. Without this every Article 90 post
// scores 999 and the series has no reliable order at any size.
function necOrderKey(article) {
  const tag = String(article.tag || article.id || "");
  const sub = tag.match(/\b\d{2,3}\.(\d+)/);
  const letter = tag.match(/\b\d{2,3}\.\d+\s*\(([A-Za-z])\)/);
  const art = necArticleNumber(article);
  return [art === null ? -1 : art, sub ? Number(sub[1]) : 0, letter ? letter[1].toUpperCase().charCodeAt(0) - 64 : 0];
}
function isChapterKickoff(article) {
  return /^ch\d+-kickoff$/.test(article.id);
}
function isChapterSummary(article) {
  return /^ch\d+-(recap|summary)$/.test(article.id);
}
function isSectionKickoff(article) {
  return !isChapterKickoff(article) && /kickoff/i.test(`${article.id} ${(article.en || {}).title || ""}`);
}
function isSectionSummary(article) {
  return !isChapterSummary(article) && /(summary|recap)/i.test(`${article.id} ${article.tag} ${(article.en || {}).title || ""}`);
}
function articleSeriesKey(article) {
  if (articleCodeFamily(article) === "NEC") {
    const necKey = necOrderKey(article);
    const necPhase = isSectionKickoff(article) ? 0 : isSectionSummary(article) ? 2 : 1;
    return [necKey[0], necKey[1], necKey[2], necPhase, ARTICLE_SOURCE_ORDER.get(article.id) || 0];
  }
  if (article.id === "kickoff") return [0, -1000, 0, 0, 0];
  if (isChapterKickoff(article)) return [article.chapter, -1000, 0, 0, 0];
  if (isChapterSummary(article)) return [article.chapter, 10000, 0, 0, 0];
  const section = articleSectionNumber(article);
  const phase = isSectionKickoff(article) ? 0 : isSectionSummary(article) ? 2 : 1;
  return [article.chapter, section, phase, articlePostNumber(article), ARTICLE_SOURCE_ORDER.get(article.id) || 0];
}
function compareSeriesOrder(a, b) {
  const aKey = articleSeriesKey(a);
  const bKey = articleSeriesKey(b);
  for (let index = 0; index < aKey.length; index += 1) {
    if (aKey[index] !== bKey[index]) return aKey[index] - bKey[index];
  }
  return a.id.localeCompare(b.id);
}
function seriesRoleLabel(article, lang) {
  if (isChapterKickoff(article)) return lang === "en" ? "Start here" : "Comience aquí";
  if (isChapterSummary(article)) return lang === "en" ? "Chapter summary" : "Resumen del capítulo";
  if (isSectionKickoff(article)) return lang === "en" ? "Section kickoff" : "Inicio de sección";
  if (isSectionSummary(article)) return lang === "en" ? "Section summary" : "Resumen de sección";
  return article.num || (lang === "en" ? "Article" : "Artículo");
}
const CHAPTER_ONE_RECAP = {
  en: {
    eyebrow: "Chapter 1 practical summary",
    title: "The IMC chapter that decides how projects move.",
    intro: "Chapter 1 can look administrative, but it is where permit path, AHJ authority, construction-document quality, inspection sequencing, approvals, appeals, violations, and stop-work response are established.",
    point: "Code compliance is not only the right design. It is the right process, documentation, approvals, sequencing, and response path.",
    items: [{
      title: "Scope and applicability",
      body: "Confirm the code path before detailing: IMC, IRC, IFGC, local amendments, existing-building triggers, repairs, alterations, and occupancy changes."
    }, {
      title: "Authority and approvals",
      body: "Permit approval does not legalize code violations. The code official can interpret, inspect, require support, revoke approvals, and enforce corrections."
    }, {
      title: "Permits and documents",
      body: "A permit-ready set shows location, nature, and extent of work clearly enough to support review, construction, and inspection."
    }, {
      title: "Inspections and enforcement",
      body: "Work that must remain visible should not be buried. Violations and stop-work items need a calm, documented correction path."
    }],
    audiences: [{
      label: "Owners",
      body: "Understand where delay, reinspection, redesign, and contingency burn often begin."
    }, {
      label: "Engineers",
      body: "Show assumptions, listings, manufacturer requirements, and coordination clearly before review."
    }, {
      label: "Contractors",
      body: "Know when field changes need revised approval and when inspection holds control the schedule."
    }],
    primary: "Read the Chapter 1 summary",
    secondary: "Filter Chapter 1 posts"
  },
  es: {
    eyebrow: "Resumen práctico del Capítulo 1",
    title: "El capítulo del IMC que decide cómo avanza el proyecto.",
    intro: "El Capítulo 1 parece administrativo, pero define el camino de permiso, autoridad del AHJ, calidad de documentos, secuencia de inspección, aprobaciones, apelaciones, violaciones y respuesta a stop-work.",
    point: "Cumplir el código no es solo tener el diseño correcto. También exige proceso, documentación, aprobaciones, secuencia y respuesta correcta.",
    items: [{
      title: "Alcance y aplicabilidad",
      body: "Confirme la ruta de código antes de detallar: IMC, IRC, IFGC, enmiendas locales, edificios existentes, reparaciones, alteraciones y cambios de uso."
    }, {
      title: "Autoridad y aprobaciones",
      body: "La aprobación del permiso no legaliza violaciones del código. El funcionario puede interpretar, inspeccionar, pedir soporte, revocar aprobaciones y exigir correcciones."
    }, {
      title: "Permisos y documentos",
      body: "Un set listo para permiso muestra ubicación, naturaleza y extensión del trabajo con suficiente claridad para revisión, construcción e inspección."
    }, {
      title: "Inspecciones y cumplimiento",
      body: "El trabajo que debe quedar visible no debe cubrirse antes de tiempo. Las violaciones y stop-work necesitan una ruta de corrección documentada."
    }],
    audiences: [{
      label: "Propietarios",
      body: "Vea dónde nacen demoras, reinspecciones, rediseño y gasto de contingencia."
    }, {
      label: "Ingenieros",
      body: "Muestre supuestos, listados, requisitos del fabricante y coordinación antes de revisión."
    }, {
      label: "Contratistas",
      body: "Sepa cuándo un cambio en campo requiere aprobación revisada y cuándo la inspección controla el cronograma."
    }],
    primary: "Leer resumen del Capítulo 1",
    secondary: "Filtrar posts del Capítulo 1"
  }
};
function ChapterOneRecap({
  lang,
  onChapterClick
}) {
  const copy = CHAPTER_ONE_RECAP[lang] || CHAPTER_ONE_RECAP.en;
  return /*#__PURE__*/React.createElement("section", {
    "data-dct-chapter-recap": "true",
    style: {
      background: SURFACE,
      borderTop: `3px solid ${ACCENT}`,
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-recap-grid": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0, 1.08fr) minmax(280px, 0.92fr)",
      gap: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "36px 40px",
      borderRight: `1px solid ${BORDER}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 14
    }
  }, copy.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(22px, 3vw, 34px)",
      color: TEXT,
      margin: "0 0 16px",
      lineHeight: 1.12
    }
  }, copy.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.68)",
      lineHeight: 1.75,
      margin: "0 0 18px"
    }
  }, copy.intro), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "15px 17px",
      background: "rgba(196,120,58,0.08)",
      borderLeft: `3px solid ${ACCENT}`,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: TEXT,
      lineHeight: 1.65,
      margin: 0
    }
  }, copy.point)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/daily-code-talk/chapter-1-recap-imc-2024/",
    style: {
      padding: "10px 16px",
      background: ACCENT,
      color: BG,
      textDecoration: "none",
      borderRadius: 3,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, copy.primary, " ->"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onChapterClick,
    style: {
      padding: "10px 16px",
      background: "transparent",
      color: ACCENT,
      border: `1px solid ${ACCENT}`,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, copy.secondary))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "30px 34px",
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, copy.items.map(item => /*#__PURE__*/React.createElement("div", {
    key: item.title,
    style: {
      paddingBottom: 16,
      borderBottom: `1px solid ${BORDER}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 15,
      color: TEXT,
      marginBottom: 6
    }
  }, item.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: MUTED,
      lineHeight: 1.6,
      margin: 0
    }
  }, item.body))), /*#__PURE__*/React.createElement("div", {
    "data-dct-recap-audience": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
      gap: 2
    }
  }, copy.audiences.map(item => /*#__PURE__*/React.createElement("div", {
    key: item.label,
    style: {
      background: BG,
      padding: "14px 14px",
      minHeight: 112
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      marginBottom: 8
    }
  }, item.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: MUTED,
      lineHeight: 1.5,
      margin: 0
    }
  }, item.body)))))));
}
// A first-time reader landing on 222 posts has no obvious way in. Each series
// has one post written as its front door, so surface it above the grid instead
// of making people infer it from the ordering. IDs are real posts in the corpus;
// if one is ever retired this renders nothing rather than a dead link.
const SERIES_START_HERE = {
  IMC: {
    id: "kickoff",
    en: "How permit intake actually works, and what the rest of the IMC series builds on.",
    es: "Cómo funciona realmente la revisión de permisos, y sobre qué se construye el resto de la serie IMC."
  },
  NEC: {
    id: "sparky-edition-launch",
    en: "Why a mechanical engineer reads the NEC, and how this series is organized.",
    es: "Por qué un ingeniero mecánico lee el NEC, y cómo está organizada esta serie."
  }
};
function SeriesStartHere({
  lang,
  codeFamily,
  onOpen
}) {
  const entry = SERIES_START_HERE[codeFamily];
  const article = entry && ARTICLES.find(a => a.id === entry.id);
  if (!article) return null;
  return /*#__PURE__*/React.createElement("button", {
    "data-dct-start-here": codeFamily,
    onClick: () => onOpen(article),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      width: "100%",
      textAlign: "left",
      background: SURFACE,
      border: `1px solid ${BORDER}`,
      borderLeft: `3px solid ${ACCENT}`,
      borderRadius: 3,
      padding: "16px 20px",
      marginBottom: 2,
      cursor: "pointer",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      flexShrink: 0
    }
  }, lang === "en" ? "Start here" : "Empiece aquí"), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 0,
      flex: "1 1 260px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      fontWeight: 600,
      color: TEXT,
      lineHeight: 1.35,
      marginBottom: 3
    }
  }, article[lang].title), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: MUTED,
      lineHeight: 1.55
    }
  }, entry[lang])), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: ACCENT,
      fontWeight: 600,
      flexShrink: 0
    }
  }, lang === "en" ? "Read ->" : "Leer ->"));
}
function DailyCodeTalk() {
  const [lang, setLang] = React.useState(() => {
    const requested = new URLSearchParams(window.location.search).get("lang");
    if (requested === "en" || requested === "es") return requested;
    try { return localStorage.getItem("mb_lang") === "es" ? "es" : "en"; }
    catch (_error) { return "en"; }
  });
  // The code-family tab is the archive's primary axis, not a decoration: it scopes
  // the chapter cards, the chapter filter row, the drill-down chips, the counts,
  // the search, and the post list. Two series of comparable size cannot share one
  // flat list, so nothing below mixes them unless the reader explicitly asks.
  const initialFilter = React.useMemo(initialFilterFromUrl, []);
  const [codeFamily, setCodeFamily] = React.useState(initialFilter.family);
  const [discipline, setDiscipline] = React.useState(initialFilter.chapter);
  const [subGroup, setSubGroup] = React.useState(null);
  const [searchAllSeries, setSearchAllSeries] = React.useState(false);
  const [search, setSearch] = React.useState(function () {
    try { return (new URLSearchParams(window.location.search).get("q") || "").slice(0, 80); }
    catch (_e) { return ""; }
  });
  const [openArticle, setOpenArticle] = React.useState(null);
  const [subscribed, setSubscribed] = React.useState(false);
  const [subscribeError, setSubscribeError] = React.useState("");
  const [email, setEmail] = React.useState("");
  const hasActiveFilter = discipline !== "All" || !!search || !!subGroup;
  React.useEffect(() => {
    localStorage.setItem("mb_lang", lang);
    document.documentElement.lang = lang;
    document.body.dataset.lang = lang;
  }, [lang]);
  const archiveHrefFor = (family, key) => !key || key === "All" ? family === "NEC" ? chapterArchiveHref(NEC_SERIES_KEY) : chapterArchiveHref("All") : chapterArchiveHref(key);
  const selectCodeFamily = nextFamily => {
    setCodeFamily(nextFamily);
    setDiscipline("All");
    setSubGroup(null);
    setSearchAllSeries(false);
    history.replaceState(null, "", archiveHrefFor(nextFamily, "All"));
    if (window.trackMBEvent) window.trackMBEvent("DCT Code Family Tab Click", {
      family: nextFamily,
      language: lang
    });
  };
  const selectDiscipline = (nextDiscipline, scrollTarget = "dct-archive") => {
    const safeDiscipline = nextDiscipline === "All" || chaptersForFamily(codeFamily).some(ch => ch.key === nextDiscipline) ? nextDiscipline : "All";
    setDiscipline(safeDiscipline);
    setSubGroup(null);
    setSearch("");
    history.replaceState(null, "", archiveHrefFor(codeFamily, safeDiscipline));
    requestAnimationFrame(() => {
      const el = document.getElementById(scrollTarget) || document.querySelector('[data-dct-disciplines="true"]');
      if (el && el.scrollIntoView) el.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  };

  // A fresh full-page load (category badge from an article page, or any link ending in
  // #dct-archive) cannot rely on the browser's native hash-scroll: #dct-archive does not
  // exist in the DOM until React mounts it, so by the time the browser tries to scroll,
  // it finds nothing. Filter state from the URL (see initialFilterFromUrl) is already
  // correct at this point - this just brings the filtered results into view to match.
  React.useEffect(() => {
    if ((window.location.hash || "").replace(/^#/, "") !== "dct-archive") return;
    requestAnimationFrame(() => {
      const el = document.getElementById("dct-archive");
      if (el && el.scrollIntoView) el.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  }, []);

  // Open the article referenced by URL hash (e.g. Daily Code Talk.html#imc-403-p1)
  // and keep the URL in sync so deep links from index.html land on the right post.
  const hashInitDone = React.useRef(false);
  React.useEffect(() => {
    const applyHash = () => {
      const id = (window.location.hash || "").replace(/^#/, "");
      if (!id || id === "dct-archive") {
        setOpenArticle(null);
        return;
      }
      const match = ARTICLES.find(a => a.id === id || a.slug === id);
      if (match && match.slug) {
        window.location.replace("/daily-code-talk/" + match.slug + "/");
      }
    };
    applyHash();
    hashInitDone.current = true;
    window.addEventListener("hashchange", applyHash);
    return () => window.removeEventListener("hashchange", applyHash);
  }, []);
  React.useEffect(() => {
    if (!hashInitDone.current) return;
    if (openArticle) {
      if (window.location.hash !== `#${openArticle}`) {
        history.replaceState(null, "", `#${openArticle}`);
      }
      window.scrollTo({
        top: 0,
        behavior: "auto"
      });
    } else if (window.location.hash) {
      history.replaceState(null, "", window.location.pathname + window.location.search);
    }
  }, [openArticle]);
  const openTrackedArticle = article => {
    if (window.trackMBEvent) {
      const content = article[lang] || article.en;
      window.trackMBEvent("Daily Code Talk Article Open", {
        articleId: article.id,
        title: content.title,
        language: lang
      });
    }
    const href = article.slug ? "/daily-code-talk/" + article.slug + "/" : (article.url ? "/" + article.url : "/daily-code-talk/");
    window.location.href = href;
  };
  const matchesText = (a, term) => {
    const needle = String(term || "").toLowerCase().trim();
    if (!needle) return true;
    const compact = needle.replace(/[^a-z0-9.]+/g, " ").replace(/\s+/g, " ").trim();
    const hay = (a.hay || "") + " " + ((a[lang] || a.en || {}).title || "") + " " + ((a[lang] || a.en || {}).summary || "") + " " + (a.tag || "") + " " + (a.id || "") + " " + (a.slug || "");
    if (hay.toLowerCase().indexOf(needle) !== -1) return true;
    if (compact && hay.toLowerCase().indexOf(compact) !== -1) return true;
    const dotted = needle.replace(/\s+/g, ".");
    if (/\d/.test(dotted) && hay.toLowerCase().indexOf(dotted) !== -1) return true;
    const spaced = needle.replace(/\./g, " ");
    return hay.toLowerCase().indexOf(spaced) !== -1;
  };
  const scoreMatch = (a, term) => {
    const needle = String(term || "").toLowerCase().trim();
    if (!needle) return 0;
    const title = ((a[lang] || a.en || {}).title || "").toLowerCase();
    const tag = String(a.tag || "").toLowerCase();
    const slug = String(a.slug || "").toLowerCase();
    const id = String(a.id || "").toLowerCase();
    const hay = String(a.hay || "").toLowerCase();
    const compact = needle.replace(/[^a-z0-9.]+/g, " ").replace(/\s+/g, " ").trim();
    const dotted = needle.replace(/\s+/g, ".");
    let s = 0;
    if (title === needle || tag === needle || id === needle) s += 120;
    if (title.indexOf(needle) !== -1) s += 80;
    if (tag.indexOf(needle) !== -1) s += 70;
    if (/\d/.test(dotted) && (title.indexOf(dotted) !== -1 || tag.indexOf(dotted) !== -1 || hay.indexOf(dotted) !== -1 || slug.indexOf(dotted) !== -1 || id.indexOf(dotted) !== -1)) s += 90;
    if (slug.indexOf(needle.replace(/\s+/g, "-")) !== -1) s += 50;
    if (hay.indexOf(needle) !== -1 || (compact && hay.indexOf(compact) !== -1)) s += 15;
    return s;
  };
  // The active series scopes the list. A search can be widened to both series on
  // request - the only place the two corpora are ever mixed, and only deliberately.
  const searchPool = search && searchAllSeries ? ARTICLES : ARTICLES.filter(a => articleCodeFamily(a) === codeFamily);
  const matchedArticles = searchPool.filter(a => {
    const matchChapter = search && searchAllSeries ? true : chapterMatches(a, discipline);
    const sub = subGroup ? articleSubGroup(a) : null;
    const matchSub = !subGroup || sub && sub.key === subGroup;
    return matchChapter && matchSub && (!search || matchesText(a, search));
  });
  const otherFamily = codeFamily === "IMC" ? "NEC" : "IMC";
  const otherSeriesHits = search && !searchAllSeries ? ARTICLES.filter(a => articleCodeFamily(a) === otherFamily && matchesText(a, search)).length : 0;
  const filtered = search
    ? matchedArticles.slice().sort((a, b) => {
      const diff = scoreMatch(b, search) - scoreMatch(a, search);
      return diff !== 0 ? diff : compareSeriesOrder(a, b);
    })
    : (discipline === "All" && !subGroup ? matchedArticles.slice().reverse() : matchedArticles.slice().sort(compareSeriesOrder));
  const featuredId = codeFamily === "NEC" ? "sparky-nec-90-kickoff" : "imc-701";
  const featured = hasActiveFilter ? null : ARTICLES.find(a => a.id === featuredId) || null;
  const rest = featured ? filtered.filter(a => a.id !== featured.id) : filtered;
  const article = openArticle ? ARTICLES.find(a => a.id === openArticle) : null;
  const articleContent = article ? article[lang] || article["en"] : null;
  const familyChapters = chaptersForFamily(codeFamily);
  const activeChapter = familyChapters.find(ch => ch.key === discipline) || null;
  const activeChapterCopy = activeChapter ? activeChapter[lang] || activeChapter.en : null;
  const activeDisciplineLabel = activeChapterCopy ? activeChapterCopy.title : discipline;
  const activeChapterComplete = activeChapter ? ARTICLES.some(a => chapterMatches(a, activeChapter.key) && isChapterSummary(a)) : false;
  // Section / NEC-article chips inside the selected chapter. A single chapter
  // already holds 68 posts, so a chapter view without this drill-down is a wall
  // of cards - and it gets worse, not better, as either series grows.
  const subGroups = activeChapter ? (() => {
    const seen = {};
    ARTICLES.filter(a => chapterMatches(a, activeChapter.key)).forEach(a => {
      const group = articleSubGroup(a);
      if (!group) return;
      if (!seen[group.key]) seen[group.key] = {
        key: group.key,
        label: group.label,
        sort: group.sort,
        count: 0
      };
      seen[group.key].count += 1;
    });
    return Object.keys(seen).map(k => seen[k]).sort((x, y) => x.sort - y.sort);
  })() : [];
  const activeSubGroup = subGroups.find(g => g.key === subGroup) || null;
  const seriesName = codeFamily === "NEC" ? lang === "en" ? "Sparky Edition (NEC)" : "Edición Sparky (NEC)" : lang === "en" ? "Mechanical Edition (IMC)" : "Edición Mecánica (IMC)";
  const chapterShortLabel = key => {
    if (key === "All") return lang === "en" ? codeFamily === "NEC" ? "All NEC" : "All IMC" : codeFamily === "NEC" ? "Todo NEC" : "Todo IMC";
    const chapter = familyChapters.find(c => c.key === key);
    const copy = chapter ? chapter[lang] || chapter.en : null;
    return copy ? copy.short || copy.title : key;
  };
  const statusLineText = (() => {
    const chapterBody = activeChapterCopy ? activeChapterCopy.body : "";
    const postWord = lang === "en" ? filtered.length === 1 ? "post" : "posts" : filtered.length === 1 ? "publicación" : "publicaciones";
    if (discipline === "All" && !subGroup) {
      return lang === "en" ? "Showing all " + filtered.length + " " + seriesName + " posts, newest first. Pick a chapter to follow its technical sequence from the opening post to the chapter summary." : "Mostrando las " + filtered.length + " publicaciones de " + seriesName + ", más recientes primero. Elija un capítulo para seguir su secuencia técnica desde la publicación inicial hasta el resumen.";
    }
    const scope = activeSubGroup ? activeDisciplineLabel + " · " + activeSubGroup.label : activeDisciplineLabel;
    const progress = activeChapterComplete ? lang === "en" ? "Start with the opening post and finish with the chapter summary." : "Comience con la publicación inicial y termine con el resumen del capítulo." : lang === "en" ? "This chapter is in progress; available posts are shown from the beginning forward." : "Este capítulo está en progreso; las publicaciones disponibles se muestran desde el inicio.";
    return lang === "en" ? "Showing " + filtered.length + " " + scope + " " + postWord + " in series order. " + progress + " " + chapterBody : "Mostrando " + filtered.length + " " + postWord + " de " + scope + " en orden de serie. " + progress + " " + chapterBody;
  })();
  if (article) {
    const content = article[lang] || article["en"];
    const canonicalArticleHref = article.slug ? `/daily-code-talk/${article.slug}/` : `/${article.url || ""}`;
    const metadataTextLinkStyle = {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED,
      textDecoration: "none"
    };
    // Sequence inside this post's own series group. Filtering on chapter number
    // alone put every NEC post and both archive-wide posts in one chapter-0
    // bucket, so "next" could jump from an NEC post to the IMC kickoff.
    const articleFamily = articleCodeFamily(article);
    const articleGroup = articleGroupKey(article);
    const sameChapter = ARTICLES.filter(a => articleCodeFamily(a) === articleFamily && articleGroupKey(a) === articleGroup).sort(compareSeriesOrder);
    const idx = sameChapter.findIndex(a => a.id === article.id);
    const prev = idx > 0 ? sameChapter[idx - 1] : null;
    const next = idx >= 0 && idx < sameChapter.length - 1 ? sameChapter[idx + 1] : null;
    // Keep related reading close to the current point in the same ordered chapter.
    const related = (() => {
      const nearby = sameChapter.filter(a => a.id !== article.id).sort((a, b) => {
        const aDistance = Math.abs(sameChapter.findIndex(item => item.id === a.id) - idx);
        const bDistance = Math.abs(sameChapter.findIndex(item => item.id === b.id) - idx);
        return aDistance - bDistance || compareSeriesOrder(a, b);
      }).slice(0, 4).sort(compareSeriesOrder);
      if (nearby.length >= 4) return nearby;
      const extra = ARTICLES.filter(a => articleCodeFamily(a) === articleFamily && a.discipline === article.discipline && a.id !== article.id && !nearby.find(p => p.id === a.id)).sort(compareSeriesOrder).slice(0, 4 - nearby.length);
      return [...nearby, ...extra].slice(0, 4);
    })();
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: "100vh",
        background: BG
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        position: "sticky",
        top: 0,
        background: "rgba(11,12,14,0.97)",
        borderBottom: `1px solid ${BORDER}`,
        padding: "0 40px",
        height: 56,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        zIndex: 100,
        backdropFilter: "blur(8px)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "/",
      style: {
        textDecoration: "none",
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "/uploads/Master Build Logo- Revised.png",
      alt: "Masterbuild",
      style: {
        height: 26,
        width: 26,
        objectFit: "contain",
        filter: "invert(1)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 800,
        fontSize: 13,
        color: TEXT,
        letterSpacing: "0.04em",
        textTransform: "uppercase"
      }
    }, "Masterbuild")), /*#__PURE__*/React.createElement("span", {
      "data-dct-nav-separator": "true",
      style: {
        color: BORDER,
        fontSize: 16
      }
    }, "|"), /*#__PURE__*/React.createElement("a", {
      href: "/daily-code-talk/",
      "data-dct-nav-label": "true",
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11,
        color: ACCENT,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        textDecoration: "none"
      }
    }, "Daily Code Talk")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpenArticle(null),
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 13,
        color: MUTED,
        background: "none",
        border: "none",
        cursor: "pointer"
      }
    }, "<- ", lang === "en" ? "All Articles" : "Todos los Artículos"), /*#__PURE__*/React.createElement(LangToggle, {
      lang: lang,
      setLang: setLang
    }))), /*#__PURE__*/React.createElement("div", {
      "data-dct-article-body": "true",
      style: {
        maxWidth: 760,
        margin: "0 auto",
        padding: "56px 40px 96px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "center",
        marginBottom: 20,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: categoryArchiveHref(article.discipline),
      "data-dct-meta-link": "discipline",
      "data-dct-category-link": "true",
      "aria-label": `Show all ${article.discipline} Daily Code Talk posts`,
      title: `Show all ${article.discipline} posts`,
      style: {
        display: "inline-flex",
        textDecoration: "none",
        borderRadius: 2
      }
    }, /*#__PURE__*/React.createElement(DisciplinePill, {
      d: article.discipline
    })), /*#__PURE__*/React.createElement("a", {
      href: canonicalArticleHref,
      "data-dct-meta-link": "section",
      "aria-label": `Open the permanent Daily Code Talk post for ${article.tag}`,
      title: "Open permanent post",
      style: metadataTextLinkStyle
    }, article.tag), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("a", {
      href: canonicalArticleHref,
      "data-dct-meta-link": "post-number",
      "aria-label": `Open the permanent Daily Code Talk post ${seriesRoleLabel(article, lang)}`,
      title: "Open permanent post",
      style: metadataTextLinkStyle
    }, seriesRoleLabel(article, lang)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED
      }
    }, article.readTime, " read")), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 800,
        fontSize: "clamp(26px, 4vw, 40px)",
        color: TEXT,
        margin: "0 0 24px",
        lineHeight: 1.15,
        letterSpacing: "-0.01em"
      }
    }, content.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 17,
        color: "rgba(240,237,232,0.65)",
        lineHeight: 1.7,
        margin: "0 0 40px",
        fontStyle: "italic"
      }
    }, content.summary), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 1,
        background: `linear-gradient(to right, ${ACCENT}, transparent)`,
        marginBottom: 40
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, content.body.map((para, i) => {
      // Emoji section headers (🧠 🏗️ 🔧 🧮 🗺️ ✅ ⛔ 📌)
      const emojiHeader = /^(🧠|🏗️|🔧|🧮|🗺️|✅|⛔|📌|🚧|🏷️)/.test(para);
      if (emojiHeader) {
        const colonIdx = para.indexOf(":");
        const icon = para.slice(0, 2);
        const rest = colonIdx > -1 ? para.slice(colonIdx + 1).trim() : para.slice(3).trim();
        const label = colonIdx > -1 ? para.slice(0, colonIdx) : "";
        return /*#__PURE__*/React.createElement("div", {
          key: i,
          style: {
            marginTop: 8
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: 15,
            color: TEXT,
            marginBottom: 6
          }
        }, label || icon), rest && /*#__PURE__*/React.createElement("p", {
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 15,
            color: "rgba(240,237,232,0.6)",
            lineHeight: 1.8,
            margin: 0
          }
        }, rest));
      }
      const labelPrefixes = ["Plain English:", "On Plans:", "Field Tip:", "Code Path:", "Check:", "Review Risk:", "Key Point:", "Calculation Check:", "Coordination Check:", "Labeling Check:"];
      if (labelPrefixes.some(prefix => para.startsWith(prefix))) {
        const [label, ...rest] = para.split(":");
        const note = rest.join(":").trim();
        return /*#__PURE__*/React.createElement("div", {
          key: i,
          style: {
            padding: "14px 16px",
            background: "rgba(196,120,58,0.08)",
            borderLeft: `3px solid ${ACCENT}`
          }
        }, /*#__PURE__*/React.createElement("div", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: 14,
            color: TEXT,
            marginBottom: note ? 4 : 0
          }
        }, label, ":"), note && /*#__PURE__*/React.createElement("p", {
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 14,
            color: "rgba(240,237,232,0.68)",
            lineHeight: 1.7,
            margin: 0
          }
        }, note));
      }
      // Bullet points
      if (para.startsWith("•") || para.startsWith("-")) {
        return /*#__PURE__*/React.createElement("div", {
          key: i,
          style: {
            display: "flex",
            gap: 10,
            alignItems: "flex-start"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            color: ACCENT,
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 13,
            flexShrink: 0,
            marginTop: 2
          }
        }, "\u2022"), /*#__PURE__*/React.createElement("p", {
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 14,
            color: "rgba(240,237,232,0.6)",
            lineHeight: 1.75,
            margin: 0
          }
        }, renderDctInline(para.replace(/^[-•]\s*/, ""))));
      }
      // Numbered list item (1. 2. 3. etc.)
      if (/^\d+[.)]\s/.test(para)) {
        const match = para.match(/^(\d+)[.)]\s+([\s\S]*)$/);
        const num = match ? match[1] : "";
        const text = match ? match[2] : para;
        return /*#__PURE__*/React.createElement("div", {
          key: i,
          style: {
            display: "flex",
            gap: 10,
            alignItems: "flex-start"
          }
        }, /*#__PURE__*/React.createElement("span", {
          style: {
            color: ACCENT,
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 13,
            flexShrink: 0,
            minWidth: 18,
            marginTop: 2
          }
        }, num + "."), /*#__PURE__*/React.createElement("p", {
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 14,
            color: "rgba(240,237,232,0.6)",
            lineHeight: 1.75,
            margin: 0
          }
        }, renderDctInline(text)));
      }
      // "**Heading** - body": a bold label with inline content on the same line.
      // Rendered as a heading plus its text instead of leaking raw ** onto the
      // page. The text after the label is preserved exactly as authored - " - " is
      // used both as a list separator and as a dash inside sentences in this
      // corpus, so it is never re-split into bullets.
      const inlineHeading = para.match(/^\*\*([^*]+)\*\*\s*[-–—]\s+([\s\S]+)$/);
      if (inlineHeading) {
        return /*#__PURE__*/React.createElement("div", {
          key: i
        }, /*#__PURE__*/React.createElement("h3", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: 16,
            color: TEXT,
            margin: "0 0 8px"
          }
        }, inlineHeading[1].trim()), /*#__PURE__*/React.createElement("p", {
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 15,
            color: "rgba(240,237,232,0.6)",
            lineHeight: 1.8,
            margin: 0
          }
        }, renderDctInline(inlineHeading[2].trim())));
      }
      // Bold heading with \n separator - render each rest line as its own paragraph
      if (para.startsWith("**") && para.includes("**\n")) {
        const [heading, ...rest] = para.split("**\n");
        const restLines = rest.join("").split("\n").filter(l => l.trim());
        return /*#__PURE__*/React.createElement("div", {
          key: i
        }, /*#__PURE__*/React.createElement("h3", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: 16,
            color: TEXT,
            margin: "0 0 8px"
          }
        }, heading.replace(/\*\*/g, "")), ...restLines.map((line, j) => /*#__PURE__*/React.createElement("p", {
          key: "r" + j,
          style: {
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 15,
            color: "rgba(240,237,232,0.6)",
            lineHeight: 1.8,
            margin: j === 0 ? 0 : "8px 0 0"
          }
        }, renderDctInline(line))));
      }
      // Standalone bold heading with no inline body content (e.g. "**Do**" ahead
      // of its own separate "- " bullet items further down the body array).
      if (/^\*\*[^*]+\*\*$/.test(para.trim())) {
        return /*#__PURE__*/React.createElement("h3", {
          key: i,
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: 16,
            color: TEXT,
            margin: "0 0 8px"
          }
        }, para.trim().replace(/\*\*/g, ""));
      }
      return /*#__PURE__*/React.createElement("p", {
        key: i,
        style: {
          fontFamily: "'IBM Plex Sans', sans-serif",
          fontSize: 15,
          color: "rgba(240,237,232,0.6)",
          lineHeight: 1.8,
          margin: 0
        }
      }, renderDctInline(para));
    })), dctGuideFor(article.chapter, lang) && /*#__PURE__*/React.createElement("section", {
      "data-dct-guide-cta": "true",
      "data-dct-guide-chapter": String(article.chapter),
      "data-no-print": true,
      style: {
        marginTop: 44,
        padding: 24,
        background: SURFACE,
        border: `1px solid ${ACCENT}`,
        borderRadius: 4,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: ACCENT,
        letterSpacing: "0.12em",
        textTransform: "uppercase",
        marginBottom: 8
      }
    }, (lang === "en" ? "Available Now - " : "Disponible Ahora - ") + dctGuideFor(article.chapter, lang).price), /*#__PURE__*/React.createElement("h2", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 800,
        fontSize: "clamp(19px, 2.6vw, 24px)",
        color: TEXT,
        lineHeight: 1.2,
        margin: "0 0 8px"
      }
    }, dctGuideFor(article.chapter, lang).headline), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 14,
        color: MUTED,
        margin: 0,
        maxWidth: 520
      }
    }, dctGuideFor(article.chapter, lang).body)), /*#__PURE__*/React.createElement("a", {
      href: dctGuideFor(article.chapter, lang).url,
      onClick: () => window.trackMBEvent && window.trackMBEvent("DCT Chapter Guide Purchase Click", {
        source: "article-inline-cta",
        offer: dctGuideFor(article.chapter, lang).key,
        chapter: article.chapter,
        articleId: article.id,
        language: lang
      }),
      style: {
        flexShrink: 0,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: 44,
        padding: "12px 22px",
        background: ACCENT,
        color: BG,
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontWeight: 800,
        fontSize: 14,
        textDecoration: "none",
        borderRadius: 3
      }
    }, lang === "en" ? "Get the Guide -> " : "Obtener la Guía -> ")), /*#__PURE__*/React.createElement(ArticleProjectCTA, {
      article: article,
      lang: lang
    }), /*#__PURE__*/React.createElement("div", {
      "data-no-print": true,
      style: {
        marginTop: 48,
        paddingTop: 24,
        borderTop: `1px solid ${BORDER}`,
        display: "flex",
        alignItems: "center",
        gap: 10,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED,
        letterSpacing: "0.1em",
        textTransform: "uppercase",
        marginRight: 4
      }
    }, lang === "en" ? "Share" : "Compartir"), /*#__PURE__*/React.createElement(ShareLinkButton, {
      article: article,
      lang: lang
    }), /*#__PURE__*/React.createElement("a", {
      href: `mailto:?subject=${encodeURIComponent(content.title + " - Masterbuild Daily Code Talk")}&body=${encodeURIComponent((content.summary || content.title) + "\n\n" + (typeof window !== "undefined" ? window.location.origin + window.location.pathname + "?lang=" + lang + "#" + article.id : ""))}`,
      onClick: () => window.trackMBEvent && window.trackMBEvent("DCT Share", {
        method: "email",
        articleId: article.id,
        language: lang
      }),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "7px 12px",
        background: "transparent",
        border: `1px solid ${BORDER}`,
        borderRadius: 3,
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 12,
        color: MUTED,
        textDecoration: "none",
        transition: "border-color 0.15s, color 0.15s"
      },
      onMouseEnter: e => {
        e.currentTarget.style.borderColor = ACCENT;
        e.currentTarget.style.color = ACCENT;
      },
      onMouseLeave: e => {
        e.currentTarget.style.borderColor = BORDER;
        e.currentTarget.style.color = MUTED;
      }
    }, lang === "en" ? "Email" : "Correo"), /*#__PURE__*/React.createElement("button", {
      onClick: () => {
        window.print();
        if (window.trackMBEvent) window.trackMBEvent("DCT Print", {
          articleId: article.id,
          language: lang
        });
      },
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "7px 12px",
        background: "transparent",
        border: `1px solid ${BORDER}`,
        borderRadius: 3,
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 12,
        color: MUTED,
        cursor: "pointer",
        transition: "border-color 0.15s, color 0.15s"
      },
      onMouseEnter: e => {
        e.currentTarget.style.borderColor = ACCENT;
        e.currentTarget.style.color = ACCENT;
      },
      onMouseLeave: e => {
        e.currentTarget.style.borderColor = BORDER;
        e.currentTarget.style.color = MUTED;
      }
    }, lang === "en" ? "Print" : "Imprimir")), (prev || next) && /*#__PURE__*/React.createElement("div", {
      "data-no-print": true,
      "data-dct-prev-next": "true",
      style: {
        marginTop: 24,
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 12
      }
    }, prev ? /*#__PURE__*/React.createElement("button", {
      onClick: () => openTrackedArticle(prev),
      style: {
        textAlign: "left",
        padding: "16px 18px",
        background: SURFACE,
        border: `1px solid ${BORDER}`,
        borderRadius: 3,
        cursor: "pointer",
        transition: "border-color 0.15s"
      },
      onMouseEnter: e => e.currentTarget.style.borderColor = ACCENT,
      onMouseLeave: e => e.currentTarget.style.borderColor = BORDER
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        marginBottom: 6
      }
    }, "<- ", lang === "en" ? "Previous" : "Anterior"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 600,
        fontSize: 13,
        color: TEXT,
        lineHeight: 1.35
      }
    }, (prev[lang] || prev.en).title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: ACCENT,
        marginTop: 4
      }
    }, prev.tag)) : /*#__PURE__*/React.createElement("div", null), next ? /*#__PURE__*/React.createElement("button", {
      onClick: () => openTrackedArticle(next),
      style: {
        textAlign: "right",
        padding: "16px 18px",
        background: SURFACE,
        border: `1px solid ${BORDER}`,
        borderRadius: 3,
        cursor: "pointer",
        transition: "border-color 0.15s"
      },
      onMouseEnter: e => e.currentTarget.style.borderColor = ACCENT,
      onMouseLeave: e => e.currentTarget.style.borderColor = BORDER
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: MUTED,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        marginBottom: 6
      }
    }, lang === "en" ? "Next" : "Siguiente", " ->"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 600,
        fontSize: 13,
        color: TEXT,
        lineHeight: 1.35
      }
    }, (next[lang] || next.en).title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: ACCENT,
        marginTop: 4
      }
    }, next.tag)) : /*#__PURE__*/React.createElement("div", null)), related.length > 0 && /*#__PURE__*/React.createElement("div", {
      "data-no-print": true,
      style: {
        marginTop: 40
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 10,
        color: ACCENT,
        letterSpacing: "0.1em",
        textTransform: "uppercase",
        marginBottom: 14
      }
    }, lang === "en" ? "Related posts" : "Artículos relacionados"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
        gap: 2
      }
    }, related.map(a => {
      const c = a[lang] || a.en;
      return /*#__PURE__*/React.createElement("button", {
        key: a.id,
        onClick: () => openTrackedArticle(a),
        style: {
          textAlign: "left",
          padding: "14px 16px",
          background: SURFACE,
          border: "none",
          cursor: "pointer",
          transition: "background 0.15s"
        },
        onMouseEnter: e => e.currentTarget.style.background = SURFACE2,
        onMouseLeave: e => e.currentTarget.style.background = SURFACE
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 9,
          color: ACCENT,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          marginBottom: 6
        }
      }, a.tag), /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: "'Plus Jakarta Sans', sans-serif",
          fontWeight: 600,
          fontSize: 13,
          color: TEXT,
          lineHeight: 1.4
        }
      }, c.title));
    }))), /*#__PURE__*/React.createElement("p", {
      style: {
        marginTop: 40,
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 12,
        color: MUTED,
        lineHeight: 1.6
      }
    }, lang === "en" ? "Daily Code Talk is educational decision support. Project-specific engineering, code interpretation, sealed deliverables, and AHJ response strategy require a separate Masterbuild engagement." : "Daily Code Talk es apoyo educativo para la toma de decisiones. La ingenier\xEDa espec\xEDfica del proyecto, la interpretaci\xF3n del c\xF3digo, los entregables sellados y la estrategia de respuesta ante el AHJ requieren un contrato separado con Masterbuild."), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 56,
        padding: "28px 32px",
        background: SURFACE,
        borderTop: `3px solid ${ACCENT}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 700,
        fontSize: 16,
        color: TEXT,
        marginBottom: 4
      }
    }, lang === "en" ? "Have a project that involves this?" : "¿Tiene un proyecto relacionado con esto?"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 13,
        color: MUTED,
        margin: 0
      }
    }, lang === "en" ? "Masterbuild handles MEP permit design, peer review, and technical advisory." : "Masterbuild gestiona diseño de permisos MEP, revisión de pares y asesoría técnica.")), /*#__PURE__*/React.createElement("a", {
      href: lang === "es" ? "/contacto/" : "/send/",
      "data-no-print": true,
      style: {
        padding: "11px 22px",
        background: ACCENT,
        color: BG,
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontWeight: 700,
        fontSize: 13,
        textDecoration: "none",
        borderRadius: 3
      }
    }, lang === "en" ? "Request a Proposal ->" : "Solicitar Propuesta ->"))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: BG
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      background: "rgba(11,12,14,0.97)",
      borderBottom: `1px solid ${BORDER}`,
      padding: "0 40px",
      height: 56,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      zIndex: 100,
      backdropFilter: "blur(8px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/",
    style: {
      textDecoration: "none",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "/uploads/Master Build Logo- Revised.png",
    alt: "Masterbuild",
    style: {
      height: 26,
      width: 26,
      objectFit: "contain",
      filter: "invert(1)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 13,
      color: TEXT,
      letterSpacing: "0.04em",
      textTransform: "uppercase"
    }
  }, "Masterbuild")), /*#__PURE__*/React.createElement("span", {
    "data-dct-nav-separator": "true",
    style: {
      color: BORDER,
      fontSize: 16
    }
  }, "|"), /*#__PURE__*/React.createElement("a", {
    href: "/daily-code-talk/",
    "data-dct-nav-label": "true",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: ACCENT,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      textDecoration: "none"
    }
  }, "Daily Code Talk")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    setLang: setLang
  }))), /*#__PURE__*/React.createElement("div", {
    "data-dct-hero": "true",
    style: {
      background: "#0F1013",
      padding: "64px 40px 56px",
      borderBottom: `1px solid ${BORDER}`,
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: `linear-gradient(to right, rgba(196,120,58,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(196,120,58,0.04) 1px, transparent 1px)`,
      backgroundSize: "48px 48px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      position: "relative",
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-hero-grid": "true",
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      flexWrap: "wrap",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: "5px 12px",
      background: "rgba(196,120,58,0.1)",
      border: "1px solid rgba(196,120,58,0.2)",
      borderRadius: 3,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: ACCENT,
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, "/ Daily Code Talk")), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 4vw, 48px)",
      color: TEXT,
      margin: "0 0 16px",
      letterSpacing: "-0.02em",
      lineHeight: 1.14,
      paddingBottom: "0.04em",
      overflow: "visible"
    }
  }, lang === "en" ? "Daily Code Talk — Mechanical and Electrical Code, Plain English, Built for the Field" : "Daily Code Talk — C\xF3digo Mec\xE1nico y El\xE9ctrico, en Espa\xF1ol Claro, para el Campo"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 16,
      color: MUTED,
      margin: 0,
      maxWidth: 520,
      lineHeight: 1.7
    }
  }, lang === "en" ? "Free archive of plain-language code breakdowns for owners, architects, GCs, designers, and permit coordinators. Two series: Mechanical Edition (IMC) and Sparky Edition (NEC). Pick a series, then a chapter. IMC Chapter 1 Permit Process Field Guide is available in Field Guides & Working Tools." : "Archivo gratuito de explicaciones claras del c\xF3digo para propietarios, arquitectos, contratistas, dise\xF1adores y coordinadores de permisos. Dos series: Edici\xF3n Mec\xE1nica (IMC) y Edici\xF3n Sparky (NEC). Elija una serie y luego un cap\xEDtulo. La Gu\xEDa de Proceso de Permisos IMC Cap\xEDtulo 1 est\xE1 en Gu\xEDas y Herramientas.")), /*#__PURE__*/React.createElement("div", {
    "data-dct-subscribe": "true",
    style: {
      background: SURFACE,
      padding: "24px 28px",
      borderTop: `3px solid ${ACCENT}`,
      minWidth: 300
    }
  }, subscribed ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "8px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 16,
      color: ACCENT,
      marginBottom: 6
    }
  }, "\u2713 ", lang === "en" ? "You're in." : "Suscrito."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: MUTED
    }
  }, lang === "en" ? "New posts will come to your inbox." : "Los nuevos artículos llegarán a su bandeja de entrada.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 10
    }
  }, lang === "en" ? "Get new posts" : "Recibir nuevos artículos"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: MUTED,
      marginBottom: 14,
      lineHeight: 1.5
    }
  }, lang === "en" ? ARTICLES.length + " posts in the archive. Useful code and field guidance when published. EN + ES." : ARTICLES.length + " artículos en el archivo. Guía útil de código y campo cuando se publique. EN + ES."), /*#__PURE__*/React.createElement("div", {
    "data-dct-subscribe-row": "true",
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: email,
    onChange: e => setEmail(e.target.value),
    type: "email",
    placeholder: lang === "en" ? "email@example.com" : "correo@ejemplo.com",
    style: {
      flex: 1,
      padding: "9px 12px",
      background: SURFACE2,
      border: `1px solid ${BORDER}`,
      borderRadius: 3,
      fontSize: 13,
      outline: "none",
      minWidth: 0
    },
    onFocus: e => e.target.style.borderColor = ACCENT,
    onBlur: e => e.target.style.borderColor = BORDER
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if (!email) return;
      setSubscribeError("");
      const fd = new FormData();
      fd.append("email", email.trim());
      const dctCatalog = window.MB_CATALOG || {};
      const dctTags = typeof dctCatalog.subscribeTags === "function" ? dctCatalog.subscribeTags(codeFamily) : [];
      dctTags.forEach(tag => fd.append("tag", tag));
      const dctEndpoint = (dctCatalog.subscribe || {}).endpoint;
      if (!dctEndpoint) {
        setSubscribeError(lang === "en" ? "Could not subscribe. Try again or use buttondown.com/masterbuild." : "No se pudo suscribir. Intente de nuevo o use buttondown.com/masterbuild.");
        return;
      }
      fetch(dctEndpoint, {
        method: "POST",
        body: fd
      }).then(response => {
        if (!response.ok) throw new Error("Subscription request failed");
        if (window.trackMBEvent) window.trackMBEvent("DCT Subscribe", { provider: "buttondown", source: "archive-hero", language: lang, series: codeFamily });
        setSubscribed(true);
      }).catch(() => setSubscribeError(lang === "en" ? "Could not subscribe. Try again or use buttondown.com/masterbuild." : "No se pudo suscribir. Intente de nuevo o use buttondown.com/masterbuild."));
    },
    style: {
      padding: "9px 16px",
      background: ACCENT,
      color: BG,
      border: "none",
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 13,
      whiteSpace: "nowrap"
    }
  }, lang === "en" ? "Subscribe" : "Suscribir")), /*#__PURE__*/React.createElement("p", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 10, color: subscribeError ? "#B74B4B" : MUTED, margin: "10px 0 0", lineHeight: 1.4 }
  }, subscribeError || (lang === "en" ? "Free Code Desk email list. Unsubscribe anytime. We do not sell subscriber data." : "Lista gratuita Code Desk. Puede cancelar cuando quiera. No vendemos datos de suscriptores."))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: BG,
      borderBottom: `1px solid ${BORDER}`,
      padding: "0 40px 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-stat-grid": "true"
  }, [{
    value: String(ARTICLES.length),
    label: lang === "en" ? "public Daily Code Talk posts" : "artículos públicos de Daily Code Talk"
  }, {
    value: String(IMC_POST_COUNT),
    label: lang === "en" ? "Mechanical Edition (IMC) posts · Ch. 1-" + IMC_CHAPTER_SPAN : "publicaciones Edición Mecánica (IMC) · Cap. 1-" + IMC_CHAPTER_SPAN
  }, {
    value: String(NEC_POST_COUNT),
    label: lang === "en" ? "Sparky Edition (NEC) posts · building toward NFPA 70" : "publicaciones Edición Sparky (NEC) · avanzando hacia NFPA 70"
  }, {
    value: "EN / ES",
    label: lang === "en" ? "every post published in both languages" : "cada publicación en ambos idiomas"
  }].map(stat => /*#__PURE__*/React.createElement("div", {
    key: stat.label,
    "data-dct-stat-card": "true"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 34,
      color: ACCENT,
      lineHeight: 1
    }
  }, stat.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: MUTED,
      lineHeight: 1.45,
      marginTop: 6
    }
  }, stat.label)))))), /*#__PURE__*/React.createElement("div", {
    "data-dct-resources-teaser": "true",
    style: {
      background: SURFACE,
      borderTop: `3px solid ${ACCENT}`,
      borderBottom: `1px solid ${BORDER}`,
      padding: "20px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: { minWidth: 0 }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginRight: 10
    }
  }, lang === "en" ? "/ Paid Resources" : "/ Recursos de Pago"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.7)"
    }
  }, lang === "en" ? "Prefer a structured toolkit over reading articles? Field guides and checklists start at $57." : "\xBFPrefiere un kit estructurado en lugar de leer art\xEDculos? Las gu\xEDas y checklists comienzan en $57.")), /*#__PURE__*/React.createElement("a", {
    href: "/resources/",
    onClick: () => window.trackMBEvent && window.trackMBEvent("DCT Resources Teaser Click", { language: lang }),
    style: {
      flexShrink: 0,
      padding: "10px 18px",
      background: ACCENT,
      color: BG,
      borderRadius: 3,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700,
      textDecoration: "none",
      whiteSpace: "nowrap"
    }
  }, lang === "en" ? "See Field Guides & Tools →" : "Ver Gu\xEDas y Herramientas →"))),
/*#__PURE__*/React.createElement("div", {
    style: {
      background: BG,
      borderBottom: `1px solid ${BORDER}`,
      padding: "44px 40px 48px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 24,
      flexWrap: "wrap",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 10
    }
  }, codeFamily === "NEC" ? lang === "en" ? "Browse NEC · Sparky Edition" : "Explorar NEC · Edición Sparky" : lang === "en" ? "Browse by chapter" : "Explorar por capítulo"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(24px, 3vw, 36px)",
      color: TEXT,
      margin: 0,
      lineHeight: 1.1
    }
  }, codeFamily === "NEC" ? lang === "en" ? "Sparky Edition: the NEC, built toward full NFPA 70 coverage." : "Edición Sparky: el NEC, hacia cobertura completa de NFPA 70." : lang === "en" ? "The IMC chapters that decide permit speed." : "Los capítulos del IMC que deciden la velocidad del permiso.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: MUTED,
      lineHeight: 1.6,
      margin: 0,
      maxWidth: 420
    }
  }, codeFamily === "NEC" ? lang === "en" ? "Electrical code studied from an MEP-coordination lens - a growing series that will eventually track NFPA 70 chapter by chapter." : "Código eléctrico estudiado desde una perspectiva de coordinación MEP - una serie en crecimiento que eventualmente cubrirá NFPA 70 capítulo por capítulo." : lang === "en" ? "Use this as a fast selector: pick the review problem first, then search the filtered articles by section number or issue." : "Use esto como selector rápido: elija primero el problema de revisión y luego busque los artículos filtrados por sección o tema.")), /*#__PURE__*/React.createElement("div", {
    "data-dct-code-family-tabs": "true",
    role: "tablist",
    "aria-label": lang === "en" ? "Code family" : "Familia de código",
    style: {
      display: "flex",
      gap: 8,
      marginBottom: 20,
      flexWrap: "wrap"
    }
  }, [{
    id: "IMC",
    label: lang === "en" ? "IMC · Mechanical Edition" : "IMC · Edición Mecánica",
    sub: lang === "en" ? IMC_POST_COUNT + " posts · Ch. 1-" + IMC_CHAPTER_SPAN : IMC_POST_COUNT + " publicaciones · Cap. 1-" + IMC_CHAPTER_SPAN
  }, {
    id: "NEC",
    label: lang === "en" ? "NEC · Sparky Edition" : "NEC · Edición Sparky",
    sub: lang === "en" ? NEC_POST_COUNT + " posts · toward full NFPA 70" : NEC_POST_COUNT + " publicaciones · hacia NFPA 70 completo"
  }].map(fam => /*#__PURE__*/React.createElement("button", {
    key: fam.id,
    type: "button",
    role: "tab",
    "aria-selected": codeFamily === fam.id,
    onClick: () => selectCodeFamily(fam.id),
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8,
      padding: "10px 16px",
      background: codeFamily === fam.id ? "rgba(196,120,58,0.12)" : SURFACE,
      border: codeFamily === fam.id ? `1px solid ${ACCENT}` : `1px solid ${BORDER}`,
      borderRadius: 3,
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 13.5,
      color: codeFamily === fam.id ? ACCENT : TEXT
    }
  }, fam.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED,
      letterSpacing: "0.03em"
    }
  }, fam.sub)))), /*#__PURE__*/React.createElement("div", {
    "data-dct-chapters-grid": "true"
  }, familyChapters.map(ch => {
    const copy = ch[lang] || ch.en;
    const isSparky = ch.codeFamily === "NEC";
    const navLabel = copy.short || copy.title;
    const count = ARTICLES.filter(a => chapterMatches(a, ch.key)).length;
    const isComplete = ARTICLES.some(a => chapterMatches(a, ch.key) && isChapterSummary(a));
    const isActive = discipline === ch.key;
    const countLabel = count === 1 ? lang === "en" ? "post" : "publicación" : lang === "en" ? "posts" : "publicaciones";
    const progressLabel = isComplete ? "" : lang === "en" ? " · In progress" : " · En progreso";
    const chapterBadge = isSparky ? ch.key === "NEC-intro" ? "90" : ch.key.replace("NEC-", "") : String(ch.num);
    const chapterLabel = isSparky ? "NEC 2026" : lang === "en" ? "Ch. " + ch.num : "Cap. " + ch.num;
    return /*#__PURE__*/React.createElement("button", {
      key: ch.key,
      "data-dct-chapter-card": "true",
      "data-active": isActive ? "true" : "false",
      onClick: () => {
        selectDiscipline(ch.key, "dct-archive");
        if (window.trackMBEvent) window.trackMBEvent("DCT Chapter Card Click", {
          chapter: ch.key,
          discipline: ch.key,
          language: lang
        });
      }
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        width: 28,
        height: 28,
        borderRadius: 3,
        background: isActive ? ACCENT : "rgba(196,120,58,0.12)",
        color: isActive ? BG : ACCENT,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: chapterBadge.length > 2 ? 9 : 12,
        fontWeight: 700
      }
    }, chapterBadge), /*#__PURE__*/React.createElement("span", {
      style: {
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontWeight: 800,
        fontSize: 13.5,
        color: TEXT,
        lineHeight: 1.1,
        whiteSpace: "nowrap"
      }
    }, navLabel), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9.5,
        color: isActive ? ACCENT : MUTED,
        letterSpacing: "0.05em",
        textTransform: "uppercase"
      }
    }, chapterLabel + " · " + count + " " + countLabel + progressLabel)));
  })), subGroups.length > 1 && /*#__PURE__*/React.createElement("div", {
    "data-dct-subgroups": "true",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flexWrap: "wrap",
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      marginRight: 4
    }
  }, codeFamily === "NEC" ? lang === "en" ? "Jump to article" : "Ir al artículo" : lang === "en" ? "Jump to section" : "Ir a la sección"), [{
    key: null,
    label: lang === "en" ? "All" : "Todas",
    count: filtered.length
  }].concat(subGroups).map(group => /*#__PURE__*/React.createElement("button", {
    key: group.key || "all",
    type: "button",
    "aria-pressed": subGroup === group.key,
    onClick: () => setSubGroup(group.key),
    style: {
      padding: "5px 10px",
      background: subGroup === group.key ? ACCENT : "transparent",
      color: subGroup === group.key ? BG : MUTED,
      border: subGroup === group.key ? "none" : "1px solid " + BORDER,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      minHeight: 30
    }
  }, group.label, group.key ? " · " + group.count : ""))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      padding: "14px 16px",
      background: SURFACE,
      border: `1px solid ${BORDER}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12.5,
      color: MUTED,
      lineHeight: 1.5,
      maxWidth: 820
    }
  }, statusLineText), discipline !== "All" && /*#__PURE__*/React.createElement("button", {
    onClick: () => selectDiscipline("All"),
    style: {
      padding: "7px 12px",
      background: "transparent",
      border: `1px solid ${BORDER}`,
      color: MUTED,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      flexShrink: 0
    }
  }, lang === "en" ? "Clear chapter filter" : "Quitar filtro")))), /*#__PURE__*/React.createElement("div", {
  id: "dct-archive",
  style: {
    background: BG,
    padding: "20px 40px 4px"
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    maxWidth: 1200,
    margin: "0 auto",
    paddingBottom: 14,
    borderBottom: `1px solid ${BORDER}`,
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap"
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 10,
    color: ACCENT,
    letterSpacing: "0.1em",
    textTransform: "uppercase"
  }
}, lang === "en" ? "Free Archive — All Daily Code Talk Posts" : "Archivo Gratuito — Todos los Art\xEDculos de Daily Code Talk"), /*#__PURE__*/React.createElement("span", {
  style: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 10,
    color: MUTED
  }
}, lang === "en" ? "No cost · EN + ES · " + ARTICLES.length + " posts" : "Sin costo · EN + ES · " + ARTICLES.length + " art\xEDculos"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: SURFACE,
      borderBottom: `1px solid ${BORDER}`,
      padding: "0 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-search-row": "true",
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 20,
      flexWrap: "wrap",
      padding: "12px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-disciplines": "true",
    style: {
      display: "flex",
      gap: 4,
      flexWrap: "wrap"
    }
  }, ["All"].concat(familyChapters.map(ch => ch.key)).map(d => /*#__PURE__*/React.createElement("a", {
    key: d,
    href: categoryArchiveHref(d),
    "data-dct-filter-link": "true",
    onClick: event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
      event.preventDefault();
      selectDiscipline(d);
    },
    style: {
      padding: "6px 14px",
      background: discipline === d ? ACCENT : "transparent",
      color: discipline === d ? BG : MUTED,
      border: discipline === d ? "none" : `1px solid ${BORDER}`,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      fontWeight: discipline === d ? 600 : 400,
      textDecoration: "none",
      transition: "all 0.15s"
    }
  }, chapterShortLabel(d)))), /*#__PURE__*/React.createElement("input", {
    value: search,
    onChange: e => setSearch(e.target.value),
    placeholder: lang === "en" ? "Search articles…" : "Buscar artículos…",
    style: {
      padding: "8px 14px",
      background: SURFACE2,
      border: `1px solid ${BORDER}`,
      borderRadius: 3,
      fontSize: 13,
      outline: "none",
      width: 220
    },
    onFocus: e => e.target.style.borderColor = ACCENT,
    onBlur: e => e.target.style.borderColor = BORDER
  }), search && /*#__PURE__*/React.createElement("div", {
    "data-dct-search-meta": "true",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap",
      width: "100%",
      paddingTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "status",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: MUTED
    }
  }, filtered.length + (lang === "en" ? " result" + (filtered.length === 1 ? "" : "s") + (searchAllSeries ? " · both series" : " in " + seriesName) : " resultado" + (filtered.length === 1 ? "" : "s") + (searchAllSeries ? " · ambas series" : " en " + seriesName))), otherSeriesHits > 0 && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setSearchAllSeries(true),
    style: {
      padding: "5px 10px",
      background: "transparent",
      border: "1px solid " + ACCENT,
      color: ACCENT,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      minHeight: 30
    }
  }, lang === "en" ? otherSeriesHits + " more in " + (otherFamily === "NEC" ? "Sparky Edition (NEC)" : "Mechanical Edition (IMC)") + " - search both" : otherSeriesHits + " más en " + (otherFamily === "NEC" ? "Edición Sparky (NEC)" : "Edición Mecánica (IMC)") + " - buscar ambas"), searchAllSeries && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setSearchAllSeries(false),
    style: {
      padding: "5px 10px",
      background: "transparent",
      border: "1px solid " + BORDER,
      color: MUTED,
      borderRadius: 3,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      minHeight: 30
    }
  }, lang === "en" ? "Back to " + seriesName + " only" : "Volver solo a " + seriesName)))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      padding: "48px 40px 96px"
    }
  }, filtered.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "80px 0",
      color: MUTED,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15
    }
  }, lang === "en" ? "No articles match your filter." : "Ningún artículo coincide con su filtro.") : /*#__PURE__*/React.createElement(React.Fragment, null, !hasActiveFilter && codeFamily === "IMC" && /*#__PURE__*/React.createElement(ChapterOneRecap, {
    lang: lang,
    onChapterClick: () => {
      selectDiscipline("Administration");
      requestAnimationFrame(() => {
        const el = document.querySelector('[data-dct-disciplines="true"]');
        if (el && el.scrollIntoView) el.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      });
    }
  }), featured && /*#__PURE__*/React.createElement("div", {
    style: {
      background: SURFACE,
      borderTop: `3px solid ${ACCENT}`,
      marginBottom: 40,
      cursor: "pointer"
    },
    onClick: () => openTrackedArticle(featured)
  }, /*#__PURE__*/React.createElement("div", {
    "data-dct-featured-grid": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 44px",
      borderRight: `1px solid ${BORDER}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      marginBottom: 16,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: categoryArchiveHref(featured.discipline),
    "data-dct-category-link": "true",
    "aria-label": `Show all ${featured.discipline} Daily Code Talk posts`,
    onClick: event => event.stopPropagation(),
    style: {
      display: "inline-flex",
      textDecoration: "none",
      borderRadius: 2
    }
  }, /*#__PURE__*/React.createElement(DisciplinePill, {
    d: featured.discipline
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED
    }
  }, featured.tag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED
    }
  }, "\xB7 ", lang === "en" ? "Featured" : "Destacado")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(20px, 2.5vw, 28px)",
      color: TEXT,
      margin: "0 0 16px",
      lineHeight: 1.2
    }
  }, featured[lang].title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: MUTED,
      lineHeight: 1.7,
      margin: "0 0 24px"
    }
  }, featured[lang].summary), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: ACCENT,
      fontWeight: 600
    }
  }, lang === "en" ? "Read article ->" : "Leer artículo ->")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 44px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      marginBottom: 16
    }
  }, lang === "en" ? "Also in this issue" : "También en esta edición"), rest.slice(0, 3).map(a => /*#__PURE__*/React.createElement("div", {
    key: a.id,
    style: {
      padding: "14px 0",
      borderBottom: `1px solid ${BORDER}`,
      cursor: "pointer"
    },
    onClick: e => {
      e.stopPropagation();
      openTrackedArticle(a);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      marginBottom: 5
    }
  }, a.tag), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: TEXT,
      fontWeight: 500,
      lineHeight: 1.35
    }
  }, a[lang].title)))))), /*#__PURE__*/React.createElement(SeriesStartHere, {
    lang: lang,
    codeFamily: codeFamily,
    onOpen: openTrackedArticle
  }), /*#__PURE__*/React.createElement("div", {
    "data-dct-grid": "true",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
      gap: 2
    }
  }, rest.map(a => /*#__PURE__*/React.createElement(ArticleCard, {
    key: a.id,
    article: a,
    lang: lang,
    onClick: () => openTrackedArticle(a)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 64,
      padding: "40px 48px",
      background: SURFACE,
      borderTop: `3px solid ${ACCENT}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      flexWrap: "wrap",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 22,
      color: TEXT,
      marginBottom: 8
    }
  }, lang === "en" ? "Need this applied to an actual project?" : "¿Necesita esto aplicado a un proyecto real?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: MUTED,
      margin: 0,
      maxWidth: 480
    }
  }, lang === "en" ? "Masterbuild provides PE-led MEP permit design, technical review, and construction-phase advisory from a Florida-licensed, Miami-based PE. TX, NJ, NY, and PA project support is reviewed by request." : "Masterbuild proporciona diseño de permisos MEP liderado por PE, revisión técnica y asesoría de construcción desde una práctica con sede en Miami y licencia en Florida. El apoyo en TX, NJ, NY y PA se revisa por solicitud.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: lang === "es" ? "/contacto/" : "/send/",
    style: {
      padding: "12px 22px",
      background: ACCENT,
      color: BG,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 13,
      textDecoration: "none",
      borderRadius: 3
    }
  }, lang === "en" ? "Request a Proposal ->" : "Solicitar Propuesta ->")))));
}
function ArticleProjectCTA({
  article,
  lang
}) {
  // Code-edition disclaimer routing. Keyed to the derived code family so a future
  // NEC post carrying a different discipline label still gets NEC language - an
  // NEC post must never show the IMC disclaimer, or the reverse.
  const isSparky = Boolean(article) && articleCodeFamily(article) === "NEC";
  const sparkyNote = lang === "es" ? "Sparky Edition usa el NEC 2026 como educación del código modelo. Verifique la edición del NEC localmente adoptada, enmiendas, alcance, listados, fabricante y AHJ antes de usarlo en un proyecto." : "Sparky Edition uses the 2026 NEC as model-code education. Verify the locally adopted NEC edition, amendments, scope, listings, manufacturer instructions, and AHJ path before project use.";
  const imcNote = lang === "es" ? "Daily Code Talk usa el IMC 2024 como educación del código modelo. Verifique el código adoptado, enmiendas, alcance, listados, fabricante y AHJ antes de usarlo en un proyecto." : "Daily Code Talk uses the 2024 IMC as model-code education. Verify the adopted code, amendments, scope, listings, manufacturer instructions, and AHJ path before project use.";
  const copy = lang === "es" ? {
    eyebrow: "Soporte de proyecto liderado por PE",
    title: "¿Necesita aplicar esto a un proyecto real?",
    body: "Masterbuild Consulting ayuda a propietarios, arquitectos, contratistas generales y equipos de proyecto a convertir preguntas de código en decisiones MEP listas para permiso antes de que los comentarios, cambios en campo o inspecciones cuesten más tiempo.",
    primary: "Enviar información del proyecto",
    secondary: "Agendar llamada de 30 minutos",
    archive: "Explorar el archivo DCT",
    note: isSparky ? sparkyNote : imcNote
  } : {
    eyebrow: "PE-led project support",
    title: "Need this applied to a live project?",
    body: "Masterbuild Consulting helps owners, architects, GCs, and project teams turn code questions into permit-ready MEP decisions before review comments, field changes, or inspection issues cost more time.",
    primary: "Request project review",
    secondary: "Book scoping call",
    archive: "Browse DCT archive",
    note: isSparky ? sparkyNote : imcNote
  };
  const track = target => {
    if (window.trackMBEvent) window.trackMBEvent("DCT Article CTA Click", {
      target,
      articleId: article.id,
      language: lang
    });
  };
  return /*#__PURE__*/React.createElement("section", {
    "data-dct-project-cta": "true",
    "data-no-print": true,
    style: {
      marginTop: 44,
      padding: 24,
      background: "linear-gradient(135deg, rgba(196,120,58,0.18), rgba(19,20,23,0.96))",
      border: "1px solid rgba(196,120,58,0.34)",
      borderRadius: 4,
      boxShadow: "0 18px 60px rgba(0,0,0,0.22)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: ACCENT,
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      marginBottom: 10
    }
  }, copy.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(21px, 3vw, 28px)",
      color: TEXT,
      lineHeight: 1.16,
      letterSpacing: 0,
      margin: "0 0 10px"
    }
  }, copy.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.72)",
      lineHeight: 1.7,
      margin: 0,
      maxWidth: 660
    }
  }, copy.body), /*#__PURE__*/React.createElement("div", {
    "data-dct-project-cta-actions": "true",
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap",
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: lang === "es" ? "/contacto/" : "/send/",
    onClick: () => track("contact"),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 42,
      padding: "10px 16px",
      background: ACCENT,
      border: `1px solid ${ACCENT}`,
      borderRadius: 3,
      color: BG,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 800,
      fontSize: 13,
      textDecoration: "none"
    }
  }, copy.primary), /*#__PURE__*/React.createElement("a", {
    href: DCT_SCOPING_CALL_URL,
    target: "_blank",
    rel: "noopener noreferrer",
    onClick: () => track("scoping-call"),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 42,
      padding: "10px 16px",
      background: "rgba(11,12,14,0.35)",
      border: `1px solid ${BORDER}`,
      borderRadius: 3,
      color: TEXT,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 13,
      textDecoration: "none"
    }
  }, copy.secondary), /*#__PURE__*/React.createElement("a", {
    href: "/daily-code-talk/",
    onClick: () => track("archive"),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 42,
      padding: "10px 16px",
      background: "transparent",
      border: `1px solid ${BORDER}`,
      borderRadius: 3,
      color: MUTED,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 13,
      textDecoration: "none"
    }
  }, copy.archive)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.52)",
      lineHeight: 1.6,
      margin: "14px 0 0",
      maxWidth: 640
    }
  }, copy.note));
}
function ShareLinkButton({
  article,
  lang
}) {
  const [copied, setCopied] = React.useState(false);
  const onCopy = async () => {
    const url = `${window.location.origin}${window.location.pathname}?lang=${lang}#${article.id}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        const ta = document.createElement("textarea");
        ta.value = url;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
      setCopied(true);
      if (window.trackMBEvent) window.trackMBEvent("DCT Share", {
        method: "copy-link",
        articleId: article.id,
        language: lang
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {/* ignore */}
  };
  return /*#__PURE__*/React.createElement("button", {
    onClick: onCopy,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "7px 12px",
      background: copied ? "rgba(196,120,58,0.15)" : "transparent",
      border: `1px solid ${copied ? ACCENT : BORDER}`,
      borderRadius: 3,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: copied ? ACCENT : MUTED,
      cursor: "pointer",
      transition: "all 0.15s"
    },
    onMouseEnter: e => {
      if (!copied) {
        e.currentTarget.style.borderColor = ACCENT;
        e.currentTarget.style.color = ACCENT;
      }
    },
    onMouseLeave: e => {
      if (!copied) {
        e.currentTarget.style.borderColor = BORDER;
        e.currentTarget.style.color = MUTED;
      }
    }
  }, copied ? lang === "en" ? "✓ Copied" : "✓ Copiado" : lang === "en" ? "Copy link" : "Copiar enlace");
}
function LangToggle({
  lang,
  setLang
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 0,
      background: SURFACE,
      borderRadius: 3,
      overflow: "hidden",
      border: `1px solid ${BORDER}`
    }
  }, ["en", "es"].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => setLang(l),
    style: {
      padding: "5px 10px",
      background: lang === l ? ACCENT : "transparent",
      color: lang === l ? BG : MUTED,
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      transition: "all 0.2s"
    }
  }, l)));
}
function DisciplinePill({
  d
}) {
  const colors = {
    "Administration": ACCENT,
    "Definitions": "#B87ACF",
    "Installation": "#4A9EBF",
    "Ventilation": "#7CB87A",
    "Exhaust Systems": "#D96B5A",
    "Combustion Air": "#E0A95B",
    "Venting Systems": "#4FBFA8",
    "HVAC": "#4A9EBF",
    "Plumbing": "#7CB87A",
    "Fire Protection": "#D96B5A",
    "Electrical": "#B87ACF",
    "Sparky Edition": "#D8B25A",
    "Code Logic": ACCENT,
    "Coordination": "#A0A0A0"
  };
  const color = colors[d] || ACCENT;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      padding: "3px 8px",
      background: `${color}18`,
      color,
      border: `1px solid ${color}30`,
      borderRadius: 2,
      letterSpacing: "0.05em"
    }
  }, d);
}
function ArticleCard({
  article,
  lang,
  onClick
}) {
  const [hov, setHov] = React.useState(false);
  const content = article[lang] || article["en"];
  const href = article.slug ? `/daily-code-talk/${article.slug}/` : `/${article.url || ""}`;
  const categoryHref = categoryArchiveHref(article.discipline);
  const handleArticleClick = e => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    if (typeof onClick === "function") onClick();
  };
  const handleCardClick = e => {
    if (e.target.closest && e.target.closest("a")) return;
    window.location.href = href;
  };
  return /*#__PURE__*/React.createElement("article", {
    "data-dct-article-card": "true",
    "data-dct-article-id": article.id,
    onClick: handleCardClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      display: "block",
      background: hov ? "#1C1E23" : SURFACE,
      padding: "28px 28px",
      cursor: "pointer",
      borderBottom: hov ? `2px solid ${ACCENT}` : "2px solid transparent",
      transition: "all 0.15s",
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 12,
      flexWrap: "wrap",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: categoryHref,
    "data-dct-category-link": "true",
    "aria-label": `Show all ${article.discipline} Daily Code Talk posts`,
    title: `Show all ${article.discipline} posts`,
    style: {
      display: "inline-flex",
      textDecoration: "none",
      borderRadius: 2
    }
  }, /*#__PURE__*/React.createElement(DisciplinePill, {
    d: article.discipline
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED
    }
  }, seriesRoleLabel(article, lang), " \xB7 ", article.readTime)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: MUTED,
      marginBottom: 8
    }
  }, article.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 600,
      fontSize: 16,
      color: TEXT,
      margin: "0 0 10px",
      lineHeight: 1.3
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: handleArticleClick,
    style: {
      color: "inherit",
      textDecoration: "none"
    }
  }, content.title)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: MUTED,
      margin: "0 0 16px",
      lineHeight: 1.6
    }
  }, content.summary), /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: handleArticleClick,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: ACCENT,
      fontWeight: 600,
      textDecoration: "none"
    }
  }, lang === "en" ? "Read ->" : "Leer ->"));
}
const dctRoot = ReactDOM.createRoot(document.getElementById("root"));
dctRoot.render(/*#__PURE__*/React.createElement(DailyCodeTalk, null));
