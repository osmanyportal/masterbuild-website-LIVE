// mb-orbital.js - IMC Chapter Orbit  +  Animated Reveal Utilities
// Pure React (React.createElement), zero external dependencies.
// Inspired by the radial-orbital-timeline and animated-hero patterns.
// Adds: MBChapterOrbit section + MBRevealObserver scroll-reveal hook.

// ─── Chapter data ─────────────────────────────────────────────────────────────
const CHAPTER_DATA = {
  en: [
    {
      id: "ch1", num: "1", title: "Administration",
      tag: "The Permit Framework",
      desc: "How mechanical permits work - scope, authority, approval, inspections, violations, and the process rules that govern every project.",
      points: ["Scope & applicability", "Permits & approval process", "AHJ authority limits", "Inspections & testing holds", "Violations & stop-work"],
      articles: 16, link: "/daily-code-talk/#kickoff",
      hasPaidGuide: true, guideHint: "Permit Readiness Review Pack"
    },
    {
      id: "ch2", num: "2", title: "Definitions",
      tag: "The Language Layer",
      desc: "The terms that control which rule applies. Plenum vs. duct, appliance vs. equipment, hood types, damper classifications - get the label wrong and the compliance path changes.",
      points: ["Plenum vs. duct", "Appliance vs. equipment", "Fire/smoke damper types", "Hood type definitions", "Flash point classifications"],
      articles: 4, link: "/daily-code-talk/#imc-201",
      hasPaidGuide: false, guideHint: null
    },
    {
      id: "ch3", num: "3", title: "General Regulations",
      tag: "Installation Baseline",
      desc: "The requirements that apply to every mechanical system regardless of type - listings, labels, location rules, pipe support, service clearances, and structural compliance.",
      points: ["Listed & labeled requirements", "Equipment location rules", "Mounting heights & garages", "Pipe support spacing", "Service clearance dimensions"],
      articles: 23, link: "/daily-code-talk/#imc-301-part-1",
      hasPaidGuide: true, guideHint: "Permit Readiness Review Pack"
    },
    {
      id: "ch4", num: "4", title: "Ventilation",
      tag: "The OA Math",
      desc: "Outdoor air calculations, natural vs. mechanical method selection, garage CO/NO₂ control, healthcare ASHRAE 170, and the breathing-zone math that reviewers check first.",
      points: ["Breathing-zone OA calculation", "Natural vs. mechanical method", "Garage CO + NO₂ control", "Healthcare ASHRAE 170/NFPA 99", "DCV & controls logic"],
      articles: 17, link: "/daily-code-talk/#imc-401-part-1",
      hasPaidGuide: true, guideHint: "Ventilation & Special Exhaust Field Guide"
    },
    {
      id: "ch5", num: "5", title: "Exhaust Systems",
      tag: "The High-Stakes Chapter",
      desc: "From grease ducts to hazardous exhaust to smoke control - the most fire-risk-intensive chapter in the IMC. System independence, termination clearances, and makeup air.",
      points: ["System independence rules", "Grease duct construction", "Hazardous exhaust capture", "Smoke control & IBC 909", "Makeup air & pressure balance"],
      articles: 68, link: "/daily-code-talk/#imc-501-part-1",
      hasPaidGuide: true, guideHint: "Ventilation & Special Exhaust Field Guide"
    },
    {
      id: "ch6", num: "6", title: "Duct Systems",
      tag: "Construction & Compliance",
      desc: "Return air restrictions, duct construction tables, insulation R-values, plenum material limits, smoke detection, and fire/smoke damper coordination.",
      points: ["Corridor return air restrictions", "Construction class tables", "Insulation R-value by location", "Plenum material requirements", "Fire/smoke damper logic"],
      articles: 47, link: "/daily-code-talk/#imc-601-part-1",
      hasPaidGuide: false, guideHint: null
    }
  ],
  es: [
    {
      id: "ch1", num: "1", title: "Administración",
      tag: "El Marco de Permisos",
      desc: "Cómo funcionan los permisos mecánicos - alcance, autoridad, aprobación, inspecciones, violaciones y las reglas del proceso que rigen cada proyecto.",
      points: ["Alcance y aplicabilidad", "Permisos y aprobaciones", "Autoridad del AHJ", "Inspecciones y retenciones", "Violaciones y paros de obra"],
      articles: 16, link: "/daily-code-talk/#kickoff",
      hasPaidGuide: true, guideHint: "Permit Readiness Review Pack"
    },
    {
      id: "ch2", num: "2", title: "Definiciones",
      tag: "La Capa de Lenguaje",
      desc: "Los términos que controlan qué regla aplica. Plenum vs. ducto, artefacto vs. equipo, tipos de campanas, clasificaciones de compuertas.",
      points: ["Plenum vs. ducto", "Artefacto vs. equipo", "Tipos de compuertas", "Tipos de campanas", "Clasificaciones de punto de inflamación"],
      articles: 4, link: "/daily-code-talk/#imc-201",
      hasPaidGuide: false, guideHint: null
    },
    {
      id: "ch3", num: "3", title: "Regulaciones Generales",
      tag: "Base de Instalación",
      desc: "Requisitos que aplican a todo sistema mecánico - listados, etiquetas, reglas de ubicación, soporte de tuberías, espacios libres de servicio.",
      points: ["Equipos listados y etiquetados", "Reglas de ubicación", "Alturas de montaje en garajes", "Espaciado de soportes de tuberías", "Dimensiones de acceso de servicio"],
      articles: 23, link: "/daily-code-talk/#imc-301-part-1",
      hasPaidGuide: true, guideHint: "Permit Readiness Review Pack"
    },
    {
      id: "ch4", num: "4", title: "Ventilación",
      tag: "El Cálculo de Aire Exterior",
      desc: "Cálculos de aire exterior, selección de método natural vs. mecánico, control de CO/NO₂ en garajes, ASHRAE 170 para salud, y la matemática de zona de respiración.",
      points: ["Cálculo de zona de respiración", "Ventilación natural vs. mecánica", "Control CO + NO₂ en garajes", "ASHRAE 170/NFPA 99 salud", "DCV y lógica de controles"],
      articles: 17, link: "/daily-code-talk/#imc-401-part-1",
      hasPaidGuide: true, guideHint: "Ventilation & Special Exhaust Field Guide"
    },
    {
      id: "ch5", num: "5", title: "Sistemas de Extracción",
      tag: "El Capítulo de Alto Riesgo",
      desc: "Desde ductos de grasa hasta extracción de materiales peligrosos - el capítulo más crítico en materia de riesgo de incendio del IMC.",
      points: ["Independencia de sistemas", "Construcción de ductos de grasa", "Captura de extracción peligrosa", "Control de humo e IBC 909", "Aire de compensación y presión"],
      articles: 68, link: "/daily-code-talk/#imc-501-part-1",
      hasPaidGuide: true, guideHint: "Ventilation & Special Exhaust Field Guide"
    },
    {
      id: "ch6", num: "6", title: "Sistemas de Ductos",
      tag: "Construcción y Cumplimiento",
      desc: "Restricciones de retorno de aire, tablas de construcción de ductos, valores R de aislamiento, materiales de plenum, detección de humo y coordinación de compuertas.",
      points: ["Restricciones de retorno en pasillos", "Tablas de clase de construcción", "Valor R por ubicación", "Requisitos de materiales en plenum", "Lógica de compuertas contra humo/fuego"],
      articles: 47, link: "/daily-code-talk/#imc-601-part-1",
      hasPaidGuide: false, guideHint: null
    }
  ]
};

// ─── Hex positions (6 nodes around a center in a 500x500 container) ──────────
// Angles in standard math coords; container center = (250, 250), radius = 180px
const HEX_POSITIONS = [
  // top
  { left: "50%",    top: "calc(50% - 180px)" },  // ch1
  // upper-right
  { left: "calc(50% + 155.9px)", top: "calc(50% - 90px)" },   // ch2
  // lower-right
  { left: "calc(50% + 155.9px)", top: "calc(50% + 90px)" },   // ch3
  // bottom
  { left: "50%",    top: "calc(50% + 180px)" },  // ch4
  // lower-left
  { left: "calc(50% - 155.9px)", top: "calc(50% + 90px)" },   // ch5
  // upper-left
  { left: "calc(50% - 155.9px)", top: "calc(50% - 90px)" },   // ch6
];

// ─── MBChapterOrbit component ─────────────────────────────────────────────────
function MBChapterOrbit({ lang, tweaks }) {
  const accent = (tweaks && tweaks.accent) || "#C4783A";
  const chapters = CHAPTER_DATA[lang] || CHAPTER_DATA.en;

  const [activeId, setActiveId] = React.useState(null);
  const [isMobile, setIsMobile] = React.useState(false);
  const activeChapter = chapters.find(c => c.id === activeId) || null;

  React.useEffect(function () {
    function check() { setIsMobile(window.innerWidth < 720); }
    check();
    window.addEventListener("resize", check);
    return function () { window.removeEventListener("resize", check); };
  }, []);

  const handleNodeClick = function (id) {
    setActiveId(function (prev) { return prev === id ? null : id; });
    window.trackMBEvent && window.trackMBEvent("Chapter Orbit Click", { chapter: id, language: lang });
  };

  // ── Header ──────────────────────────────────────────────────────────────────
  const headerEl = React.createElement("div", {
    style: { textAlign: "center", marginBottom: isMobile ? 40 : 56 }
  },
    React.createElement("span", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace", fontSize: 11,
        color: accent, letterSpacing: "0.1em",
        textTransform: "uppercase", display: "block", marginBottom: 12
      }
    }, "/ IMC 2024"),
    React.createElement("h2", {
      style: {
        fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700,
        fontSize: "clamp(24px, 3vw, 36px)", color: "#F0EDE8",
        margin: "0 0 14px", lineHeight: 1.15
      }
    }, lang === "es" ? "El Mapa Completo del Código" : "Six Chapters. 175 Articles. One Framework."),
    React.createElement("p", {
      style: {
        fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 15,
        color: "rgba(240,237,232,0.5)", maxWidth: 540,
        margin: "0 auto", lineHeight: 1.65
      }
    }, lang === "es"
      ? "Daily Code Talk cubre el IMC 2024 capítulo por capítulo. Haz clic en cualquier capítulo para ver los temas clave y acceder a los artículos."
      : "Daily Code Talk maps the full IMC 2024 - chapter by chapter, section by section. Click any chapter to see what it covers and jump to the articles."
    )
  );

  // ── Mobile grid layout ───────────────────────────────────────────────────────
  const mobileGrid = React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(2, 1fr)",
      gap: 2,
      marginBottom: activeChapter ? 24 : 0
    }
  },
    ...chapters.map(function (ch, i) {
      const isActive = activeId === ch.id;
      return React.createElement("div", {
        key: ch.id,
        onClick: function () { handleNodeClick(ch.id); },
        style: {
          padding: "20px 18px", background: isActive ? "#1A1C20" : "#131417",
          borderTop: "2px solid " + (isActive ? accent : "transparent"),
          cursor: "pointer", transition: "all 0.2s ease",
          border: "1px solid " + (isActive ? "rgba(196,120,58,0.3)" : "rgba(255,255,255,0.04)"),
          borderTop: "2px solid " + (isActive ? accent : "rgba(196,120,58,0.15)")
        }
      },
        React.createElement("div", {
          style: {
            width: 36, height: 36, borderRadius: "50%",
            background: isActive ? accent : "rgba(196,120,58,0.08)",
            border: "1px solid " + (isActive ? accent : "rgba(196,120,58,0.25)"),
            display: "flex", alignItems: "center", justifyContent: "center",
            marginBottom: 10
          }
        },
          React.createElement("span", {
            style: {
              fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800,
              fontSize: 14, color: isActive ? "#0B0C0E" : accent
            }
          }, ch.num)
        ),
        React.createElement("div", {
          style: {
            fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
            color: accent, letterSpacing: "0.08em",
            textTransform: "uppercase", marginBottom: 4
          }
        }, "Ch" + ch.num),
        React.createElement("div", {
          style: {
            fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700,
            fontSize: 13, color: "#F0EDE8", lineHeight: 1.2, marginBottom: 4
          }
        }, ch.title),
        React.createElement("div", {
          style: {
            fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
            color: "rgba(240,237,232,0.3)"
          }
        }, ch.articles + (lang === "es" ? " artículos" : " articles"))
      );
    })
  );

  // ── Desktop orbit layout ─────────────────────────────────────────────────────
  // Container is 500px square; nodes are 60x60px, offset -30px each axis for centering
  const desktopOrbit = React.createElement("div", {
    style: {
      position: "relative", width: "500px", height: "500px",
      margin: "0 auto", flexShrink: 0
    }
  },
    // Outer orbit ring (rotating dashed)
    React.createElement("div", {
      style: {
        position: "absolute", top: "50%", left: "50%",
        width: 400, height: 400,
        marginTop: -200, marginLeft: -200,
        borderRadius: "50%",
        border: "1px dashed rgba(196,120,58,0.12)",
        animation: "mbOrbitRing 60s linear infinite",
        pointerEvents: "none"
      }
    }),
    // Inner orbit ring
    React.createElement("div", {
      style: {
        position: "absolute", top: "50%", left: "50%",
        width: 360, height: 360,
        marginTop: -180, marginLeft: -180,
        borderRadius: "50%",
        border: "1px solid rgba(255,255,255,0.04)",
        pointerEvents: "none"
      }
    }),
    // Connecting lines (SVG)
    React.createElement("svg", {
      style: {
        position: "absolute", top: 0, left: 0,
        width: "100%", height: "100%",
        pointerEvents: "none", opacity: 0.2
      },
      viewBox: "0 0 500 500"
    },
      ...HEX_POSITIONS.map(function (pos, i) {
        // Very rough center-to-node lines - we draw them as short dashes from center (250,250)
        const rad_lut = [
          [250, 70],   // ch1 top
          [405.9, 160], // ch2 upper-right
          [405.9, 340], // ch3 lower-right
          [250, 430],   // ch4 bottom
          [94.1, 340],  // ch5 lower-left
          [94.1, 160],  // ch6 upper-left
        ];
        const [nx, ny] = rad_lut[i];
        const isActive = activeId === chapters[i].id;
        return React.createElement("line", {
          key: i,
          x1: 250, y1: 250, x2: nx, y2: ny,
          stroke: isActive ? accent : "rgba(196,120,58,0.5)",
          strokeWidth: isActive ? 1.5 : 0.5,
          strokeDasharray: isActive ? "none" : "4 6"
        });
      })
    ),
    // Center hub
    React.createElement("div", {
      style: {
        position: "absolute", top: "50%", left: "50%",
        width: 90, height: 90,
        marginTop: -45, marginLeft: -45,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(196,120,58,0.15) 0%, rgba(196,120,58,0.03) 70%, transparent 100%)",
        border: "1px solid rgba(196,120,58,0.35)",
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        gap: 2, zIndex: 5,
        boxShadow: "0 0 30px rgba(196,120,58,0.08)",
        animation: "mbOrbitHubPulse 3s ease-in-out infinite"
      }
    },
      React.createElement("span", {
        style: {
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 10, color: accent,
          letterSpacing: "0.1em", textTransform: "uppercase"
        }
      }, "IMC"),
      React.createElement("span", {
        style: {
          fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800,
          fontSize: 16, color: "#F0EDE8", lineHeight: 1
        }
      }, "2024"),
      React.createElement("span", {
        style: {
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 8, color: "rgba(240,237,232,0.3)",
          letterSpacing: "0.05em", marginTop: 1
        }
      }, "6 ch / 156 art")
    ),
    // Chapter nodes
    ...chapters.map(function (ch, i) {
      const pos = HEX_POSITIONS[i];
      const isActive = activeId === ch.id;
      const nodeX = [250, 405.9, 405.9, 250, 94.1, 94.1][i];
      const nodeY = [70, 160, 340, 430, 340, 160][i];
      return React.createElement("div", {
        key: ch.id,
        onClick: function () { handleNodeClick(ch.id); },
        style: {
          position: "absolute",
          left: nodeX - 30,
          top: nodeY - 30,
          width: 60, height: 60,
          zIndex: isActive ? 20 : 10,
          cursor: "pointer"
        }
      },
        // Node circle
        React.createElement("div", {
          style: {
            width: 60, height: 60, borderRadius: "50%",
            background: isActive
              ? accent
              : "#131417",
            border: "2px solid " + (isActive ? accent : "rgba(196,120,58,0.3)"),
            display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center",
            gap: 1,
            transition: "all 0.3s cubic-bezier(0.23, 1, 0.32, 1)",
            boxShadow: isActive
              ? "0 0 24px rgba(196,120,58,0.35)"
              : "0 0 0 rgba(196,120,58,0)",
            transform: isActive ? "scale(1.15)" : "scale(1)"
          }
        },
          React.createElement("span", {
            style: {
              fontFamily: "'IBM Plex Mono', monospace",
              fontSize: 8, color: isActive ? "#0B0C0E" : "rgba(240,237,232,0.35)",
              textTransform: "uppercase", letterSpacing: "0.06em"
            }
          }, "Ch"),
          React.createElement("span", {
            style: {
              fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 800,
              fontSize: 18, color: isActive ? "#0B0C0E" : accent,
              lineHeight: 1
            }
          }, ch.num)
        ),
        // Chapter label below node
        React.createElement("div", {
          style: {
            position: "absolute",
            top: 64,
            left: "50%",
            transform: "translateX(-50%)",
            whiteSpace: "nowrap",
            textAlign: "center",
            pointerEvents: "none"
          }
        },
          React.createElement("div", {
            style: {
              fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
              color: isActive ? accent : "rgba(240,237,232,0.3)",
              letterSpacing: "0.07em", textTransform: "uppercase",
              transition: "color 0.25s"
            }
          }, ch.title)
        )
      );
    })
  );

  // ── Expanded chapter detail card ─────────────────────────────────────────────
  function renderDetailCard() {
    if (!activeChapter) return null;
    return React.createElement("div", {
      style: {
        marginTop: 32,
        padding: "28px 32px",
        background: "#131417",
        border: "1px solid rgba(196,120,58,0.2)",
        borderTop: "2px solid " + accent,
        maxWidth: isMobile ? "100%" : 560,
        margin: "32px auto 0",
        animation: "mbRevealUp 0.35s cubic-bezier(0.23, 1, 0.32, 1) both"
      }
    },
      // Card header
      React.createElement("div", {
        style: {
          display: "flex", alignItems: "flex-start",
          justifyContent: "space-between", marginBottom: 16, gap: 16
        }
      },
        React.createElement("div", null,
          React.createElement("div", {
            style: {
              fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
              color: accent, letterSpacing: "0.1em",
              textTransform: "uppercase", marginBottom: 6
            }
          }, "Chapter " + activeChapter.num + "  ·  " + activeChapter.articles + " articles"),
          React.createElement("h3", {
            style: {
              fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 700,
              fontSize: 22, color: "#F0EDE8", margin: "0 0 4px"
            }
          }, activeChapter.title),
          React.createElement("div", {
            style: {
              fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
              color: "rgba(240,237,232,0.35)", letterSpacing: "0.06em"
            }
          }, activeChapter.tag)
        ),
        React.createElement("button", {
          onClick: function () { setActiveId(null); },
          style: {
            background: "none", border: "none",
            cursor: "pointer", color: "rgba(240,237,232,0.35)",
            fontSize: 22, lineHeight: 1, padding: 4,
            transition: "color 0.2s", flexShrink: 0
          },
          onMouseEnter: function (e) { e.currentTarget.style.color = "#F0EDE8"; },
          onMouseLeave: function (e) { e.currentTarget.style.color = "rgba(240,237,232,0.35)"; }
        }, "×")
      ),
      // Description
      React.createElement("p", {
        style: {
          fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14,
          color: "rgba(240,237,232,0.6)", lineHeight: 1.7,
          margin: "0 0 20px"
        }
      }, activeChapter.desc),
      // Key topics grid
      React.createElement("div", {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: "6px 16px", marginBottom: 24
        }
      },
        ...activeChapter.points.map(function (pt, i) {
          return React.createElement("div", {
            key: i,
            style: {
              display: "flex", alignItems: "flex-start",
              gap: 8, padding: "6px 0",
              borderBottom: "1px solid rgba(255,255,255,0.04)"
            }
          },
            React.createElement("span", {
              style: {
                width: 4, height: 4, borderRadius: "50%",
                background: accent, flexShrink: 0, marginTop: 6
              }
            }),
            React.createElement("span", {
              style: {
                fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13,
                color: "rgba(240,237,232,0.7)", lineHeight: 1.5
              }
            }, pt)
          );
        })
      ),
      // Footer row: article link + paid guide hint
      React.createElement("div", {
        style: {
          display: "flex", alignItems: "center",
          justifyContent: "space-between", flexWrap: "wrap", gap: 12
        }
      },
        React.createElement("a", {
          href: activeChapter.link,
          onClick: function () { window.trackMBEvent && window.trackMBEvent("Chapter Orbit Article Link", { chapter: activeChapter.id, language: lang }); },
          style: {
            display: "inline-flex", alignItems: "center", gap: 8,
            fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13,
            fontWeight: 600, color: accent,
            textDecoration: "none", letterSpacing: "0.02em",
            transition: "opacity 0.2s"
          },
          onMouseEnter: function (e) { e.currentTarget.style.opacity = "0.75"; },
          onMouseLeave: function (e) { e.currentTarget.style.opacity = "1"; }
        }, (lang === "es" ? "Explorar Capítulo " : "Browse Chapter ") + activeChapter.num + " articles →"),
        activeChapter.hasPaidGuide && React.createElement("div", {
          style: {
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "5px 10px",
            background: "rgba(196,120,58,0.08)",
            border: "1px solid rgba(196,120,58,0.2)",
            borderRadius: 2
          }
        },
          React.createElement("span", {
            style: {
              fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
              color: accent, letterSpacing: "0.08em",
              textTransform: "uppercase"
            }
          }, "📋 " + activeChapter.guideHint)
        )
      )
    );
  }

  // ── Full section render ──────────────────────────────────────────────────────
  return React.createElement("section", {
    id: "code-framework",
    style: {
      background: "#0B0C0E",
      padding: "96px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      overflow: "hidden"
    }
  },
    React.createElement("div", {
      style: { maxWidth: 1200, margin: "0 auto" }
    },
      headerEl,
      isMobile ? mobileGrid : desktopOrbit,
      renderDetailCard()
    )
  );
}

// ─── Scroll Reveal Observer ───────────────────────────────────────────────────
// Adds .visible class to any element with [data-reveal] once it enters viewport.
// Call once after React hydration via: MBInitReveal()
function MBInitReveal() {
  if (typeof IntersectionObserver === "undefined") return;
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("mb-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

  // Observe on a slight delay to let React finish painting
  setTimeout(function () {
    document.querySelectorAll("[data-reveal]").forEach(function (el) {
      observer.observe(el);
    });
  }, 200);
}

Object.assign(window, { MBChapterOrbit, MBInitReveal, CHAPTER_DATA });
