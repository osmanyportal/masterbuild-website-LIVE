/* Masterbuild Consulting — educational field tools. Not project-specific engineering. */
(function () {
  function $(id) { return document.getElementById(id); }
  var ES = document.documentElement.lang === "es";
  function contact(type) {
    return (ES ? "/contacto/" : "/send/") + (type ? "?type=" + type : "");
  }
  function show(el) {
    if (!el) return;
    el.hidden = false;
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
  }
  function track(name, props) {
    if (window.trackMBEvent) window.trackMBEvent(name, props || {});
  }
  function n(x) { return Math.round(x * 10) / 10; }
  function copyText(btn, text) {
    if (!text) return;
    function ok() { if (btn) btn.textContent = ES ? "Copiado" : "Copied"; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(ok).catch(function () {});
    }
  }

  /* ── Kitchen Type I / Type II pathfinder ───────────────────────────── */
  var kitchenForm = $("kitchen-path");
  if (kitchenForm) {
    kitchenForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var cook = (kitchenForm.cook && kitchenForm.cook.value) || "";
      var box = $("kitchen-result");
      var title = $("kitchen-result-title");
      var body = $("kitchen-result-body");
      var next = $("kitchen-result-next");
      if (!cook) {
        show(box);
        title.textContent = "Select the cooking that actually happens.";
        body.textContent = "The hood type follows the contaminant, not the room name. A “restaurant TI” can be Type I, Type II, or no hood — the equipment schedule decides.";
        next.innerHTML = '<a class="cta-primary" href="' + contact('kitchen') + '">Send the equipment schedule</a>';
        return;
      }
      var map = {
        grease: {
          t: "Likely Type I path (grease-laden vapor).",
          b: "Fryers, griddles, charbroilers, woks, smokers, and open-flame cooking typically drive IMC Chapter 5 Type I: listed or engineered hood, grease duct (506), makeup air (508), and suppression coordination. Confirm the listing, the menu, and the AHJ path before anyone prices a Type II or a residential hood.",
          href: "/send/?type=kitchen"
        },
        steam: {
          t: "Type II may apply if there is no grease-laden vapor.",
          b: "Dishwashers, steamers, and some ovens that produce heat and moisture (not grease) often sit on the Type II path. If the same line also fries or grills, the grease appliance usually controls the whole hood. Do not let a “light prep” label override the equipment schedule.",
          href: "/send/?type=kitchen"
        },
        none: {
          t: "A commercial hood may not be required.",
          b: "Microwave, beverage, and no-cook service usually do not trigger IMC 507. Still confirm warming equipment, any under-counter dishwashers, and whether the occupancy itself imposes a different exhaust rule. When in doubt, send the equipment cut sheets.",
          href: "/send/?type=kitchen"
        },
        dwelling: {
          t: "Dwelling-unit cooking is usually IMC 505, not 507.",
          b: "A range in a dwelling unit follows domestic cooking exhaust rules, including makeup air when the exhaust is large enough. Do not copy a Type I restaurant spec onto a condo kitchen without checking occupancy and 505 vs 507.",
          href: "/send/?type=kitchen"
        },
        residential_commercial: {
          t: "Residential-style cooking in a commercial occupancy needs a close read of IMC 505.6–505.8.",
          b: "A residential range in I-2, R, or similar occupancies is not automatically a Type I restaurant hood, and it is not automatically exempt. The occupancy, the appliance, and the exhaust path have to be shown. This is a frequent Miami TI comment.",
          href: "/send/?type=kitchen"
        },
        mixed: {
          t: "Mixed or unknown menu — do not guess the hood type.",
          b: "Send the architectural plan and the kitchen equipment schedule. Masterbuild will say whether the set is Type I, Type II, a 505 path, or a split system before anyone prices grease duct.",
          href: "/send/?type=kitchen"
        }
      };
      var hit = map[cook] || map.mixed;
      show(box);
      title.textContent = hit.t;
      body.textContent = hit.b + " This is educational classification against the model IMC, not a determination for your permit.";
      next.innerHTML = '<a class="cta-primary" href="' + contact('kitchen') + '">' + (ES ? 'Enviar el plano de cocina' : 'Send the kitchen plan') + '</a> <a href="/commercial-kitchen-ventilation/">Kitchen exhaust hub</a> <a href="/field-tools/#makeup">Makeup-air check</a>';
      track("Field Tool Result", { tool: "kitchen-path", result: cook });
    });
  }

  /* ── Outdoor-air occupancy estimator (IMC Table 403.3.1.1 educational) */
  var OA = {
    office: { label: "Office space", rp: 5, ra: 0.06, dens: 5 },
    conference: { label: "Conference / meeting", rp: 5, ra: 0.06, dens: 50 },
    lobby: { label: "Main entry lobby", rp: 5, ra: 0.06, dens: 10 },
    reception: { label: "Reception", rp: 5, ra: 0.06, dens: 30 },
    classroom: { label: "Classroom (age 9+)", rp: 10, ra: 0.12, dens: 35 },
    lecture: { label: "Lecture classroom", rp: 7.5, ra: 0.06, dens: 65 },
    computer: { label: "Computer lab", rp: 10, ra: 0.12, dens: 25 },
    dining: { label: "Restaurant dining", rp: 7.5, ra: 0.18, dens: 70 },
    cafe: { label: "Cafeteria / fast-food dining", rp: 7.5, ra: 0.18, dens: 100 },
    kitchen: { label: "Kitchen (cooking)", rp: 7.5, ra: 0.12, dens: 20 },
    retail: { label: "Retail sales", rp: 7.5, ra: 0.12, dens: 15 },
    mall: { label: "Mall common area", rp: 7.5, ra: 0.06, dens: 40 },
    market: { label: "Supermarket", rp: 7.5, ra: 0.06, dens: 8 },
    salon: { label: "Beauty / nail salon", rp: 20, ra: 0.12, dens: 25 },
    gym: { label: "Gym / sports play area", rp: 20, ra: 0.18, dens: 7 },
    aerobics: { label: "Health club / aerobics", rp: 20, ra: 0.06, dens: 40 },
    weights: { label: "Health club / weights", rp: 20, ra: 0.06, dens: 10 },
    auditorium: { label: "Auditorium seating", rp: 5, ra: 0.06, dens: 150 },
    worship: { label: "Place of religious worship", rp: 5, ra: 0.06, dens: 120 },
    library: { label: "Library", rp: 5, ra: 0.12, dens: 10 },
    corridor: { label: "Corridor", rp: 0, ra: 0.06, dens: 0 },
    warehouse: { label: "Warehouse", rp: 10, ra: 0.06, dens: 0 },
    hotel: { label: "Hotel bedroom / living room", rp: 5, ra: 0.06, dens: 10 }
  };

  var oaForm = $("oa-form");
  if (oaForm) {
    oaForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var key = oaForm.occ.value;
      var area = parseFloat(oaForm.area.value);
      var peopleIn = oaForm.people.value === "" ? null : parseFloat(oaForm.people.value);
      var box = $("oa-result");
      var title = $("oa-result-title");
      var body = $("oa-result-body");
      if (!key || !(area > 0)) {
        show(box);
        title.textContent = "Enter occupancy and area.";
        body.textContent = "Breathing-zone outdoor air is Rp × people + Ra × area. Area must be a positive number in square feet.";
        return;
      }
      var row = OA[key];
      var defaultP = row.dens > 0 ? (row.dens * area) / 1000 : 0;
      var P = (peopleIn != null && peopleIn >= 0) ? peopleIn : defaultP;
      var peoplePart = row.rp * P;
      var areaPart = row.ra * area;
      var vbz = peoplePart + areaPart;
      show(box);
      title.textContent = row.label + ": breathing-zone outdoor air ≈ " + n(vbz) + " cfm.";
      body.innerHTML =
        "Vbz = Rp × Pz + Ra × Az = " + row.rp + " × " + n(P) + " + " + row.ra + " × " + n(area) +
        " = <strong>" + n(vbz) + " cfm</strong>." +
        (peopleIn == null && row.dens > 0
          ? " People defaulted from Table 403.3.1.1 density (" + row.dens + " / 1,000 sf) → " + n(defaultP) + " people."
          : peopleIn == null
            ? " This occupancy has no default people density in the educational table; only the area term was used unless you enter a headcount."
            : " Using your entered headcount (" + n(P) + "), not the table default of " + n(defaultP) + ".") +
        " This is breathing-zone outdoor air (Vbz) from IMC Table 403.3.1.1 educational rates (2024 model). System outdoor air (Vot) can be higher after zone air-distribution effectiveness, multiple-zone correction, exhaust makeup, and ASHRAE 62.1 Appendix A. Healthcare and I-2 spaces generally follow ASHRAE 170 / IMC 407, not this table. Verify the adopted edition and local amendments.";
      track("Field Tool Result", { tool: "oa-estimator", occ: key, vbz: n(vbz) });
    });
  }

  /* ── Recertification records pack ──────────────────────────────────── */
  var recForm = $("recert-pack");
  if (recForm) {
    recForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var have = [];
      var missing = [];
      recForm.querySelectorAll('input[name="rec-item"]').forEach(function (cb) {
        (cb.checked ? have : missing).push(cb.value);
      });
      var addr = (recForm.rec_address && recForm.rec_address.value.trim()) || "(address / folio not entered)";
      var year = (recForm.rec_year && recForm.rec_year.value.trim()) || "(year built not entered)";
      var lines = [];
      lines.push("Electrical Building Recertification readiness — records pack");
      lines.push("Property: " + addr);
      lines.push("Year built (as entered): " + year);
      lines.push("");
      lines.push("IN HAND:");
      if (have.length) have.forEach(function (x) { lines.push("  [x] " + x); });
      else lines.push("  (none checked — that is normal at first contact)");
      lines.push("");
      lines.push("STILL NEEDED / UNKNOWN:");
      if (missing.length) missing.forEach(function (x) { lines.push("  [ ] " + x); });
      else lines.push("  (checklist complete — still confirm the notice itself)");
      lines.push("");
      lines.push("Missing records are normal. The readiness step exists to establish what exists before scope and fee are set.");
      lines.push("This list is not a due-date calculation and not a County requirement statement. Confirm every deadline against your notice.");
      var out = $("recert-copy");
      var box = $("recert-result");
      show(box);
      if (out) out.value = lines.join("\n");
      track("Field Tool Result", { tool: "recert-pack", have: have.length, missing: missing.length });
    });
    var copyBtn = $("recert-copy-btn");
    if (copyBtn) {
      copyBtn.addEventListener("click", function () {
        var out = $("recert-copy");
        if (!out || !out.value) return;
        copyText(copyBtn, out.value);
        track("Field Tool Copy", { tool: "recert-pack" });
      });
    }
  }

  /* ── Garage ventilation (IMC 404 educational) ──────────────────────── */
  var gForm = $("garage-form");
  if (gForm) {
    gForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var area = parseFloat(($("garea") && $("garea").value) || "");
      var mode = ($("gmode") && $("gmode").value) || "";
      var box = $("garage-result");
      var title = $("garage-result-title");
      var body = $("garage-result-body");
      if (!(area > 0) || !mode) {
        show(box);
        title.textContent = "Enter enclosed garage area and strategy.";
        body.textContent = "IMC 404 rates apply to enclosed parking garages. Open-garage definitions are a building-code question, not this estimator.";
        return;
      }
      var full = n(0.75 * area);
      var standby = n(0.05 * area);
      show(box);
      if (mode === "open") {
        title.textContent = "Confirm the garage is actually enclosed before using 404 rates.";
        body.innerHTML = "Louvers and “plenty of air” do not make an enclosed garage open. The adopted building-code definition of open parking garage controls. If it is enclosed, Full-On exhaust at 0.75 cfm/sf of " + n(area) + " sf is <strong>" + full + " cfm</strong>, and a CO/NO₂-automatic system still needs a Standby path at 0.05 cfm/sf = <strong>" + standby + " cfm</strong>.";
      } else if (mode === "continuous") {
        title.textContent = "Continuous path: exhaust ≈ " + full + " cfm (0.75 cfm/sf).";
        body.innerHTML = "Educational IMC 404 numbers for " + n(area) + " sf enclosed garage. Continuous operation at 0.75 cfm/sf → <strong>" + full + " cfm</strong>. Accessory rooms must stay positive to the garage. This is not fan selection, not a CO-control sequence, and not a sealed design. Daily Code Talk: <a href=\"/daily-code-talk/imc-404-enclosed-parking-garages-404-1-404-2/\">IMC 404</a>.";
      } else {
        title.textContent = "Automatic CO/NO₂ path: Full-On " + full + " cfm / Standby " + standby + " cfm.";
        body.innerHTML = "Educational IMC 404 numbers for " + n(area) + " sf. Automatic systems cycle between Full-On ≥ 0.75 cfm/sf (<strong>" + full + " cfm</strong>) and Standby ≥ 0.05 cfm/sf (<strong>" + standby + " cfm</strong>). Detectors listed to UL 2075, fail-safe to Full-On, accessory rooms positive to the garage. The common rejection is sizing for continuous 0.75 and calling it automatic — or the reverse. Verify adopted FBC Mechanical and Miami-Dade amendments.";
      }
      track("Field Tool Result", { tool: "garage-404", mode: mode, full: full });
    });
  }

  /* ── Combustion-air method (IMC Ch. 7 educational) ─────────────────── */
  var cForm = $("combustion-form");
  if (cForm) {
    cForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var btuEl = $("cbtu");
      var volEl = $("cvol");
      var methodEl = $("cmethod");
      var btu = parseFloat(btuEl && btuEl.value);
      var vol = volEl && volEl.value === "" ? null : parseFloat(volEl && volEl.value);
      var method = (methodEl && methodEl.value) || "";
      var box = $("combustion-result");
      var title = $("combustion-result-title");
      var body = $("combustion-result-body");
      if (!(btu > 0) || !method) {
        show(box);
        title.textContent = "Enter appliance input (Btu/h) and a method.";
        body.textContent = "Direct-vent and outdoor appliances follow the listing, not these indoor-opening numbers. Confirm the listing first.";
        return;
      }
      var k = btu / 1000;
      var indoorNeed = n(50 * k);
      var twoOpen = n(k / 4); /* 1 in² per 4,000 Btu/h each */
      var oneOpen = n(k / 3); /* 1 in² per 3,000 Btu/h */
      var mech = n(0.35 * k); /* 0.35 cfm per 1,000 Btu/h */
      show(box);
      if (method === "direct") {
        title.textContent = "Direct-vent / sealed combustion follows the listing, not Chapter 7 openings.";
        body.innerHTML = "If the appliance is listed as direct-vent and installed to that listing, indoor-volume and outdoor-opening tables usually do not apply. Replacement in a sealed closet still needs the listing, the vent path, and any remaining atmospheric appliances in the same room. Send the cut sheet.";
      } else if (method === "indoor") {
        var ok = (vol != null && vol >= indoorNeed);
        title.textContent = ok
          ? "Indoor volume appears to meet the 50 ft³ / 1,000 Btu/h educational check."
          : "Indoor volume may be short of the 50 ft³ / 1,000 Btu/h educational check.";
        body.innerHTML = "Appliance input " + n(btu) + " Btu/h. Educational indoor-volume requirement ≈ <strong>" + indoorNeed + " ft³</strong>" +
          (vol != null ? " vs entered volume " + n(vol) + " ft³." : ". Enter the combined room volume to compare.") +
          " Tight construction, exhaust fans, and other appliances in the same volume change this. Free area of openings is not the same as nominal louver size. Verify IMC 703 and the adopted FBC Mechanical.";
      } else if (method === "outdoor2") {
        title.textContent = "Two outdoor openings: ≈ " + twoOpen + " in² free area each (1 in² / 4,000 Btu/h).";
        body.innerHTML = "Educational 2024 IMC outdoor two-opening path for " + n(btu) + " Btu/h. Each opening ≈ <strong>" + twoOpen + " in² net free area</strong> when communicating directly outdoors. Horizontal ducts are tighter (1 in² / 2,000 Btu/h). Screens, dampers, and louver blades reduce free area below the rough opening. Dampered openings must interlock with the appliance.";
      } else if (method === "outdoor1") {
        title.textContent = "One permanent outdoor opening: ≈ " + oneOpen + " in² free area (1 in² / 3,000 Btu/h).";
        body.innerHTML = "Educational 2024 IMC one-opening path for " + n(btu) + " Btu/h → <strong>" + oneOpen + " in² net free area</strong>, with the opening typically within 12 in of the top of the enclosure and not smaller than the vent area. Confirm IMC 704 and the listing. This is not a louver schedule.";
      } else {
        title.textContent = "Mechanical combustion air: ≈ " + mech + " cfm from outdoors (0.35 cfm / 1,000 Btu/h).";
        body.innerHTML = "Educational IMC 706 rate for " + n(btu) + " Btu/h → <strong>" + mech + " cfm</strong> supplied from outdoors, interlocked so the appliance cannot fire without the fan. Engineered systems and listed packages override this table. Send the closet dimensions and the cut sheets.";
      }
      track("Field Tool Result", { tool: "combustion-air", method: method });
    });
  }

  /* ── Makeup air equality check (IMC 508 educational) ───────────────── */
  var mForm = $("makeup-form");
  if (mForm) {
    mForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var ex = parseFloat(($("mexh") && $("mexh").value) || "");
      var mu = !$("mmua") || $("mmua").value === "" ? 0 : parseFloat($("mmua").value);
      var box = $("makeup-result");
      var title = $("makeup-result-title");
      var body = $("makeup-result-body");
      if (!(ex > 0)) {
        show(box);
        title.textContent = "Enter hood / kitchen exhaust cfm.";
        body.textContent = "IMC 508 requires replacement air approximately equal to the exhaust. Transfer air can count when the source is suitable — dining OA is not automatically available.";
        return;
      }
      var gap = n(ex - mu);
      show(box);
      if (mu <= 0) {
        title.textContent = "No makeup air entered — that is the usual comment.";
        body.innerHTML = "Exhaust " + n(ex) + " cfm with no identified replacement air. Plan review will ask where the air comes from. Dedicated makeup, transfer from a ventilated adjacent space, and outdoor-air units can combine — but the path, temperature, and interlock have to be on the drawings. See <a href=\"/daily-code-talk/imc-508-commercial-kitchen-makeup-air/\">IMC 508</a>.";
      } else if (Math.abs(gap) <= Math.max(50, 0.1 * ex)) {
        title.textContent = "Exhaust and makeup are in the same neighborhood (" + n(ex) + " vs " + n(mu) + " cfm).";
        body.innerHTML = "Educational 508 check only. “Approximately equal” is not a 10% rule of thumb you can rest a permit on. Capture, door swing, dining pressure, and whether the makeup is actually available when the hood is on still have to be shown. Location of the makeup register relative to the hood lip matters as much as the cfm.";
      } else if (gap > 0) {
        title.textContent = "Makeup is short of exhaust by ≈ " + gap + " cfm.";
        body.innerHTML = "Exhaust " + n(ex) + " cfm vs makeup " + n(mu) + " cfm. That shortfall is either transfer air (identify the source and that it remains available) or a missing unit. Tight Miami TIs often try to steal dining OA that the occupancy table already assigned to people. Send the hood schedule and the HVAC zoning.";
      } else {
        title.textContent = "Makeup exceeds exhaust by ≈ " + n(mu - ex) + " cfm.";
        body.innerHTML = "More makeup than exhaust can pressurize the kitchen into dining or corridors and push grease and odor. Confirm the design intent (slightly negative kitchen is typical) and whether the extra air is a diversity, a future hood, or a schedule mismatch.";
      }
      track("Field Tool Result", { tool: "makeup-508", gap: gap });
    });
  }

  /* ── Fire / smoke damper pathfinder (IMC 607 educational) ──────────── */
  var dForm = $("damper-form");
  if (dForm) {
    dForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var fire = ($("dfire") && $("dfire").value) || "";
      var smoke = ($("dsmoke") && $("dsmoke").value) || "";
      var shaft = ($("dshaft") && $("dshaft").value) || "";
      var box = $("damper-result");
      var title = $("damper-result-title");
      var body = $("damper-result-body");
      if (!fire || !smoke || !shaft) {
        show(box);
        title.textContent = "Answer all three — the assembly type controls the damper.";
        body.textContent = "A typical that says “F/S damper where required” is a comment magnet. Each crossing needs assembly type, listing, access, and any smoke-control interface.";
        return;
      }
      var bits = [];
      if (fire === "yes") bits.push("fire damper (or combination) where a duct penetrates a fire-resistance-rated assembly");
      if (smoke === "yes") bits.push("smoke damper (or combination) at a smoke barrier / smoke partition, with the actuator and detection as required");
      if (shaft === "yes") bits.push("shaft protection — often a combination fire/smoke damper at the shaft penetration, with access from an occupied side");
      show(box);
      if (fire === "unsure" || smoke === "unsure" || shaft === "unsure") {
        title.textContent = "Do not guess the rating. Send the architectural rated-plan.";
        body.innerHTML = "IMC 607 follows the assembly the architect identified, not a mechanical typical. If the wall is unrated, a damper may not be required — and installing one “just in case” can still be wrong (access, listing, smoke-control interface). Send reflected-ceiling plans and the rated-assembly sheets. More: <a href=\"/duct-systems/\">duct systems hub</a> · <a href=\"/daily-code-talk/imc-607-part-1-607-1-607-2-1/\">IMC 607 Part 1</a>.";
      } else if (!bits.length) {
        title.textContent = "No rated crossing described — a damper may not be required at this opening.";
        body.innerHTML = "Unrated partitions do not automatically need fire or smoke dampers. Confirm the architect’s rating legend anyway; corridor walls, incidental-use separations, and smoke partitions are easy to miss. This is educational, not a 607 determination.";
      } else {
        title.textContent = "Likely path: " + bits[0] + (bits.length > 1 ? "; also " + bits.slice(1).join("; ") : "") + ".";
        body.innerHTML = "Show on the M-sheet: assembly type and rating, damper type (fire / smoke / combination), listing, access door, and any smoke-control or fire-alarm interface. Ceiling radiation dampers are a different product for rated floor/ceiling membranes. Exceptions exist (fully ducted in some assemblies, steel ducts in some shafts) — do not take an exception without citing it. Not a listing selection.";
      }
      track("Field Tool Result", { tool: "damper-607", fire: fire, smoke: smoke, shaft: shaft });
    });
  }

  /* ── Comment classifier ────────────────────────────────────────────── */
  var kForm = $("comment-form");
  if (kForm) {
    kForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var key = ($("ckind") && $("ckind").value) || "";
      var box = $("comment-result");
      var title = $("comment-result-title");
      var body = $("comment-result-body");
      var next = $("comment-result-next");
      var lib = {
        oa: {
          t: "Outdoor-air / ventilation comment.",
          b: "Reviewer wants occupancy, area, people, method, and the resulting cfm on the M-sheets — not “OA per code.” Run the estimator, then send the architectural occupancy plan.",
          href: "/send/?type=ventilation",
          more: "/ventilation/"
        },
        kitchen: {
          t: "Kitchen hood / grease / makeup comment.",
          b: "Usually missing hood type, grease-duct construction, termination, makeup air, or suppression interface. The equipment schedule decides Type I vs Type II.",
          href: "/send/?type=kitchen",
          more: "/commercial-kitchen-ventilation/"
        },
        damper: {
          t: "Fire/smoke damper or rated-penetration comment.",
          b: "Each crossing needs assembly type, damper basis, listing, and access. A typical “F/S where required” is what generated the comment.",
          href: "/send/?type=ducts",
          more: "/duct-systems/"
        },
        garage: {
          t: "Garage ventilation / CO-control comment.",
          b: "State continuous vs automatic, Full-On and Standby cfm, detector listing, and accessory-room pressure. Do not copy Table 403 onto a garage.",
          href: "/send/?type=garage",
          more: "/parking-garage-ventilation/"
        },
        combustion: {
          t: "Combustion-air / venting comment.",
          b: "Method, free area (not nominal louver), damper interlock, and existing-closet constraints. Replacement units in original closets are a frequent miss.",
          href: "/send/?type=combustion",
          more: "/combustion-air/"
        },
        load: {
          t: "Load-calculation / energy-forms comment.",
          b: "IMC 312 plus Florida energy forms. Send architectural plans, zoning assumptions, and any forms already started.",
          href: "/send/?type=load",
          more: "/hvac-load-calculations/"
        },
        recert: {
          t: "Electrical recertification / existing-building electrical.",
          b: "This is the County electrical path, not the statewide structural milestone inspection. Send the notice first. Deadlines live on the notice, not on a website calculator.",
          href: "/send/?type=recertification",
          more: "/electrical-building-recertification-miami/"
        },
        access: {
          t: "Access / clearance / condensate / location comment.",
          b: "IMC 303–307: equipment location, service space, roof access, condensate disposal. Photos of the room often close the comment faster than a revised typical.",
          href: "/send/?type=comments",
          more: "/permit-comment-response/"
        },
        plumbing: {
          t: "Plumbing / grease / isometric comment.",
          b: "Fixture units, isometrics, grease interceptor, and Miami-Dade plumbing checklists. Septic and wells are a different County path.",
          href: "/send/?type=plumbing",
          more: "/plumbing/"
        },
        other: {
          t: "Send the letter. Do not paraphrase it.",
          b: "The actual comment text, the current set, the permit number, and which comments you want Masterbuild to own. That is enough to start a written resubmittal path.",
          href: "/send/?type=comments",
          more: "/typical-plan-review-comments/"
        }
      };
      var hit = lib[key] || lib.other;
      show(box);
      title.textContent = hit.t;
      body.textContent = hit.b + " Educational triage only — not a code opinion on your letter.";
      next.innerHTML = '<a class="cta-primary" href="' + contact(key === "recert" ? "recertification" : (key === "other" || !key ? "comments" : key)) + '">' + (ES ? "Enviar la carta" : "Send the comment letter") + '</a> <a href="' + hit.more + '">' + (ES ? "Abrir el centro" : "Open the hub") + '</a> <a href="/typical-plan-review-comments/">Typical comments</a>';
      track("Field Tool Result", { tool: "comment-classifier", kind: key });
    });
  }

  /* ── IMC 401 vs 403 method ─────────────────────────────────────────── */
  var om = $("oa-method-form");
  if (om) {
    om.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = ($("oamethod") && $("oamethod").value) || "";
      var box = $("oa-method-result");
      var title = $("oa-method-result-title");
      var body = $("oa-method-result-body");
      var map = {
        mech: {
          t: "Mechanical outdoor air — Table 403 / 62.1 is the educational path.",
          b: "Vbz = Rp × people + Ra × area, then system outdoor air after zone effectiveness. Run the occupancy estimator. Do not write “OA per code.”"
        },
        natural: {
          t: "Natural ventilation is IMC 402, not Table 403 cfm.",
          b: "Openable area, occupant access, and whether the climate actually uses the openings control this path. Miami-conditioned buildings that lock the windows are not a 402 system. If the AHJ expects mechanical OA, 402 will not save a comment."
        },
        mixed: {
          t: "Mixed method — identify which rooms are which.",
          b: "A note that “some areas are naturally ventilated” is a comment magnet. Each occupancy needs a method on the M-sheet. Send the architectural floor plan."
        },
        exhaust: {
          t: "Exhaust without identified outdoor air is a makeup-air problem.",
          b: "Restrooms, kitchens, and garages that only show exhaust will get the 508 / 404 / 403 question. Show where replacement air comes from. Kitchen: use the makeup-air check. Garage: use the 404 estimator."
        }
      };
      var hit = map[v];
      show(box);
      if (!hit) {
        title.textContent = "Select how outdoor air is actually provided.";
        body.textContent = "The method is a drawing question, not a typical.";
        return;
      }
      title.textContent = hit.t;
      body.innerHTML = hit.b + ' <a href="' + contact("ventilation") + '">Send the occupancy plan</a>.';
      track("Field Tool Result", { tool: "oa-method", result: v });
    });
  }

  var pv = $("plumbing-ve-form");
  if (pv) {
    pv.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = ($("pve") && $("pve").value) || "";
      var box = $("plumbing-ve-result");
      var title = $("plumbing-ve-result-title");
      var body = $("plumbing-ve-result-body");
      var map = {
        iso: {
          t: "Skipping the isometric is not VE.",
          b: "Plan view of fixtures is not a reviewable waste/vent diagram. Miami-Dade commercial plumbing checklists already expect isometrics. Draw them or expect the comment."
        },
        grease: {
          t: "Grease interceptor cuts fail twice — review and inspection.",
          b: "If the mechanical sheets show Type I, plumbing needs a grease path now: basis, location, access, sample port. Deferring it to ‘later’ is two comments, not a savings."
        },
        stack: {
          t: "New load on an undocumented stack needs fixture units.",
          b: "Adding fixtures to ‘the existing riser’ without a unit calculation is how TIs fail. Photos of the stack plus the new fixture list is the start of the inquiry."
        },
        wh: {
          t: "Closet water-heater cuts are combustion + plumbing.",
          b: "Pan, relief, listing, and combustion air (or direct-vent listing). Deleting the louver to recover square footage is a Chapter 7 coordination miss."
        },
        sewer: {
          t: "Do not assume public sewer.",
          b: "If the street has no sewer, stop and run the OSTDS / septic screen before anyone prices underground. Wells are a different County path."
        },
        other: {
          t: "Send the plan and the cut list.",
          b: "The architectural plumbing plan, fixture list, and what someone wants to delete. Masterbuild will say what still has to be shown."
        }
      };
      var hit = map[v];
      show(box);
      if (!hit) {
        title.textContent = "Select the cut that is about to happen.";
        body.textContent = "This classifier flags permit and inspection risk. It does not size an interceptor.";
        return;
      }
      title.textContent = hit.t;
      body.innerHTML = hit.b + ' <a href="' + contact("plumbing") + '">Send the plumbing plan</a> · <a href="/plumbing-value-engineering/">VE hub</a>.';
      track("Field Tool Result", { tool: "plumbing-ve", result: v });
    });
  }

  var kp = $("kitplumb-form");
  if (kp) {
    kp.addEventListener("submit", function (e) {
      e.preventDefault();
      var hood = ($("kphood") && $("kphood").value) || "";
      var pint = ($("kpint") && $("kpint").value) || "";
      var box = $("kitplumb-result");
      var title = $("kitplumb-result-title");
      var body = $("kitplumb-result-body");
      show(box);
      if (!hood || !pint) {
        title.textContent = "Answer both sides of the set.";
        body.textContent = "The menu drives the hood and the interceptor. One typical cannot stand in for the other.";
        return;
      }
      if (pint === "septic") {
        title.textContent = "Stop. Confirm sewer vs OSTDS before anyone prices underground.";
        body.innerHTML = 'No public sewer is not a plumbing VE item. Open the <a href="/miami-dade-septic-feasibility/">septic screen</a> and send folio + intended use.';
      } else if (hood === "type1" && pint !== "yes") {
        title.textContent = "Type I without a grease path — two comments.";
        body.innerHTML = 'Mechanical is showing grease-laden cooking. Plumbing still needs interceptor basis, location, access, and sample port. “Later” fails review. <a href="' + contact("kitchen") + '">Send the equipment schedule</a> · <a href="/kitchen-plumbing-coordination/">coordination hub</a>.';
      } else if (hood === "type2" && pint === "yes") {
        title.textContent = "Interceptor with Type II — confirm the menu actually has no grease.";
        body.textContent = "If the menu later adds a fryer, both sheets are wrong. Confirm the equipment schedule is the real menu.";
      } else if (hood === "none" && pint === "yes") {
        title.textContent = "Interceptor without a hood — confirm occupancy.";
        body.textContent = "Food service without a hood can still need grease waste. Confirm the menu and whether this is a Type I miss on the M-sheets.";
      } else if (hood === "unsure" || pint === "later") {
        title.textContent = "Send both sets. Do not sequence the interceptor to after C.O.";
        body.innerHTML = '<a href="' + contact("kitchen") + '">Send kitchen + plumbing</a>.';
      } else {
        title.textContent = "Hood type and grease path appear to be talking to each other — still verify the menu.";
        body.innerHTML = 'Educational check only. Makeup air, termination, and isometric still have to be on the drawings. <a href="/kitchen-plumbing-coordination/">Coordination hub</a>.';
      }
      track("Field Tool Result", { tool: "kitplumb", hood: hood, pint: pint });
    });
  }

  var tf = $("term-form");
  if (tf) {
    tf.addEventListener("submit", function (e) {
      e.preventDefault();
      var where = ($("twhere") && $("twhere").value) || "";
      var intake = ($("tintake") && $("tintake").value) || "";
      var box = $("term-result");
      var title = $("term-result-title");
      var body = $("term-result-body");
      show(box);
      if (!where || !intake) {
        title.textContent = "Say where it terminates and whether an OA intake is in play.";
        body.textContent = "Plan review marks mystery outlets. The roof plan has to dimension this.";
        return;
      }
      var bits = [];
      if (where === "roof") {
        bits.push("Above-roof path: educational 506.3.13.1 wants the discharge opening at least 40 in above the roof surface — note it, do not hide it in a typical.");
      } else if (where === "wall") {
        bits.push("Through-wall is a special path (506.3.13.2): not a nuisance or fire hazard, not where the IBC requires protected openings, at least 3 ft from an exterior-wall opening, and 506.3.13.3 still applies. Tight Miami walls next to windows fail this often.");
      } else {
        bits.push("If the outlet is not shown, that is the comment. Identify ABOVE ROOF vs THRU WALL on the M-sheets.");
      }
      if (intake === "close" || intake === "unsure") {
        bits.push("506.3.13.3: 10 ft horizontally from, or 3 ft above, outdoor-air intakes (unless the 5 ft exception applies and discharge direction is drawn). Dimension the intake. “Nearby” is a redline.");
      }
      bits.push("Also check 10 ft to adjacent buildings / property lines and 10 ft above adjoining grade. The 5 ft exception requires discharge away from those locations, shown on the drawing.");
      title.textContent = "Dimension the outlet. Do not write “per IMC 506.”";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("kitchen") + '">Send the roof plan</a> · <a href="/grease-duct-termination/">termination hub</a> · <a href="/daily-code-talk/imc-506-part-4-506-3-13-exhaust-outlet-terminations/">Daily Code Talk</a>.';
      track("Field Tool Result", { tool: "termination-506", where: where, intake: intake });
    });
  }

  var cf = $("cond-form");
  if (cf) {
    cf.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("cloc") && $("cloc").value) || "";
      var ov = ($("cover") && $("cover").value) || "";
      var box = $("cond-result");
      var title = $("cond-result-title");
      var body = $("cond-result-body");
      show(box);
      if (!loc || !ov) {
        title.textContent = "Say where the coil sits and whether overflow is drawn.";
        body.textContent = "307 is a water-damage section. Notes without a receptor fail review.";
        return;
      }
      var bits = [];
      if (loc === "ceiling" || loc === "elec") {
        bits.push("Highest-risk location: equipment above a finished ceiling, tenant space, or electrical room. Overflow protection and shutdown have to be on the drawing, not hoped for in the field.");
      } else if (loc === "roof") {
        bits.push("Outdoor/roof still needs an approved disposal point, slope, and freeze/nuisance path. “Onto the roof” is not automatically approved.");
      } else if (loc === "unsure") {
        bits.push("If the unit location is not shown relative to the space below, that is the comment.");
      } else {
        bits.push("Closet/mech room still needs primary route, slope, approved disposal, and overflow where damage is possible.");
      }
      if (ov === "note" || ov === "no") {
        bits.push("A “drain to nearest approved receptor” note is the common redline. Show receptor, slope, overflow (pan / line / water-level device), and pump shutdown if a pump is the only path. Indoor discharge generally stays in the same occupancy/tenant.");
      } else {
        bits.push("Overflow shown is a start. Still confirm disposal point, 1 percent slope, material/size, and that indoor discharge stays in the same occupancy.");
      }
      title.textContent = "If the primary drain stops, the set has to answer.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("mep") + '">Send the unit location</a> · <a href="/condensate/">condensate hub</a> · <a href="/daily-code-talk/imc-307-condensate-disposal/">Daily Code Talk</a>.';
      track("Field Tool Result", { tool: "condensate-307", loc: loc, overflow: ov });
    });
  }

  var af = $("acc-form");
  if (af) {
    af.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("aloc") && $("aloc").value) || "";
      var boxd = ($("abox") && $("abox").value) || "";
      var box = $("acc-result");
      var title = $("acc-result-title");
      var body = $("acc-result-body");
      show(box);
      if (!loc || !boxd) {
        title.textContent = "Say where the unit sits and whether the 30×30 is drawn.";
        body.textContent = "306 is an inspection gate. Notes without dimensions fail.";
        return;
      }
      var bits = [];
      if (loc === "roof") {
        bits.push("Roof path: hatch or permanent ladder and the walkway to each unit on the roof plan. A general note is a pre-occupancy hold.");
      } else if (loc === "attic") {
        bits.push("Attic / above-ceiling: service without removing permanent construction, plus a removal path for the largest appliance.");
      } else if (loc === "closet") {
        bits.push("Tight room/closet: 306.2 passage (36×80, dwelling exception is conditional) and 30×30 at the service side with the door open.");
      } else {
        bits.push("Mechanical room: door, 36 in × 80 in passage, 30×30 at the control/service side. Dimension the box.");
      }
      if (boxd === "note" || boxd === "no") {
        bits.push("30 in × 30 in level working space at the control/service side has to be drawn — listing clearances if they are larger. Adjacent ducts and structure will eat an undimensioned note.");
      }
      title.textContent = "Draw the service envelope. Do not note it.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("mep") + '">Send the equipment location</a> · <a href="/equipment-access/">access hub</a> · <a href="/daily-code-talk/imc-306-access-and-service-space-part-1/">Daily Code Talk</a>.';
      track("Field Tool Result", { tool: "access-306", loc: loc, box: boxd });
    });
  }


  var df = $("dis-form");
  if (df) {
    df.addEventListener("submit", function (e) {
      e.preventDefault();
      var kind = ($("dkind") && $("dkind").value) || "";
      var near = ($("dnear") && $("dnear").value) || "";
      var box = $("dis-result");
      var title = $("dis-result-title");
      var body = $("dis-result-body");
      show(box);
      if (!kind || !near) {
        title.textContent = "Say what is exhausted and whether an intake is nearby.";
        body.textContent = "501.3 wants outdoor discharge that cannot be pulled back in.";
        return;
      }
      var bits = [];
      if (kind === "kitchen") {
        bits.push("Commercial kitchen grease is 506.3.13, not the environmental-air 3 ft / 10 ft row. Use the termination check.");
      } else if (kind === "dryer") {
        bits.push("Clothes dryers are IMC 504 (no screens, no screws, 3 ft from openings if the manufacturer is silent). Use the dryer check.");
      } else if (kind === "product") {
        bits.push("Product-conveying exhaust has larger separations than bathroom fans. Do not copy an environmental-air typical.");
      } else if (kind === "unsure") {
        bits.push("If the exhaust type is not identified, that is the comment. Label environmental vs grease vs dryer vs process.");
      } else {
        bits.push("Environmental air (educational 501.3.1 item 3): 3 ft to property lines; 3 ft to operable openings (not Group U); 10 ft to mechanical air intakes. Dimension them.");
      }
      if (near === "attic") {
        bits.push("Never into attics or crawl spaces (dwelling whole-house attic-fan exception is not a toilet fan). Keep it off walkways.");
      } else if (near === "close") {
        bits.push("Re-entrainment is the comment. Dimension to the intake and show discharge direction.");
      }
      title.textContent = "Dimension the outlet. Do not write “per 501.”";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("ventilation") + '">Send the elevation</a> · <a href="/exhaust-discharge/">501.3 hub</a>.';
      track("Field Tool Result", { tool: "discharge-501", kind: kind, near: near });
    });
  }
  var dry = $("dry-form");
  if (dry) {
    dry.addEventListener("submit", function (e) {
      e.preventDefault();
      var t = ($("dterm") && $("dterm").value) || "";
      var box = $("dry-result");
      var title = $("dry-result-title");
      var body = $("dry-result-body");
      show(box);
      var map = {
        ok: "Outdoor termination with a backdraft damper and a clean airstream is the start. Still confirm 3 ft from openings (if MI is silent), 12.5 in² open area, rated penetrations without a fire damper, and a lint cleanout on vertical risers.",
        screen: "No screens at the termination — lint trap and blockage risk. Outlet must stay full size (12.5 in² educational 504.4.2).",
        screws: "No fasteners protruding into the airstream. Joints per 603.9, not sheet-metal screws through the wall of the duct.",
        damper: "No fire damper or combination fire/smoke damper in a dryer duct. Maintain the assembly rating another way.",
        plenum: "Dryer ducts are independent. Do not connect to a vent connector, chimney, duct, or plenum.",
        unsure: "If the dryer duct is not on the M-sheets, that is the comment — especially through rated walls or a common riser."
      };
      title.textContent = "IMC 504 is a fire and lint section, not a flex-hose leftover.";
      body.innerHTML = (map[t] || "Pick the condition.") + ' <a href="' + contact("mep") + '">Send the routing</a> · <a href="/dryer-exhaust/">dryer hub</a>.';
      track("Field Tool Result", { tool: "dryer-504", term: t });
    });
  }


  var ch = $("chim-form");
  if (ch) {
    ch.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("ckind") && $("ckind").value) || "";
      var box = $("chim-result"), title = $("chim-result-title"), body = $("chim-result-body");
      show(box);
      var map = {
        factory: "IMC 805 listed-system path: match appliance and fuel, required UL standard (UL 103 Type HT / UL 127 / UL 959 as applicable), 30° / four-elbow offset limits, structural support for added load, listed shrouds only, insulation shield (attic: 2 in above insulation on the code-built path). Review it as one assembly from appliance to termination.",
        metal: "IMC 806.1 → NFPA 211. Show type, materials, supports, clearances, penetrations, termination, and access. A “per NFPA 211” note is not a drawing. Do not copy a factory-built typical onto a metal chimney.",
        line: "A line labeled “chimney” is the comment. Identify factory-built listed system vs metal chimney vs vent/connector, then draw the path.",
        unsure: "Send the appliance listing and a photo or routing sketch. Factory-built (805) and metal (806) are different code paths."
      };
      title.textContent = "Identify the system. Then draw it.";
      body.innerHTML = (map[k] || "Pick the type.") + ' <a href="' + contact("mep") + '">Send the routing</a> · <a href="/factory-built-chimneys/">805</a> · <a href="/metal-chimneys/">806</a>.';
      track("Field Tool Result", { tool: "chimney-805-806", kind: k });
    });
  }
  var lf = $("load-form");
  if (lf) {
    lf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("lkind") && $("lkind").value) || "";
      var box = $("load-result"), title = $("load-result-title"), body = $("load-result-body");
      show(box);
      var map = {
        cont: "Continuous load (educational Art. 100): maximum current expected for 3 hours or more. Permanently connected or “normally left on” is not automatically continuous. Duration is the question.",
        demand: "Demand factor is maximum demand divided by connected load. Do not apply a demand reduction without Code support for that occupancy/calculation. Connected load ≠ expected simultaneous demand.",
        mgmt: "Load management limits total load by controlling individual loads. Not every load may be shed. Document what is controlled, by what system, and whether the Code path allows it.",
        service: "Existing-service questions need more than nameplate addition: what operates together, for how long, what duty applies, and what can actually be controlled. That is an engineering evaluation under a written scope."
      };
      title.textContent = "Definitions first. Amps second.";
      body.innerHTML = (map[k] || "Pick the question.") + ' <a href="' + contact("mep") + '">Send the service question</a> · <a href="/continuous-load/">hub</a>.';
      track("Field Tool Result", { tool: "loaddef-100", kind: k });
    });
  }
  var ef = $("env-form");
  if (ef) {
    ef.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("eloc") && $("eloc").value) || "";
      var box = $("env-result"), title = $("env-result-title"), body = $("env-result-body");
      show(box);
      var map = {
        dry: "Dry: not normally subject to dampness or wetness. Temporary moisture does not automatically make it damp or wet. Still verify condensation around mechanical equipment.",
        damp: "Damp: protected from weather, not subject to saturation, moderate moisture. A covered exterior is a common damp location — not automatically dry. Rainproof / raintight / weatherproof / watertight are not interchangeable.",
        wet: "Wet: saturation or direct weather (and certain underground / earth-contact). Water exposure is expected. Select equipment and fittings for that location — “outdoor rated” is not enough.",
        cond: "Condensation around mechanical equipment is an environmental exposure. Do not ignore it because the room is “indoors.” Classify and match the enclosure.",
        unsure: "Classify dry / damp / wet before selecting the enclosure. Ask: direct rain? spray or accumulation? condensation? What rating is on the nameplate?"
      };
      title.textContent = "Classify the location. Then pick the enclosure.";
      body.innerHTML = (map[k] || "Pick the exposure.") + ' <a href="' + contact("mep") + '">Send the location photos</a> · <a href="/wet-location-electrical/">hub</a>.';
      track("Field Tool Result", { tool: "envloc-100", loc: k });
    });
  }


  var pf = $("pres-form");
  if (pf) {
    pf.addEventListener("submit", function (e) {
      e.preventDefault();
      var room = ($("proom") && $("proom").value) || "";
      var path = ($("ppath") && $("ppath").value) || "";
      var box = $("pres-result"), title = $("pres-result-title"), body = $("pres-result-body");
      show(box);
      if (!room || !path) {
        title.textContent = "Say what is exhausting and whether makeup is drawn.";
        body.textContent = "501.4 wants a path, not a note.";
        return;
      }
      var bits = [];
      if (room === "hood") {
        bits.push("Type I replacement air is IMC 508, not a bathroom undercut. Use the makeup-air hub.");
      } else if (room === "pos") {
        bits.push("If supply exceeds exhaust, 501.4 wants a relief path (natural or mechanical) for the excess. Show it.");
      } else if (room === "unsure") {
        bits.push("If pressure intent is not on M-101 (N / NEG / BAL), that is the comment.");
      } else {
        bits.push("Educational 501.4: for spaces other than Group R-3 and R-2 dwelling units, keep the space neutral or negative. Exhaust-only rooms need makeup to cover the deficit.");
      }
      if (path === "undercut") {
        bits.push("Do not rely on door undercuts alone for large offsets. Name the device and the path (transfer grille, OA, dedicated MAU).");
      } else if (path === "none") {
        bits.push("Nothing drawn is the comment. List required exhaust, supply, target pressure, makeup source, and relief method on M-601.");
      } else {
        bits.push("A drawn path is a start. Still confirm the makeup supports capture (feed the room, not the hood face) and that duct construction cites Chapter 6.");
      }
      title.textContent = "Balance on paper. Then draw the path.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("ventilation") + '">Send the room list</a> · <a href="/transfer-air/">501.4 hub</a>.';
      track("Field Tool Result", { tool: "pressure-5014", room: room, path: path });
    });
  }


  var af = $("attic-form");
  if (af) {
    af.addEventListener("submit", function (e) {
      e.preventDefault();
      var space = ($("aspace") && $("aspace").value) || "";
      var path = ($("apath") && $("apath").value) || "";
      var areaEl = $("area");
      var area = areaEl && areaEl.value ? Number(areaEl.value) : 0;
      var box = $("attic-result"), title = $("attic-result-title"), body = $("attic-result-body");
      show(box);
      var bits = [];
      if (path === "note") {
        bits.push("A note that says “ventilated per code” is the comment. Choose NAT-IBC openings (show sizes and locations) or MECH-406.1.");
      } else if (path === "exhaust") {
        bits.push("Mechanical 406.1 needs both supply and exhaust. Exhaust-only is the redline. Auto-enable when RH > 60% in the space.");
      } else if (path === "nat") {
        bits.push("Natural path: show IBC opening sizes/locations and bug screens; coordinate envelope and fire/smoke. Rated openings need the assembly protection.");
      } else if (path === "mech") {
        bits.push("Mechanical path (educational): exhaust ≥ 0.02 cfm/ft² of horizontal area, matching supply, RH enable > 60%. Size the fan at external static — not a catalog number.");
      }
      if (area > 0 && (path === "mech" || path === "exhaust")) {
        var cfm = Math.round(area * 0.02 * 10) / 10;
        bits.push("Educational check: " + area + " ft² × 0.02 = " + cfm + " cfm exhaust minimum. Confirm supply path and RH sensor location.");
      }
      title.textContent = "Pick a path. Then show the math.";
      body.innerHTML = (bits.join(" ") || "Select the space and the path.") + ' <a href="' + contact("ventilation") + '">Send attic/crawl area</a> · <a href="/uninhabited-spaces/">406 hub</a>.';
      track("Field Tool Result", { tool: "attic-406", space: space, path: path, area: area || null });
    });
  }


  var df = $("dom-form");
  if (df) {
    df.addEventListener("submit", function (e) {
      e.preventDefault();
      var occ = ($("docc") && $("docc").value) || "";
      var cfm = ($("dcfm") && $("dcfm").value) || "";
      var box = $("dom-result"), title = $("dom-result-title"), body = $("dom-result-body");
      show(box);
      var bits = [];
      if (occ === "rest") {
        bits.push("Commercial cooking is IMC 506/507/508, not 505. If any appliance under the hood requires Type I, the entire hood is Type I. Domestic-looking equipment used commercially still follows Type I/II.");
      } else if (occ === "i") {
        bits.push("I-1 / I-2: IMC 505.6–505.8 / IBC 420.9 path — educational: minimum 500 cfm hood, room ventilation per 403.3.1, outdoor discharge. Ductless only if listed with charcoal filter. Confirm whether the cooking load actually stays on 505 or becomes Type I/II.");
      } else if (occ === "mix") {
        bits.push("Non-R with domestic-style equipment: occupancy decides. If it still qualifies as residential-type, 505 can apply. If the cooking load requires Type I or II, switch to 506/507.");
      } else {
        bits.push("Group R / dwelling: 505. Listed equipment, smooth rigid metal duct, no flex, no screen, outdoor termination unless 505.2 expressly permits a listed recirculating hood.");
      }
      if (cfm === "over" && occ !== "rest") {
        bits.push("505.4: if domestic kitchen exhaust can exceed 400 cfm, makeup air at approximately the same rate, closure damper, automatic interlock with the hood. Draw path, damper, cfm, interlock.");
      } else if (cfm === "unsure") {
        bits.push("Put listing standard and exhaust cfm on the equipment schedule. Over-the-range microwaves with integral exhaust are the device most often missed.");
      }
      title.textContent = "Occupancy first. Then the listing. Then 400 cfm.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("kitchen") + '">Send occupancy and cut sheets</a> · <a href="/domestic-cooking/">hub</a>.';
      track("Field Tool Result", { tool: "domestic-505-507", occ: occ, cfm: cfm });
    });
  }


  var hf = $("hc-form");
  if (hf) {
    hf.addEventListener("submit", function (e) {
      e.preventDefault();
      var occ = ($("hocc") && $("hocc").value) || "";
      var box = $("hc-result"), title = $("hc-result-title"), body = $("hc-result-body");
      show(box);
      var map = {
        b: "A Group B medical office is not automatically IMC 407 / ASHRAE 170. Confirm occupancy with the program and the AHJ before copying 170 ACH onto the schedule. Chapter 4 may still govern — or 407 may already apply. Do not guess from the word “clinic.”",
        amb: "Ambulatory care: educational IMC 407.1 — meet IMC 407, ASHRAE 170, and NFPA 99; most restrictive governs. Map every clinical room to a 170 type. Show ACH, OA, pressure, filtration, temp/RH, exhaust on M-601.",
        i2: "Group I-2: same 407.1 most-restrictive path. Do not design to Table 403.3.1.1 OA rates. AIIR is negative; PE is positive — do not mix them. Start ICRA before mechanical design.",
        unsure: "“Healthcare” without a 170 room type is the comment. Send occupancy, procedures, and the room list before anyone sizes air changes."
      };
      title.textContent = "Occupancy first. 170 second. Table 403 last.";
      body.innerHTML = (map[occ] || "Select occupancy.") + ' <a href="' + contact("healthcare") + '">Send the program</a> · <a href="/ashrae-170-rooms/">407 hub</a>.';
      track("Field Tool Result", { tool: "healthcare-407", occ: occ });
    });
  }


  var of = $("oa-ctl-form");
  if (of) {
    of.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("omode") && $("omode").value) || "";
      var box = $("oa-ctl-result"), title = $("oa-ctl-result-title"), body = $("oa-ctl-result-body");
      show(box);
      var map = {
        occ: "Occupied-mode OA is the 405.1 baseline. Still show VAV-minimum OA, DCV Ra floor if used, unoccupied/fire modes, and fail-safe to design OA on sensor/actuator/BAS fault.",
        call: "Ventilation tied only to a cooling/heating call leaves occupied rooms without OA when the fan is off at setpoint. That is a 405.1 miss.",
        dcv: "DCV is allowed in standby, but never below the Ra floor. Document the floor and the points. “Maintain OA” with no measurable points is incomplete.",
        vav: "OA must be maintained across turndown and fan-speed changes, not only at design flow. Show minimum OA at VAV low flow on M-601.",
        none: "A duct plan without a controls sequence is a first-cycle comment. Put occupancy source, OA enable, DCV floor, purge, and fail-safe on M-603 and the controls drawings."
      };
      title.textContent = "Occupied means the OA is on.";
      body.innerHTML = (map[k] || "Select how OA runs.") + ' <a href="' + contact("ventilation") + '">Send the sequence</a> · <a href="/ventilation-controls/">405 hub</a>.';
      track("Field Tool Result", { tool: "oa-ctl-405", mode: k });
    });
  }
  var cf = $("clr-form");
  if (cf) {
    cf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("clist") && $("clist").value) || "";
      var box = $("clr-result"), title = $("clr-result-title"), body = $("clr-result-body");
      show(box);
      var map = {
        no: "If the listing prohibits reduction, 308 does not open a path. Listed clearance governs. Do not squeeze it with a typical.",
        ul: "UL 1618 listed assembly path: show the listed product, airspace, supports, original vs reduced clearance, and the combustible being protected. Still not closer than 1 inch to the equipment.",
        table: "Table 308.4.2: stay inside table limits. Interpolation between table values is allowed; extrapolating below the table is not. Some sources (solid-fuel small clearances, masonry chimneys, kitchen exhaust in shafts) have table limits — check them.",
        note: "“Clearance reduction per code” is the comment. Draw original clearance, reduced clearance, assembly, airspace, and listing/table basis."
      };
      title.textContent = "Listing first. Then the assembly.";
      body.innerHTML = (map[k] || "Select the path.") + ' <a href="' + contact("mep") + '">Send the listing and the tight side</a> · <a href="/clearance-reduction/">308 hub</a>.';
      track("Field Tool Result", { tool: "clearance-308", path: k });
    });
  }


  var rf = $("req-form");
  if (rf) {
    rf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("rproc") && $("rproc").value) || "";
      var box = $("req-result"), title = $("req-result-title"), body = $("req-result-body");
      show(box);
      var map = {
        none: "Put a 502 schedule block that says NONE. That proves the checklist ran. Revisit if the architect later adds a process room.",
        batt: "Battery rooms/charging: confirm battery type, hazard basis, ventilation calculation, control sequence, alarm interface, exhaust path, and fire-protection coordination. Do not leave the safety logic implied. 310 / IFC 911 may also be on the path.",
        spray: "Spray / flammable finish / dipping / powder coat: 502.2–502.7 specific rates and run-while-the-process-runs. Do not recirculate unless every code condition is documented. Do not combine with general return.",
        haz: "Over MAQ (educational 502.8): often ≥ 1 cfm/ft², usually continuous; emergency shutoff; pickup height by vapor density; no recirculation to occupied space. 502.9: local capture; 200 fpm at gas-cabinet/enclosure faces where that path applies.",
        spec: "Nail stations, firing ranges, garage pits, dry cleaning, HPM: purpose-built exhaust, pickup location (low/high/local), sometimes interlocks. Name the 502 subsection on M-601.",
        unsure: "A space on the occupancy drawings but not in the exhaust design is an inspection stop. Inventory exhausted spaces against the architectural occupancy drawings before submittal."
      };
      title.textContent = "Name the process. Then pick 502 — not 403.";
      body.innerHTML = (map[k] || "Select the process.") + ' <a href="' + contact("ventilation") + '">Send the room list</a> · <a href="/required-exhaust/">502 hub</a>.';
      track("Field Tool Result", { tool: "required-502", proc: k });
    });
  }


  var hz = $("haz-form");
  if (hz) {
    hz.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("htrig") && $("htrig").value) || "";
      var box = $("haz-result"), title = $("haz-result-title"), body = $("haz-result-body");
      show(box);
      var map = {
        lfl: "Educational 509.1–509.2: flammables that could create >25% LFL under normal conditions trigger hazardous exhaust. 509.3: keep the exhaust below 25% LFL via dilution. Direct to outdoors. No fire/smoke dampers. No shared shafts with other ducts.",
        "704": "NFPA 704 health-hazard 4 at any concentration, or health-hazard 1–3 above 1% LC50, is a 509 trigger. Capture at the source. Makeup air ≈ exhaust, interlocked. Fire walls: no penetration.",
        lab: "Labs have a limited 509 exception with strict thresholds — do not assume it. Shared-shaft lab exception needs negative pressure, controls, limits, and redundant fans. Document the exception basis.",
        gen: "“General exhaust,” a plenum shortcut, a shared shaft, or a damper on a 509 duct is the comment. Treat it as a protected path to outdoors with a written trigger basis.",
        unsure: "Escalate when SDS or process conditions do not fully describe the airborne hazard. Undercharacterized 509 systems are a liability — do not guess LFL or LC50 from a trade name."
      };
      title.textContent = "Trigger first. Then the path to outdoors.";
      body.innerHTML = (map[k] || "Select the airstream.") + ' <a href="' + contact("ventilation") + '">Send SDS and the room</a> · <a href="/hazardous-exhaust/">509 hub</a>.';
      track("Field Tool Result", { tool: "hazardous-509", trig: k });
    });
  }


  var ef = $("erv-form");
  if (ef) {
    ef.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("estream") && $("estream").value) || "";
      var box = $("erv-result"), title = $("erv-result-title"), body = $("erv-result-body");
      show(box);
      var map = {
        oa: "General occupancy pairing can be eligible. Still: UL 1812 (ducted) or UL 1815 (nonducted); access to the exchanger; document cross-leakage <10% of total design airflow so the air is not counted as recirculated. If energy code requires ERV, also IECC.",
        type1: "513.2 prohibits ERV on commercial kitchen exhaust serving Type I hoods. Do not recover grease exhaust. Sensible-only coil-type heat exchangers are the stated exception — confirm that is actually what is specified.",
        dryer: "513.2 prohibits ERV on clothes dryer exhaust (IMC 504). Do not recover dryer air.",
        haz: "513.2 prohibits ERV on hazardous exhaust (509), dust/stock/refuse conveying explosive or flammable vapors/fumes/dust, and smoke control (512). Eligibility failed before equipment selection.",
        coil: "Sensible-only recovery using coil-type heat exchangers is not limited by the 513.2 prohibition list. Still show listing, access, and that it is actually sensible-only — not a total-energy wheel on a prohibited stream.",
        unsure: "Ask: what exact exhaust airstream am I recovering from? If the answer touches hazardous, grease, smoke control, explosive dust, or dryer exhaust, stop and re-check 513.2 before modeling anything."
      };
      title.textContent = "Eligibility first. Equipment second.";
      body.innerHTML = (map[k] || "Select the airstream.") + ' <a href="' + contact("ventilation") + '">Send the airstream</a> · <a href="/energy-recovery/">513 hub</a>.';
      track("Field Tool Result", { tool: "erv-513", stream: k });
    });
  }


  var dsf = $("dsd-form");
  if (dsf) {
    dsf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("dscfm") && $("dscfm").value) || "";
      var box = $("dsd-result"), title = $("dsd-result-title"), body = $("dsd-result-body");
      show(box);
      var map = {
        under: "A single return at or below 2,000 cfm is under the 606.2.1 threshold — still check combined supply/return on a shared duct/plenum (606.2.2) and whether the system can spread smoke beyond the room (exception). Put cfm on the fan schedule.",
        over: "Return over 2,000 cfm (or combined shared capacity over 2,000 cfm): listed duct smoke detection in the return duct or plenum, upstream of filters, exhaust, OA, decontamination, and appliances. UL 268A. Install per NFPA 72. Shutdown (or smoke-control mode). Supervisory signal where FA is required.",
        riser: "Return riser serving two or more stories: detectors at each story where any portion of the return system exceeds 15,000 cfm, upstream of the riser connection.",
        fptu: "Fan-powered terminal units 2,000 cfm or less do not each need individual detectors if they shut down by an approved detection method. Document the method.",
        none: "Missing cfm and missing detector is the comment. Put design cfm on M-601 and decide 606.2.1 / 606.2.2 / 606.2.3 on paper before the FA contractor is guessing locations."
      };
      title.textContent = "Capacity first. Then the detector location.";
      body.innerHTML = (map[k] || "Select capacity.") + ' <a href="' + contact("mep") + '">Send the schedule cfm</a> · <a href="/duct-smoke-detection/">606 hub</a>.';
      track("Field Tool Result", { tool: "dsd-606", cap: k });
    });
  }


  var dvf = $("dvel-form");
  if (dvf) {
    dvf.addEventListener("submit", function (e) {
      e.preventDefault();
      var cfm = parseFloat(($("dvel-cfm") && $("dvel-cfm").value) || "0");
      var shape = ($("dvel-shape") && $("dvel-shape").value) || "rect";
      var w = parseFloat(($("dvel-w") && $("dvel-w").value) || "0");
      var h = parseFloat(($("dvel-h") && $("dvel-h").value) || "0");
      var box = $("dvel-result"), title = $("dvel-result-title"), body = $("dvel-result-body");
      show(box);
      if (!(cfm > 0) || !(w > 0) || (shape === "rect" && !(h > 0))) {
        title.textContent = "Need airflow and a size.";
        body.textContent = "Enter cfm and duct size. Zero airflow is not a duct size.";
        return;
      }
      var area = shape === "round" ? (Math.PI * w * w / 4) / 144 : (w * h) / 144;
      var vel = cfm / area;
      var flag = vel > 2500 ? "High-velocity territory — acoustic analysis, not a default commercial low-pressure duct."
        : vel > 1800 ? "Above typical commercial supply-main screening (~1,800 fpm). Check noise, pressure class, and whether this is a deliberate medium/high-velocity run."
        : vel > 1200 ? "In the commercial-main band. Confirm this is a main, not a branch to a diffuser (branch screening often ~1,200 fpm)."
        : vel > 900 ? "Reasonable for many commercial branches. Residential Manual D mains are often screened nearer 700–900 fpm."
        : vel < 400 ? "Low velocity — check oversized duct, poor throw, and whether CFM is actually this low."
        : "Inside common low-pressure screening. Still confirm friction rate, fittings, and ESP with a real run.";
      title.textContent = Math.round(vel) + " fpm  ·  " + area.toFixed(2) + " ft²";
      body.innerHTML = flag + ' Kitchen grease duct is a different method (IMC Chapter 5 / NFPA 96). <a href="' + contact("mep") + '">Send the run</a> · <a href="/calculation-support/">calculation support</a>.';
      track("Field Tool Result", { tool: "duct-velocity", vel: Math.round(vel), shape: shape });
    });
  }


  var nf = $("nat-form");
  if (nf) {
    nf.addEventListener("submit", function (e) {
      e.preventDefault();
      var sf = parseFloat(($("nat-sf") && $("nat-sf").value) || "0");
      var kind = ($("nat-kind") && $("nat-kind").value) || "direct";
      var box = $("nat-result"), title = $("nat-result-title"), body = $("nat-result-body");
      show(box);
      if (!(sf > 0)) {
        title.textContent = "Need the floor area.";
        body.textContent = "Enter the floor area served. Windows without a 4% table are the comment.";
        return;
      }
      var four = sf * 0.04;
      var eight = sf * 0.08;
      var extra = {
        direct: "402.2: provide openable area not less than 4% of the floor area served (" + four.toFixed(1) + " ft²). Operators readily accessible to occupants. Put the calc next to the room.",
        adj: "402.3: unobstructed opening to the adjoining room not less than 8% (" + eight.toFixed(1) + " ft²) and not less than 25 ft² — so " + Math.max(25, eight).toFixed(1) + " ft². Base the outdoor opening on the total area served.",
        sun: "Sunroom/patio-cover exception: interior-to-sunroom opening not less than 8% (" + eight.toFixed(1) + " ft²) and not less than 20 ft² — so " + Math.max(20, eight).toFixed(1) + " ft².",
        bg: "Still 4% openable (" + four.toFixed(1) + " ft²). Below grade: outdoor horizontal clear space at least 1½ × opening depth (grade to bottom of opening). Dimension the well."
      };
      title.textContent = "4% of " + Math.round(sf) + " ft² = " + four.toFixed(1) + " ft² openable";
      body.innerHTML = extra[kind] + ' Use free area, not the nominal window. If the owner keeps windows locked, this is not a 402 building. <a href="' + contact("ventilation") + '">Send the room areas</a> · <a href="/natural-ventilation/">402 hub</a>.';
      track("Field Tool Result", { tool: "nat-402", sf: sf, kind: kind });
    });
  }


  var vcf = $("vcat-form");
  if (vcf) {
    vcf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("vcat-kind") && $("vcat-kind").value) || "";
      var box = $("vcat-result"), title = $("vcat-result-title"), body = $("vcat-result-body");
      show(box);
      var map = {
        dv: "804.1: terminals follow the appliance manufacturer — not a copied 9 in / 12 in integral-vent number. Overlay intakes, windows, grade, and meters.",
        int: "804.2 / 804.2.1: listing and instructions control. The 9-inch natural-draft and 12-inch forced-draft figures belong here. Do not paste them onto a different category.",
        md: "804.3: UL 378. Forced vs induced. Positive-pressure portions gas-tight. Auto-fired: no burner without the exhauster. Natural-draft appliances cannot sit on the discharge side of the exhauster (804.3.6).",
        typeb: "802: listed and labeled, compatible with the appliance. Type L / pellet: UL 641. Diameter is not a listing. 2 ft / 10 ft Type L roof, 5 ft height, 2 in attic shield, 12 in door swing.",
        fbc: "805: listed factory-built chimney system — appliance, classification, offsets, supports, termination, shroud, insulation shield. Do not mix brands.",
        exist: "801 reuse four-gate: size/draft, passageway, cleanout, clearances/fireblocking. An existing chimney to remain is not a design. Solid-fuel cannot share the passageway.",
        note: "“Vent to exterior” is not 801, 802, 803, or 804. Name fuel, method, pressure, and termination before anyone buys pipe."
      };
      title.textContent = "Category first. Clearance second.";
      body.innerHTML = (map[k] || "Select a category.") + ' <a href="' + contact("mep") + '">Send the listing</a> · <a href="/general-venting/">801 hub</a> · <a href="/direct-vent/">804 hub</a>.';
      track("Field Tool Result", { tool: "vent-category", kind: k });
    });
  }


  var rf = $("ret-form");
  if (rf) {
    rf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("ret-where") && $("ret-where").value) || "";
      var box = $("ret-result"), title = $("ret-result-title"), body = $("ret-result-body");
      show(box);
      var map = {
        corridor: "601.2: corridors cannot serve as supply, return, exhaust, relief, or ventilation air ducts except for limited listed conditions. A corridor ceiling plenum as return only where a listed fire/smoke condition is met. Name the exception or move the grille.",
        exit: "601.3: exit-enclosure ventilation must be independent of other building ventilation systems. Do not tie the stair into the general HVAC.",
        kitchen: "601.5: closet, kitchen, pool, and garage conditions are exception-based, not blanket permission. Do not treat a kitchen return as default.",
        garage: "601.5: garage returns are exception-based. A garage is also a combustion and contaminant question — not a convenient plenum.",
        closet: "601.5: closet, bath, and pool rooms are exception-based, not blanket permission. Confirm the listed exception before the grille is cut.",
        otherdu: "601.5: return air cannot cross dwelling units. That is a hard stop, not a balancing note.",
        mech: "601.5: return openings must maintain combustion-appliance clearance and cannot pull from prohibited spaces unless a listed exception applies.",
        ok: "A return in the room this system supplies can still fail 601.5 if it exceeds the supply delivered to that room. Put supply vs return on M-601."
      };
      title.textContent = "Name the exception — or move the return.";
      body.innerHTML = (map[k] || "Select a location.") + ' <a href="' + contact("ducts") + '">Send the RCP</a> · <a href="/return-air/">601 hub</a>.';
      track("Field Tool Result", { tool: "return-601", where: k });
    });
  }


  var ff = $("fxd-form");
  if (ff) {
    ff.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("fxd-cross") && $("fxd-cross").value) || "";
      var box = $("fxd-result"), title = $("fxd-result-title"), body = $("fxd-result-body");
      show(box);
      var map = {
        wall: "607.7: flex and air connectors shall not pass through any fire-resistance-rated assembly. Stop the flex. Carry listed sheet steel through the wall with the 607.5 / 607.6 protection that assembly requires.",
        shaft: "A shaft is a rated assembly. Flex is not the penetration. Hard duct, damper/sleeve/firestop as 607.5 requires, then flex only after the boundary.",
        ceil: "Rated floor/ceiling, roof/ceiling, and ceiling membranes are 607.7 territory. A flex tail through the membrane is a life-safety breach, even as a 'final connection.'",
        smoke: "Smoke barriers and smoke partitions count. The flex stops; the listed steel duct with the correct 607 protection crosses.",
        none: "If every flex run stays on the occupied side of every rated line, 607.7 is not the comment. Still show the flex-to-hard-duct transition on the plan so the inspector is not guessing.",
        unsure: "Overlay the architectural life-safety plan on the M-sheet before anyone cuts flex. If you cannot name the rated lines, you cannot claim 607.7 compliance."
      };
      title.textContent = k === "none" ? "Keep the transition on the drawing." : "Flex stops. Hard duct crosses.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("ducts") + '">Send the RCP</a> · <a href="/flexible-ducts/">607.7 hub</a>.';
      track("Field Tool Result", { tool: "flex-607-7", where: k });
    });
  }


  var sf = $("sccr-form");
  if (sf) {
    sf.addEventListener("submit", function (e) {
      e.preventDefault();
      var afc = parseFloat(($("sccr-afc") && $("sccr-afc").value) || "");
      var pack = parseFloat(($("sccr-pack") && $("sccr-pack").value) || "");
      var ir = parseFloat(($("sccr-ir") && $("sccr-ir").value) || "");
      var box = $("sccr-result"), title = $("sccr-result-title"), body = $("sccr-result-body");
      show(box);
      var hasA = afc === afc && afc > 0;
      var hasP = pack === pack && pack > 0;
      var hasI = ir === ir && ir > 0;
      if (!hasA && !hasP && !hasI) {
        title.textContent = "Missing evidence is not zero risk.";
        body.innerHTML = 'Need the available fault current at this connection, the assembly SCCR, or both. A breaker interrupting rating alone does not give the VFD or control panel an SCCR. <a href="' + contact("mep") + '">Send the nameplate</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "empty" });
        return;
      }
      if (hasA && hasP && afc > pack) {
        title.textContent = "Hold procurement. The breaker does not close this.";
        body.innerHTML = hasI
          ? ("Available " + afc + " kA exceeds assembly SCCR " + pack + " kA. A " + ir + " kA interrupting rating on the breaker is a different value — it does not raise the package SCCR. Daily Code Talk’s 22 / 10 / 65 example is the same pattern. Do not relabel. Do not improvise series-rating.")
          : ("Available " + afc + " kA exceeds assembly SCCR " + pack + " kA. The breaker interrupting rating, if you only have that, is not the package SCCR.");
        body.innerHTML += ' <a href="' + contact("mep") + '">Send the study page</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "hold" });
        return;
      }
      if (hasI && !hasP) {
        title.textContent = "Interrupting rating is not SCCR.";
        body.innerHTML = ir + ' kA on the breaker does not automatically give the surrounding control panel, VFD, pump, or HVAC assembly that SCCR. Photograph the package nameplate (safe access only). Missing SCCR is unresolved. <a href="' + contact("mep") + '">Send the nameplate</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "ir-only" });
        return;
      }
      title.textContent = "Same voltage. Same rating basis. Then compare.";
      body.innerHTML = "For a fully rated arrangement, available fault current at the connection must not exceed the applicable equipment SCCR. Recheck after transformer replacements, utility upgrades, or added generators. An arc-flash label answers a different question." + ' <a href="' + contact("mep") + '">Send the one-line</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
      track("Field Tool Result", { tool: "sccr", kind: "ok-or-partial" });
    });
  }


  var racf = $("rac-form");
  if (racf) {
    racf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("rac-need") && $("rac-need").value) || "";
      var box = $("rac-result"), title = $("rac-result-title"), body = $("rac-result-body");
      show(box);
      var map = {
        none: "That path can be readily accessible — if the governing requirement uses that term. Still walk the route after the project is built. Storage and other MEP can undo it.",
        key: "Keys are not a strike against readily accessible in Article 100. Tools other than keys are. Confirm the lock is a key, not a tool-only fastener.",
        tool: "Readily accessible means without tools other than keys. A screwdriver or wrench to reach the handle is the wrong path if the requirement is readily accessible. Move the disconnect or clear the obstruction on the drawing.",
        ladder: "A portable ladder is specifically listed as something readily accessible equipment does not require. Roof geometry that needs a ladder to the RTU disconnect is a location problem, not a note.",
        move: "Moving obstacles is specifically listed. Storage in front of the disconnect is not a field workaround — it is a failed readily-accessible condition.",
        climb: "Climbing over or under obstacles is specifically listed. Trace the route in section, not just in plan.",
        demo: "Accessible wiring methods can be exposed or removed without damaging structure or finish. Destructive removal is not that condition. Flag it before concealment."
      };
      title.textContent = (k === "none" || k === "key") ? "Walk the route after occupancy." : "That path is not readily accessible.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("mep") + '">Send the path photo</a> · <a href="/readily-accessible/">Access hub</a>. This is not a 110.26 working-space calculation.';
      track("Field Tool Result", { tool: "readily-accessible", need: k });
    });
  }


  var bcf = $("bcf-form");
  if (bcf) {
    bcf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("bcf-where") && $("bcf-where").value) || "";
      var box = $("bcf-result"), title = $("bcf-result-title"), body = $("bcf-result-body");
      show(box);
      var map = {
        panel: "Conductors from that final panel OCPD to the outlet(s) are the branch circuit. Upstream of that OCPD, toward the service or SDS, is feeder territory. Put that OCPD on the one-line.",
        disc: "If that disconnect/fuse is the final OCPD protecting the circuit, the conductors beyond it to the load are the branch circuit. Confirm it is actually last — a downstream device would move the boundary.",
        up: "If another OCPD still sits between here and the load, you have not found the final branch-circuit device. Keep walking toward the load.",
        guess: "A label is not a classification. Ask: what is the final branch-circuit OCPD, and what outlet/load does it serve? Not every conductor leaving a panel is a feeder.",
        exist: "Do not classify an existing circuit from an assumed route. When origin controls scope or safety, verify with qualified personnel and required safe-work procedures — or record not verified."
      };
      title.textContent = (k === "guess" || k === "exist" || k === "up") ? "The boundary is not named yet." : "Final OCPD first. Then the name.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("mep") + '">Send the one-line</a> · <a href="/branch-circuit-vs-feeder/">Hub</a>.';
      track("Field Tool Result", { tool: "branch-feeder", where: k });
    });
  }


  var uf = $("utl-form");
  if (uf) {
    uf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("utl-auth") && $("utl-auth").value) || "";
      var box = $("utl-result"), title = $("utl-result-title"), body = $("utl-result-body");
      show(box);
      var map = {
        both: "109 wants the code official’s authorization before connecting IMC-regulated systems. Keep both writings with the commissioning plan. Verify controls and safeties are active. Use LOTO for partial energization.",
        ahj: "You have the AHJ side. The utility release is still a separate requirement. Do not treat one as the other. Align meter-set / power-on with the commissioning plan.",
        util: "The utility’s meter-set is not the AHJ’s yes. 109.1: no connection until the code official authorizes it. Hold energization.",
        temp: "109.2 allows temporary service for testing or limited use — in writing. A verbal ‘you can test’ is not that writing. Get the duration on paper; coordinate with 110.",
        exist: "Renovation error: assuming the existing connection covers the new equipment. Authorization applies to the piece being connected, not just the circuit.",
        none: "Do not energize. Unauthorized connection is a fast stop-work trigger and 109.3 disconnect territory — even later, even if it was originally connected properly."
      };
      title.textContent = (k === "both" || k === "ahj") ? "Two writings. Then energize." : "Do not energize on that record.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("existing") + '">Send the writing</a> · <a href="/utility-connection/">109 hub</a>.';
      track("Field Tool Result", { tool: "utility-109", auth: k });
    });
  }


  var nvg = $("nvg-form");
  if (nvg) {
    nvg.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("nvg-need") && $("nvg-need").value) || "";
      var box = $("nvg-result"), title = $("nvg-result-title"), body = $("nvg-result-body");
      show(box);
      var map = {
        ll: "A line-to-line three-phase motor often does not require a neutral. Still reconcile the approved wiring diagram with the feeder schedule before purchase — packaged extras can change it.",
        ctrl: "Controls or other loads inside the package may need a neutral even when the largest motor does not. The complete equipment wiring diagram settles it. Do not guess from the motor.",
        unk: "“It has a ground” is not a specification. The EGC is the fault path, not the intended normal load-current return. Open the diagram, or write: control-power neutral requirement not reconciled; electrical designer and vendor to resolve before feeder release.",
        add: "Do not add a neutral-to-equipment connection at a convenient downstream enclosure to “make a ground.” Improper connections can put normal current on metal paths. That is a bonding arrangement for the responsible electrical professional — not a field improvisation.",
        color: "A visible conductor color is an observation, not proof of function or correct termination. Older renovations relabel. Count of green wires is not a complete permitted EGC path."
      };
      title.textContent = (k === "ll") ? "Confirm the diagram, then the feeder." : "Do not treat ground and neutral as interchangeable.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("mep") + '">Send the wiring diagram</a> · <a href="/neutral-vs-ground/">Hub</a>.';
      track("Field Tool Result", { tool: "neutral-egc", need: k });
    });
  }


  var t2f = $("t2t-form");
  if (t2f) {
    t2f.addEventListener("submit", function (e) {
      e.preventDefault();
      function num(id) {
        var el = $(id);
        var v = parseFloat((el && el.value) || "");
        return v === v ? v : null;
      }
      var open = num("t2t-open"), prop = num("t2t-prop"), oa = num("t2t-oa"), grade = num("t2t-grade");
      var roof = num("t2t-roof"), wall = num("t2t-wall");
      var fails = [];
      if (open !== null && open < 3) fails.push("openings (need ≥ 3 ft)");
      if (prop !== null && prop < 10) fails.push("property line / same-lot building (need ≥ 10 ft)");
      if (oa !== null && oa < 10) fails.push("outside-air intake (need ≥ 10 ft)");
      if (grade !== null && grade < 10) fails.push("above grade (need ≥ 10 ft)");
      if (roof !== null && roof < 30) fails.push("above roof (need ≥ 30 in)");
      if (wall !== null && wall < 30) fails.push("from exterior vertical wall (need ≥ 30 in)");
      var box = $("t2t-result"), title = $("t2t-result-title"), body = $("t2t-result-body");
      show(box);
      if (fails.length) {
        title.textContent = "Relocate before inspection.";
        body.innerHTML = "Tight against 2024 IMC 506.4.2 Type II termination distances: " + fails.join("; ") + ". Also: do not discharge onto walkways. Confirm manufacturer termination and IBC opening protectives." + ' <a href="' + contact("kitchen") + '">Send the roof plan</a> · <a href="/type-ii-ducts/">Hub</a>.';
        track("Field Tool Result", { tool: "type-ii-term", ok: false });
      } else {
        title.textContent = "Those distances clear the Type II termination check.";
        body.innerHTML = "Still: rigid metallic duct, Chapter 6 construction, approved sealing if positive-pressure or moisture-laden, manufacturer termination, weather protection, and no walkway discharge. Distances belong on the drawing." + ' <a href="' + contact("kitchen") + '">Send the outlet detail</a> · <a href="/type-ii-ducts/">Hub</a>.';
        track("Field Tool Result", { tool: "type-ii-term", ok: true });
      }
    });
  }


  var dca = $("dca-form");
  if (dca) {
    dca.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("dca-seq") && $("dca-seq").value) || "";
      var box = $("dca-result"), title = $("dca-result-title"), body = $("dca-result-body");
      show(box);
      var map = {
        none: "If the path is always open, damper interlock is not the 701 issue. Still prove free area with product data, not nominal dimensions, and check room depressurization from exhaust.",
        proof: "Proof-of-open before fire is the sequence 701 is looking for. Keep actuator/controls data matched to the appliance permissive. Startup should test the worst-case negative-pressure mode.",
        end: "“Open at startup” without proof still lets the appliance fire against a closed path if the damper fails. That is the safety problem. Show the interlock.",
        note: "A note is not a system. The reviewer needs the appliance, the air source, the opening-size basis, the route, and the controls logic that keeps it from firing against a closed damper.",
        unk: "Find every damper in the combustion-air path on the M-sheet and the controls diagram before anyone sizes a grille. If you cannot name it, you cannot claim 701."
      };
      title.textContent = (k === "none" || k === "proof") ? "Prove the path. Then start up." : "Do not let it fire against a closed damper.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("combustion") + '">Send the sequence</a> · <a href="/dampered-combustion-air/">Hub</a>.';
      track("Field Tool Result", { tool: "dampered-ca", seq: k });
    });
  }


  var oai = $("oai-form");
  if (oai) {
    oai.addEventListener("submit", function (e) {
      e.preventDefault();
      function num(id) {
        var el = $(id);
        var v = parseFloat((el && el.value) || "");
        return v === v ? v : null;
      }
      var lot = num("oai-lot"), src = num("oai-src"), above = num("oai-above"), below = num("oai-below");
      var fails = [];
      if (lot !== null && lot < 10) fails.push("lot line / same-lot building (need ≥ 10 ft)");
      if (src !== null && src < 10) {
        if (above === null || above < 25) fails.push("contaminant source: need ≥ 10 ft horizontally, or ≥ 25 ft above streets/alleys/parking/loading");
      }
      if (src !== null && src < 10 && below !== null && below < 3) fails.push("source within 10 ft horizontally: intake needs ≥ 3 ft below that source (unless listed dwelling-unit combo fitting)");
      var box = $("oai-result"), title = $("oai-result-title"), body = $("oai-result-body");
      show(box);
      if (fails.length) {
        title.textContent = "Relocate the louver before it is released.";
        body.innerHTML = "Tight against 2024 IMC 401.4: " + fails.join("; ") + ". Measure from the nearest street edge, not the centerline. Flood-hazard intakes follow IBC 1612." + ' <a href="' + contact("ventilation") + '">Send the site plan</a> · <a href="/outdoor-air-intake/">Hub</a>.';
        track("Field Tool Result", { tool: "oa-intake", ok: false });
      } else {
        title.textContent = "Those distances clear the outdoor-air intake check.";
        body.innerHTML = "Still dimension it on the site plan and the elevation. Dwelling-unit listed combo intake-exhaust fittings have a 401.4(3) exception. Flood: set at or above the IBC 1612 elevation." + ' <a href="' + contact("ventilation") + '">Send the louver detail</a> · <a href="/outdoor-air-intake/">Hub</a>.';
        track("Field Tool Result", { tool: "oa-intake", ok: true });
      }
    });
  }


  var ips = $("ips-form");
  if (ips) {
    ips.addEventListener("submit", function (e) {
      e.preventDefault();
      var occ = ($("ips-occ") && $("ips-occ").value) || "";
      var open = parseFloat(($("ips-open") && $("ips-open").value) || "");
      var box = $("ips-result"), title = $("ips-result-title"), body = $("ips-result-body");
      show(box);
      if (!(open === open) || !occ) {
        title.textContent = "Need occupancy and a measured opening.";
        body.textContent = "Use the short side for rectangles, diameter for rounds, any side for squares.";
        return;
      }
      var ok = false, range = "";
      if (occ === "res") {
        range = "residential: not less than 1/4 in and not more than 1/2 in";
        ok = open >= 0.25 && open <= 0.5;
      } else {
        range = "other occupancies: greater than 1/4 in and not more than 1 in";
        ok = open > 0.25 && open <= 1;
      }
      if (ok) {
        title.textContent = "That opening clears Table 401.5.";
        body.innerHTML = range + ". Still: corrosion-resistant, suited to weather, IBC exterior-wall opening protectives if in a wall, and AMCA 550 in hurricane-prone regions for the exact model and size. Brochure mesh is not the measurement." + ' <a href="' + contact("ventilation") + '">Send the cut sheet</a> · <a href="/intake-protection/">Hub</a>.';
      } else {
        title.textContent = "That opening is outside Table 401.5.";
        body.innerHTML = "Measured " + open + " in vs " + range + ". Verify actual mesh/slot, not nominal brochure size. Hurricane-prone: AMCA 550 is a separate submittal item." + ' <a href="' + contact("ventilation") + '">Send the cut sheet</a> · <a href="/intake-protection/">Hub</a>.';
      }
      track("Field Tool Result", { tool: "intake-401-5", occ: occ, ok: ok });
    });
  }


  var recf = $("rec-form");
  if (recf) {
    recf.addEventListener("submit", function (e) {
      e.preventDefault();
      var a = ($("rec-filt") && $("rec-filt").value) || "";
      var b = ($("rec-lfl") && $("rec-lfl").value) || "";
      var c = ($("rec-mon") && $("rec-mon").value) || "";
      var box = $("rec-result"), title = $("rec-result-title"), body = $("rec-result-body");
      show(box);
      var all = a === "yes" && b === "yes" && c === "yes";
      if (all) {
        title.textContent = "Those three are on the record.";
        body.innerHTML = "Still: show DISCHARGE TO OUTDOORS vs RECIRC AIR on M-001, filter efficiency on the schedule, monitor location, and alarm/shutdown if the manufacturer or AHJ requires it. Confirm AHJ and environmental-agency permission for the specific dust. Do not treat this as general return air." + ' <a href="' + contact("mep") + '">Send the collector schedule</a> · <a href="/dust-exhaust-recirculation/">Hub</a>.';
      } else {
        title.textContent = "Default: exhaust to outdoors.";
        body.innerHTML = "510.1.3 recirculation needs all three: 99.9% at 10 µm, vapor under 25% LFL, and approved continuous monitoring. If any one is missing, discharge to the exterior (directly by flue, or indirectly through the bin/vault unless contaminants are removed)." + ' <a href="' + contact("mep") + '">Send the collector cut sheet</a> · <a href="/dust-exhaust-recirculation/">Hub</a>.';
      }
      track("Field Tool Result", { tool: "510-recirc", ok: all });
    });
  }


  var ezo = $("ezo-form");
  if (ezo) {
    ezo.addEventListener("submit", function (e) {
      e.preventDefault();
      var vbz = parseFloat(($("ezo-vbz") && $("ezo-vbz").value) || "");
      var ez = parseFloat(($("ezo-ez") && $("ezo-ez").value) || "");
      var box = $("ezo-result"), title = $("ezo-result-title"), body = $("ezo-result-body");
      show(box);
      if (!(vbz === vbz) || vbz < 0 || !(ez === ez) || ez <= 0) {
        title.textContent = "Need the zone outdoor-air rate and a zone air-distribution effectiveness from the list.";
        body.textContent = "Voz = Vbz / Ez. This is not a Table 403.3.1.1 lookup and not a multi-zone Ev calculation.";
        return;
      }
      var voz = Math.round((vbz / ez) * 10) / 10;
      title.textContent = "Voz ≈ " + voz + " cfm (educational).";
      body.innerHTML = "Vbz " + vbz + " / Ez " + ez + " = " + voz + " cfm zone outdoor airflow. Single-zone or 100% OA: Vot is the sum of Voz. Mixed-air multi-zone still needs Zp / Ev / D on M-601 — not computed here. DCV cannot go below Ra during occupancy. A fixed OA damper is not VAV outdoor-air control." + ' <a href="' + contact("ventilation") + '">Send M-601</a> · <a href="/zone-outdoor-air/">Hub</a>.';
      track("Field Tool Result", { tool: "ez-voz", ez: ez });
    });
  }


  var mdx = $("mdpex-form");
  if (mdx) {
    mdx.addEventListener("submit", function (e) {
      e.preventDefault();
      var bldg = ($("mdpex-bldg") && $("mdpex-bldg").value) || "";
      var flood = ($("mdpex-flood") && $("mdpex-flood").value) || "";
      var work = ($("mdpex-work") && $("mdpex-work").value) || "";
      var box = $("mdpex-result"), title = $("mdpex-result-title"), body = $("mdpex-result-body");
      show(box);
      var cta = ' <a href="' + contact("existing") + '">Send the scope</a> · <a href="/miami-dade-permit-exemptions/">Hub</a>.';
      if (work === "acnew" || work === "other" || work === "acswap") {
        title.textContent = work === "acswap"
          ? "Mechanical permit still required."
          : "Treat this as permitted mechanical work.";
        body.innerHTML = (work === "acswap"
          ? "County text: same-amperage AC changeout does not require an electrical permit. A mechanical permit is still required. HB 803’s $7,500 home-improvement exemption does not cover mechanical work."
          : "HB 803 (July 1, 2026) still requires permits for mechanical, electrical, plumbing, structural, and gas work even under $7,500. Multifamily units and flood-hazard properties are outside that exemption.") + cta;
        track("Field Tool Result", { tool: "md-exemption", work: work, permit: true });
        return;
      }
      var maybe = {
        inside: "County minor-repair list (licensed mechanical contractor, inside the equipment): coil, compressor, refrigerant piping, non-combustion heating, or fans. Confirm the live 105.2.2 list. Exemption is not a code holiday.",
        duct: "County list: repair of air-conditioning duct by a licensed mechanical contractor, regardless of value. Confirm the live text. Do not treat a duct replacement or relocation as a repair.",
        port: "FBC 105.2 as published by the County: portable heating, ventilation, cooling, or evaporative cooler. Not a permanent system.",
        part: "FBC 105.2 as published by the County: replacement of a part that does not alter approval or make the equipment unsafe. If the part changes the listing or capacity, it is not this exemption.",
        refr: "FBC 105.2 as published by the County: self-contained refrigeration ≤ 10 lb refrigerant and ≤ 1 hp. Both limits apply.",
        under500: "County minor-repair list: licensed mechanical contractor, ≤ $500 materials and labor. Do not split a project to stay under $500."
      };
      var note = "";
      if (bldg === "mf") note += " HB 803 does not apply to multifamily units.";
      if (flood === "yes") note += " Flood-hazard properties are not eligible for the HB 803 $7,500 path.";
      title.textContent = "Possible listed exemption — confirm with the AHJ.";
      body.innerHTML = (maybe[work] || "Confirm the County page.") + note + " This screen does not determine that your job is exempt." + cta;
      track("Field Tool Result", { tool: "md-exemption", work: work, permit: false });
    });
  }


  var qoa = $("qoa-form");
  if (qoa) {
    qoa.addEventListener("submit", function (e) {
      e.preventDefault();
      var a = parseFloat(($("qoa-area") && $("qoa-area").value) || "");
      var n = parseFloat(($("qoa-nbr") && $("qoa-nbr").value) || "");
      var red = ($("qoa-red") && $("qoa-red").value) || "";
      var box = $("qoa-result"), title = $("qoa-result-title"), body = $("qoa-result-body");
      show(box);
      if (!(a === a) || a <= 0 || !(n === n) || n < 1) {
        title.textContent = "Need Afloor and at least one bedroom.";
        body.textContent = "Nbr is not less than 1. This is not Table 403.3.1.1.";
        return;
      }
      var base = 0.01 * a + 7.5 * (n + 1);
      base = Math.round(base * 10) / 10;
      var note = " Kitchen local exhaust: 100 cfm intermittent or 25 continuous. Baths: 50 or 20. Common areas: 0.06 cfm/ft². Fans listed to AMCA 210 / ASHRAE 51. Intermittent whole-house: at least 1 hour of every 4 with equivalent average.";
      var cta = ' <a href="' + contact("ventilation") + '">Send Afloor and Nbr</a> · <a href="/low-rise-residential-ventilation/">Hub</a>.';
      if (red === "yes") {
        var cut = Math.round(base * 0.7 * 10) / 10;
        title.textContent = "QOA ≈ " + cut + " cfm with the 30% cut (educational).";
        body.innerHTML = "Base Eq. 4-9 is " + base + " cfm. 30% reduction applies only if OA is ducted to each bedroom and to living/dining/kitchen and the system is balanced and commissioned. Base without the cut: " + base + " cfm." + note + cta;
      } else if (red === "maybe") {
        title.textContent = "Do not take the 30% yet. Base QOA ≈ " + base + " cfm.";
        body.innerHTML = "Eq. 4-9: 0.01×" + a + " + 7.5×(" + n + "+1) = " + base + " cfm. The 30% cut is not a default. Prove bedroom OA and balance first." + note + cta;
      } else {
        title.textContent = "QOA ≈ " + base + " cfm (educational).";
        body.innerHTML = "Eq. 4-9: 0.01×" + a + " + 7.5×(" + n + "+1) = " + base + " cfm whole-house outdoor air. This is not a sealed design and not Table 403.3.1.1." + note + cta;
      }
      track("Field Tool Result", { tool: "eq-4-9", red: red });
    });
  }


  var rlim = $("rlim-form");
  if (rlim) {
    rlim.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("rlim-kind") && $("rlim-kind").value) || "";
      var box = $("rlim-result"), title = $("rlim-result-title"), body = $("rlim-result-body");
      show(box);
      var cta = ' <a href="' + contact("ventilation") + '">Send the OA schedule</a> · <a href="/recirculation-limits/">Hub</a>.';
      var map = {
        oa: ["Do not credit that toward minimum OA.", "403.2.1: the 403.3 minimum outdoor air cannot be recirculated. Extra air above the minimum can be. Put on M-001: recirculated air does not count toward the minimum OA rate."],
        dwell: ["Do not recirculate between dwellings.", "403.2.1: no recirculation between different dwellings or dissimilar occupancies."],
        pool: ["Pool air is not general return.", "No recirc unless dehumidified to 60% RH or less (Manual SPS), and do not send that air to other spaces (the greater-than-10% blend rule)."],
        noteb: ["Note b: 100% exhaust. No recirc out.", "Spaces flagged by Table 403.3.1.1 Note b: all supply becomes exhaust. Tag them on M-001 and the ventilation schedule."],
        noteg: ["Note g: over 10% is a recirc fail.", "Do not recirculate to other spaces if more than 10% of those spaces’ supply is from the Note g rooms."],
        xfer: ["Transfer can be makeup — OA still has to land.", "403.2.2: transfer from occupiable spaces may make up kitchens, baths, toilets, elevators, smoking lounges unless the table prohibits. Meet the exhaust cfm. Deliver required OA to those rooms, or to the source rooms, or both. Show the path."],
        extra: ["Extra air above the minimum can be recirculated.", "Same occupancy, above the 403.3 minimum, and not a Note b/g or dwelling-to-dwelling case. Still: do not credit it toward the minimum OA number."]
      };
      var row = map[k];
      if (!row) {
        title.textContent = "Pick what is being recirculated.";
        body.textContent = "This is not a 510.1.3 dust-collector check.";
        return;
      }
      title.textContent = row[0];
      body.innerHTML = row[1] + cta;
      track("Field Tool Result", { tool: "403-recirc", kind: k });
    });
  }


  var heat = $("heat-form");
  if (heat) {
    heat.addEventListener("submit", function (e) {
      e.preventDefault();
      var use = ($("heat-use") && $("heat-use").value) || "";
      var shown = ($("heat-shown") && $("heat-shown").value) || "";
      var box = $("heat-result"), title = $("heat-result-title"), body = $("heat-result-body");
      show(box);
      var cta = ' <a href="' + contact("load") + '">Send the occupancy and the mechanical schedule</a> · <a href="/temperature-control/">Temperature control</a>.';
      if (!use || !shown) {
        title.textContent = "Pick the room use and how heat is shown.";
        body.textContent = "This is not a heat-loss calculation.";
        return;
      }
      if (shown === "port") {
        title.textContent = "Portable heaters are not the heating system.";
        body.innerHTML = "IMC 309: interior spaces intended for human occupancy must be capable of 68°F at 3 feet above the floor on the design heating day. Plug-in heaters are not the compliance strategy. Show an active or passive heating system, or state a listed occupancy exception." + cta;
      } else if (use === "occ" && (shown === "none" || shown === "none-note")) {
        title.textContent = "Occupied rooms need a heating path — or a real exception.";
        body.innerHTML = "Office, retail, dwelling, classroom, and clinic rooms are intended for human occupancy. “No heat” only holds if a listed exception applies (primary purpose is not human comfort, or Group F / H / S / U). Write the exception on the mechanical cover sheet. A cover-sheet note that just says “per code” is the comment." + cta;
      } else if (use === "convert") {
        title.textContent = "The new use can trigger heating even if the old space did not.";
        body.innerHTML = "Converted storage, a warehouse office, and a shell that is now occupied are the rooms Daily Code Talk flags. Confirm occupancy and intended use before you omit heat. The 68°F / 3-foot figures are 2024 IMC 309 education." + cta;
      } else if (use === "back" && shown !== "sys") {
        title.textContent = "If people occupy it during the shift, treat it as occupancy.";
        body.innerHTML = "Back-of-house and support rooms are the ones that get missed. Confirm whether the primary purpose is human comfort. If people work there, 309 is in play unless a listed occupancy exception applies." + cta;
      } else if ((use === "fhsu" || use === "process") && shown === "none") {
        title.textContent = "Name the exception. Do not leave a blank schedule.";
        body.innerHTML = "Group F, H, S, and U, and spaces whose primary purpose is not human comfort, are the usual 309 exceptions. Put the occupancy group and the exception sentence on the cover sheet. “Normally empty” is not an occupancy classification." + cta;
      } else if (shown === "sys") {
        title.textContent = "A heating system is shown. Trace it to the design day.";
        body.innerHTML = "309 still wants the space capable of 68°F at 3 feet on the design heating day. The load file (IMC 312) and the equipment schedule have to tell the same story. Send those if the comment is about capacity, not about whether heat exists." + cta;
      } else {
        title.textContent = "Lock occupancy and intended use before omitting heat.";
        body.innerHTML = "If the architectural program and the occupancy classification disagree, that disagreement is the comment. 309 is a use question first." + cta;
      }
      track("Field Tool Result", { tool: "imc-309", use: use, shown: shown });
    });
  }


  var exchim = $("exchim-form");
  if (exchim) {
    exchim.addEventListener("submit", function (e) {
      e.preventDefault();
      var trig = ($("exchim-trig") && $("exchim-trig").value) || "";
      var gate = ($("exchim-gate") && $("exchim-gate").value) || "";
      var box = $("exchim-result"), title = $("exchim-result-title"), body = $("exchim-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send chimney photos and the new cut sheet</a> · <a href="/existing-chimneys/">Existing chimneys</a>.';
      if (!trig || !gate) {
        title.textContent = "Pick the trigger and which gates have evidence.";
        body.textContent = "This is not a flue-size calculator.";
        return;
      }
      if (trig === "fuel") {
        title.textContent = "Fuel or vent-category change is an escalate.";
        body.innerHTML = "IMC 801.18 still wants all four gates. A condensing / Category IV appliance on an old masonry flue is not a reconnect note. Survey size, passageway, cleanout, and clearance, then the manufacturer’s venting path. Gas-fired appliances also follow the fuel-gas code." + cta;
      } else if (gate === "four") {
        title.textContent = "Four gates documented — still a field-verification hold.";
        body.innerHTML = "Size, passageway, cleanout, and clearance are on the set. Assign who verifies in the field before connection. Close unused inlet openings. Do not treat prior service as current suitability." + cta;
      } else if (gate === "size") {
        title.textContent = "Size alone does not reuse the chimney.";
        body.innerHTML = "801.18 has four gates. Passing draft/size while the passageway, cleanout, or clearance is unknown is the comment. Show cleaning, repair, relining, or a listed liner if the passageway fails." + cta;
      } else if (gate === "none" || trig === "note") {
        title.textContent = "“Existing chimney to remain” is not a design.";
        body.innerHTML = "Replacement, addition, and permanent disconnection all trigger 801.18.1 through 801.18.4. Convert the note into a four-row matrix: size, passageway, cleanout, clearance — each with evidence, required action, drawing location, and who verifies." + cta;
      } else {
        title.textContent = "Document the missing gates before you reconnect.";
        body.innerHTML = "Photos of the termination are not a passageway inspection. The concealed flue needs a cleanliness, continuity, and damage plan. Confirm the cleanout is present and accessible, and that combustible clearance / fireblocking is known." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-18", trig: trig, gate: gate });
    });
  }


  var contam = $("contam-form");
  if (contam) {
    contam.addEventListener("submit", function (e) {
      e.preventDefault();
      var what = ($("contam-what") && $("contam-what").value) || "";
      var ex = ($("contam-ex") && $("contam-ex").value) || "";
      var box = $("contam-result"), title = $("contam-result-title"), body = $("contam-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the reflected-ceiling plan</a> · <a href="/contamination-prevention/">Contamination prevention</a>.';
      if (!what || !ex) {
        title.textContent = "Pick what is in the ceiling and whether an exception is shown.";
        body.textContent = "This is not a duct-size calculation.";
        return;
      }
      if (ex === "no") {
        title.textContent = "Above the ceiling is not an approved plenum path.";
        body.innerHTML = "IMC 601.4: do not run positive-pressure exhaust, chimneys, or vents through a duct or plenum so a leak becomes the air stream. Name a listed exception or move the path." + cta;
      } else if (what === "pex" && ex === "ten") {
        title.textContent = "Exception 1 is narrow. Show the 10% spaces and 603.9 joints.";
        body.innerHTML = "Positive-pressure exhaust in a ceiling return plenum only over spaces already allowed 10 percent recirculation under 403.2.1 item 4, and joints must comply with 603.9. Put that basis on the cover sheet — not “per code.”" + cta;
      } else if (ex === "listed" || ex === "nofit" || ex === "enc") {
        title.textContent = "Exception 2 needs the listing, the joint location, or the enclosure — on the sheet.";
        body.innerHTML = "Chimneys and vents through a plenum only if: listed for positive pressure and sealed per the manufacturer; or no fittings/joints in the above-ceiling space; or a conduit/enclosure with sealed joints separating that space from the plenum. Show which one." + cta;
      } else {
        title.textContent = "Identify the plenum before you route the vent.";
        body.innerHTML = "If you cannot name the exception, the path is not 601.4-compliant yet. Coordinate routing early so the path is code-compliant, not just physically convenient." + cta;
      }
      track("Field Tool Result", { tool: "imc-601-4", what: what, ex: ex });
    });
  }


  var abandon = $("abandon-form");
  if (abandon) {
    abandon.addEventListener("submit", function (e) {
      e.preventDefault();
      var what = ($("abandon-what") && $("abandon-what").value) || "";
      var shown = ($("abandon-show") && $("abandon-show").value) || "";
      var box = $("abandon-result"), title = $("abandon-result-title"), body = $("abandon-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send photos of every visible connector</a> · <a href="/abandoned-vent-openings/">Abandoned openings</a>.';
      if (!what || !shown) {
        title.textContent = "Pick what is happening and whether the old opening is shown as closed.";
        body.textContent = "This is not a closure specification.";
        return;
      }
      if (what === "multi") {
        title.textContent = "Closing one opening can change draft for whatever is still firing.";
        body.innerHTML = "A common or multi-story chimney with one appliance abandoned is an escalate. Show the approved closure method and confirm 801.18 still holds for the remaining appliances. Do not leave the old tie-in as a field find." + cta;
      } else if (shown === "cap") {
        title.textContent = "“Cap by contractor” is not a detail.";
        body.innerHTML = "IMC 801.8: abandoned inlet openings must be closed by an approved method, with a material compatible with the chimney or vent still in service. Show connector removal and the closure together." + cta;
      } else if (shown === "none" || what === "unk") {
        title.textContent = "Ask where the old appliance used to connect.";
        body.innerHTML = "A set that only draws the new vent is incomplete. Trace every old connector. An opening left unsealed undermines draft on the remaining system and can be a fire-separation gap." + cta;
      } else if (what === "same") {
        title.textContent = "Reconnect still needs the four gates — and any leftover openings closed.";
        body.innerHTML = "If the new appliance uses the same chimney, run <a href=\"/field-tools/#exchim\">801.18 size, passageway, cleanout, clearance</a>. Then close unused inlet openings from appliances that are gone." + cta;
      } else if (shown === "detail") {
        title.textContent = "A closure method is on the sheet. Confirm it matches the chimney still in service.";
        body.innerHTML = "Compatible material, connector removal shown, and remaining appliances identified. If nothing stays on that chimney, the abandonment note still has to be inspectable." + cta;
      } else {
        title.textContent = "Show the old opening and the approved closure.";
        body.innerHTML = "Replacement, relocation, conversion to direct-vent or electric, and demolition of old connectors all leave openings that 801.8 wants closed." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-8", what: what, shown: shown });
    });
  }


  var vterm = $("vterm-form");
  if (vterm) {
    vterm.addEventListener("submit", function (e) {
      e.preventDefault();
      var kind = ($("vterm-kind") && $("vterm-kind").value) || "";
      var roof = ($("vterm-roof") && $("vterm-roof").value) || "";
      var rise = ($("vterm-rise") && $("vterm-rise").value) || "";
      var box = $("vterm-result"), title = $("vterm-result-title"), body = $("vterm-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the roof photos and the cut sheet</a> · <a href="/vent-termination-height/">Vent termination height</a>.';
      if (!kind || !roof || !rise) {
        title.textContent = "Pick the vent type and both height checks.";
        body.textContent = "This is not a termination design.";
        return;
      }
      if (kind === "dv" || rise === "ex") {
        title.textContent = "The 5-foot rule yielded to the listing — still show the listing.";
        body.innerHTML = "802.6 exceptions (direct-vent, outdoor integral, pellet) move the height basis to the appliance and vent manufacturer. Name that listing. Type L 802.5 still does not apply to those systems — do not copy a Type L 2-foot / 10-foot typical onto a Category IV or pellet cap." + cta;
      } else if (roof === "deck" || roof === "short") {
        title.textContent = "The typical 2-foot roof detail is the comment.";
        body.innerHTML = "IMC 802.5 Type L: at least 2 feet above the highest point of roof penetration <strong>and</strong> at least 2 feet higher than any portion of the building within 10 feet. Check ridges, parapets, penthouse walls, dormers, and adjacent building portions on the actual roof — not a generic detail." + cta;
      } else if (rise === "base" || rise === "short") {
        title.textContent = "Measure 5 feet from the flue collar, not the floor.";
        body.innerHTML = "IMC 802.6: at least 5 feet of vertical height above the highest connected appliance flue collar. A run that looks tall in plan can still be short from the collar. Show it in section." + cta;
      } else if (kind === "unk") {
        title.textContent = "Name the vent type before you copy a height typical.";
        body.innerHTML = "Type L, masonry, Category IV plastic, direct-vent, and pellet do not share one cap height. 802.5–802.6 in this screen are the Type L / 5-foot collar checks from Daily Code Talk." + cta;
      } else if (roof === "both" && rise === "ok") {
        title.textContent = "Both height checks have evidence. Still draw them in section.";
        body.innerHTML = "2-foot / 10-foot against actual nearby geometry, and 5 feet from the highest connected collar. Do not leave final termination height to field adjustment." + cta;
      } else {
        title.textContent = "Check 802.5 and 802.6 independently.";
        body.innerHTML = "Passing the roof clearance does not pass the 5-foot collar rise. Passing the rise does not pass a parapet within 10 feet." + cta;
      }
      track("Field Tool Result", { tool: "imc-802-5-6", kind: kind, roof: roof, rise: rise });
    });
  }


  var passthru = $("passthru-form");
  if (passthru) {
    passthru.addEventListener("submit", function (e) {
      e.preventDefault();
      var where = ($("passthru-where") && $("passthru-where").value) || "";
      var path = ($("passthru-path") && $("passthru-path").value) || "";
      var box = $("passthru-result"), title = $("passthru-result-title"), body = $("passthru-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the wall type and the section</a> · <a href="/connector-pass-through/">Connector pass-through</a>.';
      if (!where || !path) {
        title.textContent = "Pick the assembly and how the pass-through is shown.";
        body.textContent = "This is not a pass-through design.";
        return;
      }
      if (where === "floor") {
        title.textContent = "Connectors cannot pass through floors or ceilings.";
        body.innerHTML = "IMC 803.10.4: a chimney connector does not go through a floor or a ceiling on its way to a masonry chimney. Keep the connector in the appliance room, or change the chimney location. This is not a field option." + cta;
      } else if (where === "rated" && path !== "listed") {
        title.textContent = "A fire-resistance-rated wall needs a listed assembly — not an improvised gap.";
        body.innerHTML = "803.10.4: connectors cannot pass through fire-resistance-rated wall assemblies unless the path is a listed wall pass-through or listed connector installed per the manufacturer. Table 803.10.4 is the combustible-wall path for connectors 10 inches or smaller — it does not waive a rated-wall listing." + cta;
      } else if (path === "clear" || path === "none") {
        title.textContent = "A clearance number without the system name is not the assembly.";
        body.innerHTML = "Table 803.10.4 Systems A (12 in), B (9 in), C (6 in), and D (2 in) each have liner, insulation, support, and attachment rules. Citing “6 inches” does not tell the inspector which system is on the job. Name the listed device or the table system." + cta;
      } else if (path === "table") {
        title.textContent = "Name System A, B, C, or D — then show liner and insulation.";
        body.innerHTML = "Table path is only for connectors not larger than 10 inches. Clearance is a minimum, not the whole assembly. Except System B, the connector extends to the inner face of the flue liner. Concealed metal exposed to flue gases: corrosion resistance and 1,800°F." + cta;
      } else if (path === "listed") {
        title.textContent = "Listed path — install it as the listing, not as a clearance typical.";
        body.innerHTML = "A listed wall pass-through device or a connector listed for wall pass-through is installed per the manufacturer. Put the listing on the detail. Noncombustible penetration seal still applies." + cta;
      } else {
        title.textContent = "Identify the wall before you draw the pipe through it.";
        body.innerHTML = "Review the assembly, not just the pipe: wall type, rating, pass-through system, and required clearance together." + cta;
      }
      track("Field Tool Result", { tool: "imc-803-10-4", where: where, path: path });
    });
  }


  var vdoor = $("vdoor-form");
  if (vdoor) {
    vdoor.addEventListener("submit", function (e) {
      e.preventDefault();
      var door = ($("vdoor-door") && $("vdoor-door").value) || "";
      var clear = ($("vdoor-clear") && $("vdoor-clear").value) || "";
      var box = $("vdoor-result"), title = $("vdoor-result-title"), body = $("vdoor-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the elevation and the door swing</a> · <a href="/vent-door-swing/">Door swing</a>.';
      if (!door || !clear) {
        title.textContent = "Pick the door and how the 12-inch clearance is shown.";
        body.textContent = "This is not a termination layout.";
        return;
      }
      if (clear === "stop") {
        title.textContent = "A doorstop is not a 12-inch clearance.";
        body.innerHTML = "IMC 802.9: the clearance must come from the permanent layout. Doorstops, closers, operational instructions, and field-installed accessories do not count. Relocate the terminal or the door." + cta;
      } else if (clear === "frame") {
        title.textContent = "Measure the full leaf swing, not the closed door.";
        body.innerHTML = "The 12-inch horizontal check is to the swept path of the door leaf — not the frame and not the closed position. Overlay the mechanical terminal with the architectural swing." + cta;
      } else if (door === "unk" || clear === "none") {
        title.textContent = "The mechanical elevation and the architectural swing have to be the same door.";
        body.innerHTML = "This miss reaches inspection because the terminal lives on M-501 and the swing lives on the A-sheet. Check service, equipment-room, balcony, patio, and access doors — not only the obvious front door." + cta;
      } else if (door === "none" || clear === "layout") {
        title.textContent = "If the full swing is plotted and the 12 inches are on the layout, keep it that way.";
        body.innerHTML = "Do not let a later door or terminal relocation depend on a closer. If relocating either one affects egress or accessibility, that is an escalate — not a field tweak." + cta;
      } else {
        title.textContent = "If the leaf enters the 12-inch zone, the layout has to change.";
        body.innerHTML = "A swinging door in that zone can damage the terminal, disrupt discharge, and let products of combustion in when the door opens." + cta;
      }
      track("Field Tool Result", { tool: "imc-802-9", door: door, clear: clear });
    });
  }


  var offset = $("offset-form");
  if (offset) {
    offset.addEventListener("submit", function (e) {
      e.preventDefault();
      var count = ($("offset-count") && $("offset-count").value) || "";
      var ang = ($("offset-ang") && $("offset-ang").value) || "";
      var sup = ($("offset-sup") && $("offset-sup").value) || "";
      var box = $("offset-result"), title = $("offset-result-title"), body = $("offset-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the chimney section</a> · <a href="/chimney-offsets/">Chimney offsets</a>.';
      if (!count || !ang || !sup) {
        title.textContent = "Pick elbow count, angle, and how the chimney is supported.";
        body.textContent = "This is not an offset schedule.";
        return;
      }
      if (count === "more") {
        title.textContent = "Four elbows is the model-code ceiling — the next field elbow is over it.";
        body.innerHTML = "IMC 805.4: no more than four elbows in the entire assembly, counted across floors and subcontractors. A new field offset has to trigger a coordinated review of elbow count, support, clearances, and termination — not approval of the elbow alone. The listing may be tighter than four." + cta;
      } else if (ang === "horiz") {
        title.textContent = "Measure 30 degrees from vertical, not from horizontal.";
        body.innerHTML = "A run that looks like a mild slope from the floor can already exceed 30 degrees from vertical. Manufacturer offset tables, elbow geometry, and listed lengths control a buildable arrangement — do not treat a sketch angle as an installation schedule." + cta;
      } else if (sup === "collar" || sup === "strap") {
        title.textContent = "A visible strap does not design the joist.";
        body.innerHTML = "IMC 805.5: joists, rafters, or other members that support a factory-built chimney must be designed for the additional load. Identify the load path through listed supports and anchors into the structure. Do not cut or notch a truss to make the route fit." + cta;
      } else if (count === "unk") {
        title.textContent = "Count the whole chimney, not this floor’s elbows.";
        body.innerHTML = "Walk appliance connection to termination as one assembly. Repeated local fixes can exhaust the four-elbow budget before anyone has checked the roof opening." + cta;
      } else if (count === "four") {
        title.textContent = "Four elbows are already used. The next beam conflict has no budget.";
        body.innerHTML = "Do not add a field elbow. Re-route, change the chimney location, or confirm the listing even allows four. 805.5 support still has to be a designed load path." + cta;
      } else {
        title.textContent = "Show the continuous route, elbow count, angles, and each support.";
        body.innerHTML = "If 1–3 elbows are on the set at 30 degrees or less from vertical, keep field changes from adding a fourth without a coordinated review. Manufacturer instructions may still limit offset more tightly than 805.4." + cta;
      }
      track("Field Tool Result", { tool: "imc-805-4-5", count: count, ang: ang, sup: sup });
    });
  }


  var cclear = $("cclear-form");
  if (cclear) {
    cclear.addEventListener("submit", function (e) {
      e.preventDefault();
      var typ = ($("cclear-type") && $("cclear-type").value) || "";
      var red = ($("cclear-red") && $("cclear-red").value) || "";
      var box = $("cclear-result"), title = $("cclear-result-title"), body = $("cclear-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the appliance type and the connector section</a> · <a href="/connector-clearance/">Connector clearance</a>.';
      var row = {
        incin: "Table 803.10.6 starting minimum for domestic electric and oil incinerators: 18 inches to combustibles.",
        dom: "Table 803.10.6 starting minimum for domestic oil and solid-fuel appliances: 18 inches to combustibles.",
        l: "Table 803.10.6 starting minimum for oil appliances labeled for Type L venting: 9 inches to combustibles.",
        low: "Table 803.10.6 starting minimum for commercial and industrial low-heat oil and solid-fuel: 18 inches to combustibles.",
        med: "Table 803.10.6 starting minimum for medium-heat oil and solid-fuel appliances: 36 inches to combustibles.",
        high: "High-heat appliances: Table 803.10.6 leaves clearance to the code official. Do not copy an 18-inch typical.",
        label: "If the appliance listing and labeling specify a different connector clearance, the labeled clearance governs — not the table row you hoped for."
      };
      if (!typ || !red) {
        title.textContent = "Pick the appliance type and whether a reduction is assumed.";
        body.textContent = "This is not a connector design.";
        return;
      }
      if (red === "sheet") {
        title.textContent = "Improvised sheet metal is not IMC 308.";
        body.innerHTML = (row[typ] || "") + " Clearance reductions are permitted only in accordance with IMC 308. A wrap in the field does not create a listed reduced-clearance assembly." + cta + ' · <a href="/clearance-reduction/">308</a>.';
      } else if (red === "unk") {
        title.textContent = "The miss is usually before the chimney, not at the appliance.";
        body.innerHTML = (row[typ] || "") + " Walk the full route: studs, joists, ceilings, finishes, casework, stored materials. A compliant appliance location does not make the connector route compliant." + cta;
      } else if (typ === "high") {
        title.textContent = "High-heat clearance is not a typical.";
        body.innerHTML = row.high + " Get the code-official determination on the set before the connector is run." + cta;
      } else if (red === "308") {
        title.textContent = "308 has to be the method — shown, not implied.";
        body.innerHTML = (row[typ] || "") + " Name the 308 reduction method and the remaining clearance along the whole route. Hidden framing behind finishes still counts." + cta + ' · <a href="/clearance-reduction/">308</a>.';
      } else {
        title.textContent = "Start with the table (or the label). Then walk the whole route.";
        body.innerHTML = (row[typ] || "") + " Do not assume 18 inches applies to every connector. Identify the classification first." + cta;
      }
      track("Field Tool Result", { tool: "imc-803-10-6", typ: typ, red: red });
    });
  }


  var vsize = $("vsize-form");
  if (vsize) {
    vsize.addEventListener("submit", function (e) {
      e.preventDefault();
      var show = ($("vsize-show") && $("vsize-show").value) || "";
      var eng = ($("vsize-eng") && $("vsize-eng").value) || "";
      var box = $("vsize-result"), title = $("vsize-result-title"), body = $("vsize-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the collar size and the liner size</a> · <a href="/minimum-vent-size/">Minimum vent size</a>.';
      if (!show || !eng) {
        title.textContent = "Pick what is on the set and whether a reduction has a basis.";
        body.textContent = "This is not a vent-size calculator.";
        return;
      }
      if (show === "miss") {
        title.textContent = "If the flue-collar size is missing, you cannot verify 801.6.";
        body.innerHTML = "List the appliance connection on the schedule, not only the vent size. The design is incomplete before you get to the vent detail." + cta;
      } else if (show === "mix") {
        title.textContent = "Three numbers that do not match is the comment.";
        body.innerHTML = "Schedule collar, connector, and chimney/liner in the detail have to be traceable to each other. Plan vs schedule mismatches are the usual flag." + cta;
      } else if (show === "dia") {
        title.textContent = "Treat this as an area calculation, not a diameter comparison.";
        body.innerHTML = "A round, oval, rectangular, or lined chimney has to be checked by equivalent area wherever the shape changes. A liner that looks about the same size as the collar can still fail 801.6." + cta;
      } else if (show === "exist") {
        title.textContent = "Existing liner size has to be field-verified — then compared by area.";
        body.innerHTML = "Do not assume an existing chimney liner is automatically large enough, or small enough. Pair this with the <a href=\"/field-tools/#exchim\">801.18 four gates</a>." + cta;
      } else if (show === "small" && eng === "none") {
        title.textContent = "Do not reduce below the connection with no reviewable basis.";
        body.innerHTML = "IMC 801.6: for a single appliance, minimum area equals the appliance connection unless Chapter 8 allows otherwise or an approved engineered system applies. Leaving it to the installer is the miss." + cta;
      } else if (eng === "ch8" || eng === "eng") {
        title.textContent = "Name the Chapter 8 exception or the engineered system on the sheet.";
        body.innerHTML = "An exception or engineered basis is allowed — it has to be reviewable. Do not imply it with a smaller pipe and no note." + cta;
      } else {
        title.textContent = "Collar, connector, and chimney/liner should be traceable by area.";
        body.innerHTML = "If they already match, keep field substitutions from shrinking the liner. Any later reduction still needs a Chapter 8 or engineered basis." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-6", show: show, eng: eng });
    });
  }


  var sflue = $("sflue-form");
  if (sflue) {
    sflue.addEventListener("submit", function (e) {
      e.preventDefault();
      var what = ($("sflue-what") && $("sflue-what").value) || "";
      var share = ($("sflue-share") && $("sflue-share").value) || "";
      var box = $("sflue-result"), title = $("sflue-result-title"), body = $("sflue-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send chimney photos and what else uses that flue</a> · <a href="/dedicated-solid-fuel-flue/">Dedicated solid-fuel flue</a>.';
      if (!what || !share) {
        title.textContent = "Pick what is being connected and what else uses that passageway.";
        body.textContent = "This is not a flue design.";
        return;
      }
      if (what === "gas") {
        title.textContent = "801.11 is the solid-fuel separation rule.";
        body.innerHTML = "Gas and oil common-venting still have their own limits — including <a href=\"/multistory-common-vent/\">no multistory common vent (801.19)</a>. Do not copy a solid-fuel dedicated-flue note onto a gas common vent without checking 801.19." + cta;
      } else if (share === "other") {
        title.textContent = "Do not connect solid-fuel to a flue that already serves another appliance.";
        body.innerHTML = "IMC 801.11: a solid-fuel-burning appliance or fireplace cannot connect to a chimney passageway that is already venting another appliance — fuel-fired or otherwise. Show a dedicated, code-compliant flue. Draft, temperature, soot/creosote, and cleaning needs are different." + cta;
      } else if (share === "look" || share === "unk") {
        title.textContent = "“It looks unused” is not a dedicated flue.";
        body.innerHTML = "On existing buildings, dedicated chimney is a claim that needs verification. Trace the full chimney, including historical tie-ins. A set that shows only the new connection, with no statement about what else uses that chimney, is incomplete. Close abandoned openings under <a href=\"/abandoned-vent-openings/\">801.8</a>." + cta;
      } else {
        title.textContent = "Dedicated path shown — still verify old tie-ins and 801.18.";
        body.innerHTML = "Coordinate liner, connector, cleanout, and termination for that dedicated path. Then run the <a href=\"/field-tools/#exchim\">four gates</a> if the chimney is existing." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-11", what: what, share: share });
    });
  }


  var clout = $("clout-form");
  if (clout) {
    clout.addEventListener("submit", function (e) {
      e.preventDefault();
      var ent = ($("clout-ent") && $("clout-ent").value) || "";
      var co = ($("clout-co") && $("clout-co").value) || "";
      var box = $("clout-result"), title = $("clout-result-title"), body = $("clout-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the chimney section or photos</a> · <a href="/chimney-cleanouts/">Chimney cleanouts</a>.';
      if (!ent || !co) {
        title.textContent = "Pick the entrance elevation and the cleanout condition.";
        body.textContent = "This is not a chimney design.";
        return;
      }
      if (ent === "note" || ent === "low") {
        title.textContent = "“Connect to existing chimney” is not an elevation.";
        body.innerHTML = "IMC 801.12: the connector enters the chimney flue at a point not less than 12 inches above the lowest portion of the interior of the flue — so it does not discharge into debris, condensate, ash, or soot at the bottom. Show the entrance height on the detail." + cta;
      } else if (co === "hide" || co === "none") {
        title.textContent = "A cleanout behind the new casework is not a cleanout.";
        body.innerHTML = "IMC 801.13: masonry chimney flues need a cleanout opening with a minimum height of 6 inches, the upper edge at least 6 inches below the lowest chimney inlet opening, and a tight-fitting noncombustible cover. Access has to survive finishes, equipment, and casework." + cta;
      } else if (co === "fp") {
        title.textContent = "The fireplace-opening exception is real — only if that opening actually gives access.";
        body.innerHTML = "A cleanout is not required for chimney flues serving masonry fireplaces when access is provided through the fireplace opening. Do not claim the exception if the opening will be blocked by glass doors, a gas log set, or finishes that prevent cleaning." + cta;
      } else {
        title.textContent = "Connector inlet above, cleanout below, both accessible — keep it that way.";
        body.innerHTML = "The vertical relationship is the review. Pair this with the <a href=\"/field-tools/#exchim\">801.18 four gates</a> on existing chimneys." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-12-13", ent: ent, co: co });
    });
  }


  var fpflue = $("fpflue-form");
  if (fpflue) {
    fpflue.addEventListener("submit", function (e) {
      e.preventDefault();
      var typ = ($("fpflue-type") && $("fpflue-type").value) || "";
      var list = ($("fpflue-list") && $("fpflue-list").value) || "";
      var acc = ($("fpflue-acc") && $("fpflue-acc").value) || "";
      var box = $("fpflue-result"), title = $("fpflue-result-title"), body = $("fpflue-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the flue type and the appliance cut sheet</a> · <a href="/fireplace-flue-connection/">Fireplace flue connection</a>.';
      if (!typ || !list || !acc) {
        title.textContent = "Pick flue type, listing, and whether access survives the finish.";
        body.textContent = "This is not a fireplace design.";
        return;
      }
      if (typ === "unk") {
        title.textContent = "Identify factory-built vs masonry before you draw the connector.";
        body.innerHTML = "IMC 801.10 treats them as different paths. They are not interchangeable." + cta;
      } else if (list === "no" || list === "unk") {
        title.textContent = "A general appliance listing often does not cover a fireplace-flue connection.";
        body.innerHTML = (typ === "fb"
          ? "801.10.2: the appliance must be specifically listed for connection to a factory-built fireplace flue, installed per the manufacturer."
          : "On masonry, still confirm the appliance and the connector path. Escalate existing masonry fireplace flues without a documented condition assessment.") + cta;
      } else if (acc === "trim" || acc === "none") {
        title.textContent = "The seal can be on the detail and the access still die behind the surround.";
        body.innerHTML = "801.10.1: noncombustible seal below the connection so room air stays out of the flue, plus permanent access for inspection and cleaning. 801.10.3 (masonry): connector and flue accessible or removable for cleaning. Glass doors, casework, and gas-log sets are the usual miss." + cta;
      } else {
        title.textContent = "Both gates have evidence — listing and access. Keep them.";
        body.innerHTML = "Show the seal, the discharge into the flue, and access that survives finishes. Pair with <a href=\"/field-tools/#sflue\">801.11</a> if this is solid-fuel, and <a href=\"/field-tools/#clout\">801.12–801.13</a> for entrance and cleanout." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-10", typ: typ, list: list, acc: acc });
    });
  }


  var cgeom = $("cgeom-form");
  if (cgeom) {
    cgeom.addEventListener("submit", function (e) {
      e.preventDefault();
      var sup = ($("cgeom-sup") && $("cgeom-sup").value) || "";
      var len = ($("cgeom-len") && $("cgeom-len").value) || "";
      var ent = ($("cgeom-ent") && $("cgeom-ent").value) || "";
      var box = $("cgeom-result"), title = $("cgeom-result-title"), body = $("cgeom-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the connector section</a> · <a href="/connector-geometry/">Connector geometry</a>.';
      if (!sup || !len || !ent) {
        title.textContent = "Pick support, length, and entry/pitch.";
        body.textContent = "This is not a connector design.";
        return;
      }
      if (sup === "collar") {
        title.textContent = "The appliance collar is not the hanger.";
        body.innerHTML = "IMC 803.10.1: connectors are adequately supported, with joints secured by sheet metal screws, rivets, or other approved means. Poor support allows sagging, joint separation, lost slope, and misalignment." + cta;
      } else if (len === "long") {
        title.textContent = "Put the chimney height on the same sheet as the run.";
        body.innerHTML = "IMC 803.10.2: maximum horizontal length of a single-wall connector is 75% of the chimney or vent height. Daily Code Talk example: a 20-foot-high chimney allows a maximum 15-foot horizontal single-wall connector. Long runs increase resistance and can reduce draft." + cta;
      } else if (ent === "poke") {
        title.textContent = "Do not poke the connector into the flue, and do not run it flat.";
        body.innerHTML = "803.10.3: extend to the inner face of the liner, not beyond it — projecting restricts flow and collects deposits. Masonry: cement the connector (and permanently cement removable thimbles with high-temperature cement). 803.10.5: at least 1/4 inch per foot (2%), rising continuously toward the chimney." + cta;
      } else if (ent === "unk" || sup === "unk") {
        title.textContent = "Trace the connector in section. Four checks, together.";
        body.innerHTML = "Support, horizontal length vs height, liner connection at the inner face, and continuous upward pitch. If any one is missing at a transition, the installation is not fully reviewable." + cta;
      } else {
        title.textContent = "Four checks have evidence. Keep field changes from undoing them.";
        body.innerHTML = "Independent support, 75% length with height on the sheet, inner-face entry, 1/4 in per ft uphill. Also <a href=\"/connector-pass-through/\">803.10.4 pass-through</a> and <a href=\"/connector-clearance/\">803.10.6 clearance</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-803-10-geom", sup: sup, len: len, ent: ent });
    });
  }


  var annular = $("annular-form");
  if (annular) {
    annular.addEventListener("submit", function (e) {
      e.preventDefault();
      var how = ($("annular-how") && $("annular-how").value) || "";
      var sec = ($("annular-sec") && $("annular-sec").value) || "";
      var box = $("annular-result"), title = $("annular-result-title"), body = $("annular-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the chimney interior photos</a> · <a href="/chimney-annular-space/">Annular space</a>.';
      if (!how || !sec) {
        title.textContent = "Pick how the second appliance is assigned and whether the interior is surveyed.";
        body.textContent = "This is not a liner design.";
        return;
      }
      if (how === "void") {
        title.textContent = "Leftover chimney space is not a second flue.";
        body.innerHTML = "IMC 801.17 prohibits using the space surrounding a flue lining system or other vent installed inside a masonry chimney to vent another appliance. Specify a separate listed liner, installed per its manufacturer — not the leftover void." + cta;
      } else if (how === "unk" || sec === "no") {
        title.textContent = "Shade every approved liner. Anything unshaded is not a vent.";
        body.innerHTML = "Trace each appliance: connector → liner or vent → chimney route → termination, without entering an undefined void. Multiple connectors into an existing chimney without identified liner paths is incomplete. Pair with <a href=\"/masonry-flue-lining/\">801.15–801.16</a>." + cta;
      } else if (how === "two") {
        title.textContent = "A second listed liner still has to match the appliance.";
        body.innerHTML = "Adding a separate liner does not, by itself, resolve sizing, listing, draft, condensate, clearance, or termination. Confirm installation instructions, cleanout, and inspection access before the layout is accepted." + cta;
      } else {
        title.textContent = "One appliance, one approved path — keep it that way.";
        body.innerHTML = "If a second appliance is added later, it needs its own approved liner. Do not assign it to the annular space around this one." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-17", how: how, sec: sec });
    });
  }


  var sfsize = $("sfsize-form");
  if (sfsize) {
    sfsize.addEventListener("submit", function (e) {
      e.preventDefault();
      var what = ($("sfsize-what") && $("sfsize-what").value) || "";
      var ratio = ($("sfsize-ratio") && $("sfsize-ratio").value) || "";
      var box = $("sfsize-result"), title = $("sfsize-result-title"), body = $("sfsize-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the collar size and the chimney size</a> · <a href="/solid-fuel-flue-size/">Solid-fuel flue size</a>.';
      if (!what || !ratio) {
        title.textContent = "Pick the appliance type and whether both areas are shown.";
        body.textContent = "This is not a flue-size calculator.";
        return;
      }
      if (what === "gas") {
        title.textContent = "801.7 is the solid-fuel oversize cap.";
        body.innerHTML = "Gas and oil still have <a href=\"/minimum-vent-size/\">801.6 minimum area</a>. Do not apply the 3:1 solid-fuel cap as a gas common-vent rule." + cta;
      } else if (ratio === "over") {
        title.textContent = "A larger chimney is not automatically better.";
        body.innerHTML = "IMC 801.7: a flue serving a solid-fuel-burning appliance cannot have a cross-sectional area greater than three times the area of the appliance flue collar or outlet. An oversized flue cools combustion products too fast — creosote and draft problems, not a conservative safety margin. Treat 3:1 as a hard upper limit." + cta;
      } else if (ratio === "dia") {
        title.textContent = "This is an area comparison, not a diameter comparison.";
        body.innerHTML = "Round flues, rectangular masonry flues, and lined chimneys all need to be checked by area wherever the geometry differs from the appliance outlet." + cta;
      } else if (ratio === "miss") {
        title.textContent = "Show both areas. Especially on existing masonry.";
        body.innerHTML = "The recurring miss is a new, smaller solid-fuel appliance on an existing masonry flue sized for a larger original unit, without checking whether the area ratio now exceeds 3:1. Field-verify the as-built flue size." + cta;
      } else {
        title.textContent = "3:1 has evidence. Keep field substitutions from opening it up.";
        body.innerHTML = "Also run <a href=\"/field-tools/#sflue\">801.11 dedicated flue</a> and <a href=\"/field-tools/#vsize\">801.6 minimum area</a>. Oversizing and undersizing are different comments." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-7", what: what, ratio: ratio });
    });
  }


  var exin = $("exin-form");
  if (exin) {
    exin.addEventListener("submit", function (e) {
      e.preventDefault();
      var side = ($("exin-side") && $("exin-side").value) || "";
      var pos = ($("exin-pos") && $("exin-pos").value) || "";
      var box = $("exin-result"), title = $("exin-result-title"), body = $("exin-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the exhauster cut sheet and which side the appliance connects</a> · <a href="/exhauster-connection/">Exhauster connection</a>.';
      if (!side || !pos) {
        title.textContent = "Pick the connection side and whether the discharge is listed for positive pressure.";
        body.textContent = "This is not an exhauster selection.";
        return;
      }
      if (side === "out") {
        title.textContent = "Do not connect the appliance on the discharge side.";
        body.innerHTML = "IMC 801.14: appliance connections to a chimney or vent equipped with a power exhauster are made on the inlet side. A natural-draft appliance downstream of a mechanical flue exhauster is an escalate." + cta;
      } else if (side === "unk") {
        title.textContent = "A fan symbol is not a pressure boundary.";
        body.innerHTML = "Draw the flow arrow. Label inlet and discharge. A reviewer should trace appliance → exhauster inlet → discharge → listed positive-pressure assembly → termination in one pass. Field selection is not a substitute." + cta;
      } else if (pos === "std" || pos === "unk") {
        title.textContent = "Standard vent joints are not automatically positive-pressure joints.";
        body.innerHTML = "Joints and piping on the positive-pressure side must be listed for positive-pressure applications as specified by the exhauster manufacturer. Pair with <a href=\"/positive-pressure-vent/\">801.9</a> and <a href=\"/mechanical-draft/\">804.3 interlocks</a>." + cta;
      } else {
        title.textContent = "Inlet side and listed discharge — keep the sequence and the listing together.";
        body.innerHTML = "Coordinate access, supports, penetrations, termination, and required controls before permit issue. Also <a href=\"/power-exhauster-termination/\">804.3.3–804.3.4</a> and <a href=\"/mechanical-draft-vertical/\">804.3.5</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-14", side: side, pos: pos });
    });
  }


  var exsize = $("exsize-form");
  if (exsize) {
    exsize.addEventListener("submit", function (e) {
      e.preventDefault();
      var nd = ($("exsize-nd") && $("exsize-nd").value) || "";
      var meth = ($("exsize-meth") && $("exsize-meth").value) || "";
      var box = $("exsize-result"), title = $("exsize-result-title"), body = $("exsize-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the appliance list and the exhauster cut sheet</a> · <a href="/exhauster-sizing/">Exhauster sizing</a>.';
      if (!nd || !meth) {
        title.textContent = "Pick whether any natural-draft appliance is on this vent, and how the fan was sized.";
        body.textContent = "This is not a fan selection.";
        return;
      }
      if (nd === "out") {
        title.textContent = "A natural-draft appliance does not belong on the discharge side.";
        body.innerHTML = "IMC 804.3.6 prohibits a natural-draft appliance connection to a vent, chimney, or connector on the discharge side of a mechanical flue exhauster. Pressure on that side is not what the appliance was designed to handle. Pair with <a href=\"/exhauster-connection/\">801.14 inlet side</a>." + cta;
      } else if (meth === "cfm" || meth === "field") {
        title.textContent = "Nominal CFM is not the manufacturer’s method.";
        body.innerHTML = "IMC 804.3.7: size the exhauster and the vent it serves from the manufacturer’s installation instructions — appliance input, vent diameter, equivalent length, fittings, resistance, draft need, connected appliances, and operating point. Do not defer final sizing to field selection." + cta;
      } else if (nd === "unk") {
        title.textContent = "Mark inlet and discharge, then highlighter-trace every appliance.";
        body.innerHTML = "Start with the appliance list and draft type. If the side is not labeled, 804.3.6 cannot be reviewed. Also ask <a href=\"/positive-flow/\">801.4–801.5 what creates the draft</a>." + cta;
      } else {
        title.textContent = "Configuration and method have evidence. Keep the record together.";
        body.innerHTML = "Retain the manufacturer sizing sheet for review and field verification. Coordinate power and interlocks under <a href=\"/mechanical-draft/\">804.3</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-804-3-6-7", nd: nd, meth: meth });
    });
  }


  var oil31 = $("oil31-form");
  if (oil31) {
    oil31.addEventListener("submit", function (e) {
      e.preventDefault();
      var fuel = ($("oil31-fuel") && $("oil31-fuel").value) || "";
      var nfpa = ($("oil31-nfpa") && $("oil31-nfpa").value) || "";
      var box = $("oil31-result"), title = $("oil31-result-title"), body = $("oil31-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the fuel type and the appliance cut sheet</a> · <a href="/oil-fired-venting/">Oil-fired venting</a>.';
      if (!fuel || !nfpa) {
        title.textContent = "Pick the fuel and whether NFPA 31 is named.";
        body.textContent = "This is not a chimney selection.";
        return;
      }
      if (fuel === "hood") {
        title.textContent = "A Type I hood is IMC 507 — not appliance venting under 801.";
        body.innerHTML = "Commercial cooking appliances under a Type I hood are reviewed under IMC 507. Do not substitute hood exhaust for 801 venting, and do not skip 801 for a fuel-fired appliance that is not under that hood. <a href=\"/commercial-kitchen-ventilation/\">Kitchen ventilation</a>." + cta;
      } else if (fuel === "oil" && (nfpa === "imc" || nfpa === "na")) {
        title.textContent = "An IMC 801 note without NFPA 31 is a technical gap on oil.";
        body.innerHTML = "IMC 801.2.1: oil-fired appliances also coordinate with NFPA 31 — chimney sizing, draft, combustion temperature, liner compatibility, and blocked-vent protection. A generic “per code” note is not sufficient. Put a venting column on the appliance schedule: fuel, method, material, governing standard." + cta;
      } else if (fuel === "804") {
        title.textContent = "804 is the exception path — still name the method.";
        body.innerHTML = "Direct-vent, integral-vent, or mechanical draft still has to be listed and shown. See <a href=\"/direct-vent/\">804.1</a> and <a href=\"/mechanical-draft/\">804.3</a>." + cta;
      } else if (fuel === "oil") {
        title.textContent = "NFPA 31 is named. Keep chimney condition and liner with it.";
        body.innerHTML = "Escalate oil-fired appliances on existing chimneys without a documented condition and liner assessment. Pair with <a href=\"/existing-chimneys/\">801.18</a> and <a href=\"/masonry-flue-lining/\">801.15–801.16</a>." + cta;
      } else {
        title.textContent = "Match the venting method to the appliance listing — not the nearby chimney.";
        body.innerHTML = "IMC 801.2: discharge to a vent, factory-built chimney, or masonry chimney unless 804 applies. The listing names the category. Add a venting column to the schedule so it cannot stay blank." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-2", fuel: fuel, nfpa: nfpa });
    });
  }


  var vcode = $("vcode-form");
  if (vcode) {
    vcode.addEventListener("submit", function (e) {
      e.preventDefault();
      var fuel = ($("vcode-fuel") && $("vcode-fuel").value) || "";
      var cite = ($("vcode-cite") && $("vcode-cite").value) || "";
      var box = $("vcode-result"), title = $("vcode-result-title"), body = $("vcode-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send the appliance schedule and the vent notes</a> · <a href="/venting-scope/">Venting scope</a>.';
      if (!fuel || !cite) {
        title.textContent = "Pick the fuel and which code is cited.";
        body.textContent = "This is not a vent selection.";
        return;
      }
      if (cite === "blank") {
        title.textContent = "If fuel, method, and governing standard are blank, the design is incomplete.";
        body.innerHTML = "IMC 801.1 is a plan-review boundary. Open the appliance schedule before the vent detail. Chimney, vent, connector, and liner are not interchangeable terms." + cta;
      } else if (fuel === "gas" && cite === "imc") {
        title.textContent = "A perfectly drawn IMC 801 detail is still wrong if the fuel is gas.";
        body.innerHTML = "801.1: gas-fired appliances vent under the International Fuel Gas Code (IFGC), not directly through Chapter 8. Check <a href=\"/direct-vent/\">Section 804</a> before assuming a direct-vent or mechanical-draft unit falls outside Chapter 8." + cta;
      } else if (fuel === "oil" && cite !== "nfpa") {
        title.textContent = "Oil still needs NFPA 31 — IMC 801 alone is not the oil path.";
        body.innerHTML = "See <a href=\"/oil-fired-venting/\">801.2.1</a>. Chimney sizing, draft, liner compatibility, and blocked-vent protection for oil equipment specifically." + cta;
      } else if (fuel === "mix") {
        title.textContent = "Mixed-fuel rooms are an escalate.";
        body.innerHTML = "Gas and oil sharing a space, listings that do not name a venting category, and conversions from gas to oil or solid fuel. Each appliance gets its own governing standard on the schedule." + cta;
      } else {
        title.textContent = "Fuel and cited standard match. Keep the terms honest.";
        body.innerHTML = "Do not label a connector a chimney. Check 804 before running a direct-vent appliance through the full prescriptive Chapter 8 path. Masonry chimneys also need <a href=\"/masonry-chimney-ibc/\">801.3 IBC coordination</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-1", fuel: fuel, cite: cite });
    });
  }


  var fluepass = $("fluepass-form");
  if (fluepass) {
    fluepass.addEventListener("submit", function (e) {
      e.preventDefault();
      var ev = ($("fluepass-ev") && $("fluepass-ev").value) || "";
      var fuel = ($("fluepass-fuel") && $("fluepass-fuel").value) || "";
      var box = $("fluepass-result"), title = $("fluepass-result-title"), body = $("fluepass-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send interior photos and prior fuel if known</a> · <a href="/flue-passageway/">Flue passageway</a>.';
      if (!ev || !fuel) {
        title.textContent = "Pick the evidence and the fuel history.";
        body.textContent = "This is not a chimney inspection.";
        return;
      }
      if (ev === "sweep") {
        title.textContent = "Cleaning is not proof the liner is continuous and sound.";
        body.innerHTML = "IMC 801.18.2: free of obstructions and combustible deposits, AND the liner or inner wall continuous — no cracks, gaps, perforations, or deterioration that would let gases, moisture, or creosote escape. A sweeping invoice is not reuse acceptance." + cta;
      } else if (ev === "ext" || ev === "none") {
        title.textContent = "Do not accept a chimney from the room or roof alone.";
        body.innerHTML = "Evaluate the full path from each connector inlet to the termination. Map defects. Then repair, reline, replace, or reject — before connecting the new appliance. Pair with <a href=\"/existing-chimneys/\">801.18 four gates</a>." + cta;
      } else if (fuel === "oil") {
        title.textContent = "Oil on existing masonry also needs an NFPA 31 repair or relining basis.";
        body.innerHTML = "801.18.2: where an oil-fired appliance connects to an existing masonry chimney, the chimney flue must be repaired or relined in accordance with NFPA 31. See <a href=\"/oil-fired-venting/\">801.2.1</a>." + cta;
      } else if (fuel === "unk" || fuel === "sf") {
        title.textContent = "Prior solid- or liquid-fuel, or a fireplace, triggers cleaning — then continuity still has to be shown.";
        body.innerHTML = "Unknown prior fuel is an escalate. Cleaning and continuity remain separate questions. Also trace clearance under <a href=\"/existing-chimney-clearance/\">801.18.4</a> — a liner does not automatically fix the framing around it." + cta;
      } else {
        title.textContent = "Full-length evidence exists. Keep clearance as a second question.";
        body.innerHTML = "Passageway condition is not surrounding construction. Relining does not automatically resolve clearance or fireblocking. <a href=\"/existing-chimney-clearance/\">801.18.4</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-18-2", ev: ev, fuel: fuel });
    });
  }


  var exsize18 = $("exsize18-form");
  if (exsize18) {
    exsize18.addEventListener("submit", function (e) {
      e.preventDefault();
      var chg = ($("exsize18-chg") && $("exsize18-chg").value) || "";
      var ev = ($("exsize18-ev") && $("exsize18-ev").value) || "";
      var box = $("exsize18-result"), title = $("exsize18-result-title"), body = $("exsize18-result-body");
      show(box);
      var cta = ' <a href="' + contact("combustion") + '">Send remaining load and chimney inside size</a> · <a href="/existing-vent-size/">Existing vent size</a>.';
      if (!chg || !ev) {
        title.textContent = "Pick what changed and whether draft and condensation were both evaluated.";
        body.textContent = "This is not a size calculator.";
        return;
      }
      if (chg === "rm" && ev !== "both") {
        title.textContent = "Re-evaluate the remaining common vent when an appliance is removed.";
        body.innerHTML = "IMC 801.18.1: resize as necessary to control flue-gas condensation and provide the required draft. Leaving the smaller load on the original flue without that evaluation is the usual condensation miss — gases cool, masonry and liner deteriorate, draft becomes unreliable." + cta;
      } else if (ev === "none" || ev === "one" || chg === "unk") {
        title.textContent = "Passing draft is not enough. Passing size is not enough.";
        body.innerHTML = "Put two columns beside the appliance schedule: existing vent condition and required vent condition. Compare dimensions, effective height, connected input, sizing basis, draft result, condensation result, and final action. Oil-fired masonry: NFPA 31. Do not leave final size to the installer." + cta;
      } else if (chg === "add") {
        title.textContent = "Added load or a condensing replacement is an escalate until the method is shown.";
        body.innerHTML = "Do not treat higher-efficiency equipment as automatically incompatible without the applicable evaluation — and do not assume the old size still works. Fuel conversion and exterior masonry chimneys belong in that same stack. Pair with <a href=\"/flue-passageway/\">801.18.2</a>." + cta;
      } else {
        title.textContent = "Existing vs required size has evidence. Keep the cleanout and clearance as separate lines.";
        body.innerHTML = "Also <a href=\"/existing-chimney-cleanout/\">801.18.3 reuse cleanout</a> and <a href=\"/existing-chimney-clearance/\">801.18.4 clearance</a>. Size is not the whole reuse decision." + cta;
      }
      track("Field Tool Result", { tool: "imc-801-18-1", chg: chg, ev: ev });
    });
  }


  var rgd = $("rgd-form");
  if (rgd) {
    rgd.addEventListener("submit", function (e) {
      e.preventDefault();
      var bal = ($("rgd-bal") && $("rgd-bal").value) || "";
      var loc = ($("rgd-loc") && $("rgd-loc").value) || "";
      var box = $("rgd-result"), title = $("rgd-result-title"), body = $("rgd-result-body");
      show(box);
      var cta = ' <a href="' + contact("hvac") + '">Send the air-device layout</a> · <a href="/registers-grilles/">Registers and grilles</a>.';
      if (!bal || !loc) {
        title.textContent = "Pick balancing access and whether any floor devices sit in a wet room.";
        body.textContent = "This is not a device schedule.";
        return;
      }
      if (loc === "wet") {
        title.textContent = "Floor devices are prohibited in those IBC wet-room floors.";
        body.innerHTML = "IMC 603.18.2: registers, grilles, and diffusers are prohibited in the floor, or the upward extension of the floor, within toilet and bathing rooms that must have smooth, hard, nonabsorbent surfaces under the IBC. Exception: dwelling units. Move it to the wall or ceiling before finishes lock." + cta;
      } else if (bal === "none") {
        title.textContent = "A supply with no accessible balancing means will fail late.";
        body.innerHTML = "603.18: supply-air adjustment in the branch duct or at each individual register, grille, or diffuser. Any balancing device used for that adjustment must have access. Pair with <a href=\"/air-balancing/\">608</a>." + cta;
      } else if (loc === "fl") {
        title.textContent = "Show the 200-pound floor-register load.";
        body.innerHTML = "603.18.1: floor registers must resist a 200-pound concentrated load on a 2-inch-diameter disc without structural failure. Call it on M-501, not as a finish note." + cta;
      } else {
        title.textContent = "Balancing access and location have evidence. Keep air dispersion as a different product.";
        body.innerHTML = "If anyone called it “fabric duct,” see <a href=\"/air-dispersion/\">603.17</a> — exposed, positive-pressure, UL 2518, no rated penetrations." + cta;
      }
      track("Field Tool Result", { tool: "imc-603-18", bal: bal, loc: loc });
    });
  }


  var vapor = $("vapor-form");
  if (vapor) {
    vapor.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("vapor-loc") && $("vapor-loc").value) || "";
      var vr = ($("vapor-vr") && $("vapor-vr").value) || "";
      var box = $("vapor-result"), title = $("vapor-result-title"), body = $("vapor-result-body");
      show(box);
      var cta = ' <a href="' + contact("hvac") + '">Send the insulation product and a roof photo</a> · <a href="/vapor-retarder/">Vapor retarder</a>.';
      if (!loc || !vr) {
        title.textContent = "Pick where the cooling duct is insulated and what vapor / weather evidence exists.";
        body.textContent = "This is not an insulation specification.";
        return;
      }
      if (vr === "open" || vr === "r") {
        title.textContent = "R-value on paper is not a vapor retarder.";
        body.innerHTML = "IMC 604.11: cooling ducts with external insulation — vapor retarder 0.05 perm maximum, or aluminum foil at least 2 mils thick, joints and seams sealed. 604.12: insulated exterior ducts also need an approved weatherproof barrier. One does not replace the other. Exterior wrap is not automatically a complete vapor-retarder system." + cta;
      } else if (loc === "spf") {
        title.textContent = "Spray foam has its own permeance exception — at the installed thickness.";
        body.innerHTML = "A separate vapor retarder is not required for spray polyurethane foam if water-vapor permeance is not greater than 3 perms per inch at the installed thickness. Exterior foam still needs weather protection under 604.12." + cta;
      } else {
        title.textContent = "Permeance and weather have evidence. Keep coil-discharge liner as a different 24-inch rule.";
        body.innerHTML = "See <a href=\"/coil-discharge-liner/\">604.13</a> for the no-water-permeable-liner zone at cooling-coil discharge." + cta;
      }
      track("Field Tool Result", { tool: "imc-604-11-12", loc: loc, vr: vr });
    });
  }


  var roofacc = $("roofacc-form");
  if (roofacc) {
    roofacc.addEventListener("submit", function (e) {
      e.preventDefault();
      var h = ($("roofacc-h") && $("roofacc-h").value) || "";
      var acc = ($("roofacc-acc") && $("roofacc-acc").value) || "";
      var box = $("roofacc-result"), title = $("roofacc-result-title"), body = $("roofacc-result-body");
      show(box);
      var cta = ' <a href="' + contact("hvac") + '">Send roof height and the unit location</a> · <a href="/roof-equipment-access/">Roof equipment access</a>.';
      if (!h || !acc) {
        title.textContent = "Pick height above grade and what access is shown.";
        body.textContent = "This is not a ladder design.";
        return;
      }
      if (h === "high" && acc !== "fixed") {
        title.textContent = "A portable ladder is not 306.5 access.";
        body.innerHTML = "IMC 306.5: if reaching the unit means climbing higher than 16 feet above grade, provide a fixed interior or exterior access. No portable ladders. Route cannot require going over obstructions taller than 30 inches or walking on roofs steeper than 4:12. Show it on the permit set — not only in the specifications. 306.5.2: receptacle at or near the equipment per NFPA 70." + cta;
      } else if (h === "unk") {
        title.textContent = "If height is not documented, 306.5 cannot be reviewed.";
        body.innerHTML = "Identify every piece of mechanical equipment more than 16 feet above grade. Tag it to the access detail. Attachment points on or referenced from structural." + cta;
      } else if (h === "low") {
        title.textContent = "16 ft or less, or Group R-3, is outside the 306.5 trigger — service space still applies.";
        body.innerHTML = "See <a href=\"/equipment-access/\">306.1–306.4</a> for working clearances at the unit itself." + cta;
      } else {
        title.textContent = "Fixed access and a receptacle have evidence. Keep the dimensions on M-501.";
        body.innerHTML = "Rails 42 in above the roof/hatch; rungs 10–14 in on center; top rung not more than 24 in below; 30×30 bottom landing; 30 in deep top landing; 3:12+ roofs get a 30 in platform with 42 in guards. Those figures are the supplied 306.5 content — confirm the adopted edition." + cta;
      }
      track("Field Tool Result", { tool: "imc-306-5", h: h, acc: acc });
    });
  }


  var exitvent = $("exitvent-form");
  if (exitvent) {
    exitvent.addEventListener("submit", function (e) {
      e.preventDefault();
      var sys = ($("exitvent-sys") && $("exitvent-sys").value) || "";
      var path = ($("exitvent-path") && $("exitvent-path").value) || "";
      var box = $("exitvent-result"), title = $("exitvent-result-title"), body = $("exitvent-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the life-safety plan and the stair fan</a> · <a href="/exit-enclosure-ventilation/">Exit enclosure ventilation</a>.';
      if (!sys || !path) {
        title.textContent = "Pick what serves the enclosure and which 601.3 item is named.";
        body.textContent = "This is not a stair-pressurization design.";
        return;
      }
      if (sys === "gen") {
        title.textContent = "A stair fan is not a toilet-exhaust tap.";
        body.innerHTML = "IMC 601.3: exit-enclosure ventilation systems must be independent of other building ventilation systems. Tying the stair into general HVAC, toilet exhaust, or a rooftop unit that also serves the corridor is the usual redline." + cta;
      } else if (path === "none" || sys === "unk") {
        title.textContent = "If the drawings cannot name which of the three items is used, 601.3 has not been designed.";
        body.innerHTML = "Item 1: equipment outside, shaft-enclosed connection. Item 2: equipment in the enclosure with outdoor intake and discharge. Item 3: equipment in the building, separated as required by the IBC for shafts. Make intake and discharge routing to outdoors explicit. Limit openings and protect them with self-closing fire-resistance-rated devices." + cta;
      } else {
        title.textContent = "A 601.3 path is named. Keep dampers at the enclosure as a second question.";
        body.innerHTML = "Coordinate shaft ratings and opening protection with architectural life-safety. Penetrations of fire partitions at the stair still go through <a href=\"/fire-partition-dampers/\">607.5.3</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-601-3", sys: sys, path: path });
    });
  }


  var fpdamp = $("fpdamp-form");
  if (fpdamp) {
    fpdamp.addEventListener("submit", function (e) {
      e.preventDefault();
      var why = ($("fpdamp-why") && $("fpdamp-why").value) || "";
      var h = ($("fpdamp-h") && $("fpdamp-h").value) || "";
      var box = $("fpdamp-result"), title = $("fpdamp-result-title"), body = $("fpdamp-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the rated plan and the duct at that wall</a> · <a href="/fire-partition-dampers/">Fire-partition dampers</a>.';
      if (!why || !h) {
        title.textContent = "Pick why the damper is missing and whether Group H or a wall register is in play.";
        body.textContent = "This is not a damper schedule.";
        return;
      }
      if (why === "spr") {
        title.textContent = "“The building is sprinklered” is not 607.5.3.";
        body.innerHTML = "Ducts and transfer openings that penetrate fire partitions generally require listed fire dampers. Exceptions 1 and 4 need full sprinkler coverage <em>and</em> the rest of their conditions. Name which exception — or show the damper." + cta;
      } else if (h === "h") {
        title.textContent = "Group H, a wall register, or a corridor opening kills the easy exceptions.";
        body.innerHTML = "Exception 3: all seven conditions at once — area not more than 100 square inches, minimum steel thickness, no corridor-to-room openings, above ceiling, no wall-register termination, steel sleeve and retaining angles, mineral wool at the annular space. Missing even one disqualifies it. Group H corridors: escalate; the exceptions do not apply there." + cta;
      } else if (why === "ex3") {
        title.textContent = "Show all seven Exception 3 conditions — not just 100 square inches.";
        body.innerHTML = "A duct that meets the area limit but terminates with a wall register, or has a corridor opening, is out. Run a checklist against each small-duct exception claim." + cta;
      } else if (why === "fd") {
        title.textContent = "A listed fire damper is shown. Keep the assembly name honest.";
        body.innerHTML = "Confirm the wall is a fire partition on the architectural life-safety plan. Fire walls, fire barriers, shafts, and smoke barriers are different 607 paths — start at <a href=\"/fire-smoke-dampers/\">name the assembly</a>." + cta;
      } else {
        title.textContent = "A named exception has evidence. Keep gage, occupancy, and sprinklers on M-001.";
        body.innerHTML = "Exception 4 still needs minimum 26 gage sheet steel and a continuous ducted system from equipment to air terminals, in a non-Group H area, through a fire partition rated 1 hour or less, in a fully sprinklered building." + cta;
      }
      track("Field Tool Result", { tool: "imc-607-5-3", why: why, h: h });
    });
  }


  var shaftd = $("shaftd-form");
  if (shaftd) {
    shaftd.addEventListener("submit", function (e) {
      e.preventDefault();
      var typ = ($("shaftd-type") && $("shaftd-type").value) || "";
      var d = ($("shaftd-d") && $("shaftd-d").value) || "";
      var box = $("shaftd-result"), title = $("shaftd-result-title"), body = $("shaftd-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the shaft type and the damper schedule</a> · <a href="/shaft-dampers/">Shaft dampers</a>.';
      if (!typ || !d) {
        title.textContent = "Pick what the shaft carries and what is shown at the opening.";
        body.textContent = "This is not a shaft design.";
        return;
      }
      if ((typ === "grease" || typ === "dryer") && d === "fd") {
        title.textContent = "A fire damper in a grease or dryer shaft is prohibited — not conservative.";
        body.innerHTML = "IMC 607.5.5: fire dampers and combination fire/smoke dampers are specifically prohibited in kitchen and dryer exhaust systems where dampers are prohibited by code. A damper in a grease shaft is a grease accumulation point. The question is the required alternative protection, not which damper type. See <a href=\"/commercial-kitchen-ventilation/\">Type I</a> and <a href=\"/dryer-exhaust/\">504</a>." + cta;
      } else if (typ === "unk" || d === "none") {
        title.textContent = "If you cannot name the shaft type from the drawings, the damper cannot be verified.";
        body.innerHTML = "Label supply, exhaust, smoke control, garage, or prohibited-damper system on M-101. Ducts through shaft enclosures generally need listed fire and smoke dampers unless a named exception is shown. Partial-height shafts still need bottom protection per IBC 713.11." + cta;
      } else if (d === "sub") {
        title.textContent = "Subduct height and continuous upward exhaust both have to be on the set.";
        body.innerHTML = "The supplied 607.5.5 content: steel exhaust subduct extending at least 22 inches vertically <em>and</em> a continuously powered fan maintaining upward exhaust. Both at once. 607.5.5.1: do not install FD/SD where closure would stop required continuous upward airflow." + cta;
      } else {
        title.textContent = "Shaft type and protection have evidence. Keep corridor SD/CD/CRD as a different wall.";
        body.innerHTML = "Smoke partitions still need listed smoke dampers under 607.5.7 unless an SD would interfere with required smoke control — then approved alternative protection, not an unprotected opening. Corridors: <a href=\"/corridor-smoke-dampers/\">607.5.4</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-607-5-5", typ: typ, d: d });
    });
  }


  var crdmode = $("crdmode-form");
  if (crdmode) {
    crdmode.addEventListener("submit", function (e) {
      e.preventDefault();
      var fan = ($("crdmode-fan") && $("crdmode-fan").value) || "";
      var d = ($("crdmode-d") && $("crdmode-d").value) || "";
      var box = $("crdmode-result"), title = $("crdmode-result-title"), body = $("crdmode-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the fan sequence and the penetration</a> · <a href="/horizontal-assembly-dampers/">Horizontal assemblies</a>.';
      if (!fan || !d) {
        title.textContent = "Pick whether the system runs during a fire and what is shown at the opening.";
        body.textContent = "This is not a damper schedule.";
        return;
      }
      if (fan === "yes" && d === "stat") {
        title.textContent = "A static CRD is not listed for a system that runs during a fire.";
        body.innerHTML = "IMC 607.6.2.1: a CRD in a system designed to operate during a fire must be listed for dynamic systems — rated for airflow and pressure during the fire event. Specifying a static CRD there is a listing violation. Read M-603 before picking the product." + cta;
      } else if (fan === "unk") {
        title.textContent = "If fire mode is not documented, the CRD listing cannot be verified.";
        body.innerHTML = "Ask three questions: through vs membrane vs nonrated; assembly rating and story count; does the system operate during a fire? Those three answers determine shaft, floor-line fire damper, CRD type, and fan-control basis." + cta;
      } else if (d === "fd") {
        title.textContent = "Floor-line fire damper or a shaft is a 607.6.1 / 607.6 path — still name it.";
        body.innerHTML = "A duct through a rated floor/ceiling connecting not more than two stories may avoid a shaft if a listed fire damper is at the floor line, or the duct is protected as a through-penetration firestop per IBC 714.5. The small-steel-duct exception (26 gage, 4 inch max, single unit, continuous to exterior, wall cavity, annular protection) is cumulative — miss one and it does not apply." + cta;
      } else {
        title.textContent = "Fire mode and CRD listing have evidence. Keep fire walls as a different assembly.";
        body.innerHTML = "A CRD is only valid as part of the specific tested floor/ceiling or roof/ceiling assembly. Do not treat a rated ceiling-membrane penetration like a standard diffuser boot. Fire walls / horizontal exits: <a href=\"/fire-wall-dampers/\">607.5.1–607.5.2</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-607-6", fan: fan, d: d });
    });
  }


  var dampacc = $("dampacc-form");
  if (dampacc) {
    dampacc.addEventListener("submit", function (e) {
      e.preventDefault();
      var acc = ($("dampacc-acc") && $("dampacc-acc").value) || "";
      var lab = ($("dampacc-lab") && $("dampacc-lab").value) || "";
      var box = $("dampacc-result"), title = $("dampacc-result-title"), body = $("dampacc-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the RCP and the damper tags</a> · <a href="/damper-access/">Damper access</a>.';
      if (!acc || !lab) {
        title.textContent = "Pick access and whether a permanent label is shown.";
        body.textContent = "This is not an access-panel design.";
        return;
      }
      if (acc === "ceil") {
        title.textContent = "A damper buried above an inaccessible ceiling is not coordinated.";
        body.innerHTML = "IMC 607.4.1: approved access large enough for inspection and maintenance. Dampers with fusible links, internal operators, or both need a minimum 12-inch by 12-inch access door or a removable duct section. Do not rely on “contractor to coordinate.”" + cta;
      } else if (acc === "cut") {
        title.textContent = "Access cannot reduce the fire-resistance rating of the assembly.";
        body.innerHTML = "607.4.1.1: duct access doors must be tight-fitting and suitable for the required duct construction. Coordinate ceiling access panels with architectural and life-safety sheets." + cta;
      } else if (lab === "no") {
        title.textContent = "Access without a 1/2-inch exterior label still fails 607.4.2.";
        body.innerHTML = "Access points must be permanently labeled on the exterior. Letters at least 1/2 inch high: FIRE/SMOKE DAMPER, SMOKE DAMPER, or FIRE DAMPER." + cta;
      } else if (acc === "remote") {
        title.textContent = "Restricted access is a remote-inspection path — name NFPA 80 or 105.";
        body.innerHTML = "607.4.1.2: if space or physical barriers limit periodic inspection or testing, the damper must be single-blade or multi-blade and comply with NFPA 80 or NFPA 105 remote-inspection requirements. Put it on M-603." + cta;
      } else {
        title.textContent = "Access and identification have evidence. Keep the damper type as a different 607 question.";
        body.innerHTML = "For every damper ask: can someone find it, open it, inspect it, test it, and reset it without damaging a rated assembly? Type of damper: <a href=\"/fire-smoke-dampers/\">607.5</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-607-4", acc: acc, lab: lab });
    });
  }


  var t1filt = $("t1filt-form");
  if (t1filt) {
    t1filt.addEventListener("submit", function (e) {
      e.preventDefault();
      var app = ($("t1filt-app") && $("t1filt-app").value) || "";
      var h = ($("t1filt-h") && $("t1filt-h").value) || "";
      var box = $("t1filt-result"), title = $("t1filt-result-title"), body = $("t1filt-result-body");
      show(box);
      var cta = ' <a href="' + contact("kitchen") + '">Send the cooking lineup and the hood elevation</a> · <a href="/type-i-filters/">Type I filters</a>.';
      if (!app || !h) {
        title.textContent = "Pick what is under the hood and what the drawings show for height and NET cfm.";
        body.textContent = "This is not a hood design.";
        return;
      }
      if (app === "char" && h !== "ok") {
        title.textContent = "A charbroiler does not get a 6-inch filter.";
        body.innerHTML = "Table 507.2.8: exposed charcoal/charbroil — 3.5 ft from cooking surface to the lowest filter edge. UL 1046 listed. 45 degrees from horizontal plus a drip tray under the lower edge." + cta;
      } else if (h === "low") {
        title.textContent = "Filter height has to match the appliance, not the typical.";
        body.innerHTML = "No exposed flame: 0.5 ft (6 in). Exposed flame/burners: 2 ft. Exposed charcoal/charbroil: 3.5 ft. Show it on the hood elevation, not only as a note." + cta;
      } else if (app === "mix") {
        title.textContent = "Mixed duty under one hood: size the whole hood to the highest-duty appliance.";
        body.innerHTML = "507.2.10: NET exhaust = total exhaust minus any air supplied directly to the hood cavity. Do not size a mixed-duty hood to the steam table if a heavy-duty fryer is on the same canopy. Extra-heavy-duty still cannot share a hood with lighter appliances under 507.2.2 — see <a href=\"/type-i-hoods/\">507.2 construction</a>." + cta;
      } else if (h === "net") {
        title.textContent = "NET cfm is total exhaust minus air supplied into the hood cavity.";
        body.innerHTML = "If makeup is dumped into the hood, subtract it. Show duty class, total cfm, and NET cfm on the hood schedule. 507.2.11: approved automatic fire suppression per IBC 904.13 and the IFC — not “by others” with no path." + cta;
      } else {
        title.textContent = "Filter listing, height, and NET have evidence. Keep makeup air as a different 508 question.";
        body.innerHTML = "Replacement air for the kitchen is <a href=\"/makeup-air/\">IMC 508</a>, not dining outdoor air and not an undercut door." + cta;
      }
      track("Field Tool Result", { tool: "imc-507-2-8", app: app, h: h });
    });
  }


  var gduct = $("gduct-form");
  if (gduct) {
    gduct.addEventListener("submit", function (e) {
      e.preventDefault();
      var path = ($("gduct-path") && $("gduct-path").value) || "";
      var test = ($("gduct-test") && $("gduct-test").value) || "";
      var box = $("gduct-result"), title = $("gduct-result-title"), body = $("gduct-result-body");
      show(box);
      var cta = ' <a href="' + contact("kitchen") + '">Send the grease-duct route and the spec</a> · <a href="/grease-duct-construction/">Grease duct construction</a>.';
      if (!path || !test) {
        title.textContent = "Pick the grease-duct path and whether a test-before-concealment note exists.";
        body.textContent = "This is not a grease-duct design.";
        return;
      }
      if (path === "none") {
        title.textContent = "Decide early: welded 16 ga, UL 1978, or listed wrap.";
        body.innerHTML = "IMC 506.3.1: steel minimum 0.0575 in (16 ga) or stainless 0.0450 in (18 ga), unless listed factory-built grease duct (UL 1978). Wrap is a listed ASTM E2336 system — not a generic jacket. Continuous liquid-tight weld or braze. No fasteners through duct walls." + cta;
      } else if (test === "no") {
        title.textContent = "Wrap it after the light test — not before.";
        body.innerHTML = "506.3.2.5: prior to shaft, wrap, or coatings that block full inspection, pass a leakage test (light test and water spray). Put “TEST PRIOR TO CONCEALMENT” on the drawings so the inspection is not missed." + cta;
      } else if (path === "wrap") {
        title.textContent = "Listed wrap is an enclosure exception — not a substitute for 16 ga or the leakage test.";
        body.innerHTML = "506.3.6 when no enclosure is required: 18 in to combustibles, 3 in to noncombustible. Exceptions exist for UL 1978, listed equipment, or listed wrap evaluated to ASTM E2336. Velocity still 500 fpm. Fan connection gaskets still 1500°F. Dampers still prohibited in grease shafts — <a href=\"/shaft-dampers/\">607.5.5</a>." + cta;
      } else {
        title.textContent = "Path and test-before-concealment have evidence. Keep termination as a different 506.3.13 question.";
        body.innerHTML = "Separate grease duct per Type I hood unless same story, same or adjoining rooms, no rated penetrations, and no solid-fuel appliances. Termination: <a href=\"/grease-duct-termination/\">506.3.13</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-506-3", path: path, test: test });
    });
  }


  var gslope = $("gslope-form");
  if (gslope) {
    gslope.addEventListener("submit", function (e) {
      e.preventDefault();
      var run = ($("gslope-run") && $("gslope-run").value) || "";
      var cl = ($("gslope-cl") && $("gslope-cl").value) || "";
      var box = $("gslope-result"), title = $("gslope-result-title"), body = $("gslope-result-body");
      show(box);
      var cta = ' <a href="' + contact("kitchen") + '">Send the grease-duct plan</a> · <a href="/grease-duct-slope-cleanouts/">Slope and cleanouts</a>.';
      if (!run || !cl) {
        title.textContent = "Pick the horizontal run and what cleanouts are shown.";
        body.textContent = "This is not a grease-duct design.";
        return;
      }
      if (run === "flat") {
        title.textContent = "If grease can pool, it will.";
        body.innerHTML = "IMC 506.3.7: continuous slope toward the hood or a grease reservoir. Minimum 1/4 in per 12 in (2%). If the horizontal duct exceeds 75 ft, slope increases to 1 in per 12 in (8.3%). Show slope arrows and the rate on every horizontal run." + cta;
      } else if (cl === "miss") {
        title.textContent = "A cleanout nobody can reach is not a cleanout.";
        body.innerHTML = "506.3.8–506.3.9: where sections cannot be cleaned from the hood or discharge, cleanouts maximum 20 ft apart and within 10 ft of turns greater than 45 degrees. Liquid-tight, steel same thickness as the duct, no fasteners through the wall, 1500°F gaskets. Minimum opening 12×12. Bottom cleanouts only if no other location works, with internal damming." + cta;
      } else if (cl === "fan") {
        title.textContent = "In-line fans need cleanouts within 3 ft on both sides.";
        body.innerHTML = "506.3.8.2: cleanouts on the inlet and outlet sides within 3 ft of fan duct connections. Horizontal discharge fans: cleanouts within 3 ft. Place cleanouts at reservoirs too." + cta;
      } else if (run === "long") {
        title.textContent = "Over 75 ft the slope is 8.3% — 2% is not enough.";
        body.innerHTML = "Factory-built grease duct follows its listing. Enclosure and rated access at those cleanouts are a different 506.3.11 / 506.3.12 question — <a href=\"/grease-duct-enclosure/\">enclosure</a>." + cta;
      } else {
        title.textContent = "Slope and cleanout spacing have evidence. Keep enclosure as a second pass.";
        body.innerHTML = "If the duct punches a ceiling, 506.3.11 wants enclosure to the outlet and a fire-rated access panel at each cleanout in that enclosure. Test-before-concealment is still <a href=\"/grease-duct-construction/\">506.3.2.5</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-506-3-7", run: run, cl: cl });
    });
  }


  var hover = $("hover-form");
  if (hover) {
    hover.addEventListener("submit", function (e) {
      e.preventDefault();
      var typ = ($("hover-type") && $("hover-type").value) || "";
      var geo = ($("hover-geo") && $("hover-geo").value) || "";
      var box = $("hover-result"), title = $("hover-result-title"), body = $("hover-result-body");
      show(box);
      var cta = ' <a href="' + contact("kitchen") + '">Send the kitchen plan and a section through the hood</a> · <a href="/hood-overhang/">Hood overhang</a>.';
      if (!typ || !geo) {
        title.textContent = "Pick canopy vs noncanopy and what is dimensioned.";
        body.textContent = "This is not a hood design.";
        return;
      }
      if (geo === "cfm" || geo === "tight") {
        title.textContent = "CFM will not fix a hood that is too short.";
        body.innerHTML = "IMC 507.1.6: size the hood to the appliance footprint first, then calculate exhaust. Canopy: inside lower edge at least 6 in beyond the cooking surface on all open sides; front lower lip no more than 4 ft above. Dimension it on plan <em>and</em> section. Missing sections are the leading overhang comment." + cta;
      } else if (typ === "non" && geo === "high") {
        title.textContent = "A noncanopy hood at 4 ft is over the 3 ft limit.";
        body.innerHTML = "Noncanopy: locate the hood no more than 3 ft above the cooking surface; hood edge set back no more than 1 ft from the cooking surface. Flush exception: only where that side is closed off by a noncombustible wall or panel." + cta;
      } else if (geo === "high") {
        title.textContent = "Canopy lip over 4 ft will not capture consistently.";
        body.innerHTML = "Front lower lip of a canopy hood: no more than 4 ft above the cooking surface. NET cfm is a different 507.2.10 question — <a href=\"/type-i-filters/\">filters and NET</a>." + cta;
      } else {
        title.textContent = "Overhang and lip height have evidence. Keep the fan as a different 506.5 question.";
        body.innerHTML = "Upblast fans still need hinge, cable, restraint, 18 in above the roof, and a grease drain — <a href=\"/type-i-exhaust-fans/\">506.5</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-507-1-6", typ: typ, geo: geo });
    });
  }


  var hexc = $("hexc-form");
  if (hexc) {
    hexc.addEventListener("submit", function (e) {
      e.preventDefault();
      var claim = ($("hexc-claim") && $("hexc-claim").value) || "";
      var vent = ($("hexc-vent") && $("hexc-vent").value) || "";
      var box = $("hexc-result"), title = $("hexc-result-title"), body = $("hexc-result-body");
      show(box);
      var cta = ' <a href="' + contact("kitchen") + '">Send the appliance lineup and any listing</a> · <a href="/hood-exceptions/">Hood exceptions</a>.';
      if (!claim || !vent) {
        title.textContent = "Pick the hood claim and whether space ventilation is shown if there is no Type I/II hood.";
        body.textContent = "This is not a listing determination.";
        return;
      }
      if (claim === "none") {
        title.textContent = "“No hood required” is not a designer preference.";
        body.innerHTML = "IMC 507.1 exceptions only hold when the listing is on the drawings: UL 710B recirculating, listed integral downdraft (NFPA 96), smoker ovens with integral exhaust, UL 2162 wood-fuel ovens, UL 197 reduced-grease electric cooking, or UL 921 dishwashers with self-contained condensing. Put the exception number, listing standard, and model on M-001." + cta;
      } else if (claim === "mix") {
        title.textContent = "If any appliance under the hood needs Type I, the entire hood is Type I.";
        body.innerHTML = "Type I is always the “safe upgrade,” but it then triggers Type I installation rules — grease duct, filters, suppression, makeup. One fryer under a Type II canopy is a first-cycle comment." + cta;
      } else if (vent === "skip") {
        title.textContent = "Skipping the hood does not skip kitchen ventilation.";
        body.innerHTML = "UL 710B spaces are still kitchens under Table 403.3.1.1. Each appliance counts as at least 100 sf. Heat/moisture-only path: space exhaust at 0.70 cfm/sf plus that 100 sf minimum. Coordinate the exception with the AHJ before issuing." + cta;
      } else if (claim === "rec") {
        title.textContent = "Listing is on the set. Keep Type I construction as a different 507.2 question if you still have a hood.";
        body.innerHTML = "Residential appliances used commercially still go to 507, not 505 — <a href=\"/domestic-cooking/\">505 vs 507</a>. Interlock and capture test: <a href=\"/hood-interlocks/\">507.1.1</a>." + cta;
      } else {
        title.textContent = "Type I for the lineup is the conservative path. Keep interlock and capture test as the next 507.1 questions.";
        body.innerHTML = "Auto-start or appliance interlock; sensor within 15 minutes; smoke/steam capture test before final — <a href=\"/hood-interlocks/\">507.1.1–507.1.7</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-507-1", claim: claim, vent: vent });
    });
  }


  var ugduct = $("ugduct-form");
  if (ugduct) {
    ugduct.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("ugduct-loc") && $("ugduct-loc").value) || "";
      var test = ($("ugduct-test") && $("ugduct-test").value) || "";
      var box = $("ugduct-result"), title = $("ugduct-result-title"), body = $("ugduct-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the duct route and the flood elevation if one exists</a> · <a href="/underground-ducts/">Underground ducts</a>.';
      if (!loc || !test) {
        title.textContent = "Pick where the duct sits and whether coating, concrete, slope, and a pre-burial leak test are shown.";
        body.textContent = "This is not an underground-duct design.";
        return;
      }
      if (loc === "ug" && test === "bare") {
        title.textContent = "Bury it after the leak test — not before.";
        body.innerHTML = "IMC 603.8: ducts must be approved for underground installation. Metallic ducts without an approved coating must be encased in at least 2 inches of concrete. Slope 1/8 in per foot to drainage with access. Seal, secure, and test before burial or encasement, including IECC leak testing. Plastic: PVC/HDPE, 150°F max design temperature." + cta;
      } else if (loc === "ug") {
        title.textContent = "Within 4 in of earth is still an underground-duct problem.";
        body.innerHTML = "603.14: ducts cannot be installed in or within 4 inches of earth unless they comply with 603.8. A duct 3 in off grade with no coating is not “above ground.”" + cta;
      } else if (loc === "flood" || test === "floodmiss") {
        title.textContent = "A sized duct still fails for flood and weather.";
        body.innerHTML = "603.13: in flood hazard areas, ducts must be above the IBC 1612 elevation for utilities, or designed to prevent water entry/accumulation up to that elevation. Below: resist hydrostatic, hydrodynamic, and buoyancy effects. 603.16: weather-protect exterior ducts, linings, coverings, and vibration-isolation connectors. Miami-Dade: <a href=\"/miami-dade-permit-resources/\">permit path</a> · <a href=\"/duct-flood-weather/\">603.13–603.16</a>." + cta;
      } else {
        title.textContent = "Above grade and away from earth. Keep garage 26-gage and furnace clearance as different 603 questions.";
        body.innerHTML = "Dwelling-to-private-garage: continuous 26-gage sheet steel, no openings into the garage (603.7). Furnace connections: clearance per the manufacturer (603.11). Vehicle damage: approved barriers (603.15)." + cta;
      }
      track("Field Tool Result", { tool: "imc-603-8", loc: loc, test: test });
    });
  }


  var hazshaft = $("hazshaft-form");
  if (hazshaft) {
    hazshaft.addEventListener("submit", function (e) {
      e.preventDefault();
      var mix = ($("hazshaft-mix") && $("hazshaft-mix").value) || "";
      var fan = ($("hazshaft-fan") && $("hazshaft-fan").value) || "";
      var box = $("hazshaft-result"), title = $("hazshaft-result-title"), body = $("hazshaft-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the one-line</a> · <a href="/hazardous-exhaust-shafts/">Hazardous exhaust shafts</a>.';
      if (!mix || !fan) {
        title.textContent = "Pick what shares the path and whether redundant fans are shown.";
        body.textContent = "This is not a lab-exhaust design.";
        return;
      }
      if (mix === "perc") {
        title.textContent = "Perchloric-acid hoods are not manifolded. Period.";
        body.innerHTML = "IMC 509.4 lab exception: no perchloric acid hoods manifolded. Dedicated system, dedicated shaft, dedicated fans. Do not tie it into “the lab header.”" + cta;
      } else if (mix === "mix") {
        title.textContent = "Incompatible materials cannot share a hazardous-exhaust system.";
        body.innerHTML = "If the International Fire Code says the materials are incompatible, they cannot be exhausted through the same hazardous-exhaust system. “We put a filter on it” is not 509.4." + cta;
      } else if (mix === "shaft") {
        title.textContent = "Hazardous exhaust cannot share a shaft with toilet, relief, return, or kitchen.";
        body.innerHTML = "No common shafts with other duct systems. Only allowed when the shared shaft contains hazardous exhaust originating in the same fire area. Different fire areas in a common shaft: IBC 717.5.3 Exception 1 Item 1.1." + cta;
      } else if (fan === "one") {
        title.textContent = "A lab manifold needs redundant fans — one fan is not the exception.";
        body.innerHTML = "Redundant exhaust fans for each hazardous-exhaust duct system: either parallel fans running simultaneously, each capable of the full required exhaust, or lead/lag so one runs if the other fails or is shut down for service. Also: negative pressure, same fire area, flow-regulating device on each control branch, biological safety cabinets filtered." + cta;
      } else {
        title.textContent = "Mixing and shafts have evidence. Keep 503 fans and 607.5.5 as different questions.";
        body.innerHTML = "Motors and fans in hazardous exhaust: <a href=\"/hazardous-exhaust-fans/\">503</a>. Fire/smoke dampers in grease or hazardous shafts are still a 607.5.5 miss — <a href=\"/shaft-dampers/\">shaft dampers</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-509-4", mix: mix, fan: fan });
    });
  }


  var plenummat = $("plenummat-form");
  if (plenummat) {
    plenummat.addEventListener("submit", function (e) {
      e.preventDefault();
      var exp = ($("plenummat-exp") && $("plenummat-exp").value) || "";
      var flood = ($("plenummat-flood") && $("plenummat-flood").value) || "";
      var box = $("plenummat-result"), title = $("plenummat-result-title"), body = $("plenummat-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the RCP and the product cut sheets</a> · <a href="/plenum-materials/">Plenum materials</a>.';
      if (!exp || !flood) {
        title.textContent = "Pick what is exposed in the plenum and whether flood elevation is identified.";
        body.textContent = "This is not a materials listing.";
        return;
      }
      if (exp === "foam") {
        title.textContent = "Ordinary foam and PVC do not belong in a return plenum.";
        body.innerHTML = "IMC 602.3.7–602.3.10: flame spread 25 or less, smoke developed 50 or less (ASTM E84 / UL 723). Foam as interior finish/trim: that, or NFPA 286 / IBC 2603.9. Higher values only if separated from airflow by a thermal barrier, corrosion-resistant steel, or 1-inch masonry/concrete. Plastic plumbing: listed 25/50, or UL 2846 water piping. Insulation, adhesives, coatings: 25/50 and ASTM C411 at service temperature ≥250°F." + cta;
      } else if (exp === "gadget") {
        title.textContent = "Discrete products in a plenum need UL 2043 — not a generic plastic box.";
        body.innerHTML = "602.3.6: exposed electrical, plumbing, and mechanical products listed for plenum use per UL 2043. Exception: metallic electrical enclosures." + cta;
      } else if (flood === "below" || flood === "unk") {
        title.textContent = "Flood-zone plenums are not a civil-only note.";
        body.innerHTML = "602.4: plenums in flood zones must be above the IBC 1612 utility elevation, or resist water entry, hydrostatic, and buoyancy loads. Put the elevation on M-001. Miami-Dade: <a href=\"/miami-dade-permit-resources/\">permit path</a>. Ducts: <a href=\"/duct-flood-weather/\">603.13</a>." + cta;
      } else {
        title.textContent = "Listings and flood elevation have evidence. Keep 602 fire-area and fuel-fired limits as different questions.";
        body.innerHTML = "Plenum overview (one fire area, no fuel-fired appliances, inspection before the ceiling closes): <a href=\"/plenums/\">602</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-602-3", exp: exp, flood: flood });
    });
  }


  var h2vent = $("h2vent-form");
  if (h2vent) {
    h2vent.addEventListener("submit", function (e) {
      e.preventDefault();
      var path = ($("h2vent-path") && $("h2vent-path").value) || "";
      var ign = ($("h2vent-ign") && $("h2vent-ign").value) || "";
      var box = $("h2vent-result"), title = $("h2vent-result-title"), body = $("h2vent-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the hydrogen-room envelope</a> · <a href="/hydrogen-ventilation/">Hydrogen ventilation</a>.';
      if (!path || !ign) {
        title.textContent = "Pick the ventilation path and where ignition sources sit.";
        body.textContent = "This is not a hydrogen-system design.";
        return;
      }
      if (path === "none") {
        title.textContent = "Hydrogen does not wait at the floor like gasoline vapor.";
        body.innerHTML = "IMC 304.5: pick natural (304.5.1), mechanical (502.16), or approved engineered (304.5.3). Rooms that communicate directly with a private garage are treated as the garage. Natural needs two permanent openings in the same exterior wall — upper within 12 in of the ceiling, lower within 12 in of the floor. Total free area ≥ 0.5 sf per 1,000 cubic feet. Minimum opening dimension 3 in. Room ≤ 850 sf. Hydrogen output ≤ 4 scfm per 250 sf." + cta;
      } else if (ign === "high" || ign === "unk") {
        title.textContent = "Ignition at the stratification layer is the miss 304.5 is written to catch.";
        body.innerHTML = "Natural: ignition sources ≥ 12 in below the ceiling. Mechanical: ignition sources below the exhaust-outlet elevation (304.5.2). Louvers: net free area; if unknown, wood = 25%, metal = 75%; fixed open. Electrical classification belongs on both electrical and mechanical drawings. Fire-marshal pre-review is typical." + cta;
      } else if (path === "eng") {
        title.textContent = "Engineered 304.5.3 is an approved alternative — document the basis, do not leave it as a note.";
        body.innerHTML = "M-001 picks the path. M-601: vent path, room area and volume, free area or exhaust cfm, ignition-source elevation, detection/alarm sensor type and location. Battery rooms are a different 502 question — <a href=\"/battery-room-exhaust/\">502.3–502.5</a>." + cta;
      } else {
        title.textContent = "Path and ignition elevation have evidence. Keep 502.16 mechanical rates as a drawing, not a typical.";
        body.innerHTML = "Mechanical hydrogen exhaust is IMC 502.16 — do not copy a 404 garage rate onto a hydrogen room. Parking garage: <a href=\"/parking-garage-ventilation/\">404</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-304-5", path: path, ign: ign });
    });
  }


  var htchim = $("htchim-form");
  if (htchim) {
    htchim.addEventListener("submit", function (e) {
      e.preventDefault();
      var temp = ($("htchim-temp") && $("htchim-temp").value) || "";
      var term = ($("htchim-term") && $("htchim-term").value) || "";
      var box = $("htchim-result"), title = $("htchim-result-title"), body = $("htchim-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the outlet temperature and the termination</a> · <a href="/high-temperature-exhaust/">High-temperature exhaust</a>.';
      if (!temp || !term) {
        title.textContent = "Pick the heat class (or “over 600°F, no class”) and whether Table 510.2 height is shown.";
        body.textContent = "This is not a chimney design.";
        return;
      }
      if (temp === "unk" || term === "short") {
        title.textContent = "Over 600°F is not just another exhaust outlet.";
        body.innerHTML = "IMC 510.2: outlets exceeding 600°F (315°C) are designed as a chimney per Table 510.2. Minimum wall thickness in all categories: 0.127 in (No. 10 MSG). Name the heat class on M-001. A kitchen-fan typical is the wrong sheet." + cta;
      } else if (temp === "high") {
        title.textContent = "High-heat (over 2,000°F): 20 ft is the educational height, not 3 ft.";
        body.innerHTML = "Lining: 4½ in laid on a 4½ in bed. Terminate 20 ft above the roof opening, and 20 ft above any part of a building within 50 ft. Clearance: per the design engineer — combustibles not exceeding 160°F." + cta;
      } else if (temp === "med") {
        title.textContent = "Medium-heat (2,000°F max): 10 ft above the roof — and 36 in interior clearance.";
        body.innerHTML = "Lining: up to 18 in diameter = 2½ in; over 18 in = 4½ in on a 4½ in bed. Terminate 10 ft above the roof opening, and 10 ft above any part of a building within 25 ft. Clearance to combustibles: 36 in interior, 24 in exterior. Factory-built 805 is a different path — <a href=\"/medium-heat-chimneys/\">805</a>." + cta;
      } else {
        title.textContent = "Low-heat (1,000°F normal): no lining, 3 ft above the roof — still a 510.2 chimney.";
        body.innerHTML = "Terminate 3 ft above the roof opening, and 2 ft above any part of a building within 10 ft. Clearance to combustibles: 18 in interior, 6 in exterior. Noncombustibles: 2 in up to 18 in diameter, 4 in over 18 in. Lining generally bottom to top; for the noted condition, 24 in below the connector to 24 ft above." + cta;
      }
      track("Field Tool Result", { tool: "imc-510-2", temp: temp, term: term });
    });
  }


  var hazmat = $("hazmat-form");
  if (hazmat) {
    hazmat.addEventListener("submit", function (e) {
      e.preventDefault();
      var maq = ($("hazmat-maq") && $("hazmat-maq").value) || "";
      var path = ($("hazmat-path") && $("hazmat-path").value) || "";
      var box = $("hazmat-result"), title = $("hazmat-result-title"), body = $("hazmat-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the inventory — or a list of what is stored</a> · <a href="/hazmat-exhaust/">Hazmat exhaust</a>.';
      if (!maq || !path) {
        title.textContent = "Pick whether quantities are over MAQ and how the exhaust is shown.";
        body.textContent = "This is not a hazmat inventory.";
        return;
      }
      if (path === "fd") {
        title.textContent = "Hazmat and HPM ducts that cross rated assemblies go in rated shafts. No fire dampers.";
        body.innerHTML = "IMC 502.10: exhaust at fabrication areas, workstations, liquid storage, HPM rooms, gas rooms, gas cabinets, and exhausted enclosures per IMC / IBC / IFC. Do not add a fire damper to “protect” the shaft — that is the miss 509.4 and 502.10 are written to catch. <a href=\"/hazardous-exhaust-shafts/\">509.4 shafts</a>." + cta;
      } else if (path === "recirc" || maq === "over") {
        title.textContent = "“Exhaust per code” is not a 502.8 design.";
        body.innerHTML = "Over MAQ: dedicated hazmat exhaust (or proven natural) for storage rooms, gas rooms, and use areas. Storage: ≥ 1 cfm/ft², typically continuous, emergency shutoff outside the room. Pickup low for heavy vapors, high for light ones. Do not recirculate contaminated air to occupied spaces. NFPA 704 ratings of 3–4 trigger local capture at the point of generation. Many 502.9 materials also need 200 fpm face velocity and/or scrubbers per IFC." + cta;
      } else {
        title.textContent = "Under MAQ is a documented claim — keep the inventory with the set.";
        body.innerHTML = "Review will not finish on a placeholder. Coordinate the hazardous-materials inventory with the permit timeline. 509 systems are a different path — <a href=\"/hazardous-exhaust/\">509</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-8", maq: maq, path: path });
    });
  }


  var fconv = $("fconv-form");
  if (fconv) {
    fconv.addEventListener("submit", function (e) {
      e.preventDefault();
      function num(id) {
        var el = $(id);
        var v = parseFloat((el && el.value) || "");
        return v === v ? v : null;
      }
      var kind = ($("fconv-kind") && $("fconv-kind").value) || "";
      var a = num("fconv-a"), b = num("fconv-b");
      var box = $("fconv-result"), title = $("fconv-result-title"), body = $("fconv-result-body");
      show(box);
      var cta = ' <a href="' + contact("hvac") + '">Send the areas and the occupancy</a> · <a href="/field-conversions/">Field conversions</a>.';
      if (!kind) {
        title.textContent = "Pick which identity you are checking.";
        body.textContent = "This is not a load calculation.";
        return;
      }
      if (kind === "air") {
        if (a === null || b === null || a <= 0 || b <= 0) {
          title.textContent = "Enter CFM and ΔT (°F).";
          body.innerHTML = "Sea-level sensible identity: Btuh ≈ 1.08 × CFM × ΔT. 1.08 = 0.075 lb/ft³ × 0.24 × 60. Miami humidity and altitude change it." + cta;
          return;
        }
        var q = 1.08 * a * b;
        title.textContent = "About " + Math.round(q).toLocaleString() + " Btu/h sensible (sea-level check).";
        body.innerHTML = n(a) + " cfm × 1.08 × " + n(b) + " °F. That is a dry-air identity, not total cooling. Wet coils use CFM × 4.5 × Δenthalpy — and Δh comes from states, not from a guessed ΔT. Do not size the coil from this." + cta;
      } else if (kind === "water") {
        if (a === null || b === null || a <= 0 || b <= 0) {
          title.textContent = "Enter GPM and ΔT (°F).";
          body.innerHTML = "Standard-water identity: Btuh ≈ 500 × GPM × ΔT. 500 = 8.33 lb/gal × 60. Glycol needs a fluid correction." + cta;
          return;
        }
        var qw = 500 * a * b;
        var tons = qw / 12000;
        title.textContent = "About " + Math.round(qw).toLocaleString() + " Btu/h (" + n(tons) + " tons if this were evaporator load).";
        body.innerHTML = n(a) + " gpm × 500 × " + n(b) + " °F. 1 ton = 12,000 Btu/h. If this loop is 30% propylene glycol, 500 is the wrong factor. Traditional thumbs like 2.4 gpm/ton assume a ΔT — they are not this project." + cta;
      } else if (kind === "ach") {
        if (a === null || b === null || a <= 0 || b <= 0) {
          title.textContent = "Enter CFM and room volume (ft³).";
          body.innerHTML = "ACH = CFM × 60 ÷ volume. This is not IMC Table 403 outdoor air and not a kitchen capture rate." + cta;
          return;
        }
        var ach = (a * 60) / b;
        title.textContent = "About " + n(ach) + " air changes per hour.";
        body.innerHTML = n(a) + " cfm × 60 ÷ " + n(b) + " ft³. Use this to check a note, not to replace Table 403 people+area outdoor air." + cta;
      } else {
        if (a === null || a <= 0) {
          title.textContent = "Enter EER (or skip to COP by putting COP in the first box and telling us).";
          body.innerHTML = "COP ≈ EER ÷ 3.412. EER ≈ 12 ÷ (kW/ton). kW/ton ≈ 12 ÷ EER. These convert ratings — they do not prove the machine will hit them in Miami." + cta;
          return;
        }
        var cop = a / 3.412;
        var kwpt = 12 / a;
        title.textContent = "EER " + n(a) + " → about COP " + n(cop) + " and " + n(kwpt) + " kW/ton.";
        body.innerHTML = "COP ≈ EER ÷ 3.412. kW/ton ≈ 12 ÷ EER. Nameplate EER is not the same as the plant COP on a 95°F condensing day. Send the rating sheet with the load." + cta;
      }
      track("Field Tool Result", { tool: "field-conv", kind: kind });
    });
  }


  var rfg = $("rfg-form");
  if (rfg) {
    rfg.addEventListener("submit", function (e) {
      e.preventDefault();
      var cls = ($("rfg-class") && $("rfg-class").value) || "";
      var room = ($("rfg-room") && $("rfg-room").value) || "";
      var box = $("rfg-result"), title = $("rfg-result-title"), body = $("rfg-result-body");
      show(box);
      var cta = ' <a href="' + contact("hvac") + '">Send the nameplate and the room</a> · <a href="/refrigerant-safety/">Refrigerant safety</a>.';
      if (!cls || !room) {
        title.textContent = "Pick the ASHRAE 34 class and where the equipment sits.";
        body.textContent = "This is not a refrigerant selection.";
        return;
      }
      if (cls === "unk") {
        title.textContent = "A refrigerant number is not an ASHRAE 34 class.";
        body.innerHTML = "Put the class (A1, A2L, B1, …) next to the number and the charge in pounds. “R-410A equivalent” is not a class. EPA Section 608 still governs recovery on the swap." + cta;
      } else if (cls === "a2l" || room === "swap") {
        title.textContent = "A2L is not a drop-in note.";
        body.innerHTML = "Subclass 2L means burning velocity under 10 cm/s — difficult to ignite, still a flammability class. Charge limits, occupancy, machinery-room ventilation, leak detection, and the listing (often UL 60335-2-40) move with it. Do not keep the old A1 room note. Coordinate ASHRAE 15 and IMC Chapter 11 — do not invent a cfm from a brochure." + cta;
      } else if (cls === "b") {
        title.textContent = "Class B is a higher-toxicity ASHRAE 34 group (OEL below 400 ppm) — not the same as fire-code “toxic.”";
        body.innerHTML = "Asphyxiation (oxygen displacement) is still the dominant exposure risk. Put OEL, charge, and the occupied vs machinery-room path on the set. Fire-code toxic/highly toxic language is a different test — keep both straight with the AHJ." + cta;
      } else if (room === "occupied") {
        title.textContent = "Occupied-space charge is a listing and ASHRAE 15 question — not a typical.";
        body.innerHTML = "Even A1 in occupied space has charge and listing limits. Send the nameplate charge and the room volume. Conversions (1.08 / 500 / 12,000) do not answer this — <a href=\"/field-conversions/\">field conversions</a>." + cta;
      } else {
        title.textContent = "Class and room have evidence. Keep EPA 608 recovery on the swap.";
        body.innerHTML = "Section 608 still applies to HFCs and next-generation blends, not only old CFCs. Nameplate, charge, and recovery path belong in the closeout packet." + cta;
      }
      track("Field Tool Result", { tool: "ashrae-34", cls: cls, room: room });
    });
  }


  var smkctl = $("smkctl-form");
  if (smkctl) {
    smkctl.addEventListener("submit", function (e) {
      e.preventDefault();
      var kind = ($("smkctl-kind") && $("smkctl-kind").value) || "";
      var insp = ($("smkctl-insp") && $("smkctl-insp").value) || "";
      var box = $("smkctl-result"), title = $("smkctl-result-title"), body = $("smkctl-result-body");
      show(box);
      var cta = ' <a href="' + contact("comments") + '">Send the life-safety sheets</a> · <a href="/smoke-control/">Smoke control</a>.';
      if (!kind || !insp) {
        title.textContent = "Pick what is on the set and whether special inspection is written.";
        body.textContent = "This is not a smoke-control design.";
        return;
      }
      if (kind === "910" || kind === "tbd") {
        title.textContent = "Calling atrium exhaust “smoke control” is how 512 stalls.";
        body.innerHTML = "IMC 512 is IBC 909: a tenable path for evacuation or relocation. IBC/IFC Section 910 smoke/heat removal is a different intent and a different method. Put a one-page narrative on the set: zones, method (pressurization / airflow / exhaust), performance targets, duration, activation, standby power, acceptance tests. Many AHJs want a separate smoke-control permit. <a href=\"/smoke-heat-vents/\">311 / 910 vents</a>." + cta;
      } else if (insp === "none") {
        title.textContent = "512.3 special inspection cannot be “TBD by contractor.”";
        body.innerHTML = "Systems tied to IBC 909 require special inspections and tests in the final installed condition (IBC 1704). Spell out procedures, methods, and what will be inspected. Confirm the analysis method with the AHJ before anyone sizes a fan." + cta;
      } else {
        title.textContent = "909 basis and inspection language have evidence. Keep the narrative with the set.";
        body.innerHTML = "A drawings-only submittal still cycles. The reviewer reads the narrative first. Dampers at smoke barriers are a 607 question — <a href=\"/fire-smoke-dampers/\">607</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-512", kind: kind, insp: insp });
    });
  }


  var salon = $("salon-form");
  if (salon) {
    salon.addEventListener("submit", function (e) {
      e.preventDefault();
      var pick = ($("salon-pick") && $("salon-pick").value) || "";
      var run = ($("salon-run") && $("salon-run").value) || "";
      var box = $("salon-result"), title = $("salon-result-title"), body = $("salon-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the station count and the RCP</a> · <a href="/salon-exhaust/">Salon exhaust</a>.';
      if (!pick || !run) {
        title.textContent = "Pick how close the inlet is to the chemicals and when the fan runs.";
        body.textContent = "This is not a salon design.";
        return;
      }
      if (pick === "cap" || pick === "far") {
        title.textContent = "A nail station is not a restroom with a ceiling grille.";
        body.innerHTML = "IMC 502.20: local exhaust per Table 403.3.1.1 Note h. No factory exhaust: inlets within 12 inches horizontally and vertically of where chemicals are applied. Do not cap a factory collar in the return plenum. Do not manifold salon exhaust into environmental return." + cta;
      } else if (run === "int") {
        title.textContent = "The exhaust runs whenever the space is occupied — not when someone notices fumes.";
        body.innerHTML = "A restroom timer or an occupant switch is not 502.20.1. Keep the design basis on M-601 (12 in pickup, code reference). Coating rooms and CNG repair are different 502 rows in the same post — process first, then the fan." + cta;
      } else {
        title.textContent = "Pickup and occupied-hour operation have evidence. Keep the duct to outdoors.";
        body.innerHTML = "Still: do not tie this into general return. Projector, coating, and lighter-than-air repair use other 502.11–502.19 bases (cfm/lamp, 1 cfm/ft² at the floor, low inlets / high outlets). <a href=\"/hazmat-exhaust/\">502.8 MAQ</a> is a different trigger." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-20", pick: pick, run: run });
    });
  }


  var smkmeth = $("smkmeth-form");
  if (smkmeth) {
    smkmeth.addEventListener("submit", function (e) {
      e.preventDefault();
      var m = ($("smkmeth-m") && $("smkmeth-m").value) || "";
      var t = ($("smkmeth-t") && $("smkmeth-t").value) || "";
      var box = $("smkmeth-result"), title = $("smkmeth-result-title"), body = $("smkmeth-result-body");
      show(box);
      var cta = ' <a href="' + contact("comments") + '">Send the method and the door schedule</a> · <a href="/smoke-control-methods/">Smoke-control methods</a>.';
      if (!m || !t) {
        title.textContent = "Pick the method and whether door force / duration / layer height are on the set.";
        body.textContent = "This is not a smoke-control design.";
        return;
      }
      if (m === "unk" || t === "door") {
        title.textContent = "Minimum ΔP that makes the stair door unopenable is a failed system.";
        body.innerHTML = "Name the method per zone. Fully sprinklered pressurization: ΔP ≥ 0.05 in. water gauge, limited by IBC door-opening force. Not fully sprinklered: ΔP ≥ 2× the maximum calculated design-fire ΔP. Duration: ≥ 20 minutes after detection or 1.5 × calculated egress time, whichever is greater. Documentation first — <a href=\"/smoke-control/\">512.1–512.3</a>." + cta;
      } else if (m === "a") {
        title.textContent = "Airflow toward the fire cannot exceed 200 fpm.";
        body.innerHTML = "512.7 needs AHJ approval and NFPA 92. If calculations exceed 200 fpm toward the fire, the airflow method is not allowed. Opening geometry has to prevent flow reversal." + cta;
      } else if (m === "e") {
        title.textContent = "Keep the smoke layer at least 6 ft above the egress walking surface.";
        body.innerHTML = "512.8 exhaust (atriums/malls) needs building-official approval and NFPA 92. Show the smoke-filling calculation, design fire, exhaust rate, and makeup air. A 910 vent is not this method — <a href=\"/smoke-heat-vents/\">311 / 910</a>." + cta;
      } else {
        title.textContent = "Pressurization target and door-force check have evidence. Keep stack, wind, and HVAC modes in the analysis.";
        body.innerHTML = "Most smoke-control failures are unmodeled stack / wind / fire buoyancy and sequences that fight each other (512.4), not a small fan. Stairs and hoistways still follow IBC/IFC smoke-control provisions." + cta;
      }
      track("Field Tool Result", { tool: "imc-512-6", m: m, t: t });
    });
  }


  var fuel18 = $("fuel18-form");
  if (fuel18) {
    fuel18.addEventListener("submit", function (e) {
      e.preventDefault();
      var fuel = ($("fuel18-fuel") && $("fuel18-fuel").value) || "";
      var h = ($("fuel18-h") && $("fuel18-h").value) || "";
      var box = $("fuel18-result"), title = $("fuel18-result-title"), body = $("fuel18-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the section showing inlet height</a> · <a href="/fuel-dispensing-exhaust/">Fuel-dispensing exhaust</a>.';
      if (!fuel || !h) {
        title.textContent = "Pick the fuel and whether the opening is within 18 in of the floor.";
        body.textContent = "This is not a fuel-station design.";
        return;
      }
      if (fuel === "h2") {
        title.textContent = "Hydrogen does not wait at the floor like gasoline vapor.";
        body.innerHTML = "Lighter-than-air fuels invert the pickup. IMC 304.5 / 502.16: high outlets, ignition below the stratification layer, fire-marshal first. Do not copy the 18 in AFF gasoline rule onto hydrogen. <a href=\"/hydrogen-ventilation/\">304.5</a>." + cta;
      } else if (h === "high") {
        title.textContent = "Gasoline vapor does not wait at the canopy.";
        body.innerHTML = "IMC 502.1.2: in fuel-dispensing areas, the bottom of exhaust or inlet openings must be ≤ 18 inches above the floor. High concentrations of flammable vapor are IMC 509, not a toilet fan. Tag M-101: LOW EXH INLET ≤ 18 IN AFF." + cta;
      } else {
        title.textContent = "Low inlet has evidence. Keep 509 in view if concentrations are hazardous.";
        body.innerHTML = "Aircraft fueling (502.2) is floor-level or in-slab for the same reason — heavy vapors pool. Do not manifold this with environmental return. Garage CO control is a different 404 path — <a href=\"/parking-garage-ventilation/\">404</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-1-2", fuel: fuel, h: h });
    });
  }


  var drecirc = $("drecirc-form");
  if (drecirc) {
    drecirc.addEventListener("submit", function (e) {
      e.preventDefault();
      var path = ($("drecirc-path") && $("drecirc-path").value) || "";
      var three = ($("drecirc-3") && $("drecirc-3").value) || "";
      var box = $("drecirc-result"), title = $("drecirc-result-title"), body = $("drecirc-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the collector cut and the discharge path</a> · <a href="/dust-recirculation/">Dust recirculation</a>.';
      if (!path || !three) {
        title.textContent = "Pick whether air returns to the plant and whether all three recirc criteria are on the schedule.";
        body.textContent = "This is not a dust-system design.";
        return;
      }
      if (path === "rec" || three === "miss") {
        title.textContent = "A recirculating dust collector with no 99.9% note is not 510.1.3.";
        body.innerHTML = "Default: discharge to outdoors (direct flue or through the bin/vault) unless contaminants are removed. Recirculation requires all three: particulate removal ≥ 99.9% at 10 microns; vapor concentrations < 25% of the lower flammable limit (LFL); approved equipment that continuously monitors vapor concentration. Cyclone delivery shall not discharge into a firebox (510.1.2). Open-air terminals: approved noncombustible spark screen (510.1.4)." + cta;
      } else {
        title.textContent = "Outdoor discharge has evidence. Keep explosion control in view.";
        body.innerHTML = "510.1.5 explosion control is a different question — relief that actually releases, not a bird screen. <a href=\"/dust-explosion-control/\">510.1.5</a> · over 600°F is a chimney — <a href=\"/high-temperature-exhaust/\">510.2</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-510-1-3", path: path, three: three });
    });
  }


  var smkhw = $("smkhw-form");
  if (smkhw) {
    smkhw.addEventListener("submit", function (e) {
      e.preventDefault();
      var pwr = ($("smkhw-pwr") && $("smkhw-pwr").value) || "";
      var duct = ($("smkhw-duct") && $("smkhw-duct").value) || "";
      var box = $("smkhw-result"), title = $("smkhw-result-title"), body = $("smkhw-result-body");
      show(box);
      var cta = ' <a href="' + contact("comments") + '">Send the mechanical and electrical schedules</a> · <a href="/smoke-control-hardware/">Smoke-control hardware</a>.';
      if (!pwr || !duct) {
        title.textContent = "Pick power/panel listing and whether leak test / Ts / listed dampers are noted.";
        body.textContent = "This is not a smoke-control design.";
        return;
      }
      if (pwr === "norm") {
        title.textContent = "A life-safety fan on a normal circuit is not 512.11.";
        body.innerHTML = "Standby power per IBC 2702. Transfer switches in a separate 1-hour-rated room, ventilated directly outdoors. UPS coverage for volatile-memory components for a 15-minute outage. The control unit must be listed to UL 864 as smoke-control equipment — a generic fire-alarm panel is not 512.12. Weekly preprogrammed test: audible, visual, and printed report. Wiring in continuous raceways." + cta;
      } else if (duct === "tbd") {
        title.textContent = "Leak test “by TAB” is not 512.10.2.";
        body.innerHTML = "Ducts: leak test to 1.5× maximum design pressure; leakage ≤ 5% of design flow, documented. Fan components rated for probable smoke-temperature rise (Ts). Automatic dampers listed. Belt-driven fans: at least 2 belts and 1.5× belt count for design duty; motors not over nameplate horsepower; minimum service factor 1.15. Control-air tubing generally Type L ACR copper; test at 3× operating pressure for 30 minutes." + cta;
      } else {
        title.textContent = "Power, listing, and leak-test language have evidence. Keep the firefighter’s panel in the IFC path.";
        body.innerHTML = "Methods and door force are a different 512.6 question — <a href=\"/smoke-control-methods/\">0.05 in. w.g. / 200 fpm / 6 ft</a>. Documentation first — <a href=\"/smoke-control/\">512.1</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-512-10", pwr: pwr, duct: duct });
    });
  }


  var smkbar = $("smkbar-form");
  if (smkbar) {
    smkbar.addEventListener("submit", function (e) {
      e.preventDefault();
      var open = ($("smkbar-open") && $("smkbar-open").value) || "";
      var leak = ($("smkbar-leak") && $("smkbar-leak").value) || "";
      var box = $("smkbar-result"), title = $("smkbar-result-title"), body = $("smkbar-result-body");
      show(box);
      var cta = ' <a href="' + contact("comments") + '">Send the life-safety and M sheets</a> · <a href="/smoke-barriers/">Smoke barriers</a>.';
      if (!open || !leak) {
        title.textContent = "Pick how openings are protected and whether leakage ratios are in the permit set.";
        body.textContent = "This is not a smoke-control design.";
        return;
      }
      if (open === "grille" || open === "untag") {
        title.textContent = "A transfer grille across a smoke barrier with no damper will not hold ΔP.";
        body.innerHTML = "IMC 512.5.3.2: ducts and transfer openings through smoke barriers need a minimum Class II, 250°F smoke damper. Doors: automatic-closing smoke-barrier assemblies. Trace each barrier and count every opening. <a href=\"/fire-smoke-dampers/\">607</a>." + cta;
      } else if (leak === "ext") {
        title.textContent = "Leakage-area ratios belong in the permit set, not only in an external report.";
        body.innerHTML = "Walls A/Aw = 0.00100. Interior exit stairs / ramps / exit passageways A/Aw = 0.00035. Other shafts A/Aw = 0.00150. Floors/roofs A/AF = 0.00050. Ratios do not include door gaps or operable windows — add those in 512.5.1. Pressurization systems prove compliance by achieving required ΔP in smoke mode." + cta;
      } else {
        title.textContent = "Openings and leakage language have evidence. Keep ΔP and door force in view.";
        body.innerHTML = "0.05 in. w.g. that makes the stair door unopenable is still a failed system — <a href=\"/smoke-control-methods/\">512.6</a>. Hardware / UL 864 / standby power — <a href=\"/smoke-control-hardware/\">512.10</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-512-5", open: open, leak: leak });
    });
  }


  var cngrep = $("cngrep-form");
  if (cngrep) {
    cngrep.addEventListener("submit", function (e) {
      e.preventDefault();
      var fuel = ($("cngrep-fuel") && $("cngrep-fuel").value) || "";
      var path = ($("cngrep-path") && $("cngrep-path").value) || "";
      var box = $("cngrep-result"), title = $("cngrep-result-title"), body = $("cngrep-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the section and the fuel type</a> · <a href="/cng-repair-exhaust/">CNG repair exhaust</a>.';
      if (!fuel || !path) {
        title.textContent = "Pick the fuel and whether inlets/outlets/interlock match 502.16.";
        body.textContent = "This is not a repair-garage design.";
        return;
      }
      if (fuel === "gas") {
        title.textContent = "Gasoline vapor sits on the slab — that is 502.1.2, not 502.16.";
        body.innerHTML = "Fuel-dispensing: bottom of openings ≤ 18 in above the floor. Do not invert it. <a href=\"/fuel-dispensing-exhaust/\">502.1.2</a>." + cta;
      } else if (path === "18") {
        title.textContent = "Do not copy the gasoline 18-inch inlet onto a hydrogen bay.";
        body.innerHTML = "IMC 502.16: mechanical exhaust with inlets low, outlets high, rate based on room volume (put the basis on M-601 — there is no single cfm on this page), and automatic shutdown of fueling when exhaust fails. Hydrogen repair also NFPA 2. Generating/refueling is 304.5 — <a href=\"/hydrogen-ventilation/\">304.5</a>." + cta;
      } else {
        title.textContent = "Low inlets, high outlets, and the fueling interlock have evidence. Keep NFPA 2 on hydrogen.";
        body.innerHTML = "Do not manifold this into environmental return. 404 garage CO control is a different path — <a href=\"/parking-garage-ventilation/\">404</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-16", fuel: fuel, path: path });
    });
  }


  var projex = $("projex-form");
  if (projex) {
    projex.addEventListener("submit", function (e) {
      e.preventDefault();
      var col = ($("projex-col") && $("projex-col").value) || "";
      var path = ($("projex-path") && $("projex-path").value) || "";
      var box = $("projex-result"), title = $("projex-result-title"), body = $("projex-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the cut sheet and the ceiling plan</a> · <a href="/projector-exhaust/">Projector exhaust</a>.';
      if (!col || !path) {
        title.textContent = "Pick whether the collar is connected and where the duct goes.";
        body.textContent = "This is not a projector-room design.";
        return;
      }
      if (col === "cap" || path === "ret") {
        title.textContent = "A projector collar capped in the return is not 502.11.";
        body.innerHTML = "Hard-connect a factory collar and size it to the manufacturer. Without a collar: electric-arc ≥ 200 cfm per lamp; xenon ≥ 300 cfm per lamp and housing ≤ 130°F. Dedicated path to outdoors — not house exhaust, not return. Count lamps, not rooms." + cta;
      } else {
        title.textContent = "Collar or per-lamp cfm, and an outdoor path, have evidence. Keep 130°F on xenon housings.";
        body.innerHTML = "Coating rooms are a different 502.12 path — floor pickup at 1 cfm per square foot. <a href=\"/organic-coating-exhaust/\">502.12</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-11", col: col, path: path });
    });
  }


  var coat1 = $("coat1-form");
  if (coat1) {
    coat1.addEventListener("submit", function (e) {
      e.preventDefault();
      var pick = ($("coat1-pick") && $("coat1-pick").value) || "";
      var out = ($("coat1-out") && $("coat1-out").value) || "";
      var box = $("coat1-result"), title = $("coat1-result-title"), body = $("coat1-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the floor area and the section</a> · <a href="/organic-coating-exhaust/">Organic-coating exhaust</a>.';
      if (!pick || !out) {
        title.textContent = "Pick pickup/rate and whether discharge and makeup are dedicated.";
        body.textContent = "This is not a coating-booth design.";
        return;
      }
      if (pick === "high" || out === "ret") {
        title.textContent = "A high grille over a coating floor is not 502.12.";
        body.innerHTML = "Enclosed Class I organic coating: ≥ 1 cfm per square foot of solid floor, pickup at floor level, discharge outdoors, clean makeup that sweeps the floor. Solvent vapor sits on the slab. Do not take makeup from a hazardous room. High concentrations may also be IMC 509." + cta;
      } else {
        title.textContent = "Floor pickup, 1 cfm/ft², outdoor discharge, and makeup have evidence.";
        body.innerHTML = "If quantities exceed the maximum allowable quantity, that is a 502.8 / 509 question — <a href=\"/hazmat-exhaust/\">502.8</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-12", pick: pick, out: out });
    });
  }


  var tailpipe = $("tailpipe-form");
  if (tailpipe) {
    tailpipe.addEventListener("submit", function (e) {
      e.preventDefault();
      var run = ($("tailpipe-run") && $("tailpipe-run").value) || "";
      var hose = ($("tailpipe-hose") && $("tailpipe-hose").value) || "";
      var box = $("tailpipe-result"), title = $("tailpipe-result-title"), body = $("tailpipe-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the bay count and a photo</a> · <a href="/source-capture-exhaust/">Source-capture exhaust</a>.';
      if (!run || !hose) {
        title.textContent = "Pick how engines run and whether a hose is on the tailpipe.";
        body.textContent = "This is not a shop design.";
        return;
      }
      if (run === "place" && hose === "wall") {
        title.textContent = "A ceiling fan over a running engine is not source capture.";
        body.innerHTML = "IMC 502.14: where engines run in place, connect source-capture to the tailpipe and provide the room ventilation in IMC 403. A wall fan or a CO sensor is not the hose. Discharge outdoors — not into the return. CNG/hydrogen bays still follow 502.16 (low inlets, high outlets) — <a href=\"/cng-repair-exhaust/\">502.16</a>." + cta;
      } else if (run === "move") {
        title.textContent = "The exception is move-in / move-out, EV-only, or a 1–2 family garage — not a 20-minute scan.";
        body.innerHTML = "If engines only run long enough to park, or the space is EV-only, or it is a one- or two-family dwelling, 502.14 source capture is not the trigger. Enclosed parking still has a 404 path — <a href=\"/parking-garage-ventilation/\">404</a>. If diagnosis starts happening in the bay, the exception no longer fits." + cta;
      } else {
        title.textContent = "Tailpipe capture and outdoor discharge have evidence. Keep 403 room ventilation in view.";
        body.innerHTML = "Pits and basements that can see Class I liquids or LP-gas still need exhaust so vapor cannot pool (502.13–502.15). Spray in the same shop is 502.7 — <a href=\"/spray-finish-exhaust/\">502.7</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-14", run: run, hose: hose });
    });
  }


  var sprayex = $("sprayex-form");
  if (sprayex) {
    sprayex.addEventListener("submit", function (e) {
      e.preventDefault();
      var lock = ($("sprayex-lock") && $("sprayex-lock").value) || "";
      var air = ($("sprayex-air") && $("sprayex-air").value) || "";
      var box = $("sprayex-result"), title = $("sprayex-result-title"), body = $("sprayex-result-body");
      show(box);
      var cta = ' <a href="' + contact("exhaust") + '">Send the booth cut and the control note</a> · <a href="/spray-finish-exhaust/">Spray-finish exhaust</a>.';
      if (!lock || !air) {
        title.textContent = "Pick whether the gun is interlocked and where the air goes.";
        body.textContent = "This is not a spray-booth design.";
        return;
      }
      if (lock === "none" || air === "ret") {
        title.textContent = "If the spray gun still runs when the fan is off, it is not 502.7.";
        body.innerHTML = "Run exhaust during and after spraying — including during construction. Interlock so spray cannot run without exhaust. Recirculation is the exception: vapors below 25% of the lower flammable limit (LFL), with monitoring and automatic shutdown. Each booth or room gets its own exhaust to outdoors unless the manifold rules are documented. Non-sparking fan wheels; motors out of the airstream — <a href=\"/hazardous-exhaust-fans/\">503</a>." + cta;
      } else {
        title.textContent = "Interlock and outdoor path have evidence. Keep 503 fan construction in view.";
        body.innerHTML = "Enclosed Class I organic coating is a different 502.12 row (1 cfm per square foot at the floor) — <a href=\"/organic-coating-exhaust/\">502.12</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-502-7", lock: lock, air: air });
    });
  }


  var undercut = $("undercut-form");
  if (undercut) {
    undercut.addEventListener("submit", function (e) {
      e.preventDefault();
      var kind = ($("undercut-kind") && $("undercut-kind").value) || "";
      var alt = ($("undercut-alt") && $("undercut-alt").value) || "";
      var hSel = ($("undercut-h") && $("undercut-h").value) || "";
      var w = parseFloat(($("undercut-w") && $("undercut-w").value) || "") || 0;
      var cfm = parseFloat(($("undercut-cfm") && $("undercut-cfm").value) || "") || 0;
      var h = parseFloat(hSel);
      var box = $("undercut-result"), title = $("undercut-result-title"), body = $("undercut-result-body");
      show(box);
      var cta = ' <a href="' + contact("ducts") + '">Send the supply to the room and a photo of the door</a> · <a href="/return-transfer-openings/">Undercuts & jump ducts</a>.';
      if (!kind || !alt || hSel === "") {
        title.textContent = "Pick the room type, undercut, and whether a jump duct or dedicated return exists.";
        body.textContent = "This is not a duct design.";
        return;
      }
      var doorW = (w > 0) ? w : 32;
      var area = (h > 0) ? (doorW * h) : 0;
      var areaTxt = area ? (Math.round(area) + " in² gross (door " + doorW + " in × " + h + " in undercut, before carpet and door swing)") : "no undercut";
      if (alt === "ret") {
        title.textContent = "A dedicated return in the room is the clean 601.5 path.";
        body.innerHTML = "Return from that room still cannot exceed the supply delivered to it. Stay 10 feet from an open combustion chamber or draft hood in the same space. Do not take return from a bath, kitchen, garage, or another dwelling unit unless a listed exception applies. <a href=\"/return-air/\">601 prohibited locations</a>." + cta;
      } else if (kind === "closet" && alt === "none" && h < 1.5) {
        title.textContent = "Closets under 30 square feet need a 1½-inch undercut, a louvered door, or 30 in² net free area.";
        body.innerHTML = "That closet return can serve only that closet. A ¾-inch gap is not the 601.5 closet path. Gross undercut now: " + areaTxt + "." + cta;
      } else if (alt === "none" && cfm > 0 && area > 0 && area < cfm) {
        title.textContent = "A ¾-inch undercut is not a return-air design.";
        body.innerHTML = "Gross undercut: " + areaTxt + ". Field recommendation (not a code minimum): about 1 in² of transfer opening per 1 cfm delivered. At " + cfm + " cfm, that is on the order of " + cfm + " in² — this undercut is smaller. Higher-airflow rooms usually need a transfer grille or a jump duct. Size openings to the manufacturer, ACCA Manual D, or the PE. Type I hoods are 508, not an undercut — <a href=\"/makeup-air/\">508</a>." + cta;
      } else if (alt === "none" && (cfm <= 0 || area <= 0)) {
        title.textContent = "Do not assume a door undercut alone will balance the room.";
        body.innerHTML = "Gross undercut: " + areaTxt + ". A ¾-inch undercut at a 32-inch door is only about 24 in² gross. Enter the supply cfm to compare against the ~1 in² per cfm field recommendation, or add a jump duct / transfer grille. Closets under 30 sf still need 1½ inch or 30 in² net free area." + cta;
      } else if (kind === "closet") {
        title.textContent = "Closet 1½-inch / 30 in² path has evidence. Keep it serving only that closet.";
        body.innerHTML = "Gross undercut: " + areaTxt + ". If you used a grille, call out net free area, not nominal. Jump ducts through rated construction are a 607 question." + cta;
      } else {
        title.textContent = "A jump duct or transfer grille is the usual answer once the undercut is too small.";
        body.innerHTML = "Gross undercut: " + areaTxt + ". Size the grille or jump duct to the manufacturer, ACCA Manual D, or the PE. The 1 in² per cfm figure is a Daily Code Talk field recommendation, not a code minimum. Exhaust-only rooms are still 501.4 — <a href=\"/transfer-air/\">501.4</a>." + cta;
      }
      track("Field Tool Result", { tool: "imc-601-5", kind: kind, alt: alt, area: area, cfm: cfm });
    });
  }


  var filt = $("tool-filter");
  if (filt) {
    filt.addEventListener("input", function () {
      var s = (filt.value || "").toLowerCase().trim();
      var any = false;
      document.querySelectorAll(".tool").forEach(function (el) {
        var hay = (el.textContent || "").toLowerCase();
        var hide = !!(s && hay.indexOf(s) === -1);
        el.hidden = hide;
        if (!hide) any = true;
      });
      var empty = $("tool-filter-empty");
      if (empty) empty.hidden = !s || any;
    });
  }

  if (document.querySelector(".tool")) {
    var index = document.getElementById("tools-index") || document.getElementById("tool-filter");
    if (index && !index.id) index.id = "tools-index";
    var topHref = "#tools-index";
    document.querySelectorAll(".tool").forEach(function (el) {
      if (el.querySelector(".back-to-tools-link")) return;
      var p = document.createElement("p");
      p.className = "back-to-tools-inline";
      p.innerHTML = '<a class="back-to-tools-link" href="' + topHref + '">' + (ES ? "↑ Lista de herramientas" : "↑ Back to tool list") + "</a>";
      el.appendChild(p);
    });
    if (!document.getElementById("back-to-tools")) {
      var btn = document.createElement("a");
      btn.id = "back-to-tools";
      btn.className = "back-to-tools";
      btn.href = topHref;
      btn.textContent = ES ? "↑ Herramientas" : "↑ Tools";
      btn.setAttribute("aria-label", ES ? "Volver a la lista de herramientas" : "Back to the tool list at the top");
      document.body.appendChild(btn);
      function vis() {
        btn.classList.toggle("is-on", window.scrollY > 360);
      }
      window.addEventListener("scroll", vis, { passive: true });
      vis();
    }
  }

})();
