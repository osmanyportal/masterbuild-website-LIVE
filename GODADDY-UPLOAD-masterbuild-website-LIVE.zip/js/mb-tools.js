/* Masterbuild Consulting — educational field tools. Not project-specific engineering. */
(function () {
  function $(id) { return document.getElementById(id); }
  var ES = document.documentElement.lang === "es";
  function contact(type) {
    return (ES ? "/contacto/" : "/send/") + (type ? "?type=" + type : "");
  }
  function show(el) {
    if (!el) return;
    el.hidden = false;
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
  }
  function track(name, props) {
    if (window.trackMBEvent) window.trackMBEvent(name, props || {});
  }
  function n(x) { return Math.round(x * 10) / 10; }
  function copyText(btn, text) {
    if (!text) return;
    function ok() { if (btn) btn.textContent = ES ? "Copiado" : "Copied"; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(ok).catch(function () {});
    }
  }

  /* ── Kitchen Type I / Type II pathfinder ───────────────────────────── */
  var kitchenForm = $("kitchen-path");
  if (kitchenForm) {
    kitchenForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var cook = (kitchenForm.cook && kitchenForm.cook.value) || "";
      var box = $("kitchen-result");
      var title = $("kitchen-result-title");
      var body = $("kitchen-result-body");
      var next = $("kitchen-result-next");
      if (!cook) {
        show(box);
        title.textContent = "Select the cooking that actually happens.";
        body.textContent = "The hood type follows the contaminant, not the room name. A “restaurant TI” can be Type I, Type II, or no hood — the equipment schedule decides.";
        next.innerHTML = '<a class="cta-primary" href="' + contact('kitchen') + '">Send the equipment schedule</a>';
        return;
      }
      var map = {
        grease: {
          t: "Likely Type I path (grease-laden vapor).",
          b: "Fryers, griddles, charbroilers, woks, smokers, and open-flame cooking typically drive IMC Chapter 5 Type I: listed or engineered hood, grease duct (506), makeup air (508), and suppression coordination. Confirm the listing, the menu, and the AHJ path before anyone prices a Type II or a residential hood.",
          href: "/send/?type=kitchen"
        },
        steam: {
          t: "Type II may apply if there is no grease-laden vapor.",
          b: "Dishwashers, steamers, and some ovens that produce heat and moisture (not grease) often sit on the Type II path. If the same line also fries or grills, the grease appliance usually controls the whole hood. Do not let a “light prep” label override the equipment schedule.",
          href: "/send/?type=kitchen"
        },
        none: {
          t: "A commercial hood may not be required.",
          b: "Microwave, beverage, and no-cook service usually do not trigger IMC 507. Still confirm warming equipment, any under-counter dishwashers, and whether the occupancy itself imposes a different exhaust rule. When in doubt, send the equipment cut sheets.",
          href: "/send/?type=kitchen"
        },
        dwelling: {
          t: "Dwelling-unit cooking is usually IMC 505, not 507.",
          b: "A range in a dwelling unit follows domestic cooking exhaust rules, including makeup air when the exhaust is large enough. Do not copy a Type I restaurant spec onto a condo kitchen without checking occupancy and 505 vs 507.",
          href: "/send/?type=kitchen"
        },
        residential_commercial: {
          t: "Residential-style cooking in a commercial occupancy needs a close read of IMC 505.6–505.8.",
          b: "A residential range in I-2, R, or similar occupancies is not automatically a Type I restaurant hood, and it is not automatically exempt. The occupancy, the appliance, and the exhaust path have to be shown. This is a frequent Miami TI comment.",
          href: "/send/?type=kitchen"
        },
        mixed: {
          t: "Mixed or unknown menu — do not guess the hood type.",
          b: "Send the architectural plan and the kitchen equipment schedule. Masterbuild will say whether the set is Type I, Type II, a 505 path, or a split system before anyone prices grease duct.",
          href: "/send/?type=kitchen"
        }
      };
      var hit = map[cook] || map.mixed;
      show(box);
      title.textContent = hit.t;
      body.textContent = hit.b + " This is educational classification against the model IMC, not a determination for your permit.";
      next.innerHTML = '<a class="cta-primary" href="' + contact('kitchen') + '">' + (ES ? 'Enviar el plano de cocina' : 'Send the kitchen plan') + '</a> <a href="/commercial-kitchen-ventilation/">Kitchen exhaust hub</a> <a href="/field-tools/#makeup">Makeup-air check</a>';
      track("Field Tool Result", { tool: "kitchen-path", result: cook });
    });
  }

  /* ── Outdoor-air occupancy estimator (IMC Table 403.3.1.1 educational) */
  var OA = {
    office: { label: "Office space", rp: 5, ra: 0.06, dens: 5 },
    conference: { label: "Conference / meeting", rp: 5, ra: 0.06, dens: 50 },
    lobby: { label: "Main entry lobby", rp: 5, ra: 0.06, dens: 10 },
    reception: { label: "Reception", rp: 5, ra: 0.06, dens: 30 },
    classroom: { label: "Classroom (age 9+)", rp: 10, ra: 0.12, dens: 35 },
    lecture: { label: "Lecture classroom", rp: 7.5, ra: 0.06, dens: 65 },
    computer: { label: "Computer lab", rp: 10, ra: 0.12, dens: 25 },
    dining: { label: "Restaurant dining", rp: 7.5, ra: 0.18, dens: 70 },
    cafe: { label: "Cafeteria / fast-food dining", rp: 7.5, ra: 0.18, dens: 100 },
    kitchen: { label: "Kitchen (cooking)", rp: 7.5, ra: 0.12, dens: 20 },
    retail: { label: "Retail sales", rp: 7.5, ra: 0.12, dens: 15 },
    mall: { label: "Mall common area", rp: 7.5, ra: 0.06, dens: 40 },
    market: { label: "Supermarket", rp: 7.5, ra: 0.06, dens: 8 },
    salon: { label: "Beauty / nail salon", rp: 20, ra: 0.12, dens: 25 },
    gym: { label: "Gym / sports play area", rp: 20, ra: 0.18, dens: 7 },
    aerobics: { label: "Health club / aerobics", rp: 20, ra: 0.06, dens: 40 },
    weights: { label: "Health club / weights", rp: 20, ra: 0.06, dens: 10 },
    auditorium: { label: "Auditorium seating", rp: 5, ra: 0.06, dens: 150 },
    worship: { label: "Place of religious worship", rp: 5, ra: 0.06, dens: 120 },
    library: { label: "Library", rp: 5, ra: 0.12, dens: 10 },
    corridor: { label: "Corridor", rp: 0, ra: 0.06, dens: 0 },
    warehouse: { label: "Warehouse", rp: 10, ra: 0.06, dens: 0 },
    hotel: { label: "Hotel bedroom / living room", rp: 5, ra: 0.06, dens: 10 }
  };

  var oaForm = $("oa-form");
  if (oaForm) {
    oaForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var key = oaForm.occ.value;
      var area = parseFloat(oaForm.area.value);
      var peopleIn = oaForm.people.value === "" ? null : parseFloat(oaForm.people.value);
      var box = $("oa-result");
      var title = $("oa-result-title");
      var body = $("oa-result-body");
      if (!key || !(area > 0)) {
        show(box);
        title.textContent = "Enter occupancy and area.";
        body.textContent = "Breathing-zone outdoor air is Rp × people + Ra × area. Area must be a positive number in square feet.";
        return;
      }
      var row = OA[key];
      var defaultP = row.dens > 0 ? (row.dens * area) / 1000 : 0;
      var P = (peopleIn != null && peopleIn >= 0) ? peopleIn : defaultP;
      var peoplePart = row.rp * P;
      var areaPart = row.ra * area;
      var vbz = peoplePart + areaPart;
      show(box);
      title.textContent = row.label + ": breathing-zone outdoor air ≈ " + n(vbz) + " cfm.";
      body.innerHTML =
        "Vbz = Rp × Pz + Ra × Az = " + row.rp + " × " + n(P) + " + " + row.ra + " × " + n(area) +
        " = <strong>" + n(vbz) + " cfm</strong>." +
        (peopleIn == null && row.dens > 0
          ? " People defaulted from Table 403.3.1.1 density (" + row.dens + " / 1,000 sf) → " + n(defaultP) + " people."
          : peopleIn == null
            ? " This occupancy has no default people density in the educational table; only the area term was used unless you enter a headcount."
            : " Using your entered headcount (" + n(P) + "), not the table default of " + n(defaultP) + ".") +
        " This is breathing-zone outdoor air (Vbz) from IMC Table 403.3.1.1 educational rates (2024 model). System outdoor air (Vot) can be higher after zone air-distribution effectiveness, multiple-zone correction, exhaust makeup, and ASHRAE 62.1 Appendix A. Healthcare and I-2 spaces generally follow ASHRAE 170 / IMC 407, not this table. Verify the adopted edition and local amendments.";
      track("Field Tool Result", { tool: "oa-estimator", occ: key, vbz: n(vbz) });
    });
  }

  /* ── Recertification records pack ──────────────────────────────────── */
  var recForm = $("recert-pack");
  if (recForm) {
    recForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var have = [];
      var missing = [];
      recForm.querySelectorAll('input[name="rec-item"]').forEach(function (cb) {
        (cb.checked ? have : missing).push(cb.value);
      });
      var addr = (recForm.rec_address && recForm.rec_address.value.trim()) || "(address / folio not entered)";
      var year = (recForm.rec_year && recForm.rec_year.value.trim()) || "(year built not entered)";
      var lines = [];
      lines.push("Electrical Building Recertification readiness — records pack");
      lines.push("Property: " + addr);
      lines.push("Year built (as entered): " + year);
      lines.push("");
      lines.push("IN HAND:");
      if (have.length) have.forEach(function (x) { lines.push("  [x] " + x); });
      else lines.push("  (none checked — that is normal at first contact)");
      lines.push("");
      lines.push("STILL NEEDED / UNKNOWN:");
      if (missing.length) missing.forEach(function (x) { lines.push("  [ ] " + x); });
      else lines.push("  (checklist complete — still confirm the notice itself)");
      lines.push("");
      lines.push("Missing records are normal. The readiness step exists to establish what exists before scope and fee are set.");
      lines.push("This list is not a due-date calculation and not a County requirement statement. Confirm every deadline against your notice.");
      var out = $("recert-copy");
      var box = $("recert-result");
      show(box);
      if (out) out.value = lines.join("\n");
      track("Field Tool Result", { tool: "recert-pack", have: have.length, missing: missing.length });
    });
    var copyBtn = $("recert-copy-btn");
    if (copyBtn) {
      copyBtn.addEventListener("click", function () {
        var out = $("recert-copy");
        if (!out || !out.value) return;
        copyText(copyBtn, out.value);
        track("Field Tool Copy", { tool: "recert-pack" });
      });
    }
  }

  /* ── Garage ventilation (IMC 404 educational) ──────────────────────── */
  var gForm = $("garage-form");
  if (gForm) {
    gForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var area = parseFloat(($("garea") && $("garea").value) || "");
      var mode = ($("gmode") && $("gmode").value) || "";
      var box = $("garage-result");
      var title = $("garage-result-title");
      var body = $("garage-result-body");
      if (!(area > 0) || !mode) {
        show(box);
        title.textContent = "Enter enclosed garage area and strategy.";
        body.textContent = "IMC 404 rates apply to enclosed parking garages. Open-garage definitions are a building-code question, not this estimator.";
        return;
      }
      var full = n(0.75 * area);
      var standby = n(0.05 * area);
      show(box);
      if (mode === "open") {
        title.textContent = "Confirm the garage is actually enclosed before using 404 rates.";
        body.innerHTML = "Louvers and “plenty of air” do not make an enclosed garage open. The adopted building-code definition of open parking garage controls. If it is enclosed, Full-On exhaust at 0.75 cfm/sf of " + n(area) + " sf is <strong>" + full + " cfm</strong>, and a CO/NO₂-automatic system still needs a Standby path at 0.05 cfm/sf = <strong>" + standby + " cfm</strong>.";
      } else if (mode === "continuous") {
        title.textContent = "Continuous path: exhaust ≈ " + full + " cfm (0.75 cfm/sf).";
        body.innerHTML = "Educational IMC 404 numbers for " + n(area) + " sf enclosed garage. Continuous operation at 0.75 cfm/sf → <strong>" + full + " cfm</strong>. Accessory rooms must stay positive to the garage. This is not fan selection, not a CO-control sequence, and not a sealed design. Daily Code Talk: <a href=\"/daily-code-talk/imc-404-enclosed-parking-garages-404-1-404-2/\">IMC 404</a>.";
      } else {
        title.textContent = "Automatic CO/NO₂ path: Full-On " + full + " cfm / Standby " + standby + " cfm.";
        body.innerHTML = "Educational IMC 404 numbers for " + n(area) + " sf. Automatic systems cycle between Full-On ≥ 0.75 cfm/sf (<strong>" + full + " cfm</strong>) and Standby ≥ 0.05 cfm/sf (<strong>" + standby + " cfm</strong>). Detectors listed to UL 2075, fail-safe to Full-On, accessory rooms positive to the garage. The common rejection is sizing for continuous 0.75 and calling it automatic — or the reverse. Verify adopted FBC Mechanical and Miami-Dade amendments.";
      }
      track("Field Tool Result", { tool: "garage-404", mode: mode, full: full });
    });
  }

  /* ── Combustion-air method (IMC Ch. 7 educational) ─────────────────── */
  var cForm = $("combustion-form");
  if (cForm) {
    cForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var btuEl = $("cbtu");
      var volEl = $("cvol");
      var methodEl = $("cmethod");
      var btu = parseFloat(btuEl && btuEl.value);
      var vol = volEl && volEl.value === "" ? null : parseFloat(volEl && volEl.value);
      var method = (methodEl && methodEl.value) || "";
      var box = $("combustion-result");
      var title = $("combustion-result-title");
      var body = $("combustion-result-body");
      if (!(btu > 0) || !method) {
        show(box);
        title.textContent = "Enter appliance input (Btu/h) and a method.";
        body.textContent = "Direct-vent and outdoor appliances follow the listing, not these indoor-opening numbers. Confirm the listing first.";
        return;
      }
      var k = btu / 1000;
      var indoorNeed = n(50 * k);
      var twoOpen = n(k / 4); /* 1 in² per 4,000 Btu/h each */
      var oneOpen = n(k / 3); /* 1 in² per 3,000 Btu/h */
      var mech = n(0.35 * k); /* 0.35 cfm per 1,000 Btu/h */
      show(box);
      if (method === "direct") {
        title.textContent = "Direct-vent / sealed combustion follows the listing, not Chapter 7 openings.";
        body.innerHTML = "If the appliance is listed as direct-vent and installed to that listing, indoor-volume and outdoor-opening tables usually do not apply. Replacement in a sealed closet still needs the listing, the vent path, and any remaining atmospheric appliances in the same room. Send the cut sheet.";
      } else if (method === "indoor") {
        var ok = (vol != null && vol >= indoorNeed);
        title.textContent = ok
          ? "Indoor volume appears to meet the 50 ft³ / 1,000 Btu/h educational check."
          : "Indoor volume may be short of the 50 ft³ / 1,000 Btu/h educational check.";
        body.innerHTML = "Appliance input " + n(btu) + " Btu/h. Educational indoor-volume requirement ≈ <strong>" + indoorNeed + " ft³</strong>" +
          (vol != null ? " vs entered volume " + n(vol) + " ft³." : ". Enter the combined room volume to compare.") +
          " Tight construction, exhaust fans, and other appliances in the same volume change this. Free area of openings is not the same as nominal louver size. Verify IMC 703 and the adopted FBC Mechanical.";
      } else if (method === "outdoor2") {
        title.textContent = "Two outdoor openings: ≈ " + twoOpen + " in² free area each (1 in² / 4,000 Btu/h).";
        body.innerHTML = "Educational 2024 IMC outdoor two-opening path for " + n(btu) + " Btu/h. Each opening ≈ <strong>" + twoOpen + " in² net free area</strong> when communicating directly outdoors. Horizontal ducts are tighter (1 in² / 2,000 Btu/h). Screens, dampers, and louver blades reduce free area below the rough opening. Dampered openings must interlock with the appliance.";
      } else if (method === "outdoor1") {
        title.textContent = "One permanent outdoor opening: ≈ " + oneOpen + " in² free area (1 in² / 3,000 Btu/h).";
        body.innerHTML = "Educational 2024 IMC one-opening path for " + n(btu) + " Btu/h → <strong>" + oneOpen + " in² net free area</strong>, with the opening typically within 12 in of the top of the enclosure and not smaller than the vent area. Confirm IMC 704 and the listing. This is not a louver schedule.";
      } else {
        title.textContent = "Mechanical combustion air: ≈ " + mech + " cfm from outdoors (0.35 cfm / 1,000 Btu/h).";
        body.innerHTML = "Educational IMC 706 rate for " + n(btu) + " Btu/h → <strong>" + mech + " cfm</strong> supplied from outdoors, interlocked so the appliance cannot fire without the fan. Engineered systems and listed packages override this table. Send the closet dimensions and the cut sheets.";
      }
      track("Field Tool Result", { tool: "combustion-air", method: method });
    });
  }

  /* ── Makeup air equality check (IMC 508 educational) ───────────────── */
  var mForm = $("makeup-form");
  if (mForm) {
    mForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var ex = parseFloat(($("mexh") && $("mexh").value) || "");
      var mu = !$("mmua") || $("mmua").value === "" ? 0 : parseFloat($("mmua").value);
      var box = $("makeup-result");
      var title = $("makeup-result-title");
      var body = $("makeup-result-body");
      if (!(ex > 0)) {
        show(box);
        title.textContent = "Enter hood / kitchen exhaust cfm.";
        body.textContent = "IMC 508 requires replacement air approximately equal to the exhaust. Transfer air can count when the source is suitable — dining OA is not automatically available.";
        return;
      }
      var gap = n(ex - mu);
      show(box);
      if (mu <= 0) {
        title.textContent = "No makeup air entered — that is the usual comment.";
        body.innerHTML = "Exhaust " + n(ex) + " cfm with no identified replacement air. Plan review will ask where the air comes from. Dedicated makeup, transfer from a ventilated adjacent space, and outdoor-air units can combine — but the path, temperature, and interlock have to be on the drawings. See <a href=\"/daily-code-talk/imc-508-commercial-kitchen-makeup-air/\">IMC 508</a>.";
      } else if (Math.abs(gap) <= Math.max(50, 0.1 * ex)) {
        title.textContent = "Exhaust and makeup are in the same neighborhood (" + n(ex) + " vs " + n(mu) + " cfm).";
        body.innerHTML = "Educational 508 check only. “Approximately equal” is not a 10% rule of thumb you can rest a permit on. Capture, door swing, dining pressure, and whether the makeup is actually available when the hood is on still have to be shown. Location of the makeup register relative to the hood lip matters as much as the cfm.";
      } else if (gap > 0) {
        title.textContent = "Makeup is short of exhaust by ≈ " + gap + " cfm.";
        body.innerHTML = "Exhaust " + n(ex) + " cfm vs makeup " + n(mu) + " cfm. That shortfall is either transfer air (identify the source and that it remains available) or a missing unit. Tight Miami TIs often try to steal dining OA that the occupancy table already assigned to people. Send the hood schedule and the HVAC zoning.";
      } else {
        title.textContent = "Makeup exceeds exhaust by ≈ " + n(mu - ex) + " cfm.";
        body.innerHTML = "More makeup than exhaust can pressurize the kitchen into dining or corridors and push grease and odor. Confirm the design intent (slightly negative kitchen is typical) and whether the extra air is a diversity, a future hood, or a schedule mismatch.";
      }
      track("Field Tool Result", { tool: "makeup-508", gap: gap });
    });
  }

  /* ── Fire / smoke damper pathfinder (IMC 607 educational) ──────────── */
  var dForm = $("damper-form");
  if (dForm) {
    dForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var fire = ($("dfire") && $("dfire").value) || "";
      var smoke = ($("dsmoke") && $("dsmoke").value) || "";
      var shaft = ($("dshaft") && $("dshaft").value) || "";
      var box = $("damper-result");
      var title = $("damper-result-title");
      var body = $("damper-result-body");
      if (!fire || !smoke || !shaft) {
        show(box);
        title.textContent = "Answer all three — the assembly type controls the damper.";
        body.textContent = "A typical that says “F/S damper where required” is a comment magnet. Each crossing needs assembly type, listing, access, and any smoke-control interface.";
        return;
      }
      var bits = [];
      if (fire === "yes") bits.push("fire damper (or combination) where a duct penetrates a fire-resistance-rated assembly");
      if (smoke === "yes") bits.push("smoke damper (or combination) at a smoke barrier / smoke partition, with the actuator and detection as required");
      if (shaft === "yes") bits.push("shaft protection — often a combination fire/smoke damper at the shaft penetration, with access from an occupied side");
      show(box);
      if (fire === "unsure" || smoke === "unsure" || shaft === "unsure") {
        title.textContent = "Do not guess the rating. Send the architectural rated-plan.";
        body.innerHTML = "IMC 607 follows the assembly the architect identified, not a mechanical typical. If the wall is unrated, a damper may not be required — and installing one “just in case” can still be wrong (access, listing, smoke-control interface). Send reflected-ceiling plans and the rated-assembly sheets. More: <a href=\"/duct-systems/\">duct systems hub</a> · <a href=\"/daily-code-talk/imc-607-part-1-607-1-607-2-1/\">IMC 607 Part 1</a>.";
      } else if (!bits.length) {
        title.textContent = "No rated crossing described — a damper may not be required at this opening.";
        body.innerHTML = "Unrated partitions do not automatically need fire or smoke dampers. Confirm the architect’s rating legend anyway; corridor walls, incidental-use separations, and smoke partitions are easy to miss. This is educational, not a 607 determination.";
      } else {
        title.textContent = "Likely path: " + bits[0] + (bits.length > 1 ? "; also " + bits.slice(1).join("; ") : "") + ".";
        body.innerHTML = "Show on the M-sheet: assembly type and rating, damper type (fire / smoke / combination), listing, access door, and any smoke-control or fire-alarm interface. Ceiling radiation dampers are a different product for rated floor/ceiling membranes. Exceptions exist (fully ducted in some assemblies, steel ducts in some shafts) — do not take an exception without citing it. Not a listing selection.";
      }
      track("Field Tool Result", { tool: "damper-607", fire: fire, smoke: smoke, shaft: shaft });
    });
  }

  /* ── Comment classifier ────────────────────────────────────────────── */
  var kForm = $("comment-form");
  if (kForm) {
    kForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var key = ($("ckind") && $("ckind").value) || "";
      var box = $("comment-result");
      var title = $("comment-result-title");
      var body = $("comment-result-body");
      var next = $("comment-result-next");
      var lib = {
        oa: {
          t: "Outdoor-air / ventilation comment.",
          b: "Reviewer wants occupancy, area, people, method, and the resulting cfm on the M-sheets — not “OA per code.” Run the estimator, then send the architectural occupancy plan.",
          href: "/send/?type=ventilation",
          more: "/ventilation/"
        },
        kitchen: {
          t: "Kitchen hood / grease / makeup comment.",
          b: "Usually missing hood type, grease-duct construction, termination, makeup air, or suppression interface. The equipment schedule decides Type I vs Type II.",
          href: "/send/?type=kitchen",
          more: "/commercial-kitchen-ventilation/"
        },
        damper: {
          t: "Fire/smoke damper or rated-penetration comment.",
          b: "Each crossing needs assembly type, damper basis, listing, and access. A typical “F/S where required” is what generated the comment.",
          href: "/send/?type=ducts",
          more: "/duct-systems/"
        },
        garage: {
          t: "Garage ventilation / CO-control comment.",
          b: "State continuous vs automatic, Full-On and Standby cfm, detector listing, and accessory-room pressure. Do not copy Table 403 onto a garage.",
          href: "/send/?type=garage",
          more: "/parking-garage-ventilation/"
        },
        combustion: {
          t: "Combustion-air / venting comment.",
          b: "Method, free area (not nominal louver), damper interlock, and existing-closet constraints. Replacement units in original closets are a frequent miss.",
          href: "/send/?type=combustion",
          more: "/combustion-air/"
        },
        load: {
          t: "Load-calculation / energy-forms comment.",
          b: "IMC 312 plus Florida energy forms. Send architectural plans, zoning assumptions, and any forms already started.",
          href: "/send/?type=load",
          more: "/hvac-load-calculations/"
        },
        recert: {
          t: "Electrical recertification / existing-building electrical.",
          b: "This is the County electrical path, not the statewide structural milestone inspection. Send the notice first. Deadlines live on the notice, not on a website calculator.",
          href: "/send/?type=recertification",
          more: "/electrical-building-recertification-miami/"
        },
        access: {
          t: "Access / clearance / condensate / location comment.",
          b: "IMC 303–307: equipment location, service space, roof access, condensate disposal. Photos of the room often close the comment faster than a revised typical.",
          href: "/send/?type=comments",
          more: "/permit-comment-response/"
        },
        plumbing: {
          t: "Plumbing / grease / isometric comment.",
          b: "Fixture units, isometrics, grease interceptor, and Miami-Dade plumbing checklists. Septic and wells are a different County path.",
          href: "/send/?type=plumbing",
          more: "/plumbing/"
        },
        other: {
          t: "Send the letter. Do not paraphrase it.",
          b: "The actual comment text, the current set, the permit number, and which comments you want Masterbuild to own. That is enough to start a written resubmittal path.",
          href: "/send/?type=comments",
          more: "/typical-plan-review-comments/"
        }
      };
      var hit = lib[key] || lib.other;
      show(box);
      title.textContent = hit.t;
      body.textContent = hit.b + " Educational triage only — not a code opinion on your letter.";
      next.innerHTML = '<a class="cta-primary" href="' + contact(key === "recert" ? "recertification" : (key === "other" || !key ? "comments" : key)) + '">' + (ES ? "Enviar la carta" : "Send the comment letter") + '</a> <a href="' + hit.more + '">' + (ES ? "Abrir el centro" : "Open the hub") + '</a> <a href="/typical-plan-review-comments/">Typical comments</a>';
      track("Field Tool Result", { tool: "comment-classifier", kind: key });
    });
  }

  /* ── IMC 401 vs 403 method ─────────────────────────────────────────── */
  var om = $("oa-method-form");
  if (om) {
    om.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = ($("oamethod") && $("oamethod").value) || "";
      var box = $("oa-method-result");
      var title = $("oa-method-result-title");
      var body = $("oa-method-result-body");
      var map = {
        mech: {
          t: "Mechanical outdoor air — Table 403 / 62.1 is the educational path.",
          b: "Vbz = Rp × people + Ra × area, then system outdoor air after zone effectiveness. Run the occupancy estimator. Do not write “OA per code.”"
        },
        natural: {
          t: "Natural ventilation is IMC 402, not Table 403 cfm.",
          b: "Openable area, occupant access, and whether the climate actually uses the openings control this path. Miami-conditioned buildings that lock the windows are not a 402 system. If the AHJ expects mechanical OA, 402 will not save a comment."
        },
        mixed: {
          t: "Mixed method — identify which rooms are which.",
          b: "A note that “some areas are naturally ventilated” is a comment magnet. Each occupancy needs a method on the M-sheet. Send the architectural floor plan."
        },
        exhaust: {
          t: "Exhaust without identified outdoor air is a makeup-air problem.",
          b: "Restrooms, kitchens, and garages that only show exhaust will get the 508 / 404 / 403 question. Show where replacement air comes from. Kitchen: use the makeup-air check. Garage: use the 404 estimator."
        }
      };
      var hit = map[v];
      show(box);
      if (!hit) {
        title.textContent = "Select how outdoor air is actually provided.";
        body.textContent = "The method is a drawing question, not a typical.";
        return;
      }
      title.textContent = hit.t;
      body.innerHTML = hit.b + ' <a href="' + contact("ventilation") + '">Send the occupancy plan</a>.';
      track("Field Tool Result", { tool: "oa-method", result: v });
    });
  }

  var pv = $("plumbing-ve-form");
  if (pv) {
    pv.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = ($("pve") && $("pve").value) || "";
      var box = $("plumbing-ve-result");
      var title = $("plumbing-ve-result-title");
      var body = $("plumbing-ve-result-body");
      var map = {
        iso: {
          t: "Skipping the isometric is not VE.",
          b: "Plan view of fixtures is not a reviewable waste/vent diagram. Miami-Dade commercial plumbing checklists already expect isometrics. Draw them or expect the comment."
        },
        grease: {
          t: "Grease interceptor cuts fail twice — review and inspection.",
          b: "If the mechanical sheets show Type I, plumbing needs a grease path now: basis, location, access, sample port. Deferring it to ‘later’ is two comments, not a savings."
        },
        stack: {
          t: "New load on an undocumented stack needs fixture units.",
          b: "Adding fixtures to ‘the existing riser’ without a unit calculation is how TIs fail. Photos of the stack plus the new fixture list is the start of the inquiry."
        },
        wh: {
          t: "Closet water-heater cuts are combustion + plumbing.",
          b: "Pan, relief, listing, and combustion air (or direct-vent listing). Deleting the louver to recover square footage is a Chapter 7 coordination miss."
        },
        sewer: {
          t: "Do not assume public sewer.",
          b: "If the street has no sewer, stop and run the OSTDS / septic screen before anyone prices underground. Wells are a different County path."
        },
        other: {
          t: "Send the plan and the cut list.",
          b: "The architectural plumbing plan, fixture list, and what someone wants to delete. Masterbuild will say what still has to be shown."
        }
      };
      var hit = map[v];
      show(box);
      if (!hit) {
        title.textContent = "Select the cut that is about to happen.";
        body.textContent = "This classifier flags permit and inspection risk. It does not size an interceptor.";
        return;
      }
      title.textContent = hit.t;
      body.innerHTML = hit.b + ' <a href="' + contact("plumbing") + '">Send the plumbing plan</a> · <a href="/plumbing-value-engineering/">VE hub</a>.';
      track("Field Tool Result", { tool: "plumbing-ve", result: v });
    });
  }

  var kp = $("kitplumb-form");
  if (kp) {
    kp.addEventListener("submit", function (e) {
      e.preventDefault();
      var hood = ($("kphood") && $("kphood").value) || "";
      var pint = ($("kpint") && $("kpint").value) || "";
      var box = $("kitplumb-result");
      var title = $("kitplumb-result-title");
      var body = $("kitplumb-result-body");
      show(box);
      if (!hood || !pint) {
        title.textContent = "Answer both sides of the set.";
        body.textContent = "The menu drives the hood and the interceptor. One typical cannot stand in for the other.";
        return;
      }
      if (pint === "septic") {
        title.textContent = "Stop. Confirm sewer vs OSTDS before anyone prices underground.";
        body.innerHTML = 'No public sewer is not a plumbing VE item. Open the <a href="/miami-dade-septic-feasibility/">septic screen</a> and send folio + intended use.';
      } else if (hood === "type1" && pint !== "yes") {
        title.textContent = "Type I without a grease path — two comments.";
        body.innerHTML = 'Mechanical is showing grease-laden cooking. Plumbing still needs interceptor basis, location, access, and sample port. “Later” fails review. <a href="' + contact("kitchen") + '">Send the equipment schedule</a> · <a href="/kitchen-plumbing-coordination/">coordination hub</a>.';
      } else if (hood === "type2" && pint === "yes") {
        title.textContent = "Interceptor with Type II — confirm the menu actually has no grease.";
        body.textContent = "If the menu later adds a fryer, both sheets are wrong. Confirm the equipment schedule is the real menu.";
      } else if (hood === "none" && pint === "yes") {
        title.textContent = "Interceptor without a hood — confirm occupancy.";
        body.textContent = "Food service without a hood can still need grease waste. Confirm the menu and whether this is a Type I miss on the M-sheets.";
      } else if (hood === "unsure" || pint === "later") {
        title.textContent = "Send both sets. Do not sequence the interceptor to after C.O.";
        body.innerHTML = '<a href="' + contact("kitchen") + '">Send kitchen + plumbing</a>.';
      } else {
        title.textContent = "Hood type and grease path appear to be talking to each other — still verify the menu.";
        body.innerHTML = 'Educational check only. Makeup air, termination, and isometric still have to be on the drawings. <a href="/kitchen-plumbing-coordination/">Coordination hub</a>.';
      }
      track("Field Tool Result", { tool: "kitplumb", hood: hood, pint: pint });
    });
  }

  var tf = $("term-form");
  if (tf) {
    tf.addEventListener("submit", function (e) {
      e.preventDefault();
      var where = ($("twhere") && $("twhere").value) || "";
      var intake = ($("tintake") && $("tintake").value) || "";
      var box = $("term-result");
      var title = $("term-result-title");
      var body = $("term-result-body");
      show(box);
      if (!where || !intake) {
        title.textContent = "Say where it terminates and whether an OA intake is in play.";
        body.textContent = "Plan review marks mystery outlets. The roof plan has to dimension this.";
        return;
      }
      var bits = [];
      if (where === "roof") {
        bits.push("Above-roof path: educational 506.3.13.1 wants the discharge opening at least 40 in above the roof surface — note it, do not hide it in a typical.");
      } else if (where === "wall") {
        bits.push("Through-wall is a special path (506.3.13.2): not a nuisance or fire hazard, not where the IBC requires protected openings, at least 3 ft from an exterior-wall opening, and 506.3.13.3 still applies. Tight Miami walls next to windows fail this often.");
      } else {
        bits.push("If the outlet is not shown, that is the comment. Identify ABOVE ROOF vs THRU WALL on the M-sheets.");
      }
      if (intake === "close" || intake === "unsure") {
        bits.push("506.3.13.3: 10 ft horizontally from, or 3 ft above, outdoor-air intakes (unless the 5 ft exception applies and discharge direction is drawn). Dimension the intake. “Nearby” is a redline.");
      }
      bits.push("Also check 10 ft to adjacent buildings / property lines and 10 ft above adjoining grade. The 5 ft exception requires discharge away from those locations, shown on the drawing.");
      title.textContent = "Dimension the outlet. Do not write “per IMC 506.”";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("kitchen") + '">Send the roof plan</a> · <a href="/grease-duct-termination/">termination hub</a> · <a href="/daily-code-talk/imc-506-part-4-506-3-13-exhaust-outlet-terminations/">DCT #62</a>.';
      track("Field Tool Result", { tool: "termination-506", where: where, intake: intake });
    });
  }

  var cf = $("cond-form");
  if (cf) {
    cf.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("cloc") && $("cloc").value) || "";
      var ov = ($("cover") && $("cover").value) || "";
      var box = $("cond-result");
      var title = $("cond-result-title");
      var body = $("cond-result-body");
      show(box);
      if (!loc || !ov) {
        title.textContent = "Say where the coil sits and whether overflow is drawn.";
        body.textContent = "307 is a water-damage section. Notes without a receptor fail review.";
        return;
      }
      var bits = [];
      if (loc === "ceiling" || loc === "elec") {
        bits.push("Highest-risk location: equipment above a finished ceiling, tenant space, or electrical room. Overflow protection and shutdown have to be on the drawing, not hoped for in the field.");
      } else if (loc === "roof") {
        bits.push("Outdoor/roof still needs an approved disposal point, slope, and freeze/nuisance path. “Onto the roof” is not automatically approved.");
      } else if (loc === "unsure") {
        bits.push("If the unit location is not shown relative to the space below, that is the comment.");
      } else {
        bits.push("Closet/mech room still needs primary route, slope, approved disposal, and overflow where damage is possible.");
      }
      if (ov === "note" || ov === "no") {
        bits.push("A “drain to nearest approved receptor” note is the common redline. Show receptor, slope, overflow (pan / line / water-level device), and pump shutdown if a pump is the only path. Indoor discharge generally stays in the same occupancy/tenant.");
      } else {
        bits.push("Overflow shown is a start. Still confirm disposal point, 1 percent slope, material/size, and that indoor discharge stays in the same occupancy.");
      }
      title.textContent = "If the primary drain stops, the set has to answer.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("mep") + '">Send the unit location</a> · <a href="/condensate/">condensate hub</a> · <a href="/daily-code-talk/imc-307-condensate-disposal/">DCT 307</a>.';
      track("Field Tool Result", { tool: "condensate-307", loc: loc, overflow: ov });
    });
  }

  var af = $("acc-form");
  if (af) {
    af.addEventListener("submit", function (e) {
      e.preventDefault();
      var loc = ($("aloc") && $("aloc").value) || "";
      var boxd = ($("abox") && $("abox").value) || "";
      var box = $("acc-result");
      var title = $("acc-result-title");
      var body = $("acc-result-body");
      show(box);
      if (!loc || !boxd) {
        title.textContent = "Say where the unit sits and whether the 30×30 is drawn.";
        body.textContent = "306 is an inspection gate. Notes without dimensions fail.";
        return;
      }
      var bits = [];
      if (loc === "roof") {
        bits.push("Roof path: hatch or permanent ladder and the walkway to each unit on the roof plan. A general note is a pre-occupancy hold.");
      } else if (loc === "attic") {
        bits.push("Attic / above-ceiling: service without removing permanent construction, plus a removal path for the largest appliance.");
      } else if (loc === "closet") {
        bits.push("Tight room/closet: 306.2 passage (36×80, dwelling exception is conditional) and 30×30 at the service side with the door open.");
      } else {
        bits.push("Mechanical room: door, 36 in × 80 in passage, 30×30 at the control/service side. Dimension the box.");
      }
      if (boxd === "note" || boxd === "no") {
        bits.push("30 in × 30 in level working space at the control/service side has to be drawn — listing clearances if they are larger. Adjacent ducts and structure will eat an undimensioned note.");
      }
      title.textContent = "Draw the service envelope. Do not note it.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("mep") + '">Send the equipment location</a> · <a href="/equipment-access/">access hub</a> · <a href="/daily-code-talk/imc-306-access-and-service-space-part-1/">DCT 306</a>.';
      track("Field Tool Result", { tool: "access-306", loc: loc, box: boxd });
    });
  }


  var df = $("dis-form");
  if (df) {
    df.addEventListener("submit", function (e) {
      e.preventDefault();
      var kind = ($("dkind") && $("dkind").value) || "";
      var near = ($("dnear") && $("dnear").value) || "";
      var box = $("dis-result");
      var title = $("dis-result-title");
      var body = $("dis-result-body");
      show(box);
      if (!kind || !near) {
        title.textContent = "Say what is exhausted and whether an intake is nearby.";
        body.textContent = "501.3 wants outdoor discharge that cannot be pulled back in.";
        return;
      }
      var bits = [];
      if (kind === "kitchen") {
        bits.push("Commercial kitchen grease is 506.3.13, not the environmental-air 3 ft / 10 ft row. Use the termination check.");
      } else if (kind === "dryer") {
        bits.push("Clothes dryers are IMC 504 (no screens, no screws, 3 ft from openings if the manufacturer is silent). Use the dryer check.");
      } else if (kind === "product") {
        bits.push("Product-conveying exhaust has larger separations than bathroom fans. Do not copy an environmental-air typical.");
      } else if (kind === "unsure") {
        bits.push("If the exhaust type is not identified, that is the comment. Label environmental vs grease vs dryer vs process.");
      } else {
        bits.push("Environmental air (educational 501.3.1 item 3): 3 ft to property lines; 3 ft to operable openings (not Group U); 10 ft to mechanical air intakes. Dimension them.");
      }
      if (near === "attic") {
        bits.push("Never into attics or crawl spaces (dwelling whole-house attic-fan exception is not a toilet fan). Keep it off walkways.");
      } else if (near === "close") {
        bits.push("Re-entrainment is the comment. Dimension to the intake and show discharge direction.");
      }
      title.textContent = "Dimension the outlet. Do not write “per 501.”";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("ventilation") + '">Send the elevation</a> · <a href="/exhaust-discharge/">501.3 hub</a>.';
      track("Field Tool Result", { tool: "discharge-501", kind: kind, near: near });
    });
  }
  var dry = $("dry-form");
  if (dry) {
    dry.addEventListener("submit", function (e) {
      e.preventDefault();
      var t = ($("dterm") && $("dterm").value) || "";
      var box = $("dry-result");
      var title = $("dry-result-title");
      var body = $("dry-result-body");
      show(box);
      var map = {
        ok: "Outdoor termination with a backdraft damper and a clean airstream is the start. Still confirm 3 ft from openings (if MI is silent), 12.5 in² open area, rated penetrations without a fire damper, and a lint cleanout on vertical risers.",
        screen: "No screens at the termination — lint trap and blockage risk. Outlet must stay full size (12.5 in² educational 504.4.2).",
        screws: "No fasteners protruding into the airstream. Joints per 603.9, not sheet-metal screws through the wall of the duct.",
        damper: "No fire damper or combination fire/smoke damper in a dryer duct. Maintain the assembly rating another way.",
        plenum: "Dryer ducts are independent. Do not connect to a vent connector, chimney, duct, or plenum.",
        unsure: "If the dryer duct is not on the M-sheets, that is the comment — especially through rated walls or a common riser."
      };
      title.textContent = "IMC 504 is a fire and lint section, not a flex-hose leftover.";
      body.innerHTML = (map[t] || "Pick the condition.") + ' <a href="' + contact("mep") + '">Send the routing</a> · <a href="/dryer-exhaust/">dryer hub</a>.';
      track("Field Tool Result", { tool: "dryer-504", term: t });
    });
  }


  var ch = $("chim-form");
  if (ch) {
    ch.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("ckind") && $("ckind").value) || "";
      var box = $("chim-result"), title = $("chim-result-title"), body = $("chim-result-body");
      show(box);
      var map = {
        factory: "IMC 805 listed-system path: match appliance and fuel, required UL standard (UL 103 Type HT / UL 127 / UL 959 as applicable), 30° / four-elbow offset limits, structural support for added load, listed shrouds only, insulation shield (attic: 2 in above insulation on the code-built path). Review it as one assembly from appliance to termination.",
        metal: "IMC 806.1 → NFPA 211. Show type, materials, supports, clearances, penetrations, termination, and access. A “per NFPA 211” note is not a drawing. Do not copy a factory-built typical onto a metal chimney.",
        line: "A line labeled “chimney” is the comment. Identify factory-built listed system vs metal chimney vs vent/connector, then draw the path.",
        unsure: "Send the appliance listing and a photo or routing sketch. Factory-built (805) and metal (806) are different code paths."
      };
      title.textContent = "Identify the system. Then draw it.";
      body.innerHTML = (map[k] || "Pick the type.") + ' <a href="' + contact("mep") + '">Send the routing</a> · <a href="/factory-built-chimneys/">805</a> · <a href="/metal-chimneys/">806</a>.';
      track("Field Tool Result", { tool: "chimney-805-806", kind: k });
    });
  }
  var lf = $("load-form");
  if (lf) {
    lf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("lkind") && $("lkind").value) || "";
      var box = $("load-result"), title = $("load-result-title"), body = $("load-result-body");
      show(box);
      var map = {
        cont: "Continuous load (educational Art. 100): maximum current expected for 3 hours or more. Permanently connected or “normally left on” is not automatically continuous. Duration is the question.",
        demand: "Demand factor is maximum demand divided by connected load. Do not apply a demand reduction without Code support for that occupancy/calculation. Connected load ≠ expected simultaneous demand.",
        mgmt: "Load management limits total load by controlling individual loads. Not every load may be shed. Document what is controlled, by what system, and whether the Code path allows it.",
        service: "Existing-service questions need more than nameplate addition: what operates together, for how long, what duty applies, and what can actually be controlled. That is an engineering evaluation under a written scope."
      };
      title.textContent = "Definitions first. Amps second.";
      body.innerHTML = (map[k] || "Pick the question.") + ' <a href="' + contact("mep") + '">Send the service question</a> · <a href="/continuous-load/">hub</a>.';
      track("Field Tool Result", { tool: "loaddef-100", kind: k });
    });
  }
  var ef = $("env-form");
  if (ef) {
    ef.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("eloc") && $("eloc").value) || "";
      var box = $("env-result"), title = $("env-result-title"), body = $("env-result-body");
      show(box);
      var map = {
        dry: "Dry: not normally subject to dampness or wetness. Temporary moisture does not automatically make it damp or wet. Still verify condensation around mechanical equipment.",
        damp: "Damp: protected from weather, not subject to saturation, moderate moisture. A covered exterior is a common damp location — not automatically dry. Rainproof / raintight / weatherproof / watertight are not interchangeable.",
        wet: "Wet: saturation or direct weather (and certain underground / earth-contact). Water exposure is expected. Select equipment and fittings for that location — “outdoor rated” is not enough.",
        cond: "Condensation around mechanical equipment is an environmental exposure. Do not ignore it because the room is “indoors.” Classify and match the enclosure.",
        unsure: "Classify dry / damp / wet before selecting the enclosure. Ask: direct rain? spray or accumulation? condensation? What rating is on the nameplate?"
      };
      title.textContent = "Classify the location. Then pick the enclosure.";
      body.innerHTML = (map[k] || "Pick the exposure.") + ' <a href="' + contact("mep") + '">Send the location photos</a> · <a href="/wet-location-electrical/">hub</a>.';
      track("Field Tool Result", { tool: "envloc-100", loc: k });
    });
  }


  var pf = $("pres-form");
  if (pf) {
    pf.addEventListener("submit", function (e) {
      e.preventDefault();
      var room = ($("proom") && $("proom").value) || "";
      var path = ($("ppath") && $("ppath").value) || "";
      var box = $("pres-result"), title = $("pres-result-title"), body = $("pres-result-body");
      show(box);
      if (!room || !path) {
        title.textContent = "Say what is exhausting and whether makeup is drawn.";
        body.textContent = "501.4 wants a path, not a note.";
        return;
      }
      var bits = [];
      if (room === "hood") {
        bits.push("Type I replacement air is IMC 508, not a bathroom undercut. Use the makeup-air hub.");
      } else if (room === "pos") {
        bits.push("If supply exceeds exhaust, 501.4 wants a relief path (natural or mechanical) for the excess. Show it.");
      } else if (room === "unsure") {
        bits.push("If pressure intent is not on M-101 (N / NEG / BAL), that is the comment.");
      } else {
        bits.push("Educational 501.4: for spaces other than Group R-3 and R-2 dwelling units, keep the space neutral or negative. Exhaust-only rooms need makeup to cover the deficit.");
      }
      if (path === "undercut") {
        bits.push("Do not rely on door undercuts alone for large offsets. Name the device and the path (transfer grille, OA, dedicated MAU).");
      } else if (path === "none") {
        bits.push("Nothing drawn is the comment. List required exhaust, supply, target pressure, makeup source, and relief method on M-601.");
      } else {
        bits.push("A drawn path is a start. Still confirm the makeup supports capture (feed the room, not the hood face) and that duct construction cites Chapter 6.");
      }
      title.textContent = "Balance on paper. Then draw the path.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("ventilation") + '">Send the room list</a> · <a href="/transfer-air/">501.4 hub</a>.';
      track("Field Tool Result", { tool: "pressure-5014", room: room, path: path });
    });
  }


  var af = $("attic-form");
  if (af) {
    af.addEventListener("submit", function (e) {
      e.preventDefault();
      var space = ($("aspace") && $("aspace").value) || "";
      var path = ($("apath") && $("apath").value) || "";
      var areaEl = $("area");
      var area = areaEl && areaEl.value ? Number(areaEl.value) : 0;
      var box = $("attic-result"), title = $("attic-result-title"), body = $("attic-result-body");
      show(box);
      var bits = [];
      if (path === "note") {
        bits.push("A note that says “ventilated per code” is the comment. Choose NAT-IBC openings (show sizes and locations) or MECH-406.1.");
      } else if (path === "exhaust") {
        bits.push("Mechanical 406.1 needs both supply and exhaust. Exhaust-only is the redline. Auto-enable when RH > 60% in the space.");
      } else if (path === "nat") {
        bits.push("Natural path: show IBC opening sizes/locations and bug screens; coordinate envelope and fire/smoke. Rated openings need the assembly protection.");
      } else if (path === "mech") {
        bits.push("Mechanical path (educational): exhaust ≥ 0.02 cfm/ft² of horizontal area, matching supply, RH enable > 60%. Size the fan at external static — not a catalog number.");
      }
      if (area > 0 && (path === "mech" || path === "exhaust")) {
        var cfm = Math.round(area * 0.02 * 10) / 10;
        bits.push("Educational check: " + area + " ft² × 0.02 = " + cfm + " cfm exhaust minimum. Confirm supply path and RH sensor location.");
      }
      title.textContent = "Pick a path. Then show the math.";
      body.innerHTML = (bits.join(" ") || "Select the space and the path.") + ' <a href="' + contact("ventilation") + '">Send attic/crawl area</a> · <a href="/uninhabited-spaces/">406 hub</a>.';
      track("Field Tool Result", { tool: "attic-406", space: space, path: path, area: area || null });
    });
  }


  var df = $("dom-form");
  if (df) {
    df.addEventListener("submit", function (e) {
      e.preventDefault();
      var occ = ($("docc") && $("docc").value) || "";
      var cfm = ($("dcfm") && $("dcfm").value) || "";
      var box = $("dom-result"), title = $("dom-result-title"), body = $("dom-result-body");
      show(box);
      var bits = [];
      if (occ === "rest") {
        bits.push("Commercial cooking is IMC 506/507/508, not 505. If any appliance under the hood requires Type I, the entire hood is Type I. Domestic-looking equipment used commercially still follows Type I/II.");
      } else if (occ === "i") {
        bits.push("I-1 / I-2: DCT 505.6–505.8 / IBC 420.9 path — educational: minimum 500 cfm hood, room ventilation per 403.3.1, outdoor discharge. Ductless only if listed with charcoal filter. Confirm whether the cooking load actually stays on 505 or becomes Type I/II.");
      } else if (occ === "mix") {
        bits.push("Non-R with domestic-style equipment: occupancy decides. If it still qualifies as residential-type, 505 can apply. If the cooking load requires Type I or II, switch to 506/507.");
      } else {
        bits.push("Group R / dwelling: 505. Listed equipment, smooth rigid metal duct, no flex, no screen, outdoor termination unless 505.2 expressly permits a listed recirculating hood.");
      }
      if (cfm === "over" && occ !== "rest") {
        bits.push("505.4: if domestic kitchen exhaust can exceed 400 cfm, makeup air at approximately the same rate, closure damper, automatic interlock with the hood. Draw path, damper, cfm, interlock.");
      } else if (cfm === "unsure") {
        bits.push("Put listing standard and exhaust cfm on the equipment schedule. Over-the-range microwaves with integral exhaust are the device most often missed.");
      }
      title.textContent = "Occupancy first. Then the listing. Then 400 cfm.";
      body.innerHTML = bits.join(" ") + ' <a href="' + contact("kitchen") + '">Send occupancy and cut sheets</a> · <a href="/domestic-cooking/">hub</a>.';
      track("Field Tool Result", { tool: "domestic-505-507", occ: occ, cfm: cfm });
    });
  }


  var hf = $("hc-form");
  if (hf) {
    hf.addEventListener("submit", function (e) {
      e.preventDefault();
      var occ = ($("hocc") && $("hocc").value) || "";
      var box = $("hc-result"), title = $("hc-result-title"), body = $("hc-result-body");
      show(box);
      var map = {
        b: "A Group B medical office is not automatically IMC 407 / ASHRAE 170. Confirm occupancy with the program and the AHJ before copying 170 ACH onto the schedule. Chapter 4 may still govern — or 407 may already apply. Do not guess from the word “clinic.”",
        amb: "Ambulatory care: educational IMC 407.1 — meet IMC 407, ASHRAE 170, and NFPA 99; most restrictive governs. Map every clinical room to a 170 type. Show ACH, OA, pressure, filtration, temp/RH, exhaust on M-601.",
        i2: "Group I-2: same 407.1 most-restrictive path. Do not design to Table 403.3.1.1 OA rates. AIIR is negative; PE is positive — do not mix them. Start ICRA before mechanical design.",
        unsure: "“Healthcare” without a 170 room type is the comment. Send occupancy, procedures, and the room list before anyone sizes air changes."
      };
      title.textContent = "Occupancy first. 170 second. Table 403 last.";
      body.innerHTML = (map[occ] || "Select occupancy.") + ' <a href="' + contact("healthcare") + '">Send the program</a> · <a href="/ashrae-170-rooms/">407 hub</a>.';
      track("Field Tool Result", { tool: "healthcare-407", occ: occ });
    });
  }


  var of = $("oa-ctl-form");
  if (of) {
    of.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("omode") && $("omode").value) || "";
      var box = $("oa-ctl-result"), title = $("oa-ctl-result-title"), body = $("oa-ctl-result-body");
      show(box);
      var map = {
        occ: "Occupied-mode OA is the 405.1 baseline. Still show VAV-minimum OA, DCV Ra floor if used, unoccupied/fire modes, and fail-safe to design OA on sensor/actuator/BAS fault.",
        call: "Ventilation tied only to a cooling/heating call leaves occupied rooms without OA when the fan is off at setpoint. That is a 405.1 miss.",
        dcv: "DCV is allowed in standby, but never below the Ra floor. Document the floor and the points. “Maintain OA” with no measurable points is incomplete.",
        vav: "OA must be maintained across turndown and fan-speed changes, not only at design flow. Show minimum OA at VAV low flow on M-601.",
        none: "A duct plan without a controls sequence is a first-cycle comment. Put occupancy source, OA enable, DCV floor, purge, and fail-safe on M-603 and the controls drawings."
      };
      title.textContent = "Occupied means the OA is on.";
      body.innerHTML = (map[k] || "Select how OA runs.") + ' <a href="' + contact("ventilation") + '">Send the sequence</a> · <a href="/ventilation-controls/">405 hub</a>.';
      track("Field Tool Result", { tool: "oa-ctl-405", mode: k });
    });
  }
  var cf = $("clr-form");
  if (cf) {
    cf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("clist") && $("clist").value) || "";
      var box = $("clr-result"), title = $("clr-result-title"), body = $("clr-result-body");
      show(box);
      var map = {
        no: "If the listing prohibits reduction, 308 does not open a path. Listed clearance governs. Do not squeeze it with a typical.",
        ul: "UL 1618 listed assembly path: show the listed product, airspace, supports, original vs reduced clearance, and the combustible being protected. Still not closer than 1 inch to the equipment.",
        table: "Table 308.4.2: stay inside table limits. Interpolation between table values is allowed; extrapolating below the table is not. Some sources (solid-fuel small clearances, masonry chimneys, kitchen exhaust in shafts) have table limits — check them.",
        note: "“Clearance reduction per code” is the comment. Draw original clearance, reduced clearance, assembly, airspace, and listing/table basis."
      };
      title.textContent = "Listing first. Then the assembly.";
      body.innerHTML = (map[k] || "Select the path.") + ' <a href="' + contact("mep") + '">Send the listing and the tight side</a> · <a href="/clearance-reduction/">308 hub</a>.';
      track("Field Tool Result", { tool: "clearance-308", path: k });
    });
  }


  var rf = $("req-form");
  if (rf) {
    rf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("rproc") && $("rproc").value) || "";
      var box = $("req-result"), title = $("req-result-title"), body = $("req-result-body");
      show(box);
      var map = {
        none: "Put a 502 schedule block that says NONE. That proves the checklist ran. Revisit if the architect later adds a process room.",
        batt: "Battery rooms/charging: confirm battery type, hazard basis, ventilation calculation, control sequence, alarm interface, exhaust path, and fire-protection coordination. Do not leave the safety logic implied. 310 / IFC 911 may also be on the path.",
        spray: "Spray / flammable finish / dipping / powder coat: 502.2–502.7 specific rates and run-while-the-process-runs. Do not recirculate unless every code condition is documented. Do not combine with general return.",
        haz: "Over MAQ (educational 502.8): often ≥ 1 cfm/ft², usually continuous; emergency shutoff; pickup height by vapor density; no recirculation to occupied space. 502.9: local capture; 200 fpm at gas-cabinet/enclosure faces where that path applies.",
        spec: "Nail stations, firing ranges, garage pits, dry cleaning, HPM: purpose-built exhaust, pickup location (low/high/local), sometimes interlocks. Name the 502 subsection on M-601.",
        unsure: "A space on the occupancy drawings but not in the exhaust design is an inspection stop. Inventory exhausted spaces against the architectural occupancy drawings before submittal."
      };
      title.textContent = "Name the process. Then pick 502 — not 403.";
      body.innerHTML = (map[k] || "Select the process.") + ' <a href="' + contact("ventilation") + '">Send the room list</a> · <a href="/required-exhaust/">502 hub</a>.';
      track("Field Tool Result", { tool: "required-502", proc: k });
    });
  }


  var hz = $("haz-form");
  if (hz) {
    hz.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("htrig") && $("htrig").value) || "";
      var box = $("haz-result"), title = $("haz-result-title"), body = $("haz-result-body");
      show(box);
      var map = {
        lfl: "Educational 509.1–509.2: flammables that could create >25% LFL under normal conditions trigger hazardous exhaust. 509.3: keep the exhaust below 25% LFL via dilution. Direct to outdoors. No fire/smoke dampers. No shared shafts with other ducts.",
        "704": "NFPA 704 health-hazard 4 at any concentration, or health-hazard 1–3 above 1% LC50, is a 509 trigger. Capture at the source. Makeup air ≈ exhaust, interlocked. Fire walls: no penetration.",
        lab: "Labs have a limited 509 exception with strict thresholds — do not assume it. Shared-shaft lab exception needs negative pressure, controls, limits, and redundant fans. Document the exception basis.",
        gen: "“General exhaust,” a plenum shortcut, a shared shaft, or a damper on a 509 duct is the comment. Treat it as a protected path to outdoors with a written trigger basis.",
        unsure: "Escalate when SDS or process conditions do not fully describe the airborne hazard. Undercharacterized 509 systems are a liability — do not guess LFL or LC50 from a trade name."
      };
      title.textContent = "Trigger first. Then the path to outdoors.";
      body.innerHTML = (map[k] || "Select the airstream.") + ' <a href="' + contact("ventilation") + '">Send SDS and the room</a> · <a href="/hazardous-exhaust/">509 hub</a>.';
      track("Field Tool Result", { tool: "hazardous-509", trig: k });
    });
  }


  var ef = $("erv-form");
  if (ef) {
    ef.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("estream") && $("estream").value) || "";
      var box = $("erv-result"), title = $("erv-result-title"), body = $("erv-result-body");
      show(box);
      var map = {
        oa: "General occupancy pairing can be eligible. Still: UL 1812 (ducted) or UL 1815 (nonducted); access to the exchanger; document cross-leakage <10% of total design airflow so the air is not counted as recirculated. If energy code requires ERV, also IECC.",
        type1: "513.2 prohibits ERV on commercial kitchen exhaust serving Type I hoods. Do not recover grease exhaust. Sensible-only coil-type heat exchangers are the stated exception — confirm that is actually what is specified.",
        dryer: "513.2 prohibits ERV on clothes dryer exhaust (IMC 504). Do not recover dryer air.",
        haz: "513.2 prohibits ERV on hazardous exhaust (509), dust/stock/refuse conveying explosive or flammable vapors/fumes/dust, and smoke control (512). Eligibility failed before equipment selection.",
        coil: "Sensible-only recovery using coil-type heat exchangers is not limited by the 513.2 prohibition list. Still show listing, access, and that it is actually sensible-only — not a total-energy wheel on a prohibited stream.",
        unsure: "Ask: what exact exhaust airstream am I recovering from? If the answer touches hazardous, grease, smoke control, explosive dust, or dryer exhaust, stop and re-check 513.2 before modeling anything."
      };
      title.textContent = "Eligibility first. Equipment second.";
      body.innerHTML = (map[k] || "Select the airstream.") + ' <a href="' + contact("ventilation") + '">Send the airstream</a> · <a href="/energy-recovery/">513 hub</a>.';
      track("Field Tool Result", { tool: "erv-513", stream: k });
    });
  }


  var dsf = $("dsd-form");
  if (dsf) {
    dsf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("dscfm") && $("dscfm").value) || "";
      var box = $("dsd-result"), title = $("dsd-result-title"), body = $("dsd-result-body");
      show(box);
      var map = {
        under: "A single return at or below 2,000 cfm is under the 606.2.1 threshold — still check combined supply/return on a shared duct/plenum (606.2.2) and whether the system can spread smoke beyond the room (exception). Put cfm on the fan schedule.",
        over: "Return over 2,000 cfm (or combined shared capacity over 2,000 cfm): listed duct smoke detection in the return duct or plenum, upstream of filters, exhaust, OA, decontamination, and appliances. UL 268A. Install per NFPA 72. Shutdown (or smoke-control mode). Supervisory signal where FA is required.",
        riser: "Return riser serving two or more stories: detectors at each story where any portion of the return system exceeds 15,000 cfm, upstream of the riser connection.",
        fptu: "Fan-powered terminal units 2,000 cfm or less do not each need individual detectors if they shut down by an approved detection method. Document the method.",
        none: "Missing cfm and missing detector is the comment. Put design cfm on M-601 and decide 606.2.1 / 606.2.2 / 606.2.3 on paper before the FA contractor is guessing locations."
      };
      title.textContent = "Capacity first. Then the detector location.";
      body.innerHTML = (map[k] || "Select capacity.") + ' <a href="' + contact("mep") + '">Send the schedule cfm</a> · <a href="/duct-smoke-detection/">606 hub</a>.';
      track("Field Tool Result", { tool: "dsd-606", cap: k });
    });
  }


  var dvf = $("dvel-form");
  if (dvf) {
    dvf.addEventListener("submit", function (e) {
      e.preventDefault();
      var cfm = parseFloat(($("dvel-cfm") && $("dvel-cfm").value) || "0");
      var shape = ($("dvel-shape") && $("dvel-shape").value) || "rect";
      var w = parseFloat(($("dvel-w") && $("dvel-w").value) || "0");
      var h = parseFloat(($("dvel-h") && $("dvel-h").value) || "0");
      var box = $("dvel-result"), title = $("dvel-result-title"), body = $("dvel-result-body");
      show(box);
      if (!(cfm > 0) || !(w > 0) || (shape === "rect" && !(h > 0))) {
        title.textContent = "Need airflow and a size.";
        body.textContent = "Enter cfm and duct size. Zero airflow is not a duct size.";
        return;
      }
      var area = shape === "round" ? (Math.PI * w * w / 4) / 144 : (w * h) / 144;
      var vel = cfm / area;
      var flag = vel > 2500 ? "High-velocity territory — acoustic analysis, not a default commercial low-pressure duct."
        : vel > 1800 ? "Above typical commercial supply-main screening (~1,800 fpm). Check noise, pressure class, and whether this is a deliberate medium/high-velocity run."
        : vel > 1200 ? "In the commercial-main band. Confirm this is a main, not a branch to a diffuser (branch screening often ~1,200 fpm)."
        : vel > 900 ? "Reasonable for many commercial branches. Residential Manual D mains are often screened nearer 700–900 fpm."
        : vel < 400 ? "Low velocity — check oversized duct, poor throw, and whether CFM is actually this low."
        : "Inside common low-pressure screening. Still confirm friction rate, fittings, and ESP with a real run.";
      title.textContent = Math.round(vel) + " fpm  ·  " + area.toFixed(2) + " ft²";
      body.innerHTML = flag + ' Kitchen grease duct is a different method (IMC Chapter 5 / NFPA 96). <a href="' + contact("mep") + '">Send the run</a> · <a href="/calculation-support/">calculation support</a>.';
      track("Field Tool Result", { tool: "duct-velocity", vel: Math.round(vel), shape: shape });
    });
  }


  var nf = $("nat-form");
  if (nf) {
    nf.addEventListener("submit", function (e) {
      e.preventDefault();
      var sf = parseFloat(($("nat-sf") && $("nat-sf").value) || "0");
      var kind = ($("nat-kind") && $("nat-kind").value) || "direct";
      var box = $("nat-result"), title = $("nat-result-title"), body = $("nat-result-body");
      show(box);
      if (!(sf > 0)) {
        title.textContent = "Need the floor area.";
        body.textContent = "Enter the floor area served. Windows without a 4% table are the comment.";
        return;
      }
      var four = sf * 0.04;
      var eight = sf * 0.08;
      var extra = {
        direct: "402.2: provide openable area not less than 4% of the floor area served (" + four.toFixed(1) + " ft²). Operators readily accessible to occupants. Put the calc next to the room.",
        adj: "402.3: unobstructed opening to the adjoining room not less than 8% (" + eight.toFixed(1) + " ft²) and not less than 25 ft² — so " + Math.max(25, eight).toFixed(1) + " ft². Base the outdoor opening on the total area served.",
        sun: "Sunroom/patio-cover exception: interior-to-sunroom opening not less than 8% (" + eight.toFixed(1) + " ft²) and not less than 20 ft² — so " + Math.max(20, eight).toFixed(1) + " ft².",
        bg: "Still 4% openable (" + four.toFixed(1) + " ft²). Below grade: outdoor horizontal clear space at least 1½ × opening depth (grade to bottom of opening). Dimension the well."
      };
      title.textContent = "4% of " + Math.round(sf) + " ft² = " + four.toFixed(1) + " ft² openable";
      body.innerHTML = extra[kind] + ' Use free area, not the nominal window. If the owner keeps windows locked, this is not a 402 building. <a href="' + contact("ventilation") + '">Send the room areas</a> · <a href="/natural-ventilation/">402 hub</a>.';
      track("Field Tool Result", { tool: "nat-402", sf: sf, kind: kind });
    });
  }


  var vcf = $("vcat-form");
  if (vcf) {
    vcf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("vcat-kind") && $("vcat-kind").value) || "";
      var box = $("vcat-result"), title = $("vcat-result-title"), body = $("vcat-result-body");
      show(box);
      var map = {
        dv: "804.1: terminals follow the appliance manufacturer — not a copied 9 in / 12 in integral-vent number. Overlay intakes, windows, grade, and meters.",
        int: "804.2 / 804.2.1: listing and instructions control. The 9-inch natural-draft and 12-inch forced-draft figures belong here. Do not paste them onto a different category.",
        md: "804.3: UL 378. Forced vs induced. Positive-pressure portions gas-tight. Auto-fired: no burner without the exhauster. Natural-draft appliances cannot sit on the discharge side of the exhauster (804.3.6).",
        typeb: "802: listed and labeled, compatible with the appliance. Type L / pellet: UL 641. Diameter is not a listing. 2 ft / 10 ft Type L roof, 5 ft height, 2 in attic shield, 12 in door swing.",
        fbc: "805: listed factory-built chimney system — appliance, classification, offsets, supports, termination, shroud, insulation shield. Do not mix brands.",
        exist: "801 reuse four-gate: size/draft, passageway, cleanout, clearances/fireblocking. An existing chimney to remain is not a design. Solid-fuel cannot share the passageway.",
        note: "“Vent to exterior” is not 801, 802, 803, or 804. Name fuel, method, pressure, and termination before anyone buys pipe."
      };
      title.textContent = "Category first. Clearance second.";
      body.innerHTML = (map[k] || "Select a category.") + ' <a href="' + contact("mep") + '">Send the listing</a> · <a href="/general-venting/">801 hub</a> · <a href="/direct-vent/">804 hub</a>.';
      track("Field Tool Result", { tool: "vent-category", kind: k });
    });
  }


  var rf = $("ret-form");
  if (rf) {
    rf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("ret-where") && $("ret-where").value) || "";
      var box = $("ret-result"), title = $("ret-result-title"), body = $("ret-result-body");
      show(box);
      var map = {
        corridor: "601.2: corridors cannot serve as supply, return, exhaust, relief, or ventilation air ducts except for limited listed conditions. A corridor ceiling plenum as return only where a listed fire/smoke condition is met. Name the exception or move the grille.",
        exit: "601.3: exit-enclosure ventilation must be independent of other building ventilation systems. Do not tie the stair into the general HVAC.",
        kitchen: "601.5: closet, kitchen, pool, and garage conditions are exception-based, not blanket permission. Do not treat a kitchen return as default.",
        garage: "601.5: garage returns are exception-based. A garage is also a combustion and contaminant question — not a convenient plenum.",
        closet: "601.5: closet, bath, and pool rooms are exception-based, not blanket permission. Confirm the listed exception before the grille is cut.",
        otherdu: "601.5: return air cannot cross dwelling units. That is a hard stop, not a balancing note.",
        mech: "601.5: return openings must maintain combustion-appliance clearance and cannot pull from prohibited spaces unless a listed exception applies.",
        ok: "A return in the room this system supplies can still fail 601.5 if it exceeds the supply delivered to that room. Put supply vs return on M-601."
      };
      title.textContent = "Name the exception — or move the return.";
      body.innerHTML = (map[k] || "Select a location.") + ' <a href="' + contact("ducts") + '">Send the RCP</a> · <a href="/return-air/">601 hub</a>.';
      track("Field Tool Result", { tool: "return-601", where: k });
    });
  }


  var ff = $("fxd-form");
  if (ff) {
    ff.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("fxd-cross") && $("fxd-cross").value) || "";
      var box = $("fxd-result"), title = $("fxd-result-title"), body = $("fxd-result-body");
      show(box);
      var map = {
        wall: "607.7: flex and air connectors shall not pass through any fire-resistance-rated assembly. Stop the flex. Carry listed sheet steel through the wall with the 607.5 / 607.6 protection that assembly requires.",
        shaft: "A shaft is a rated assembly. Flex is not the penetration. Hard duct, damper/sleeve/firestop as 607.5 requires, then flex only after the boundary.",
        ceil: "Rated floor/ceiling, roof/ceiling, and ceiling membranes are 607.7 territory. A flex tail through the membrane is a life-safety breach, even as a 'final connection.'",
        smoke: "Smoke barriers and smoke partitions count. The flex stops; the listed steel duct with the correct 607 protection crosses.",
        none: "If every flex run stays on the occupied side of every rated line, 607.7 is not the comment. Still show the flex-to-hard-duct transition on the plan so the inspector is not guessing.",
        unsure: "Overlay the architectural life-safety plan on the M-sheet before anyone cuts flex. If you cannot name the rated lines, you cannot claim 607.7 compliance."
      };
      title.textContent = k === "none" ? "Keep the transition on the drawing." : "Flex stops. Hard duct crosses.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("ducts") + '">Send the RCP</a> · <a href="/flexible-ducts/">607.7 hub</a>.';
      track("Field Tool Result", { tool: "flex-607-7", where: k });
    });
  }


  var sf = $("sccr-form");
  if (sf) {
    sf.addEventListener("submit", function (e) {
      e.preventDefault();
      var afc = parseFloat(($("sccr-afc") && $("sccr-afc").value) || "");
      var pack = parseFloat(($("sccr-pack") && $("sccr-pack").value) || "");
      var ir = parseFloat(($("sccr-ir") && $("sccr-ir").value) || "");
      var box = $("sccr-result"), title = $("sccr-result-title"), body = $("sccr-result-body");
      show(box);
      var hasA = afc === afc && afc > 0;
      var hasP = pack === pack && pack > 0;
      var hasI = ir === ir && ir > 0;
      if (!hasA && !hasP && !hasI) {
        title.textContent = "Missing evidence is not zero risk.";
        body.innerHTML = 'Need the available fault current at this connection, the assembly SCCR, or both. A breaker interrupting rating alone does not give the VFD or control panel an SCCR. <a href="' + contact("mep") + '">Send the nameplate</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "empty" });
        return;
      }
      if (hasA && hasP && afc > pack) {
        title.textContent = "Hold procurement. The breaker does not close this.";
        body.innerHTML = hasI
          ? ("Available " + afc + " kA exceeds assembly SCCR " + pack + " kA. A " + ir + " kA interrupting rating on the breaker is a different value — it does not raise the package SCCR. Daily Code Talk’s 22 / 10 / 65 example is the same pattern. Do not relabel. Do not improvise series-rating.")
          : ("Available " + afc + " kA exceeds assembly SCCR " + pack + " kA. The breaker interrupting rating, if you only have that, is not the package SCCR.");
        body.innerHTML += ' <a href="' + contact("mep") + '">Send the study page</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "hold" });
        return;
      }
      if (hasI && !hasP) {
        title.textContent = "Interrupting rating is not SCCR.";
        body.innerHTML = ir + ' kA on the breaker does not automatically give the surrounding control panel, VFD, pump, or HVAC assembly that SCCR. Photograph the package nameplate (safe access only). Missing SCCR is unresolved. <a href="' + contact("mep") + '">Send the nameplate</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
        track("Field Tool Result", { tool: "sccr", kind: "ir-only" });
        return;
      }
      title.textContent = "Same voltage. Same rating basis. Then compare.";
      body.innerHTML = "For a fully rated arrangement, available fault current at the connection must not exceed the applicable equipment SCCR. Recheck after transformer replacements, utility upgrades, or added generators. An arc-flash label answers a different question." + ' <a href="' + contact("mep") + '">Send the one-line</a> · <a href="/sccr-fault-current/">SCCR hub</a>.';
      track("Field Tool Result", { tool: "sccr", kind: "ok-or-partial" });
    });
  }


  var racf = $("rac-form");
  if (racf) {
    racf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("rac-need") && $("rac-need").value) || "";
      var box = $("rac-result"), title = $("rac-result-title"), body = $("rac-result-body");
      show(box);
      var map = {
        none: "That path can be readily accessible — if the governing requirement uses that term. Still walk the route after the project is built. Storage and other MEP can undo it.",
        key: "Keys are not a strike against readily accessible in Article 100. Tools other than keys are. Confirm the lock is a key, not a tool-only fastener.",
        tool: "Readily accessible means without tools other than keys. A screwdriver or wrench to reach the handle is the wrong path if the requirement is readily accessible. Move the disconnect or clear the obstruction on the drawing.",
        ladder: "A portable ladder is specifically listed as something readily accessible equipment does not require. Roof geometry that needs a ladder to the RTU disconnect is a location problem, not a note.",
        move: "Moving obstacles is specifically listed. Storage in front of the disconnect is not a field workaround — it is a failed readily-accessible condition.",
        climb: "Climbing over or under obstacles is specifically listed. Trace the route in section, not just in plan.",
        demo: "Accessible wiring methods can be exposed or removed without damaging structure or finish. Destructive removal is not that condition. Flag it before concealment."
      };
      title.textContent = (k === "none" || k === "key") ? "Walk the route after occupancy." : "That path is not readily accessible.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("mep") + '">Send the path photo</a> · <a href="/readily-accessible/">Access hub</a>. This is not a 110.26 working-space calculation.';
      track("Field Tool Result", { tool: "readily-accessible", need: k });
    });
  }


  var bcf = $("bcf-form");
  if (bcf) {
    bcf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("bcf-where") && $("bcf-where").value) || "";
      var box = $("bcf-result"), title = $("bcf-result-title"), body = $("bcf-result-body");
      show(box);
      var map = {
        panel: "Conductors from that final panel OCPD to the outlet(s) are the branch circuit. Upstream of that OCPD, toward the service or SDS, is feeder territory. Put that OCPD on the one-line.",
        disc: "If that disconnect/fuse is the final OCPD protecting the circuit, the conductors beyond it to the load are the branch circuit. Confirm it is actually last — a downstream device would move the boundary.",
        up: "If another OCPD still sits between here and the load, you have not found the final branch-circuit device. Keep walking toward the load.",
        guess: "A label is not a classification. Ask: what is the final branch-circuit OCPD, and what outlet/load does it serve? Not every conductor leaving a panel is a feeder.",
        exist: "Do not classify an existing circuit from an assumed route. When origin controls scope or safety, verify with qualified personnel and required safe-work procedures — or record not verified."
      };
      title.textContent = (k === "guess" || k === "exist" || k === "up") ? "The boundary is not named yet." : "Final OCPD first. Then the name.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("mep") + '">Send the one-line</a> · <a href="/branch-circuit-vs-feeder/">Hub</a>.';
      track("Field Tool Result", { tool: "branch-feeder", where: k });
    });
  }


  var uf = $("utl-form");
  if (uf) {
    uf.addEventListener("submit", function (e) {
      e.preventDefault();
      var k = ($("utl-auth") && $("utl-auth").value) || "";
      var box = $("utl-result"), title = $("utl-result-title"), body = $("utl-result-body");
      show(box);
      var map = {
        both: "109 wants the code official’s authorization before connecting IMC-regulated systems. Keep both writings with the commissioning plan. Verify controls and safeties are active. Use LOTO for partial energization.",
        ahj: "You have the AHJ side. The utility release is still a separate requirement. Do not treat one as the other. Align meter-set / power-on with the commissioning plan.",
        util: "The utility’s meter-set is not the AHJ’s yes. 109.1: no connection until the code official authorizes it. Hold energization.",
        temp: "109.2 allows temporary service for testing or limited use — in writing. A verbal ‘you can test’ is not that writing. Get the duration on paper; coordinate with 110.",
        exist: "Renovation error: assuming the existing connection covers the new equipment. Authorization applies to the piece being connected, not just the circuit.",
        none: "Do not energize. Unauthorized connection is a fast stop-work trigger and 109.3 disconnect territory — even later, even if it was originally connected properly."
      };
      title.textContent = (k === "both" || k === "ahj") ? "Two writings. Then energize." : "Do not energize on that record.";
      body.innerHTML = (map[k] || "Select a condition.") + ' <a href="' + contact("existing") + '">Send the writing</a> · <a href="/utility-connection/">109 hub</a>.';
      track("Field Tool Result", { tool: "utility-109", auth: k });
    });
  }

})();
