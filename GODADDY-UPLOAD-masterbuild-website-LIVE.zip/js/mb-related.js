/* Contextual hub strip on Daily Code Talk posts. Education → engagement path. */
(function () {
  var path = (location.pathname || "").toLowerCase();
  if (path.indexOf("/daily-code-talk/") === -1) return;
  if (path === "/daily-code-talk/" || path === "/daily-code-talk/index.html") return;

  function card(href, title, sub) {
    return '<a href="' + href + '"><strong>' + title + "</strong><small>" + sub + "</small></a>";
  }

  var cards = [];
  if (/imc-40[0-9]|chapter-4|ventilation/.test(path)) {
    cards.push(card("/ventilation/", "Ventilation hub", "IMC Chapter 4 — outdoor air, method, intakes"));
    if (/407|ambulatory|i-2|ashrae/.test(path)) {
      cards.push(card("/healthcare-ventilation/", "Healthcare ventilation", "IMC 407 / ASHRAE 170 path"));
    }
    if (/404|garage|parking/.test(path)) {
      cards.push(card("/parking-garage-ventilation/", "Parking garage ventilation", "IMC 404 — not Table 403"));
      cards.push(card("/field-tools/#garage", "404 cfm estimator", "Full-On 0.75 / Standby 0.05"));
    }
  }
  if (/imc-50[0-9]|chapter-5|exhaust|kitchen|hood|grease|makeup|dryer|509|hazardous|512|smoke/.test(path)) {
    if (/506|507|508|kitchen|hood|grease|makeup/.test(path)) {
      cards.push(card("/commercial-kitchen-ventilation/", "Kitchen exhaust hub", "IMC 506–508 Type I / Type II"));
      cards.push(card("/field-tools/", "Type I vs Type II pathfinder", "Educational classification before you price grease duct"));
      cards.push(card("/field-tools/#makeup", "Makeup-air check", "IMC 508 — approximately equal"));
    } else if (/404|garage/.test(path)) {
      cards.push(card("/parking-garage-ventilation/", "Parking garage ventilation", "IMC 404"));
    } else if (/512|smoke/.test(path)) {
      cards.push(card("/mechanical-code/", "IMC / mechanical code map", "Chapter 5 smoke control series"));
    } else {
      cards.push(card("/mechanical-code/", "IMC exhaust chapter", "Required exhaust, dryers, kitchens, hazardous, smoke"));
    }
  }
  if (/imc-60[0-9]|chapter-6|duct|plenum|damper|607/.test(path)) {
    cards.push(card("/duct-systems/", "Duct systems hub", "IMC Chapter 6 — construction, plenums, 607 dampers"));
    cards.push(card("/field-tools/#dampers", "607 damper pathfinder", "Assembly type controls the damper"));
  }
  if (/imc-70[0-9]|combustion/.test(path)) {
    cards.push(card("/combustion-air/", "Combustion air hub", "IMC Chapter 7 — free area, dampers, existing rooms"));
    cards.push(card("/field-tools/#combustion", "Combustion-air method check", "Indoor volume vs outdoor openings vs listing"));
  }
  if (/imc-80[0-9]|venting|chimney|801/.test(path)) {
    cards.push(card("/mechanical-code/", "IMC venting", "Chapter 8 — chimneys, existing flues, 801.18"));
    cards.push(card("/combustion-air/", "Combustion air", "Air supply that the venting path depends on"));
  }
  if (/312|load/.test(path)) {
    cards.push(card("/hvac-load-calculations/", "HVAC load calculations", "IMC 312 + Florida checklist"));
  }
  if (/nec|sparky|article-90|article-100|electrical/.test(path)) {
    cards.push(card("/electrical-code/", "NEC / Sparky Edition", "MEP-coordination reading of the electrical code"));
    cards.push(card("/electrical-building-recertification-miami/", "Electrical recertification", "Miami-Dade readiness path"));
  }
  if (/102|existing|applicability/.test(path)) {
    cards.push(card("/existing-buildings/", "Existing-building MEP", "What stays, what upgrades, where cost lives"));
  }

  cards.push(card("/permit-comment-response/", "Permit comment response", "Send the comment letter, not a blank RFP"));
  cards.push(card("/contact/", "Send project background", "Fixed-fee after scope review"));

  var seen = {};
  var html = "";
  cards.forEach(function (c) {
    var m = c.match(/href="([^"]+)"/);
    var href = m ? m[1] : c;
    if (seen[href]) return;
    seen[href] = 1;
    html += c;
  });

  var wrap = document.createElement("section");
  wrap.className = "related-hubs";
  wrap.innerHTML =
    "<h2>Apply this with Masterbuild</h2>" +
    '<p class="note">Daily Code Talk is education. These hubs are the live-set path: what the drawings must show, what to send, and when it becomes a written engagement.</p>' +
    '<div class="hub-strip">' + html + "</div>";

  var style = document.createElement("style");
  style.textContent =
    ".related-hubs{margin:36px 0 8px}" +
    ".related-hubs h2{font-size:18px;margin:0 0 8px;color:#C4783A}" +
    ".related-hubs .note{font-size:14px;color:rgba(240,237,232,.58);margin:0 0 12px}" +
    ".hub-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}" +
    ".hub-strip a{display:block;padding:14px 16px;background:#131417;border:1px solid rgba(255,255,255,.08);color:#F0EDE8}" +
    ".hub-strip a:hover{border-color:rgba(196,120,58,.5);text-decoration:none}" +
    ".hub-strip small{display:block;color:rgba(240,237,232,.55);font-size:13px;margin-top:6px}";
  document.head.appendChild(style);

  var cta = document.querySelector("section.cta");
  if (cta && cta.parentNode) cta.parentNode.insertBefore(wrap, cta);
  else {
    var main = document.querySelector("main");
    if (main) main.appendChild(wrap);
  }

  if (window.trackMBEvent) {
    wrap.addEventListener("click", function (e) {
      var a = e.target && e.target.closest ? e.target.closest("a") : null;
      if (!a) return;
      window.trackMBEvent("DCT Hub Click", { href: a.getAttribute("href") || "", page: location.pathname });
    });
  }
})();
