// mb-more.jsx  -  Experience, About, Fee Process sections (EN + ES)

const MORE_CONTENT = {
  en: {
    experience: {
      eyebrow: "/ Experience",
      headline: "Built on direct PE involvement",
      sub: "Masterbuild draws on a track record of signed-and-sealed MEP work across commercial, residential, and high-demand projects  -  delivered with the same principal-led model applied today.",
      stats: [{
        val: "All MEP",
        label: "Disciplines In-House",
        desc: "HVAC, plumbing, fire protection, and electrical design  -  all handled by the same principal engineer."
      }, {
        val: "PE",
        label: "Credentials",
        desc: "Osmany Portal holds Florida PE licensure. Licensure in other states confirmed per project scope."
      }, {
        val: "15+ yrs",
        label: "MEP Experience",
        desc: "Over fifteen years of MEP engineering judgment applied to commercial, high-end residential, and high-reliability scopes."
      }, {
        val: "FL + Request",
        label: "Jurisdiction Reach",
        desc: "Miami-based and Florida-licensed. TX, NJ, NY, and PA project support is reviewed by request based on scope, licensure path, and jurisdiction."
      }],
      sectors: {
        label: "Project types in prior PE-stamped work",
        items: ["Commercial tenant improvements", "High-end custom residential", "Multifamily residential", "Mixed-use", "Existing building renovations", "Plumbing-system feasibility assessments", "Infrastructure assessments", "Construction-phase advisory", "Healthcare & medical facilities", "Labs & research environments", "Data centers & server rooms"]
      },
      photo: {
        caption: "PE-stamped drawings delivered across commercial and residential scopes"
      }
    },
    about: {
      eyebrow: "/ About",
      headline: "Why boutique matters in MEP consulting",
      body: ["Masterbuild Consulting was founded on a straightforward premise: most MEP problems that surface during permitting, construction, or project delivery trace back to one of three things  -  code logic that wasn't followed through design, coordination gaps that weren't caught on paper, or engineering judgment that never made it onto the drawings.", "At large MEP shops, the licensed engineer signs and stamps. The project is run by someone else. Client questions go through layers. Field issues come back as surprises. That model works at scale, but it introduces risk that boutique clients  -  especially those with demanding scopes, tight permit schedules, or high-finish projects  -  can't absorb.", "Masterbuild is structured differently. Osmany Portal, PE is the firm. Every scope is reviewed, every drawing set is checked, and every technical call is made by the same licensed engineer the client spoke with at intake. There are no layers, no hand-offs, and no juniors running your job."],
      profile: {
        name: "Osmany Portal, PE",
        title: "Principal Engineer  -  Masterbuild Consulting",
        bio: "Miami-based PE with prior signed-and-sealed experience across commercial and high-end residential MEP in partnership with MEPTECH Solutions, plus current support for Roble Technologies energy-site verification and Existing Building LLC feasibility-assessment reports. Founded Masterbuild Consulting to offer direct PE access to clients who need technical judgment  -  not just drawings.",
        credentials: ["Florida Licensed Professional Engineer", "15+ years of MEP engineering experience", "All four MEP disciplines in-house — HVAC, plumbing, fire protection, electrical", "Select TX, NJ, NY, and PA projects by request", "Bilingual in English and Spanish"],
        linkedIn: "https://www.linkedin.com/in/osmanyportal/"
      },
      proof: {
        label: "Selected working relationships",
        note: "Partner links provided where authorized; references available during scope review",
        items: [{
          org: "MEPTECH Solutions",
          role: "Qualifying PE and responsible design professional. Monthly signed-and-sealed sets  -  MEP on residential, mechanical and plumbing on commercial.",
          url: "https://www.meptechsolutions.com/"
        }, {
          org: "Roble Technologies",
          role: "Field verifications and site visits supporting energy-site work.",
          url: "https://getroble.com/"
        }, {
          org: "Existing Building LLC",
          role: "Existing-conditions assessment reports for commercial buildings.",
          url: "https://www.existing-building.com/"
        }, {
          org: "Public & Private Plan-Review Experience",
          role: "Experience on both sides of the counter  -  preparing permit sets in private practice and reviewing plans on the public side."
        }]
      },
      values: [{
        title: "Direct accountability",
        body: "The PE on the drawings is the PE running the scope. That's not a feature  -  it's how engineering is supposed to work."
      }, {
        title: "Code logic, not code compliance",
        body: "Drawings aren't just checked against a code list. They're built around how reviewers think, how inspectors look, and how the building will actually get built."
      }, {
        title: "Honest scope, honest fees",
        body: "Fixed fees scoped to what the project actually needs. No padding, no scope creep management, no billing surprises."
      }]
    },
    fee: {
      eyebrow: "/ Fee Process",
      headline: "How a Masterbuild engagement works",
      sub: "Five steps from first contact to permitted drawings. No ambiguity, no retainer surprises, no scope drift.",
      steps: [{
        num: "01",
        title: "You send the real project background",
        body: "A good inquiry includes the project address, current stage, what disciplines are needed, and the actual question or decision on the table. Background files, drawings, or prior permit feedback are always helpful. The more specific, the faster we can scope.",
        tag: "Inquiry"
      }, {
        num: "02",
        title: "Masterbuild reviews and asks the right questions",
        body: "Osmany reviews what you've sent, identifies any gaps, and follows up with targeted questions before scoping. This step protects both sides  -  a proposal written from incomplete information serves no one.",
        tag: "Scope Review"
      }, {
        num: "03",
        title: "Fixed-fee proposal issued",
        body: "You receive a written proposal with a defined scope, deliverables, milestone structure, and a fixed fee. No hourly billing. No open-ended engagements. If the scope changes, a written amendment is issued before additional work begins.",
        tag: "Proposal"
      }, {
        num: "04",
        title: "Engagement letter signed  -  retainer due",
        body: "On acceptance, you sign the engagement letter and pay the retainer to start. The retainer is applied to your first milestone. Work begins within 1-2 business days of retainer receipt, depending on current queue.",
        tag: "Kickoff"
      }, {
        num: "05",
        title: "Milestone-based delivery and billing",
        body: "Deliverables and invoices are tied to defined milestones  -  typically SD/schematic, permit CDs, and final approval. You know what you're getting and when. Final payment is due on permit approval or construction-phase close.",
        tag: "Delivery"
      }],
      note: "Masterbuild does not bill hourly for standard permit scopes. Fixed fees are quoted after scope review  -  not estimated upfront before understanding your project.",
      cta: "Start an inquiry"
    }
  },
  es: {
    experience: {
      eyebrow: "/ Experiencia",
      headline: "Construido sobre la participación directa del PE",
      sub: "Masterbuild se basa en un historial de trabajo MEP sellado y firmado en proyectos comerciales, residenciales y de alta demanda, entregado con el mismo modelo de liderazgo de PE que se aplica hoy.",
      stats: [{
        val: "Todo MEP",
        label: "Disciplinas Internas",
        desc: "HVAC, plomería, protección contra incendios y diseño eléctrico  -  todo gestionado por el mismo ingeniero principal."
      }, {
        val: "PE",
        label: "Credenciales",
        desc: "Osmany Portal tiene licencia PE de Florida. La licencia en otros estados se confirma por alcance de proyecto."
      }, {
        val: "15+ años",
        label: "Experiencia MEP",
        desc: "Más de quince años de juicio de ingeniería MEP aplicados a proyectos comerciales, residenciales de alto nivel y de alta confiabilidad."
      }, {
        val: "FL + Solicitud",
        label: "Alcance Jurisdiccional",
        desc: "Con sede en Miami y licencia en Florida. El apoyo en TX, NJ, NY y PA se revisa por solicitud según alcance, ruta de licencia y jurisdicción."
      }],
      sectors: {
        label: "Tipos de proyectos en trabajo previo sellado por PE",
        items: ["Mejoras de inquilinos comerciales", "Residencial personalizado de alto nivel", "Residencial multifamiliar", "Uso mixto", "Renovaciones de edificios existentes", "Evaluaciones de factibilidad de sistemas de plomería", "Evaluaciones de infraestructura", "Asesoría en fase de construcción", "Instalaciones de salud y médicas", "Laboratorios y entornos de investigación", "Centros de datos y salas de servidores"]
      },
      photo: {
        caption: "Planos sellados por PE entregados en alcances comerciales y residenciales"
      }
    },
    about: {
      eyebrow: "/ Nosotros",
      headline: "Por qué importa el tamaño boutique en consultoría MEP",
      body: ["Masterbuild Consulting fue fundada sobre una premisa directa: la mayoría de los problemas MEP que surgen durante el permiso, la construcción o la entrega del proyecto se remontan a una de tres cosas: lógica de código que no se siguió en el diseño, brechas de coordinación que no se detectaron en papel, o juicio de ingeniería que nunca llegó a los planos.", "En grandes firmas MEP, el ingeniero licenciado firma y sella. El proyecto lo gestiona otra persona. Las preguntas del cliente pasan por capas. Los problemas de campo regresan como sorpresas. Ese modelo funciona a escala, pero introduce riesgos que los clientes boutique no pueden absorber.", "Masterbuild está estructurado de manera diferente. Osmany Portal, PE es la firma. Cada alcance es revisado, cada conjunto de planos es verificado, y cada decisión técnica es tomada por el mismo ingeniero licenciado con quien habló el cliente en el proceso de incorporación."],
      profile: {
        name: "Osmany Portal, PE",
        title: "Ingeniero Principal  -  Masterbuild Consulting",
        bio: "PE con sede en Miami con experiencia previa sellada y firmada en MEP comercial y residencial de alto nivel en alianza con MEPTECH Solutions, además de soporte actual para verificación energética de Roble Technologies e informes de factibilidad con Existing Building LLC. Fundó Masterbuild Consulting para ofrecer acceso directo al PE a clientes que necesitan juicio técnico, no solo planos.",
        credentials: ["Ingeniero Profesional Licenciado en Florida", "Más de 15 años de experiencia en ingeniería MEP", "Las cuatro disciplinas MEP internas — HVAC, plomería, protección contra incendios, electricidad", "TX, NJ, NY y PA revisados por solicitud", "Bilingüe  -  inglés y español"],
        linkedIn: "https://www.linkedin.com/in/osmanyportal/"
      },
      proof: {
        label: "Relaciones de trabajo seleccionadas",
        note: "Enlaces de socios disponibles donde están autorizados; referencias durante la revisión de alcance",
        items: [{
          org: "MEPTECH Solutions",
          role: "PE calificador y profesional de diseño responsable. Planos firmados y sellados cada mes  -  MEP en residencial, mecánica y plomería en comercial.",
          url: "https://www.meptechsolutions.com/"
        }, {
          org: "Roble Technologies",
          role: "Verificaciones de campo y visitas a sitio para trabajo de sitios de energía.",
          url: "https://getroble.com/"
        }, {
          org: "Existing Building LLC",
          role: "Informes de evaluación de condiciones existentes para edificios comerciales.",
          url: "https://www.existing-building.com/"
        }, {
          org: "Experiencia de Revisión Pública y Privada",
          role: "Experiencia en ambos lados  -  preparando planos de permiso en el sector privado y revisando planos en el sector público."
        }]
      },
      values: [{
        title: "Responsabilidad directa",
        body: "El PE en los planos es el PE que gestiona el alcance. Eso no es una característica  -  así es como se supone que funciona la ingeniería."
      }, {
        title: "Lógica de código, no solo cumplimiento",
        body: "Los planos no solo se verifican contra una lista de código. Se construyen en torno a cómo piensan los revisores, cómo miran los inspectores, y cómo se construirá el edificio."
      }, {
        title: "Alcance honesto, honorarios honestos",
        body: "Honorarios fijos según lo que el proyecto realmente necesita. Sin relleno, sin gestión de expansión de alcance, sin sorpresas de facturación."
      }]
    },
    fee: {
      eyebrow: "/ Proceso de Honorarios",
      headline: "Cómo funciona un compromiso con Masterbuild",
      sub: "Cinco pasos desde el primer contacto hasta los planos con permiso. Sin ambigüedad, sin sorpresas de anticipo, sin derivación de alcance.",
      steps: [{
        num: "01",
        title: "Usted envía los antecedentes reales del proyecto",
        body: "Una buena consulta incluye la dirección del proyecto, la etapa actual, las disciplinas necesarias y la pregunta o decisión real en cuestión. Los archivos de antecedentes, planos o retroalimentación previa de permisos siempre son útiles.",
        tag: "Consulta"
      }, {
        num: "02",
        title: "Masterbuild revisa y hace las preguntas correctas",
        body: "Osmany revisa lo que usted envió, identifica brechas y realiza preguntas específicas antes de definir el alcance. Este paso protege a ambas partes.",
        tag: "Revisión de Alcance"
      }, {
        num: "03",
        title: "Propuesta de precio fijo emitida",
        body: "Recibe una propuesta escrita con alcance definido, entregables, estructura de hitos y honorario fijo. Sin facturación por hora. Sin compromisos abiertos.",
        tag: "Propuesta"
      }, {
        num: "04",
        title: "Carta de encargo firmada  -  anticipo requerido",
        body: "Al aceptar, usted firma la carta de encargo y paga el anticipo para comenzar. El trabajo inicia dentro de 1-2 días hábiles del recibo del anticipo.",
        tag: "Inicio"
      }, {
        num: "05",
        title: "Entrega y facturación por hitos",
        body: "Los entregables y facturas están vinculados a hitos definidos. Usted sabe qué recibe y cuándo. El pago final vence al aprobarse el permiso.",
        tag: "Entrega"
      }],
      note: "Masterbuild no factura por hora para alcances de permiso estándar. Los honorarios fijos se cotizan después de la revisión del alcance, no se estiman sin entender su proyecto.",
      cta: "Iniciar una consulta"
    }
  }
};
window.MORE_CONTENT = MORE_CONTENT;

// ── Blueprint SVG placeholder ─────────────────────────────────────────────
function BlueprintPlaceholder({
  width = "100%",
  height = 280,
  caption,
  note
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width,
      height,
      background: "#0A0D12",
      border: "1px solid rgba(196,120,58,0.12)",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(rgba(196,120,58,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(196,120,58,0.08) 1px, transparent 1px)",
      backgroundSize: "32px 32px"
    }
  }), /*#__PURE__*/React.createElement("svg", {
    width: "220",
    height: "160",
    viewBox: "0 0 220 160",
    fill: "none",
    style: {
      position: "relative",
      zIndex: 1,
      opacity: 0.45
    }
  }, /*#__PURE__*/React.createElement("rect", {
    x: "20",
    y: "20",
    width: "180",
    height: "120",
    stroke: "rgba(196,120,58,0.7)",
    strokeWidth: "1.5",
    fill: "none",
    strokeDasharray: "4 2"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "40",
    y: "40",
    width: "60",
    height: "40",
    stroke: "rgba(196,120,58,0.5)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "120",
    y: "40",
    width: "60",
    height: "40",
    stroke: "rgba(196,120,58,0.5)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "40",
    y: "95",
    width: "140",
    height: "30",
    stroke: "rgba(196,120,58,0.5)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "70",
    cy: "60",
    r: "12",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "62",
    y1: "60",
    x2: "78",
    y2: "60",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "70",
    y1: "52",
    x2: "70",
    y2: "68",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "150",
    cy: "60",
    r: "12",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "142",
    y1: "60",
    x2: "158",
    y2: "60",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "150",
    y1: "52",
    x2: "150",
    y2: "68",
    stroke: "rgba(74,158,191,0.6)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M70 48 L70 30 L150 30 L150 48",
    stroke: "rgba(74,158,191,0.4)",
    strokeWidth: "2",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "52",
    y: "100",
    width: "8",
    height: "8",
    stroke: "rgba(124,184,122,0.6)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "68",
    y: "100",
    width: "8",
    height: "8",
    stroke: "rgba(124,184,122,0.6)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "20",
    y1: "155",
    x2: "200",
    y2: "155",
    stroke: "rgba(196,120,58,0.3)",
    strokeWidth: "0.5"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "20",
    y1: "152",
    x2: "20",
    y2: "158",
    stroke: "rgba(196,120,58,0.3)",
    strokeWidth: "0.5"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "200",
    y1: "152",
    x2: "200",
    y2: "158",
    stroke: "rgba(196,120,58,0.3)",
    strokeWidth: "0.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "130",
    y: "130",
    width: "70",
    height: "16",
    stroke: "rgba(196,120,58,0.3)",
    strokeWidth: "0.5",
    fill: "none"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "155",
    y1: "130",
    x2: "155",
    y2: "146",
    stroke: "rgba(196,120,58,0.2)",
    strokeWidth: "0.5"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 12,
      left: 0,
      right: 0,
      textAlign: "center",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 9,
      color: "rgba(196,120,58,0.35)",
      letterSpacing: "0.15em",
      textTransform: "uppercase"
    }
  }, "Masterbuild Consulting \xB7 MEP Engineering"), caption && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 10,
      left: 12,
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 9,
      color: "rgba(196,120,58,0.45)",
      letterSpacing: "0.08em",
      textTransform: "uppercase"
    }
  }, caption));
}

// ── Experience Section ────────────────────────────────────────────────────
function MBExperience({
  lang,
  tweaks
}) {
  const t = MORE_CONTENT[lang].experience;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    id: "experience",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "40px 80px",
      alignItems: "start",
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 20px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.75,
      margin: 0
    }
  }, t.sub)), /*#__PURE__*/React.createElement(BlueprintPlaceholder, {
    height: 240,
    caption: t.photo.caption
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 2,
      marginBottom: 40
    }
  }, t.stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "32px 28px",
      background: "#131417",
      borderTop: `2px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 26,
      color: accent,
      marginBottom: 8
    }
  }, s.val), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 600,
      fontSize: 13,
      color: "#F0EDE8",
      marginBottom: 10,
      textTransform: "uppercase",
      letterSpacing: "0.04em"
    }
  }, s.label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.6
    }
  }, s.desc)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "28px 32px",
      background: "#131417",
      display: "flex",
      flexWrap: "wrap",
      gap: 12,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginRight: 8,
      whiteSpace: "normal",
      maxWidth: "100%",
      lineHeight: 1.5
    }
  }, t.sectors.label), t.sectors.items.map((item, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.55)",
      padding: "4px 12px",
      background: "#0B0C0E",
      borderRadius: 2
    }
  }, item)))));
}

// ── About Section ─────────────────────────────────────────────────────────
function MBAbout({
  lang,
  tweaks
}) {
  const t = MORE_CONTENT[lang].about;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    id: "about",
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 28px",
      maxWidth: 700,
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "40px 80px",
      alignItems: "start",
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, t.body.map((para, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: i === 0 ? "rgba(240,237,232,0.75)" : "rgba(240,237,232,0.5)",
      lineHeight: 1.8,
      margin: 0,
      ...(i === 0 ? {
        fontWeight: 500
      } : {})
    }
  }, para))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#131417",
      padding: "36px",
      borderTop: `3px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      height: 72,
      borderRadius: "50%",
      background: `rgba(196,120,58,0.1)`,
      border: `2px solid rgba(196,120,58,0.3)`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 20,
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 24,
      color: accent
    }
  }, "OP"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 18,
      color: "#F0EDE8",
      marginBottom: 4
    }
  }, t.profile.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.06em",
      marginBottom: 20
    }
  }, t.profile.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.7,
      margin: "0 0 24px"
    }
  }, t.profile.bio), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      marginBottom: 24
    }
  }, t.profile.credentials.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 4,
      height: 4,
      borderRadius: "50%",
      background: accent,
      flexShrink: 0,
      display: "inline-block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.65)"
    }
  }, c)))), /*#__PURE__*/React.createElement("a", {
    href: t.profile.linkedIn,
    target: "_blank",
    rel: "noreferrer",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      textDecoration: "none",
      letterSpacing: "0.06em",
      borderBottom: `1px solid rgba(196,120,58,0.3)`,
      paddingBottom: 2
    }
  }, "LinkedIn \u2192"))), t.proof && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, t.proof.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: "rgba(240,237,232,0.35)",
      letterSpacing: "0.04em"
    }
  }, t.proof.note)), /*#__PURE__*/React.createElement("div", {
    className: "mb-authority-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
      gap: 2
    }
  }, t.proof.items.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "24px 26px",
      background: "#131417",
      borderTop: "2px solid rgba(196,120,58,0.35)"
    }
  }, p.url ? /*#__PURE__*/React.createElement("a", {
    href: p.url,
    target: "_blank",
    rel: "noreferrer",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      color: "#F0EDE8",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      marginBottom: 10,
      display: "inline-block",
      textDecoration: "none",
      borderBottom: `1px solid rgba(196,120,58,0.35)`,
      paddingBottom: 2
    },
    title: `${lang === "en" ? "Visit" : "Visitar"} ${p.org}`
  }, p.org) : /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      color: "#F0EDE8",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      marginBottom: 10
    }
  }, p.org), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.65
    }
  }, p.role), p.url && /*#__PURE__*/React.createElement("a", {
    href: p.url,
    target: "_blank",
    rel: "noreferrer",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      textDecoration: "none",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      display: "inline-block",
      marginTop: 16
    }
  }, lang === "en" ? "Visit partner →" : "Visitar socio →"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 2
    }
  }, t.values.map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "32px 28px",
      background: "#131417",
      borderLeft: i === 0 ? `3px solid ${accent}` : "3px solid transparent"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 17,
      color: "#F0EDE8",
      margin: "0 0 12px"
    }
  }, v.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.7
    }
  }, v.body))))));
}

// ── Fee Process Section ───────────────────────────────────────────────────
function MBFeeProcess({
  lang,
  tweaks
}) {
  const t = MORE_CONTENT[lang].fee;
  const accent = tweaks.accent;
  const [activeStep, setActiveStep] = React.useState(0);
  return /*#__PURE__*/React.createElement("section", {
    id: "fee",
    style: {
      background: "#0B0C0E",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 3.5vw, 44px)",
      color: "#F0EDE8",
      margin: "0 0 16px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 16,
      color: "rgba(240,237,232,0.5)",
      margin: "0 0 28px",
      maxWidth: 560
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1.4fr",
      gap: "4px 0",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, t.steps.map((step, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActiveStep(i),
    style: {
      padding: "20px 24px",
      background: activeStep === i ? "#131417" : "transparent",
      border: "none",
      borderLeft: activeStep === i ? `3px solid ${accent}` : "3px solid transparent",
      cursor: "pointer",
      textAlign: "left",
      transition: "all 0.15s"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 12,
      color: activeStep === i ? accent : "rgba(240,237,232,0.25)",
      minWidth: 24
    }
  }, step.num), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 9,
      color: activeStep === i ? accent : "rgba(240,237,232,0.2)",
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 4
    }
  }, step.tag), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 600,
      fontSize: 15,
      color: activeStep === i ? "#F0EDE8" : "rgba(240,237,232,0.4)",
      lineHeight: 1.2
    }
  }, step.title)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#131417",
      padding: "40px 44px",
      borderTop: `3px solid ${accent}`,
      minHeight: 260
    }
  }, t.steps.map((step, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: activeStep === i ? "block" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      marginBottom: 12
    }
  }, step.tag, " / Step ", step.num), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(20px, 2.2vw, 26px)",
      color: "#F0EDE8",
      margin: "0 0 20px",
      lineHeight: 1.25
    }
  }, step.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "rgba(240,237,232,0.6)",
      lineHeight: 1.8,
      margin: "0 0 28px"
    }
  }, step.body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, i > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: () => setActiveStep(i - 1),
    style: {
      background: "none",
      border: "1px solid rgba(255,255,255,0.1)",
      color: "rgba(240,237,232,0.4)",
      padding: "8px 16px",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      borderRadius: 2
    }
  }, "\u2190 ", lang === "en" ? "Previous" : "Anterior"), i < t.steps.length - 1 && /*#__PURE__*/React.createElement("button", {
    onClick: () => setActiveStep(i + 1),
    style: {
      background: accent,
      border: "none",
      color: "#0B0C0E",
      padding: "8px 18px",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 600,
      borderRadius: 2
    }
  }, lang === "en" ? "Next" : "Siguiente", " \u2192"), i === t.steps.length - 1 && /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    style: {
      background: accent,
      color: "#0B0C0E",
      padding: "8px 18px",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 600,
      borderRadius: 2,
      textDecoration: "none"
    }
  }, t.cta, " \u2192")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      padding: "16px 24px",
      background: "rgba(196,120,58,0.05)",
      border: "1px solid rgba(196,120,58,0.15)",
      display: "flex",
      gap: 14,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      fontSize: 14,
      flexShrink: 0,
      marginTop: 1
    }
  }, " - "), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.5)",
      margin: 0,
      lineHeight: 1.6,
      fontStyle: "italic"
    }
  }, t.note))));
}
Object.assign(window, {
  MORE_CONTENT,
  BlueprintPlaceholder,
  MBExperience,
  MBAbout,
  MBFeeProcess
});
