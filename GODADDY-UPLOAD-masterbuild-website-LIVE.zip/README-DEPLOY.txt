Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod138.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 129 / prod138)
  Packets: IMC 603 duct construction (flex through a wall is not a
  connector; 14 ft), 604 insulation (one R-value is not a spec; 24 in
  coil zone), 403.3.1.1 Voz (divide by Ez), 603.18 outlets (not finish
  items; 200 lb; no floor grille in a public restroom).
  Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
