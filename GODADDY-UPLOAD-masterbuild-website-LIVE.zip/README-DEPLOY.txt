Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod108.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 99 / prod108)
  - /miami-dade-permit-portals/ — MEP-filtered County door map (apply / track / inspect / recert)
  - /miami-dade-mechanical-review/ — PE order of operations; official County PDFs linked, not copied
  - Spanish: /portales-de-permiso-miami-dade/, /revision-mecanica-miami-dade/
  - Field tools: 117 screens. New: #mdport and #mdrev
  - We did NOT host County PDFs or copy the mechanical guideline form.

SEVEN THINGS TO CHECK THE MOMENT IT IS LIVE

  1. https://masterbuildconsulting.com/resources/
     Chapter 8 shows "Get the Guide - $199". A Chapters 7 + 8 bundle card shows
     $299 and "Save $49".

  2. https://masterbuildconsulting.com/field-tools/
     Sticky category bar, 13 category cards, 117 screens. Run any chimney screen -
     the result must carry a $199 Chapter 8 offer. Click a screen's "Copy link",
     paste it in a new tab, and confirm it lands ON that screen.

  3. Any Daily Code Talk article, e.g.
     /daily-code-talk/imc-801-1-scope-venting-governing-code-path/
     Order should read: article, then a "$199" offer, then "I'll email you when the
     next guide ships", then the project CTA. Open a Sparky Edition post - it must
     show the email block but NO product offer.

  4. Enter your own email in that block. Confirm the Buttondown confirmation
     email arrives.

  5. https://masterbuildconsulting.com/guide-delivered/
     With no query string it must show ONLY the "email me" fallback - no downloads.

  6. https://masterbuildconsulting.com/library/
     Must NOT list files. A 403 or 404 is correct; a directory listing is not.

  7. BUY YOUR OWN PRODUCT ONCE, with a real card, using the bundle link. Confirm
     the redirect lands on /guide-delivered/. Then refund yourself in Stripe.

LIVE CHECKOUT LINKS IN THIS PACKAGE
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.
