Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod110.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 101 / prod110)
  Lead magnets (original Masterbuild writing — no County rate tables):
  - /miami-dade-mep-fees/ + mb-md-mep-fees-en/es.pdf
  - /miami-dade-electrical-review/ + electrical pre-upload PDF
  - /miami-dade-plumbing-review/ + plumbing pre-upload PDF
  - Field tools: 118 screens. New: #mdfee
  We do NOT quote County dollars. We do NOT publish Article 110.26 dimensions.

SEVEN THINGS TO CHECK THE MOMENT IT IS LIVE

  1. https://masterbuildconsulting.com/resources/
     New free cards: fee navigator, electrical pre-upload, plumbing pre-upload.

  2. https://masterbuildconsulting.com/miami-dade-mep-fees/
     No dollar amounts. Live County PDF links. Send CTA to /send/.

  3. https://masterbuildconsulting.com/field-tools/#mdfee
     Run “Exact AC change-out” — result must say Category 31 is not the mechanical permit.

  4. Enter your own email on /miami-dade-field-packets/. Confirm Buttondown.

  5. https://masterbuildconsulting.com/guide-delivered/
     With no query string it must show ONLY the "email me" fallback - no downloads.

  6. https://masterbuildconsulting.com/library/
     Must NOT list files.

  7. BUY YOUR OWN PRODUCT ONCE, then refund yourself in Stripe.

LIVE CHECKOUT LINKS IN THIS PACKAGE
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.
