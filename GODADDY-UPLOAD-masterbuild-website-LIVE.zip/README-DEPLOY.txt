Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod118.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 109 / prod118)
  - /miami-dade-equipment-setback/ — pad within 10 feet needs a survey
  - /miami-dade-wall-openings/ — a louver kills the 0-foot wall
  - /miami-dade-height-exemptions/ — parapet over 5 feet is height, not 306.5
  - Field tools: 126 screens. New: #mdsetback
  We do NOT copy 33-49 / 33-50 lot tables. We do NOT certify property lines.
  We do NOT seal coastal setbacks or seawalls.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
