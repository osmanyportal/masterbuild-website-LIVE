Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod141.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 132 / prod141)
  Packets: IMC 507.2 Type I (cfm/ft; wrap is not enclosure), 506.3.13
  grease termination (40 in; 10/3 ft), 506.3.7 slope/cleanouts (2%;
  20 ft / 10 ft), 307 condensate (if the primary stops, where does
  the water go?).
  Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
