Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod116.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 107 / prod116)
  - /miami-dade-180-day-clock/ — a fail does not extend
  - /miami-dade-temp-power/ — not a work-with
  - /miami-dade-revision-rework/ — three portal doors
  - Field tools: 124 screens. New: #mdclock
  We do NOT copy County inspection checklists. We do NOT invent NEC 110.26
  numbers. We do NOT quote extension or temp-power dollars.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
