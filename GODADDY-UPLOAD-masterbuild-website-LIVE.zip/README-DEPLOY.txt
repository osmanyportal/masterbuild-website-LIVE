Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod144.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 135 / prod144)
  Packets: IMC 401.2 path (tight dwellings are mechanical), 507.1.1
  interlock (auto-start / 15 min sensor / capture test), 507.1
  exceptions (listing on the drawings; 0.70 cfm/sf), 607.5.3
  partitions ("sprinklered" is not the exception).
  Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
