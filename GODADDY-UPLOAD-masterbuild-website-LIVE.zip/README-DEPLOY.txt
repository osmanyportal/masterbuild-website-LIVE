Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod111.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 102 / prod111)
  40-year recertification lead magnets (not County forms):
  - /miami-dade-40-year-notice/ + owner-clock PDF EN/ES
  - /miami-dade-electrical-recert-prep/ + field-prep PDF EN/ES
  - Field tools: 119 screens. New: #md40
  We do NOT quote County filing fees or fines. We do NOT seal structural or 8C-6 guardrails.
  We do NOT copy the County electrical-recertification form.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
