Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod113.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 104 / prod113)
  - /miami-dade-plumbing-inspection/ — dry pan is a story; meter by purveyor
  - /miami-dade-electrical-inspection/ — working space is not storage
  - /miami-dade-fire-desk/ — Fire is a second desk; no dollar quotes
  - Field tools: 121 screens. New: #mdinsp
  We do NOT copy County inspection checklists. We do NOT invent NEC 110.26 numbers.
  We do NOT quote Fire dollars.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
