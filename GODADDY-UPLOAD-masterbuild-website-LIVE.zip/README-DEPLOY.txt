Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod122.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 113 / prod122)
  Daily Code Talk #167–#171 (IMC 901–905) and Sparky Edition Article 110
  (kickoff through 110.14) are now on the site.
  Hubs: /chapter-9-general/, /masonry-fireplaces/, /factory-built-fireplaces/,
  /pellet-appliances/, /fireplace-stoves/, /electrical-connections/,
  /electrical-environment/.
  Field tools: 130 screens. New: #nec114.
  We do NOT invent 110.26 working-space dimensions.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
