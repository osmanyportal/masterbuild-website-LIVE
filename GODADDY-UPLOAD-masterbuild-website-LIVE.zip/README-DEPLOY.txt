Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod133.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 124 / prod133)
  Packets: IMC 407 healthcare (ASHRAE 170, not Table 403), 513 ERV
  (name the airstream; Type I is prohibited), 606 duct smoke (2,000 cfm
  combined), 501.3 discharge (3 ft / 10 ft; grease is 506.3.13).
  Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
