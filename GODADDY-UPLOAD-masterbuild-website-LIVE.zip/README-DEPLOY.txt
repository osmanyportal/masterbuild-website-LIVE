Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod149.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 140 / prod149)
  Impact-fee coordinator: /miami-dade-impact-fees/ (ES: /tarifas-de-impacto-miami-dade/).
  Five County buckets, the unit that actually bills, classification traps.
  Dated educational snapshot of the County schedule you provided 17 Sep 2026 —
  clearly labeled NOT A QUOTE. Confirm the live County PDF.
  MEP fee-sheet baseline PDF with category units + dated snapshot.
  Field tool #134: which bucket and which unit? Does not compute a total.
  Owner baseline transcription: _docs/BASELINE_MD_FEE_SNAPSHOT_2026-09.md
  (do not upload _docs to GoDaddy).
  Still no invented 110.26 or IMC 906. County PDFs are linked, not hosted.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
