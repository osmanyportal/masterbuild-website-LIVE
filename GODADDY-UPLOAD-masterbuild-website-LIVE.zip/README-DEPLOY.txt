Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod109.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 100 / prod109)
  Lead-magnet PE field packets (original Masterbuild writing — not County forms):
  - /uploads/mb-md-mechanical-preupload-en.pdf (+ ES)
  - /uploads/mb-md-mechanical-inspection-day-en.pdf (+ ES)
  - /uploads/mb-md-approved-as-noted-en.pdf (+ ES)
  Landing: /miami-dade-field-packets/  (ES: /paquetes-de-campo-miami-dade/)
  County PDFs are still linked, never hosted.

SEVEN THINGS TO CHECK THE MOMENT IT IS LIVE

  1. https://masterbuildconsulting.com/resources/
     Chapter 8 shows "Get the Guide - $199". A Chapters 7 + 8 bundle card shows
     $299 and "Save $49". New free cards: three Miami-Dade field packets.

  2. https://masterbuildconsulting.com/miami-dade-field-packets/
     Three PDF links download. Email capture block appears. Send CTA goes to /send/.

  3. https://masterbuildconsulting.com/field-tools/
     Sticky category bar, 13 category cards, 117 screens.

  4. Enter your own email in the packet page block. Confirm Buttondown confirmation.

  5. https://masterbuildconsulting.com/guide-delivered/
     With no query string it must show ONLY the "email me" fallback - no downloads.

  6. https://masterbuildconsulting.com/library/
     Must NOT list files. A 403 or 404 is correct; a directory listing is not.

  7. BUY YOUR OWN PRODUCT ONCE, with a real card, using the bundle link. Confirm
     the redirect lands on /guide-delivered/. Then refund yourself in Stripe.

LIVE CHECKOUT LINKS IN THIS PACKAGE
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.
