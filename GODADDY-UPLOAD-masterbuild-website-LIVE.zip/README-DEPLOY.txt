Masterbuild Consulting - website package
17 September 2026. Cache token 20260917-prod145.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 136 / prod145)
  Packets: IMC 601 return (a corridor is not a duct), 601.5 undercuts
  (¾ in is not a return design; closet 1½ in / 30 in²), 607.6
  horizontal (static CRD vs a fan that runs in a fire), 304.11
  roof-edge (10 ft / 42 in; a parapet you never measured is not a guard).
  Still no invented 110.26 or IMC 906. No invented IBC load numbers.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
