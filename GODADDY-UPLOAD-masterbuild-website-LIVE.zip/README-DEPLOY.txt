Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod119.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 110 / prod119)
  - /miami-dade-variance-clock/ — three years unused, the Board may take it back
  - /miami-dade-dic/ — DIC is zoning, not mechanical review
  - /miami-dade-moratorium/ — a new condenser is not a fence
  - Field tools: 127 screens. New: #mdzone
  We do NOT copy CZAB hearing procedures. We do NOT invent 33-304 County-impact
  thresholds. We do NOT take Water and Sewer. We do NOT argue vested rights.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
