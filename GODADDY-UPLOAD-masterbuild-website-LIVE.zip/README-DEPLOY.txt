Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod130.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 121 / prod130)
  Packets: IMC 404 parking garage (0.75 / 0.05 cfm/ft2 from DCT), 502.8
  hazmat/HPM (1 cfm/ft2, no fire damper in the shaft), 509 hazardous
  exhaust (not a plenum shortcut), 510.1.3 dust recirc (all three or
  outdoors). Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
