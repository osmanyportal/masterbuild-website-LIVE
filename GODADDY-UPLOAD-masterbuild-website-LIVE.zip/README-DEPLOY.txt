Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod117.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 108 / prod117)
  - /miami-dade-workforce-housing/ — expedite is not skipped review
  - /miami-dade-whu-equipment-screen/ — a parapet is not 306.5
  - /miami-dade-whu-septic/ — zoning did not buy the drain field
  - Field tools: 125 screens. New: #mdwhu
  We do NOT copy Chapter 33 intensity tables. We do NOT process Housing
  Agreements or impact-fee exemptions. We do NOT take Water and Sewer.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
