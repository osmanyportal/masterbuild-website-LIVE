Masterbuild Consulting - website package
16 September 2026. Cache token 20260916-prod129.

THIS IS THE ONLY ZIP. If you find another one anywhere, it is older than this.

UPLOAD
  1. Unzip this file.
  2. Upload the CONTENTS of public_html/ into the GoDaddy public_html folder.
     Include .htaccess AND the /library/ folder - turn on "show hidden files"
     in the GoDaddy file manager first, or both get silently skipped.
  3. Do NOT upload this README or the _docs/ folder.

WHAT IS NEW IN THIS PACKAGE (Pass 120 / prod129)
  Packets: IMC 502.1.2 fuel dispensing (18 in AFF), 502.7.7 dip/powder
  (no invented face velocity), 502.7 floor resurfacing (box fan is not
  502.7; HB 803 does not exempt mechanical), 502.3-502.5 battery rooms.
  Still no invented 110.26 or IMC 906.

ROLLBACK
  Take a copy of public_html on GoDaddy before you overwrite it.

LIVE CHECKOUT LINKS
  Chapter 8            $199  https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b
  Chapters 7+8 bundle  $299  https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c
