// mb-app.jsx  -  CTA, Footer, App root + render

const CONTACT_LEAD_MAGNET_SAMPLE_CHECKLIST_PDF = "uploads/permit-readiness-sample-checklist.pdf";
// Guarded catalog read. An unguarded window.MB_CATALOG.x at script load takes
// the whole page down if the catalog fails to load or parse - the same outage
// class already fixed in resources.js and daily-code-talk.js.
const MB_APP_CATALOG = window.MB_CATALOG || {};
const CONFIG_LINK_CALENDLY_SCOPING_CALL = MB_APP_CATALOG.scopingCall || "https://calendly.com/osmany-portal-masterbuildconsulting/30min";
const APP_CONTENT = {
  en: {
    cta: {
      eyebrow: "/ Next Step",
      headline: "Send the drawings and the real question.",
      sub: "A strong inquiry includes the project location, current stage, background files, and the actual decision point. That creates a real proposal conversation  -  not generic back-and-forth.",
      fields: {
        name: "Name",
        email: "Email",
        phone: "Phone",
        org: "Company / Organization",
        project: "Project type & location",
        message: "What's the actual question or decision?",
        submit: "Send Project Background",
        note: "Or email directly:"
      },
      phone: "+1 (786) 398-6940",
      email: "osmany.portal@masterbuildconsulting.com",
      leadMagnet: {
        eyebrow: "Not ready to write a scope?",
        title: "Start with the free permit-readiness sample.",
        body: "Use the sample checklist to organize project background before requesting a fixed-fee proposal.",
        cta: "Get the sample",
        success: "Sample ready.",
        download: "Download checklist",
        placeholder: "email@example.com",
        subject: "Masterbuild Permit Readiness Sample Checklist download"
      },
      path: {
        eyebrow: "What happens next",
        steps: [{
          label: "01 · Send background",
          body: "Location, stage, drawings if you have them, and the actual decision that needs to be made."
        }, {
          label: "02 · Scope review",
          body: "Fit, missing information, jurisdiction, and licensure path confirmed before anything is priced."
        }, {
          label: "03 · Written proposal",
          body: "Defined scope, deliverables, milestone structure, and a fixed fee. No hourly billing for standard permit scopes."
        }, {
          label: "04 · PE-direct delivery",
          body: "The licensed engineer runs the work, the review comments, and the construction-phase questions."
        }],
        note: "If it is not a fit, Masterbuild says so early instead of issuing a proposal."
      },
      scheduling: {
        eyebrow: "Lower-friction option",
        title: "Book a 30-minute scoping call.",
        body: "Use this when you know the project is real but do not have the full scope written yet. The call is for fit, timing, and next-step clarity.",
        cta: "Book a 30-minute scoping call",
        fallbackSubject: "30-minute scoping call request"
      }
    },
    footer: {
      tagline: "High-accountability MEP consulting.",
      nav: [{
        label: "Services",
        href: "#services"
      }, {
        label: "Project Fit",
        href: "#fit"
      }, {
        label: "About",
        href: "#about"
      }, {
        label: "Engagement Sizes",
        href: "#pricing"
      }, {
        label: "MEP Engineering in Miami",
        href: "/mep-engineering-miami/"
      }, {
        label: "About",
        href: "/about/"
      }, {
        label: "Process",
        href: "/process/"
      }, {
        label: "Selected Work",
        href: "/work/"
      }, {
        label: "Electrical Recertification",
        href: "/electrical-building-recertification-miami/"
      }, {
        label: "Septic Feasibility",
        href: "/miami-dade-septic-feasibility/"
      }, {
        label: "Private-Well Readiness",
        href: "/miami-dade-private-well-readiness/"
      }, {
        label: "Daily Code Talk",
        href: "/daily-code-talk/"
      }, {
        label: "Ventilation",
        href: "/ventilation/"
      }, {
        label: "Tenant improvements",
        href: "/tenant-improvement-mep-miami/"
      }, {
        label: "Field tools",
        href: "/field-tools/"
      }, {
        label: "Resources",
        href: "/resources/"
      }, {
        label: "Privacy",
        href: "/privacy/"
      }, {
        label: "Disclaimer",
        href: "/disclaimer/"
      }, {
        label: "FAQ",
        href: "#faq"
      }],
      bilingual: "Spanish-language technical content and bilingual project communication available as a premium service.",
      license: "Licensure, sealing, and delivery structure confirmed per project scope and jurisdiction.",
      copy: "© Masterbuild Consulting. All rights reserved. MasterBuild Contractors & Engineering Services LLC | Public brand: Masterbuild Consulting."
    }
  },
  es: {
    cta: {
      eyebrow: "/ Próximo Paso",
      headline: "Envíe los planos y la pregunta real.",
      sub: "Una consulta sólida incluye la ubicación del proyecto, la etapa actual, los archivos de antecedentes y el punto de decisión real. Eso crea una conversación de propuesta real, no intercambios genéricos.",
      fields: {
        name: "Nombre",
        email: "Correo electrónico",
        phone: "Teléfono",
        org: "Empresa / Organización",
        project: "Tipo y ubicación del proyecto",
        message: "¿Cuál es la pregunta o decisión real?",
        submit: "Enviar Antecedentes del Proyecto",
        note: "O escríbanos directamente:"
      },
      phone: "+1 (786) 398-6940",
      email: "osmany.portal@masterbuildconsulting.com",
      leadMagnet: {
        eyebrow: "¿Aún no tiene el alcance listo?",
        title: "Empiece con la muestra gratis de preparación para permisos.",
        body: "Use el checklist muestra para ordenar los antecedentes del proyecto antes de pedir una propuesta de fee fijo.",
        cta: "Recibir la muestra",
        success: "Muestra lista.",
        download: "Descargar checklist",
        placeholder: "correo@ejemplo.com",
        subject: "Masterbuild Permit Readiness Sample Checklist download"
      },
      path: {
        eyebrow: "Qué sigue",
        steps: [{
          label: "01 · Envíe antecedentes",
          body: "Ubicación, etapa, planos si los tiene, y la decisión real que hay que tomar."
        }, {
          label: "02 · Revisión de alcance",
          body: "Encaje, información faltante, jurisdicción y ruta de licencia confirmados antes de cotizar."
        }, {
          label: "03 · Propuesta escrita",
          body: "Alcance definido, entregables, estructura de hitos y fee fijo. Sin cobro por hora para alcances estándar de permiso."
        }, {
          label: "04 · Entrega PE-directa",
          body: "El ingeniero licenciado maneja el trabajo, los comentarios de revisión y las preguntas de construcción."
        }],
        note: "Si no hay encaje, Masterbuild lo dice temprano en lugar de emitir una propuesta."
      },
      scheduling: {
        eyebrow: "Opción más simple",
        title: "Reserve una llamada de alcance de 30 minutos.",
        body: "Use esta opción cuando el proyecto es real pero todavía no tiene el alcance completo por escrito. La llamada es para confirmar encaje, tiempo y próximos pasos.",
        cta: "Reservar llamada de 30 minutos",
        fallbackSubject: "Solicitud de llamada de alcance de 30 minutos"
      }
    },
    footer: {
      tagline: "Consultoría MEP de alta responsabilidad.",
      nav: [{
        label: "Servicios",
        href: "#services"
      }, {
        label: "Encaje del Proyecto",
        href: "#fit"
      }, {
        label: "Nosotros",
        href: "#about"
      }, {
        label: "Tamaños de Compromiso",
        href: "#pricing"
      }, {
        label: "Ingeniería MEP en Miami",
        href: "/ingenieria-mep-miami/"
      }, {
        label: "Recertificación Eléctrica",
        href: "/recertificacion-electrica-de-edificios-miami/"
      }, {
        label: "Viabilidad Séptica",
        href: "/viabilidad-septica-miami-dade/"
      }, {
        label: "Preparación de Pozo Privado",
        href: "/preparacion-pozo-privado-miami-dade/"
      }, {
        label: "Daily Code Talk",
        href: "/daily-code-talk/"
      }, {
        label: "Mejoras de locales",
        href: "/mejoras-de-locales-mep-miami/"
      }, {
        label: "Contacto",
        href: "/contacto/"
      }, {
        label: "Recursos",
        href: "#resources"
      }, {
        label: "Preguntas Frecuentes",
        href: "#faq"
      }],
      bilingual: "Contenido técnico en español y comunicación bilingüe de proyecto disponibles como servicio premium.",
      license: "Licencia, sellado y estructura de entrega confirmados por alcance del proyecto y jurisdicción.",
      copy: "© Masterbuild Consulting. Todos los derechos reservados. MasterBuild Contractors & Engineering Services LLC | Marca pública: Masterbuild Consulting."
    }
  }
};

// ─── CTA / Contact ────────────────────────────────────────────────────────
function MBContactCTA({
  lang,
  tweaks
}) {
  const t = APP_CONTENT[lang].cta;
  const accent = tweaks.accent;
  const [form, setForm] = React.useState({
    name: "",
    email: "",
    phone: "",
    org: "",
    projectType: "",
    disciplines: [],
    state: "",
    stage: "",
    permitDeadline: "",
    hasDrawings: "",
    blockingIssue: "",
    documentLink: "",
    website: "",
    message: ""
  });
  const [sent, setSent] = React.useState(false);
  const [submitError, setSubmitError] = React.useState("");
  const [sampleEmail, setSampleEmail] = React.useState("");
  const [sampleReady, setSampleReady] = React.useState(false);
  React.useEffect(() => {
    const applyServiceInterest = () => {
      let interest = null;
      try {
        interest = window.sessionStorage.getItem("mb_service_interest");
        if (interest) window.sessionStorage.removeItem("mb_service_interest");
      } catch (e) {}
      if (!interest) return;
      const prefix = lang === "en" ? "Interest: " : "Interés: ";
      setForm(f => f.message ? f : { ...f, message: `${prefix}${interest}\n\n` });
    };
    applyServiceInterest();
    window.addEventListener("hashchange", applyServiceInterest);
    return () => window.removeEventListener("hashchange", applyServiceInterest);
  }, [lang]);
  const PROJECT_TYPE_OPTS = lang === "en" ? ["", "Permit-level MEP construction documents", "Permit comment response / resubmittal", "Commercial Tenant Improvement", "Commercial kitchen / Type I hood", "New Construction  -  Commercial", "High-End Residential", "Multifamily / Mixed-Use", "Existing Building Renovation", "Healthcare / Medical Facility", "Lab / Research Facility", "Data Center / Server Room", "Assessment or Feasibility Study", "Construction Advisory", "Electrical Building Recertification - 30- or 40-Year Readiness - Miami-Dade", "Miami-Dade septic / OSTDS feasibility", "Private-well record and permit readiness", "Monthly Design Advisory retainer", "Other"] : ["", "Documentos MEP para permiso", "Respuesta a comentarios de permiso", "Mejora de Inquilino Comercial", "Cocina comercial / campana Tipo I", "Nueva Construcción  -  Comercial", "Residencial de Alto Nivel", "Multifamiliar / Uso Mixto", "Renovación de Edificio Existente", "Centro de Salud / Instalación Médica", "Laboratorio / Instalación de Investigación", "Centro de Datos / Sala de Servidores", "Estudio de Evaluación o Viabilidad", "Asesoría de Construcción", "Recertificación Eléctrica de Edificios - Preparación de 30 o 40 Años - Miami-Dade", "Viabilidad séptica / OSTDS Miami-Dade", "Preparación de pozo privado", "Asesoría de diseño mensual", "Otro"];
  const STATE_OPTS = lang === "en"
    ? ["", "Miami-Dade County, FL", "City of Miami, FL", "Miami Beach, FL", "Broward County, FL", "Other Florida", "NY", "NJ", "TX", "PA", "Other / Multiple"]
    : ["", "Condado Miami-Dade, FL", "Ciudad de Miami, FL", "Miami Beach, FL", "Condado Broward, FL", "Otra Florida", "NY", "NJ", "TX", "PA", "Otro / Múltiple"];
  const DEADLINE_OPTS = lang === "en"
    ? ["", "Flexible / No hard deadline", "Within 6 months", "Within 3 months", "Within 6 weeks", "ASAP / Urgent"]
    : ["", "Flexible / Sin fecha límite", "Dentro de 6 meses", "Dentro de 3 meses", "Dentro de 6 semanas", "Lo antes posible / Urgente"];
  const DRAWINGS_OPTS = lang === "en"
    ? ["", "Yes — complete architectural drawings", "Partial — some drawings available", "Sketches / schematic only", "No drawings yet"]
    : ["", "Sí — planos arquitectónicos completos", "Parcial — algunos planos disponibles", "Solo bocetos / esquemáticos", "Sin planos todavía"];
  const STAGE_OPTS = lang === "en" ? ["", "Pre-Design / Feasibility", "Schematic Design", "Design Development", "Ready for Permit Submission", "Under Permit Review", "Construction Support", "Existing Building  -  No Active Design"] : ["", "Pre-Diseño / Factibilidad", "Diseño Esquemático", "Desarrollo de Diseño", "Listo para Submisión de Permiso", "En Revisión de Permiso", "Soporte de Construcción", "Edificio Existente  -  Sin Diseño Activo"];
  const DISC_OPTS = lang === "en"
    ? ["HVAC", "Plumbing", "Fire Protection", "Electrical"]
    : ["HVAC", "Plomería", "Protección Contra Incendios", "Eléctrico"];
  const toggleDisc = d => setForm(f => ({
    ...f,
    disciplines: f.disciplines.includes(d) ? f.disciplines.filter(x => x !== d) : [...f.disciplines, d]
  }));
  const selectStyle = {
    width: "100%",
    padding: "11px 14px",
    background: "#1C1E23",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#F0EDE8",
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: 14,
    outline: "none",
    borderRadius: 3,
    appearance: "none",
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23C4783A' stroke-width='1.5' fill='none'/%3E%3C/svg%3E")`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "right 12px center",
    paddingRight: 36,
    cursor: "pointer",
    transition: "border-color 0.2s"
  };
  const inputStyle = {
    width: "100%",
    padding: "12px 16px",
    background: "#1C1E23",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#F0EDE8",
    fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: 14,
    outline: "none",
    borderRadius: 3,
    boxSizing: "border-box",
    transition: "border-color 0.2s"
  };
  const labelStyle = {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 10,
    color: accent,
    letterSpacing: "0.1em",
    textTransform: "uppercase",
    display: "block",
    marginBottom: 6
  };
  const handleSubmit = async e => {
    e.preventDefault();
    setSubmitError("");
    if (form.website) return;
    if (!form.name.trim() || !form.email.trim() || !form.phone.trim()) {
      setSubmitError(lang === "en" ? "Please provide your name, email, and phone number so Masterbuild can follow up properly." : "Indique su nombre, correo y teléfono para que Masterbuild pueda dar seguimiento correctamente.");
      return;
    }
    if (window.trackMBEvent) window.trackMBEvent("Contact Form Submit", {
      language: lang,
      leadType: "project_inquiry",
      followUpPriority: "high"
    });
    const disciplineStr = form.disciplines.length ? form.disciplines.join(", ") : lang === "en" ? "Not specified" : "No especificado";
    const inquiryText = `${form.projectType} ${form.message} ${form.blockingIssue}`;
    const isPrivateProviderInquiry = /private provider|proveedor privado/i.test(inquiryText);
    const isElectricalRecertInquiry = /electrical.*recert|recertification|recertificaci[oó]n|30[- ]?year|40[- ]?year|30[- ]?a[nñ]os|40[- ]?a[nñ]os/i.test(inquiryText);
    const isSeptic = /septic|ostds|s[eé]ptic/i.test(inquiryText);
    const isWell = /private[- ]?well|pozo/i.test(inquiryText);
    const isKitchen = /kitchen|hood|campana/i.test(inquiryText);
    let shortType = "MEP";
    if (isPrivateProviderInquiry) shortType = "PRIVATE PROVIDER - SERVICE UNAVAILABLE";
    else if (isElectricalRecertInquiry) shortType = "Recertification";
    else if (isSeptic) shortType = "Septic";
    else if (isWell) shortType = "Private Well";
    else if (isKitchen) shortType = "Kitchen Exhaust";
    else if (/comment|resubmittal/i.test(inquiryText)) shortType = "Permit Comments";
    const routedSubject = `[NEW PROJECT] ${shortType} / ${disciplineStr.split(",")[0] || "MEP"} / ${form.state || "Jurisdiction TBD"} / ${form.stage || "Stage TBD"}`;
    try {
      const response = await fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          lead_type: isPrivateProviderInquiry ? "Private Provider inquiry - service unavailable" : isElectricalRecertInquiry ? "Electrical Building Recertification readiness inquiry" : "Project inquiry / proposal request",
          lead_intent: isPrivateProviderInquiry ? "Service unavailable; owner review of any unsolicited inquiry" : isElectricalRecertInquiry ? "Confirm recertification notice or case, jurisdiction, record set, requested electrical scope, and responsible electrical-discipline professional before proposal" : "Request a fixed-fee proposal conversation",
          follow_up_priority: "High",
          source: "Public website contact form",
          submission_route: window.location.pathname || "/",
          next_action: isPrivateProviderInquiry ? "Do not quote or accept Private Provider work. Firm registration, required professional liability coverage, and owner release evidence must be verified before this service is marketed or offered." : isElectricalRecertInquiry ? "Confirm the Electrical Building Recertification notice or case, jurisdiction, building records, requested electrical scope, access, and responsible electrical-discipline professional before accepting report work." : "Review project fit, missing background, and respond with scoping questions or proposal path.",
          name: form.name,
          email: form.email,
          phone: form.phone,
          org: form.org,
          project_type: form.projectType,
          disciplines: disciplineStr,
          state_jurisdiction: form.state,
          project_stage: form.stage,
          permit_deadline: form.permitDeadline || (lang === "en" ? "Not specified" : "No especificado"),
          existing_drawings: form.hasDrawings || (lang === "en" ? "Not specified" : "No especificado"),
          blocking_issue: form.blockingIssue || (lang === "en" ? "Not specified" : "No especificado"),
          document_link: form.documentLink || (lang === "en" ? "No link provided — files should be sent as a share URL" : "Sin enlace"),
          message: form.message,
          _subject: routedSubject,
          _replyto: form.email,
          _template: "table",
          _captcha: "false"
        })
      });
      if (!response.ok) throw new Error("Form submission failed");
      setSent(true);
    } catch (error) {
      setSubmitError(lang === "en" ? "The form did not submit. Please email osmany.portal@masterbuildconsulting.com or call +1 (786) 398-6940." : "El formulario no se envió. Escriba a osmany.portal@masterbuildconsulting.com o llame al +1 (786) 398-6940.");
    }
  };
  const handleSampleDownload = () => {
    const cleanEmail = sampleEmail.trim();
    if (!cleanEmail) return;
    fetch("https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        lead_type: "Free sample PDF request",
        lead_intent: "Download permit readiness sample checklist",
        follow_up_priority: "Low",
        email: cleanEmail,
        source: "Contact section lead magnet",
        submission_route: window.location.pathname || "/",
        asset: "Permit Readiness Sample Checklist",
        language: lang,
        next_action: "Send sample and optionally nurture toward permit-readiness or proposal workflow.",
        _subject: `${t.leadMagnet.subject} (${lang.toUpperCase()})`,
        _template: "table",
        _captcha: "false"
      })
    }).catch(() => {}).finally(() => setSampleReady(true));
  };
  const schedulingHref = CONFIG_LINK_CALENDLY_SCOPING_CALL || `mailto:${t.email}?subject=${encodeURIComponent(t.scheduling.fallbackSubject)}`;
  const showCalendlyEmbed = Boolean(CONFIG_LINK_CALENDLY_SCOPING_CALL) && (typeof window === "undefined" || window.innerWidth >= 900);
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-contact-grid",
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "1fr 1.2fr",
      gap: "64px 80px",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      display: "block",
      marginBottom: 16
    }
  }, t.eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(28px, 3.5vw, 46px)",
      color: "#F0EDE8",
      margin: "0 0 24px",
      lineHeight: 1.1
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      lineHeight: 1.75,
      color: "rgba(240,237,232,0.55)",
      margin: "0 0 40px"
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      background: "rgba(196,120,58,0.1)",
      border: "1px solid rgba(196,120,58,0.2)",
      borderRadius: 3,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: accent,
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.09 9.82a19.79 19.79 0 01-3.07-8.63A2 2 0 012 .99h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006.29 6.29l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"
  }))), /*#__PURE__*/React.createElement("a", {
    href: `tel:${t.phone}`,
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 14,
      color: "#F0EDE8",
      textDecoration: "none"
    }
  }, t.phone)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      background: "rgba(196,120,58,0.1)",
      border: "1px solid rgba(196,120,58,0.2)",
      borderRadius: 3,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: accent,
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "22,6 12,13 2,6"
  }))), /*#__PURE__*/React.createElement("a", {
    href: `mailto:${t.email}`,
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 13,
      color: accent,
      textDecoration: "none",
      wordBreak: "break-all"
    }
  }, t.email)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      background: "rgba(196,120,58,0.1)",
      border: "1px solid rgba(196,120,58,0.2)",
      borderRadius: 3,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: accent,
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6z"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "9",
    width: "4",
    height: "12"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "4",
    cy: "4",
    r: "2"
  }))), /*#__PURE__*/React.createElement("a", {
    href: "https://www.linkedin.com/in/osmanyportal/",
    target: "_blank",
    rel: "noreferrer",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 13,
      color: "#F0EDE8",
      textDecoration: "none"
    }
  }, "linkedin.com/in/osmanyportal"))), /*#__PURE__*/React.createElement("div", {
    "data-proposal-path": "true",
    style: {
      marginTop: 34,
      padding: "22px 24px",
      background: "#131417",
      borderTop: "1px solid rgba(255,255,255,0.07)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 14
    }
  }, t.path.eyebrow), /*#__PURE__*/React.createElement("ol", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      listStyle: "none",
      margin: 0,
      padding: 0
    }
  }, t.path.steps.map(step => /*#__PURE__*/React.createElement("li", {
    key: step.label
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: "#F0EDE8",
      letterSpacing: "0.04em",
      marginBottom: 3
    }
  }, step.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.6
    }
  }, step.body)))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "14px 0 0",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.38)",
      lineHeight: 1.6
    }
  }, t.path.note)), /*#__PURE__*/React.createElement("div", {
    "data-scheduling-cta": "scoping-call",
    style: {
      marginTop: 34,
      padding: "22px 24px",
      background: "rgba(196,120,58,0.08)",
      borderTop: `3px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 8
    }
  }, t.scheduling.eyebrow), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 19,
      color: "#F0EDE8",
      lineHeight: 1.25,
      margin: "0 0 10px"
    }
  }, t.scheduling.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.58)",
      lineHeight: 1.6,
      margin: "0 0 14px"
    }
  }, t.scheduling.body), /*#__PURE__*/React.createElement("a", {
    href: schedulingHref,
    target: showCalendlyEmbed ? "_blank" : undefined,
    rel: showCalendlyEmbed ? "noopener noreferrer" : undefined,
    "data-analytics": "scoping-call-click",
    style: {
      display: "inline-flex",
      justifyContent: "center",
      width: "100%",
      padding: "10px 14px",
      background: accent,
      color: "#0B0C0E",
      textDecoration: "none",
      borderRadius: 2,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, t.scheduling.cta), showCalendlyEmbed && /*#__PURE__*/React.createElement("iframe", {
    title: t.scheduling.cta,
    src: CONFIG_LINK_CALENDLY_SCOPING_CALL,
    style: {
      width: "100%",
      height: 640,
      border: "1px solid rgba(255,255,255,0.08)",
      marginTop: 16,
      background: "#0B0C0E"
    }
  })), /*#__PURE__*/React.createElement("div", {
    "data-contact-lead-magnet": "permit-readiness-sample",
    style: {
      marginTop: 34,
      padding: "22px 24px",
      background: "#131417",
      borderTop: `3px solid ${accent}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 8
    }
  }, t.leadMagnet.eyebrow), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 19,
      color: "#F0EDE8",
      lineHeight: 1.25,
      margin: "0 0 10px"
    }
  }, t.leadMagnet.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.55)",
      lineHeight: 1.6,
      margin: "0 0 14px"
    }
  }, t.leadMagnet.body), sampleReady ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: accent
    }
  }, t.leadMagnet.success), /*#__PURE__*/React.createElement("a", {
    href: CONTACT_LEAD_MAGNET_SAMPLE_CHECKLIST_PDF,
    download: true,
    "data-analytics": "contact-lead-magnet-download",
    style: {
      display: "inline-flex",
      justifyContent: "center",
      padding: "10px 14px",
      background: accent,
      color: "#0B0C0E",
      textDecoration: "none",
      borderRadius: 2,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 700
    }
  }, t.leadMagnet.download)) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: sampleEmail,
    onChange: e => setSampleEmail(e.target.value),
    onKeyDown: e => e.key === "Enter" && handleSampleDownload(),
    type: "email",
    placeholder: t.leadMagnet.placeholder,
    style: {
      flex: 1,
      minWidth: 180,
      padding: "9px 11px",
      background: "#0B0C0E",
      border: "1px solid rgba(255,255,255,0.1)",
      color: "#F0EDE8",
      borderRadius: 2,
      outline: "none",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12
    },
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.1)"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: handleSampleDownload,
    "data-analytics": "contact-lead-magnet-submit",
    style: {
      padding: "9px 14px",
      background: accent,
      color: "#0B0C0E",
      border: "none",
      borderRadius: 2,
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      fontWeight: 700
    }
  }, t.leadMagnet.cta)))), /*#__PURE__*/React.createElement("div", {
    className: "mb-cta-card",
    style: {
      background: "#131417",
      padding: "40px",
      borderTop: `3px solid ${accent}`
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "40px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 22,
      color: accent,
      marginBottom: 12
    }
  }, "\u2713 ", lang === "en" ? "Message received." : "Mensaje recibido."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      color: "rgba(240,237,232,0.5)",
      lineHeight: 1.6
    }
  }, lang === "en" ? "Masterbuild will review your project background and respond with a real proposal conversation." : "Masterbuild revisará los antecedentes de su proyecto y responderá con una conversación de propuesta real.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-cta-form-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, t.fields.name), /*#__PURE__*/React.createElement("input", {
    value: form.name,
    onChange: e => setForm({
      ...form,
      name: e.target.value
    }),
    required: true,
    autoComplete: "name",
    style: inputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, t.fields.email), /*#__PURE__*/React.createElement("input", {
    value: form.email,
    onChange: e => setForm({
      ...form,
      email: e.target.value
    }),
    required: true,
    type: "email",
    autoComplete: "email",
    style: inputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb-cta-form-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, t.fields.phone), /*#__PURE__*/React.createElement("input", {
    value: form.phone,
    onChange: e => setForm({
      ...form,
      phone: e.target.value
    }),
    type: "tel",
    required: true,
    autoComplete: "tel",
    style: inputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, t.fields.org), /*#__PURE__*/React.createElement("input", {
    value: form.org,
    onChange: e => setForm({
      ...form,
      org: e.target.value
    }),
    autoComplete: "organization",
    style: inputStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Project Type" : "Tipo de Proyecto"), /*#__PURE__*/React.createElement("select", {
    value: form.projectType,
    onChange: e => setForm({
      ...form,
      projectType: e.target.value
    }),
    required: true,
    style: selectStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }, PROJECT_TYPE_OPTS.map((o, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: o,
    style: {
      background: "#1C1E23"
    }
  }, o || (lang === "en" ? "Select project type…" : "Seleccionar tipo…"))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Disciplines Needed" : "Disciplinas Requeridas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, DISC_OPTS.map(d => {
    const active = form.disciplines.includes(d);
    return /*#__PURE__*/React.createElement("button", {
      key: d,
      type: "button",
      onClick: () => toggleDisc(d),
      style: {
        padding: "7px 14px",
        background: active ? `rgba(196,120,58,0.15)` : "#1C1E23",
        border: active ? `1px solid ${accent}` : "1px solid rgba(255,255,255,0.08)",
        color: active ? accent : "rgba(240,237,232,0.5)",
        fontFamily: "'IBM Plex Sans', sans-serif",
        fontSize: 12,
        borderRadius: 3,
        cursor: "pointer",
        transition: "all 0.15s"
      }
    }, d);
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb-cta-form-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "State / Jurisdiction" : "Estado / Jurisdicción"), /*#__PURE__*/React.createElement("select", {
    value: form.state,
    onChange: e => setForm({
      ...form,
      state: e.target.value
    }),
    style: selectStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }, STATE_OPTS.map((o, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: o,
    style: {
      background: "#1C1E23"
    }
  }, o || (lang === "en" ? "Select state…" : "Seleccionar estado…"))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Project Stage" : "Etapa del Proyecto"), /*#__PURE__*/React.createElement("select", {
    value: form.stage,
    onChange: e => setForm({
      ...form,
      stage: e.target.value
    }),
    style: selectStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }, STAGE_OPTS.map((o, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: o,
    style: {
      background: "#1C1E23"
    }
  }, o || (lang === "en" ? "Select stage…" : "Seleccionar etapa…")))))), /*#__PURE__*/React.createElement("div", {
    className: "mb-cta-form-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Permit Deadline" : "Fecha Límite de Permiso"), /*#__PURE__*/React.createElement("select", {
    value: form.permitDeadline,
    onChange: e => setForm({
      ...form,
      permitDeadline: e.target.value
    }),
    style: selectStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }, DEADLINE_OPTS.map((o, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: o,
    style: {
      background: "#1C1E23"
    }
  }, o || (lang === "en" ? "Select timeline…" : "Seleccionar plazo…"))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Existing Drawings" : "Planos Existentes"), /*#__PURE__*/React.createElement("select", {
    value: form.hasDrawings,
    onChange: e => setForm({
      ...form,
      hasDrawings: e.target.value
    }),
    style: selectStyle,
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  }, DRAWINGS_OPTS.map((o, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: o,
    style: {
      background: "#1C1E23"
    }
  }, o || (lang === "en" ? "Select drawings status…" : "Estado de planos…")))))), /*#__PURE__*/React.createElement("div", {
    style: { position: "absolute", left: "-9999px", height: 0, overflow: "hidden" },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("label", null, "Company website"), /*#__PURE__*/React.createElement("input", {
    tabIndex: -1,
    autoComplete: "off",
    value: form.website,
    onChange: e => setForm({ ...form, website: e.target.value })
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "What is currently preventing progress?" : "¿Qué impide el avance ahora?"), /*#__PURE__*/React.createElement("input", {
    value: form.blockingIssue,
    onChange: e => setForm({ ...form, blockingIssue: e.target.value }),
    placeholder: lang === "en" ? "e.g. plan-review comments, unknown service capacity, recertification notice" : "p. ej. comentarios de revisión, capacidad desconocida, aviso de recertificación",
    style: inputStyle
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, lang === "en" ? "Link to drawings, comments, or notice" : "Enlace a planos, comentarios o aviso"), /*#__PURE__*/React.createElement("input", {
    value: form.documentLink,
    type: "url",
    onChange: e => setForm({ ...form, documentLink: e.target.value }),
    placeholder: "https://",
    style: inputStyle
  })), /*#__PURE__*/React.createElement("p", {
    style: { fontSize: 12, color: "rgba(240,237,232,0.45)", margin: "-6px 0 8px", fontFamily: "'IBM Plex Sans', sans-serif" }
  }, lang === "en" ? "Use a share link. Raw CAD is not uploaded through this form." : "Use un enlace compartido. No se cargan archivos CAD por este formulario."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, t.fields.message), /*#__PURE__*/React.createElement("textarea", {
    value: form.message,
    onChange: e => setForm({
      ...form,
      message: e.target.value
    }),
    required: true,
    rows: 4,
    style: {
      ...inputStyle,
      resize: "vertical"
    },
    onFocus: e => e.target.style.borderColor = accent,
    onBlur: e => e.target.style.borderColor = "rgba(255,255,255,0.08)"
  })), submitError && /*#__PURE__*/React.createElement("div", {
    role: "alert",
    style: {
      padding: "12px 14px",
      background: "rgba(217,107,90,0.1)",
      border: "1px solid rgba(217,107,90,0.35)",
      color: "#F0EDE8",
      borderRadius: 3,
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      lineHeight: 1.5
    }
  }, submitError), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: {
      padding: "14px 24px",
      background: accent,
      color: "#0B0C0E",
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 14,
      letterSpacing: "0.02em",
      borderRadius: 3,
      transition: "opacity 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.opacity = "0.85",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, t.fields.submit)))));
}

// ─── Footer ───────────────────────────────────────────────────────────────
function MBFooter({
  lang,
  setLang,
  tweaks
}) {
  const t = APP_CONTENT[lang].footer;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "#080909",
      padding: "64px 40px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb-footer-grid",
    style: {
      display: "grid",
      gridTemplateColumns: "1.5fr 1fr 1fr",
      gap: "40px 60px",
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "uploads/Master Build Logo- Revised.png",
    alt: "Masterbuild",
    loading: "lazy",
    decoding: "async",
    width: "44",
    height: "44",
    style: {
      height: 44,
      width: 44,
      objectFit: "contain",
      filter: "invert(1)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 18,
      color: "#F0EDE8",
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      lineHeight: 1
    }
  }, "Masterbuild"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 400,
      fontSize: 11,
      color: accent,
      letterSpacing: "0.12em",
      textTransform: "uppercase"
    }
  }, "Consulting"))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.4)",
      lineHeight: 1.7,
      margin: "0 0 20px",
      maxWidth: 280
    }
  }, t.tagline), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.3)",
      lineHeight: 1.6,
      margin: "0 0 20px",
      maxWidth: 280
    }
  }, t.bilingual), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 0,
      background: "rgba(255,255,255,0.05)",
      borderRadius: 3,
      overflow: "hidden",
      border: "1px solid rgba(255,255,255,0.07)",
      width: "fit-content"
    }
  }, ["en", "es"].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => setLang(l),
    style: {
      padding: "5px 14px",
      background: lang === l ? accent : "transparent",
      color: lang === l ? "#0B0C0E" : "rgba(240,237,232,0.4)",
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      transition: "all 0.2s"
    }
  }, l.toUpperCase())))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 20
    }
  }, lang === "en" ? "Navigation" : "Navegación"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, t.nav.map(item => /*#__PURE__*/React.createElement("a", {
    key: item.href,
    href: item.href,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      color: "rgba(240,237,232,0.45)",
      textDecoration: "none",
      transition: "color 0.2s"
    },
    onMouseEnter: e => e.target.style.color = "#F0EDE8",
    onMouseLeave: e => e.target.style.color = "rgba(240,237,232,0.45)"
  }, item.label)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      marginBottom: 20
    }
  }, lang === "en" ? "Contact" : "Contacto"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "tel:+17863986940",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 13,
      color: "rgba(240,237,232,0.5)",
      textDecoration: "none"
    }
  }, "+1 (786) 398-6940"), /*#__PURE__*/React.createElement("a", {
    href: "mailto:osmany.portal@masterbuildconsulting.com",
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      textDecoration: "none",
      wordBreak: "break-all"
    }
  }, "osmany.portal@masterbuildconsulting.com"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      color: "rgba(240,237,232,0.3)"
    }
  }, "Miami, FL  -  Licensure confirmed per project scope"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      marginTop: 4
    }
  }, [{
    label: "LI",
    href: "https://www.linkedin.com/in/osmanyportal/"
  }, {
    label: "Co",
    href: "https://www.linkedin.com/company/masterbuildconsulting/"
  }, {
    label: "IG",
    href: "https://www.instagram.com/masterbuildconsulting/"
  }, {
    label: "YT",
    href: "https://www.youtube.com/@masterbuildconsulting"
  }].map(s => /*#__PURE__*/React.createElement("a", {
    key: s.label,
    href: s.href,
    target: "_blank",
    rel: "noreferrer",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Footer Social Click", {
      platform: s.label === "LI" ? "linkedin-personal" : s.label === "Co" ? "linkedin-company" : s.label === "IG" ? "instagram" : "youtube",
      language: lang
    }),
    style: {
      width: 32,
      height: 32,
      background: "rgba(255,255,255,0.05)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: 3,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 10,
      color: "rgba(240,237,232,0.4)",
      textDecoration: "none",
      transition: "all 0.2s"
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = accent;
      e.currentTarget.style.color = accent;
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
      e.currentTarget.style.color = "rgba(240,237,232,0.4)";
    }
  }, s.label)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid rgba(255,255,255,0.05)",
      paddingTop: 24,
      display: "flex",
      justifyContent: "space-between",
      flexWrap: "wrap",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      color: "rgba(240,237,232,0.25)"
    }
  }, t.copy), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 11,
      color: "rgba(240,237,232,0.2)",
      maxWidth: 480,
      textAlign: "right"
    }
  }, t.license))));
}

// ─── Main App ─────────────────────────────────────────────────────────────
function getInitialSiteLang() {
  try {
    const params = new URLSearchParams(window.location.search);
    const routeLang = (params.get("lang") || params.get("language") || "").toLowerCase();
    const path = window.location.pathname.toLowerCase();
    if (routeLang === "es" || path.endsWith("/es") || path.endsWith("/es/") || path.endsWith("/es.html")) return "es";
    if (routeLang === "en" || path.endsWith("/en") || path.endsWith("/en/") || path.endsWith("/en.html")) return "en";
    if (window.MB_DEFAULT_LANG === "es") return "es";
    const savedLang = window.localStorage.getItem("mb_lang");
    return savedLang === "es" ? "es" : "en";
  } catch (err) {
    return "en";
  }
}
function updateLanguageUrl(nextLang) {
  try {
    const target = nextLang === "es" ? "es.html" : "en.html";
    const hash = window.location.hash || "";
    window.history.replaceState(null, "", `${target}${hash}`);
  } catch (err) {}
}
function MasterbuildApp() {
  const [lang, setLang] = React.useState(getInitialSiteLang);
  const [tweaks, setTweak] = useTweaks({
    accent: "#C4783A",
    darkMode: true
  });
  const safeTweaks = tweaks || {
    accent: "#C4783A",
    darkMode: true
  };
  const changeLanguage = React.useCallback(nextLang => {
    setLang(nextLang);
    updateLanguageUrl(nextLang);
  }, []);
  React.useEffect(() => {
    document.documentElement.lang = lang;
    document.body.dataset.lang = lang;
    try {
      window.localStorage.setItem("mb_lang", lang);
    } catch (err) {}
  }, [lang]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#0B0C0E",
      minHeight: "100vh"
    }
  }, /*#__PURE__*/React.createElement(TweaksPanel, {
    title: "Tweaks"
  }, /*#__PURE__*/React.createElement(TweakColor, {
    label: "Accent Color",
    value: safeTweaks.accent,
    onChange: v => setTweak("accent", v)
  }), /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Dark Mode",
    value: safeTweaks.darkMode,
    onChange: v => setTweak("darkMode", v)
  })), /*#__PURE__*/React.createElement(MBNav, {
    lang: lang,
    setLang: changeLanguage,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBHero, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBDifferentiators, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBEarlyCapture, {
    lang: lang
  }), /*#__PURE__*/React.createElement(MBServices, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBKnowledgeHubs, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBExistingBuildings, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBFitCheck, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBTrustBand, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBDailyCodeTalk, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBResourceLibrary, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBAbout, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBPricingBand, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBFAQ, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBContactCTA, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBFloatingCTA, {
    lang: lang,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBFooter, {
    lang: lang,
    setLang: changeLanguage,
    tweaks: safeTweaks
  }), /*#__PURE__*/React.createElement(MBScrollDepthTracker, null));
}
const mbRoot = ReactDOM.createRoot(document.getElementById("root"));
mbRoot.render(/*#__PURE__*/React.createElement(MasterbuildApp, null));

// Activate scroll-reveal observer once React hydration settles
setTimeout(function () { window.MBInitReveal && window.MBInitReveal(); }, 600);
