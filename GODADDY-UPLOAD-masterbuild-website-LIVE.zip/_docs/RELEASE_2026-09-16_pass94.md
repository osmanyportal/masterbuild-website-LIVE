# Release note — Pass 94 (16 September 2026)

Cache token: `20260916-prod103`.

Baseline: the 14 September production ZIP the owner attached (`masterbuild-website-LIVE.zip`, prod102). This pass does not rebuild that package; it adds two leftover unique Daily Code Talk hubs on top of it.

## What changed

### IMC 504.10–504.11 commercial / multistory dryer exhaust
A dwelling 4-inch dryer page already existed. Condo and hotel shafts were still a gap. Unique numbers from Daily Code Talk only: fan motors outside the airstream; multiple dryers continuous or interlocked; 6 in to combustibles; single UL 2158A transition ≤ 8 ft, not concealed; rated shaft; no dampers in the common duct; 26-gauge straight metal; continuous fan on standby power with a failure signal; makeup air; 12×12 cleanout at the base; dryers only.

### IMC 502.6 dry-cleaning exhaust
Type II: 1 cfm/ft² in dry-clean and drying rooms. Type IV/V: loading-door area or a hood at that opening. Distinct from 502.12 coating (same 1 cfm/ft² number, different pickup).

### Field tools
105 → 107 screens. `#cdryer` in general exhaust. `#drycln` in hazardous / special-process.

## Still owner-only

Unchanged — see `ITEMS_REQUIRING_OWNER_INPUT.md`. Do not invent NEC 110.26 numbers. Do not publish a street address.
