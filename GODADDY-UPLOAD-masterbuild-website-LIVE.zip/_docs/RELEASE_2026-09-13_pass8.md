# Release notes — Pass 8, 13 September 2026

Cache token `20260913-prod98`. **Chapter 8 and the Chapters 7 + 8 bundle are on sale, and the
site now delivers them itself.**

---

## Bottom line

Pass 7 built the product and left it inert. Pass 8 turned it on end to end: two Stripe products,
two Payment Links, instant self-service delivery, and the offer placed on 231 Daily Code Talk
article pages that previously carried no product at all.

Nothing here is waiting on a decision. One thing is waiting on ten minutes of your time: buy each
product once yourself and refund one, which closes the last commercial gate.

---

## 1. Stripe — created live, in your account

| | Chapter 8 | Chapters 7 + 8 bundle |
|---|---|---|
| Product | `prod_VFbU78MqEKERz0` | `prod_VFbUPMt48h5IKG` |
| Price | $199.00 USD, one time | $299.00 USD, one time |
| Payment Link | `https://buy.stripe.com/cNi6oHcaI9290af6Dt2Nq0b` | `https://buy.stripe.com/3cI9ATb6Ea6de159PF2Nq0c` |
| Tax code | General — Electronically Supplied Services (`txcd_10000000`), matching the existing ten products | same |
| Collects | email + customer name | email + customer name |
| After payment | redirect to `/guide-delivered/?p=ch8` | redirect to `/guide-delivered/?p=ch788` |

Both checkout pages were opened and confirmed rendering the right product, price and payment
methods (card, Apple Pay, Klarna, Link, Cash App Pay, Amazon Pay).

**Two things I deliberately did not change, that are worth ten minutes with your CPA:**

- **"Collect tax automatically" is on**, matching the existing products. Florida does not tax
  electronically delivered goods and you are nowhere near economic nexus in any other state, so
  today it computes $0 and costs nothing. It starts costing when Stripe Tax billing applies.
  Leave it for consistency; revisit when there is volume.
- **Promotion codes are off.** Turning them on later means editing each link. If you want a
  LinkedIn or referral code, do it before you promote, not after.

## 2. Delivery is solved — the site hands over the files

This was the largest open operational risk in Pass 7: Stripe's confirmation email does not attach
files, so every sale was a manual send, including the one that lands at 11pm on a Friday.

`/guide-delivered/` now reads the Stripe session id from the redirect and renders the download
list for whichever product was bought. Files live at an unguessable path under `/library/`, are
`Disallow`ed in `robots.txt`, carry `X-Robots-Tag: noindex`, and `.htaccess` blocks directory
listing and cross-domain hotlinking. With no session id the page shows nothing but a "email me and
I will send them" fallback.

**The honest trade:** this is light protection, not DRM. A buyer can share the link. For a $199
PDF with zero marginal cost and zero sales to date, three-second delivery is worth far more than
the sharing risk. Per-buyer watermarking is the upgrade if sharing ever becomes a real number. To
reverse it, delete `/library/` from the tree and point the redirect back at a "check your email"
message.

Verified in a browser across four cases: no params → fallback only; `?p=ch8` without a session →
fallback only; `?p=ch8` with a session → five files, all resolving 200; `?p=ch788` with a session →
nine files across both chapters, all resolving 200.

## 3. The offer now appears on 231 article pages

The archive has carried a chapter-aware guide CTA since it was built, but a deep link into an
article redirects to the static shell — so a reader arriving from search or LinkedIn never saw it.
**231 article pages, the firm's largest organic surface, were the only pages in the funnel with no
product on them.**

`js/mb-article-offer.js` fixes it. Each shell is stamped `<main data-mb-chapter="N">` at build
time from the same `dct-index.js` field the archive uses, so the offer cannot drift from the
article. Chapters 1, 2, 3, 5, 6, 7, 8 and the ventilation guide (4) all map. NEC "Sparky Edition"
posts are deliberately not stamped — an NEC chapter number is not an IMC chapter number, and
offering the venting guide on an article about communications circuits is worse than offering
nothing. The block is inert for any chapter whose guide has no checkout.

Verified: chapters 1, 4, 5, 6, 7 and 8 each render their own guide at their own price; Sparky
renders nothing.

## 4. Storefront

`/resources/` gained four Stripe links (21 → 25): a Chapter 8 grid card, a 7 + 8 bundle grid card
with the saving computed from the catalog, and a bundle upsell strip inside the Chapter 8 panel
that appears only when both the bundle and Chapter 7 are sellable. The Chapter 8 panel switched
itself from free-sample mode to checkout mode with no code change, as designed.

## 5. Brand note — one decision for you

The site runs **two accents**: `#CA540A` in `css/mb-chrome.css` (the 689 static pages, the field
tools, the delivery page) and `#C4783A` via an `ACCENT` constant in the React apps, the homepage
and the 237 article shells — 2,622 occurrences across 274 files. They never mix inside one file,
so nothing looks broken, but the homepage and storefront are a slightly different orange from the
rest of the site.

I did not unify them, because which one is canonical is a brand decision and the paid PDFs use
`#C4783A` while `mb-chrome.css` documents `#CA540A` as the system accent. The new article-offer
block uses `#C4783A` so it matches the page it lands on.

Unifying is one command either way:

```
grep -rl 'C4783A' --include='*.html' --include='*.js' --include='*.css' . \
  | tr '\n' '\0' | xargs -0 sed -i 's/C4783A/CA540A/g'
```

## 6. Everything from Pass 7 still applies

The rebuilt 105-screen field-tool library, the Project Basis screen, the three fixed defects, the
Spanish page and `/guide-delivered/` all shipped in Pass 7 and are unchanged here. See
`RELEASE_2026-09-13_pass7.md`.

---

## Verification run for this pass

| Check | Result |
|---|---|
| Internal links crawled | 22,618 — 0 broken |
| JSON-LD blocks parsed | all valid, 0 errors |
| Screens that submit and answer | 105 / 105 (EN), 10 / 10 (ES) |
| Contextual guide offers on screens | 92 (was 70 — Chapter 8's 22 screens now priced) |
| Chapter 8 offer on chimney screens | 22 / 22, correct link and price |
| Article offer by chapter | 1, 4, 5, 6, 7, 8 correct; Sparky correctly silent |
| Storefront Stripe links | 25 (was 21) |
| Delivery gate | 4 cases correct; 14 / 14 offered files resolve 200 |
| Checkout pages | both render the right product, price and methods |
| Pages rendered and error-free | 15 sampled |
| Horizontal scroll at 360 px | none |
| Zip verified byte-identical to the build tree | yes |

## Still open

1. **Buy each product once and refund one.** Ten minutes. Closes commercial-gate items 6 and 7.
2. **Record the technical reviewer and review date** in the Chapter 8 manifest — both are `null`,
   and the standard does not allow asserting PE review before it happens.
3. **The Chapter 7 naming question.** Its subject lives in the fuel gas code, not in Chapter 7 of
   the mechanical code. Now that it is inside a bundle you are actively selling, this gets more
   expensive with every sale.
4. **Distribution.** See `LAUNCH_KIT_Chapter_8.md`. Lifetime external revenue is still $0; that is
   not a checkout problem and never was.
