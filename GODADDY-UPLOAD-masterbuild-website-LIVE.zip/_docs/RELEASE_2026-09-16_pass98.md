# Release note — Pass 98 (16 September 2026)

Cache token: `20260916-prod107`. Field tools: 115 screens.

## This pass

`equipment-installation` already owns 304.1–304.4 (listing, 18 in, FVIR). Leftover unique from 304 Part 3:

1. **304.6–304.7 garage mounting height** — 8 ft public / 6 ft private. Vehicles-pass-below: MI + 1 ft above the tallest door. Exception: impact protection + 304.3 + NFPA 30A. Distinct from 404 ventilation and 502.13 pits.
2. **304.10–304.11 pads and roof-edge guards** — pad 3 in above grade or suspend 6 in. Service within 10 ft of an edge with drop over 30 in: 42 in guards, 21-in sphere, 30 in past each end, IBC loads. Distinct from 306.5 (how you get up).

Do not invent 110.26. Do not invent IBC load numbers.
