# Release note — Pass 95 (16 September 2026)

Cache token: `20260916-prod104`. Field tools: 109 screens.

## Thoughts on the recent revisions

The 14 September prod102 package was the first time the library behaved like a product: 13 groups, a sticky rail without a Windows scrollbar, Chapter 8 on sale, honest screen counts. Overnight DCT hubs had been stacking pages; prod102 made them findable.

Highest-value recent content, in order:
1. **601.5 undercuts / jump ducts** — every TI in Miami hits a closed bedroom with a ¾-inch gap. The 1 in²/cfm line is labeled a field recommendation, not a code minimum. That honesty is the brand.
2. **504.10–504.11 common dryer shafts** — South Florida multifamily. A damper in a lint shaft is a fire. Distinct from the dwelling 4-inch page.
3. **502.6 Type II dry cleaning** — same 1 cfm/ft² number as coating, different rooms. Distinguishing them prevents a reviewer from applying the wrong row.

Removed “street address not published.” Correct. Saying you hid it was louder than hiding it.

Still waiting on the owner: IMC 901 DCT #167, NEC 110.26 numbers, Chapter 7 naming, accent color, first Buttondown issue, one live Stripe purchase-and-refund.

## This pass

502.17 tire/buffing: NFPA 91 + collector on the machine. No invented collector cfm.
502.19 indoor firing range: Chapter 4 + OSHA 1910.1025 (lead). No invented capture velocity.

Do not invent 110.26.
