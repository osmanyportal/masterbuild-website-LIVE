# Release note — Pass 99 (16 September 2026)

Cache token: `20260916-prod108`. Field tools: 117 screens.

## County page reviewed

https://www.miamidade.gov/permits/home.asp?cat=build (and `?cat=mechanical`)

Scraped for *topics and official URLs only*. We did not copy County PDFs, fee rates, or the commercial mechanical guideline form.

Kept (MEP, brand-aligned):
- e-Permitting / Plans Tracking / MeetQ / ePayment / recertification portal
- Official mechanical commercial + residential guidelines (linked)
- Mechanical inspection checklist (linked)
- Mechanical fee sheet (linked, rates not reproduced)
- Approved as Noted criteria (linked)
- How-to-apply facts we already teach (UP#, upfront fees, 180-day, NOC HVAC <$15k)

Dropped on purpose:
- Film, parking, solid waste, roadway, tree, marine, vacation rental
- WASD as a Masterbuild service (still noted as a different review)
- Hosting County PDFs

## This pass

1. `/miami-dade-permit-portals/` — which door
2. `/miami-dade-mechanical-review/` — PE order of operations mapped to Masterbuild hubs

Do not invent 110.26.
