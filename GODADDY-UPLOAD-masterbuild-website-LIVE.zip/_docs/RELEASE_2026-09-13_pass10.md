# Release notes — Pass 10, 13 September 2026 (final)

Cache token `20260913-prod101`. **This is the only package. `masterbuild-website-LIVE.zip` is the
single source of truth; every other zip has been removed.**

---

## Bottom line

A correctness pass and a cleanup pass. The headline item is a technical-accuracy fix on the page
that carries the firm's own strongest argument, and it was wrong.

---

## 1. The combustion-air hub taught the wrong code authority

`/combustion-air/` — the page that ranks for the firm's own topic — still said *"IMC Chapter 7 is
the drawing"* and was titled *"Combustion Air for Fuel-Fired Equipment | IMC Chapter 7."*

That contradicts the correction this firm published in Pass 5, contradicts `llms.txt`, contradicts
all 105 field tools, and contradicts the core argument of the $149 guide being sold from the same
site. A reader who arrived from search got the wrong book from the PE who corrected it everywhere
else.

Rewritten. The page now opens with **"Combustion air is not in the Mechanical code. That is where
most sets go wrong,"** states that Chapter 7 is two sections long and carries no sizing method, and
adds a five-row routing table:

| Appliance | Where the criteria live |
|---|---|
| Gas-fired | IFGC 304, in Florida the FBC Fuel Gas — indoor 304.5, outdoor 304.6, combination 304.7, engineered 304.8, mechanical 304.9 |
| Oil-fired | NFPA 31 |
| Solid-fuel | The listed manufacturer instructions |
| Direct-vent | Outside the chapter's methods entirely |
| Any, with a damper | Mechanical 701.2 still applies — interlock, no manual dampers, shaft through rated construction |

Title, description, og/twitter, eyebrow and the risk callouts all follow. A new callout names the
specific error: *"Combustion air per IMC 703" — there is no 703. Chapter 7 stops at 701.2.*

The Spanish twin `/aire-combustion-con-damper/` was already correct. `/dampered-combustion-air/`
and `/florida-building-code/` were already correct.

## 2. The Spanish tool page had drifted

Its combustion screen still carried the old "IMC Chapter 7 educational rates" kicker, and the ten
screens were numbered 01, 01, 02, 03, 05, 05, 06… Renumbered 01–10 in document order and every
screen now declares its own `data-guide` chapter, so the contextual offer there matches the English
library exactly instead of guessing.

## 3. Unused files removed

- **Eight superseded county checklist PDFs** — 1.7 MB. The site links the `-en` and `-es`
  bilingual versions; these were the earlier unsuffixed originals, referenced from nowhere.
- **Five unused logo variants** — `logo.png`, `logo-white.png`, and three "Cropped" / "White"
  files. Only `Master Build Logo- Revised.png` is used, on 695 pages.
- **`Daily Code Talk.html`** (21 KB) — a legacy duplicate of `/daily-code-talk/` with a space in
  the filename. Replaced with a 635-byte redirect stub rather than deleted, because old LinkedIn
  posts may still link it; it now carries `noindex` and redirects.

Orphan scan across all 96 remaining assets: **zero files with no inbound reference.**

## 4. A performance experiment, measured and reverted

`content-visibility: auto` on the 105 tool cards roughly halved first contentful paint
(248 ms → 124 ms locally). It was **reverted on purpose.**

It gives offscreen cards an estimated height, so the document keeps growing for seconds after load
and anchor scrolling lands short — two of eight sampled deep links missed by more than 2,000 px
even after an adaptive re-scroll that re-aimed 25 times over 2.5 s. Deep links into individual
screens are a core feature here: the result panel generates them, 126 hub pages link specific
anchors, and the Spanish page links all 105. Correctness beat a sub-150 ms local paint gain.

The reason is written into the stylesheet so nobody re-adds it without reading it. Revisit only
with per-card intrinsic sizes that hold at every viewport width.

The deep-link scroll settle it exposed was kept: anchors now re-aim on the next frame until the
card is actually where it should be, which is an improvement on any long page.

## 5. FAQ structured data — checked, not needed

Twenty-two pages already carry `FAQPage` schema, and they are the right twenty-two: the commercial
landing pages, the service hubs, the homepage shells and `/faq/`. The ~430 topic hub pages are
short single-topic pages built around "what the drawings should identify" and "what to send" — not
question-and-answer content. Generating FAQ schema for them would be marking up questions nobody
asked. Left alone deliberately.

## 6. One package

`06_WEBSITE` now holds exactly one zip: **`masterbuild-website-LIVE.zip`**. The production pass
zips and the entire `_ARCHIVE_2026-09-13` folder are gone. Everything recoverable from Google
Drive trash for 30 days if you want any of it back.

---

## Verification run

| Check | Result |
|---|---|
| Internal links crawled | 22,916 — 0 broken |
| JSON-LD blocks parsed | all valid, 0 errors |
| Orphaned assets | 0 of 96 |
| Screens that submit and answer | 105 / 105 EN, 10 / 10 ES |
| Deep links sampled across the page | 8 / 8 land on target |
| Contextual guide offers | 92 on screens, correct chapter and price |
| Article offers | chapters 1, 4, 5, 6, 7, 8 correct; NEC silent |
| Subscribe | 5 surfaces, correct tags, honeypot hidden, invalid blocked |
| Storefront Stripe links | 25 |
| Homepages | all three: Chapter 8, bundle, 105 tools, correct counts |
| Delivery gate | 4 cases correct, every file resolves 200 |
| Tool result → intake carry | 1,263 characters prefilled |
| Titles containing markup | 0 |
| Zip verified byte-identical to the build tree | yes |

## Still open — all owner decisions

1. **Upload the zip.** Nothing in Passes 7–10 is live until you do.
2. **Buy each product once and refund one.** Ten minutes, closes the last commercial gate.
3. **Technical reviewer and review date** in the Chapter 8 manifest — both still `null`.
4. **The Chapter 7 naming question.** Now sharper than ever: the hub page correctly says the
   criteria are not in Chapter 7, and the product is still called the Chapter 7 guide.
5. **The brand accent split** — `#CA540A` vs `#C4783A`, one command either way.
6. **Send the first Buttondown issue.** The site now collects addresses for a list that has never
   mailed anyone.
7. **Distribution.** `LAUNCH_KIT_Chapter_8.md`. Lifetime external revenue is still $0.
