# Release note — Pass 11 (14 September 2026)

Cache token: `20260914-prod102` (2,145 references). Bumped because `css/mb-chrome.css`
and `js/mb-fieldtools.js` both changed; returning visitors would otherwise keep the
old copies.

## What changed and why

### 1. The category rail no longer shows a browser scrollbar (visible defect on the live site)

The sticky category rail on `/field-tools/` scrolls horizontally because 13 chips do
not fit on one line. It carried `scrollbar-width: thin`, which on **Windows Chrome is
not a slim overlay bar** — it renders the classic grey track with arrow buttons, about
15px tall, sitting directly on the rail's orange bottom border. On the live site it
read as a browser artifact glued to a brand element, and it was the first thing visible
under the nav.

Fixed by hiding the native scrollbar (`scrollbar-width: none`, `-ms-overflow-style: none`,
`::-webkit-scrollbar { display: none }`) and replacing the affordance with three things:

- an **edge fade** on whichever side still has chips off-screen. `mb-fieldtools.js` sets
  `data-ov="start" | "mid" | "end"` on the rail from `scrollLeft` and removes the
  attribute entirely when everything fits, so the fade never lies about hidden content;
- **wheel-to-scroll** while the pointer is over the rail (vertical wheel deltas move the
  rail horizontally, and only `preventDefault()` when the rail actually moved, so the
  page still scrolls once the rail is at its end);
- the existing auto-centring of the active chip, which already followed the reader.

### 2. The search field shows its whole hint

`#tool-filter` was capped at 420px. The placeholder — the actual instruction on that
page — measures 525px, so it truncated at "SCCR," and the reader never saw
"permit exemption." Now `width: 100%; max-width: 640px`, measured at 638px of usable
field against 525px of text. Unchanged at phone width (354px at 390px viewport), where
the placeholder truncating is expected.

### 3. `.tool-search` got `scroll-margin-top: 76px`

Same clearance the tool cards already had. Anything scrolled to the top of the viewport
lands under the sticky rail otherwise; the search label was being covered.

## Verification at prod102

| Check | Result |
|---|---|
| Rail scrollbar height (1440 / 1100 / 820 / 390) | 0px at every width |
| `data-ov` at rail start / rail end | `start` / `end` at every width |
| Filter field width desktop / phone | 638px / 354px (placeholder 525px) |
| Internal links crawled | 22,916 — 0 broken |
| Invalid JSON-LD | 0 |
| Orphaned assets | 0 of 96 |
| Field tools EN | 105 screens, 13 categories, 13 chips, 105 index links, 0 dead anchors, 0 submit failures |
| Field tools ES | 10 screens, 2 categories, 0 dead anchors, 0 console errors |
| Deep links sampled | 4/4 land at exactly 76px |
| Delivery gate | 4/4 cases correct (2 fallback, ch8 → 5 files, bundle → 9 files) |
| Subscribe | correct on all 5 surfaces, honeypot hidden, invalid email posts nothing |
| Article offers | chapters 1/4/5/6/7/8 correct, Sparky/NEC silent |
| Homepages | EN, ES and /en.html all carry Chapter 8, the bundle, "105" and 17 Stripe links |

## Still owner-only

Unchanged from Pass 10 — see `_docs/ITEMS_REQUIRING_OWNER_INPUT.md`. In short: upload
the zip, buy each product once and refund it, fill the two `null` reviewer fields in the
Chapter 8 manifest, settle the Chapter 7 naming question, settle the brand accent
(`#CA540A` vs `#C4783A`), send the first Buttondown issue.
