# Release notes — Pass 9, 13 September 2026

Cache token `20260913-prod100`. **The site now asks for an email. Until this pass it never did.**

---

## Bottom line

Pass 8 closed the sales funnel. Pass 9 fixed the leak above it and put the firm's biggest
differentiator on the front door.

Three things changed that matter, and four defects got fixed.

---

## 1. Email capture — the biggest leak on the site

690 pages, 105 free screens, 256 articles, four ungated PDFs, and **not one page captured an
email.** 269 files linked to Buttondown; none had a form. Every visitor who read a guide and left
was gone for good. The subscribe endpoint and tag scheme were already configured in
`mb-catalog.js` and had never been used.

`js/mb-subscribe.js` now renders an inline block wherever a page declares
`data-mb-subscribe="IMC|NEC"`. It is on:

- `/field-tools/` and `/herramientas-de-campo/` — the highest-intent free pages
- `/guide-delivered/` — the single best moment to ask, right after a purchase
- **all 256 Daily Code Talk article shells**, tagged `IMC` or `NEC` by discipline

**The promise is deliberately narrow, and that is the point.** The Buttondown list has never
received an issue. A promise you do not keep costs more than no promise, so the block says exactly
what the firm can deliver from a standing start: *"I'll email you when the next guide ships. A new
chapter guide or a new field tool. That is the whole list — it is not a newsletter and there is no
weekly cadence."* Keep that promise and the list is worth something. Turn it into a weekly
newsletter you abandon in three weeks and it is worth less than nothing.

Tags come from `MB_CATALOG.subscribeTags()`, so NEC posts add `sparky-edition` alongside
`daily-code-talk` and existing list automations are unaffected. It posts straight to Buttondown's
embed endpoint — no third party sees the address, no page carries an API key. Verified: correct
tags per family, Spanish renders Spanish, an invalid address never posts, and the success state
tells the reader to confirm by email (which is the real receipt, because the embed endpoint's
response is opaque by design).

## 2. The 105 free tools now exist on the homepage

They were the firm's largest top-of-funnel asset and the front door mentioned them **once, in a
nav link**. The crawl-time `<noscript>` block — which is what Google actually quotes in the SERP
snippet — did not mention them at all.

- All three homepage shells (`index.html`, `en.html`, `es.html`) gained a "Free field tools"
  section in the crawl-time block, with deep links to all thirteen category anchors. That is
  thirteen new internal links into the library from the highest-authority page on the site.
- The rendered card changed from *"Helpers that turn a vague question into a better inquiry"* to
  **"105 free field tools — decision screens in 13 groups, no login, no email."** Same for the
  Spanish card.
- The free PDFs are now named in the crawl block instead of buried: Chapter 4, the Chapter 8
  four-gate sample, the Chapter 7 sample, and the eight county checklists.

## 3. Chapter 8 and the bundle reached the homepage

The rendered homepage product grid stopped at the Chapters 6 + 7 bundle. It now carries Chapter 8
($199) and the Combustion Air + Venting bundle ($299) in **both** language trees, with their free
samples and the saving computed from the catalog. Homepage Stripe links: 15 → 17.

## 4. Phone is no longer required on the intake form

`/send/` and `/contacto/` required name, email, **phone**, project type and the question. Phone
required is friction with no filtering value: a serious buyer who prefers email bounces, and an
unserious one types any ten digits. The real quality gate is having to describe the problem, and
that stays required.

Now required: name, email, project type, the question. The phone label reads
*"optional — I reply by email first"*, so the change is visible rather than silent.

This is a conversion judgment on your funnel, and it is one `required` attribute to put back if you
disagree.

## 5. Defects found and fixed

- **Two pages had raw HTML inside `<title>`.** `/equipment-access/` rendered
  `Equipment Access | IMC 306. Electrical disconnects: <a href="/readily-accessible/">NEC readily
  accessible</a> — Masterbuild` as its title — an `<a>` tag had bled in from body copy. Same on
  `/temporary-equipment/`. Both produced garbage SERP titles. Fixed, with `og:title` and
  `twitter:title` kept in step.
- **A Spanish page carried an English title.** `/plenums-es/` was titled "Plenums | IMC 602" on a
  `lang="es"` page. Now "Plenos".
- **The homepage published stale post counts** — 231 IMC / 20 NEC / 251 total against an actual
  234 / 22 / 256. Corrected.
- **An unlabelled form control.** The recertification tool's output textarea had no label.
  Labelled, with an `aria-label` describing it as read-only.
- **The subscribe honeypot rendered visibly on 256 pages.** The bot trap relies on a `.honey`
  rule in `css/mb-chrome.css`, and the Daily Code Talk shells carry their own stylesheet and
  never load it. A labelled "Website" field appeared above the email input on every article —
  confusing to a reader, and anyone who filled it in would have had their subscription silently
  discarded. The block now brings its own rule, scoped, so it is invisible wherever it lands.
  Caught by looking at a rendered screenshot, not by any of the automated checks.

## 6. Order of asks on an article page

Article, then the **paid chapter offer**, then the **free email ask**, then the engagement CTA.
The offer sits directly under the article while the reader is still holding the technical
argument; the free ask catches everyone who will not buy today. `mb-article-offer.js` anchors
itself to the subscribe host rather than relying on which deferred script happens to run first,
so the order is deterministic instead of a race.

## 7. Accessibility

Audited the field-tool library, the subscribe block, the article offer, the download page and the
storefront: no unlabelled controls, no tap target under 24 px in any added component, no empty
links or buttons. Contrast on every added text style passes AA against its real composited
background. The download-file metadata line was lightened from 58% to 72% opacity anyway — it is
the most important text on the most important page.

*Harness note for whoever runs this next:* `qa_a11y.mjs` does not composite alpha, so any text on a
translucent panel reads as a false failure. `.dl-meta` reports 3.76:1 and is actually 7.4:1 over
the real background. Fix the harness before trusting that number.

---

## Verification run for this pass

| Check | Result |
|---|---|
| Internal links crawled | 22,923 — 0 broken |
| JSON-LD blocks parsed | all valid, 0 errors |
| Screens that submit and answer | 105 / 105 |
| Subscribe block | 5 surfaces, correct family tags, invalid address blocked, ES in Spanish |
| Honeypot hidden | 4 surfaces, including the shells that do not load mb-chrome.css |
| Ask order on articles | chapter offer, then the free email ask, then the engagement CTA |
| Article offer by chapter | 1, 4, 5, 6, 7, 8 correct; Sparky correctly silent |
| Homepages | all three render Chapter 8 + bundle, 17 Stripe links, correct counts |
| Intake required fields | name, email, project type, question — phone optional |
| Tool result → intake carry | 1,263 characters prefilled |
| Delivery gate | 4 cases correct; all offered files resolve 200 |
| Titles containing markup | 0 (was 2) |
| Unlabelled form controls | 0 (was 1) |
| Pages rendered and error-free | 15 sampled |
| Zip verified byte-identical to the build tree | yes |

## Still open

1. **Buy each product once and refund one.** Unchanged from Pass 8, still the last commercial gate.
2. **Technical reviewer and review date** in the Chapter 8 manifest — both still `null`.
3. **The Chapter 7 naming question.**
4. **The brand accent split** — `#CA540A` vs `#C4783A`, 2,622 occurrences. One command either way.
5. **353 titles over 60 characters and 175 descriptions over 160.** Mostly deliberate density on
   the hub pages, where the important words are at the front and only "— Masterbuild" gets cut.
   Worth a pass on the Daily Code Talk shells, where 158 titles run to a median of 78 characters,
   but not worth a blind mass rewrite of pages that may already rank.
6. **Send the first Buttondown issue.** There is now a form collecting addresses for a list that
   has never mailed anyone. Collecting and not sending is worse than not collecting.
