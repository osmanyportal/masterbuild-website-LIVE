# Miami-Dade fee snapshot — owner baseline (17 September 2026)

**Not for GoDaddy public_html.** Educational copy of the County sheets the owner provided. Not a Masterbuild fee quote. Confirm the live County PDF the day anyone applies. Do not host the County forms.

Official pages:
- Impact fees: https://www.miamidade.gov/zoning/impact-fees.asp (786-315-2670)
- Mechanical / electrical / plumbing-gas fee sheets under miamidade.gov building documents

## Impact fees — how the table is organized

Columns: Mobility context zones 1–4, Fire, Police, School, Parks DIST 1 North / DIST 2 Middle / DIST 3 South.

Mobility rates on that sheet **did not include the 2% administrative fee**.

Fire is paid to the County except Miami, Miami Beach, Hialeah, Coral Gables, Key Biscayne.

Affordable / workforce housing exemption path: County page currently describes coverage up to 120% AMI. Masterbuild does not process exemptions.

### Residential (per unit unless noted)

| Land use | Mobility CZ1 / CZ2 / CZ3 / CZ4 | Fire | Police | School | Parks N / M / S |
|---|---|---|---|---|---|
| Single-family detached | $9,633 / $9,275 / $10,179 / $10,625 | $527.55 | $688.42 | $612/unit + $0.918/gsf | $4,902.89 / $3,459.68 / $3,084.21 |
| Single-family attached | $7,355 / $7,082 / $7,772 / $8,112 | $527.55 | $688.42 | same method | $4,146.92 / $2,826.07 / $2,834.46 |
| Multifamily low-rise | $6,885 / $6,629 / $7,276 / $7,594 | $527.55 | $688.42 | same method | $2,878.04 / $2,169.00 / $1,910.87 |
| Multifamily mid-rise | $4,638 / $4,465 / $4,901 / $5,115 | $527.55 | $688.42 | same method | $2,878.04 / $2,169.00 / $1,910.87 |
| Multifamily high-rise | $4,638 / $4,465 / $4,901 / $5,115 | $527.55 | $688.42 | same method | $2,878.04 / $2,169.00 / $1,910.87 |
| Mobile home park | $7,274 / $7,003 / $7,686 / $8,022 | $527.55 | $688.42 | same method | $4,902.89 / $3,459.68 / $3,084.21 |

### Lodging

| Land use | Mobility CZ1–4 | Fire | Police | Unit |
|---|---|---|---|---|
| Hotel | $8,816 / $8,488 / $9,316 / $9,724 | $0.5642 | $0.4777 | unit |
| All-suites hotel | $2,814 / $2,709 / $2,973 / $3,103 | $0.5642 | $0.4777 | unit / sq ft |
| Motel | $1,719 / $1,655 / $1,816 / $1,895 | $0.5642 | $0.4777 | unit / sq ft |
| Business hotel | $2,571 / $2,475 / $2,716 / $2,835 | $0.5642 | $0.4777 | unit / sq ft |

### Industrial (per sq ft)

| Land use | Mobility CZ1–4 | Fire | Police |
|---|---|---|---|
| General light industrial | $4.944 / $4.760 / $5.225 / $5.453 | $1.7086 | $0.4777 |
| Manufacturing | $3.443 / $3.315 / $3.638 / $3.797 | $1.7086 | $0.4777 |
| Warehousing | $1.747 / $1.682 / $1.846 / $1.927 | $1.7086 | $0.4777 |
| Mini-warehousing | $1.481 / $1.426 / $1.565 / $1.634 | $1.7086 | $0.4777 |
| Data center | $12.555 / $12.088 / $13.267 / $13.847 | $1.7086 | $0.4777 |

Fulfillment / high-cube rows are **not** the warehouse row. Confirm sort vs non-sort vs parcel hub vs cold storage on the live sheet.

### Office (per sq ft) — 1–50,000 gsf band

Mobility $17.610 / $16.954 / $18.607 / $19.422. Fire $0.4191. Police $0.4777. Larger bands step down — do not use this band on a 200,000 gsf building.

### Restaurant / fuel

| Land use | Mobility CZ1–4 | Unit |
|---|---|---|
| Fine dining | $966 / $930 / $1,021 / $1,066 | seat |
| High-turnover sit-down | $1,514 / $1,457 / $1,599 / $1,669 | seat |
| Fast-food without drive-through | $82.514 / $79.444 / $87.190 / $91.007 | sq ft |
| Fast-food with drive-through | $85.626 / $82.440 / $90.478 / $94.439 | sq ft |
| Coffee / donut with drive-through | $97.732 / $94.095 / $103.269 / $107.790 | sq ft |
| Gasoline / service station | $39,175 / $37,718 / $41,395 / $43,207 | pump |

Remaining land-use rows (retail size bands, medical, institutional, recreational) stay on the live County PDF. Do not invent a missing row.

## Mechanical fee sheet — category baseline

Published minimum on that sheet: **$227.90**. Wrong category: no refund. Work without a permit: double fee on that sheet.

- SFR/duplex new or addition: $0.11/sf of master permit (sheet notation 0.11¢)
- AC / exact change-out: $24.17/ton. Exact change-out **>15 tons requires processing**
- Heating: $4.84/kW
- Duct insulation: $0.04/sf AC space. Pipe insulation: $3.59/ft
- Pressure process piping: $5.64/ft (not medical gas)
- Refrigeration: $24.17/ton
- Ductwork: $0.11/sf to 3,000 sf; $0.06 3,001–10,000; $0.04 over 10,000
- Boiler HP on that sheet = **33,479 Btu/h**. Boiler <837 MBTU $120.76; 837–6695 $144.91; over 6695 $201.26
- Commercial hoods: $201.26/hood — **own application**
- Cooling towers: $169.07/cell
- Clothes dryer / exhaust fan: $48.31 each
- Smoke control / spray booth / fire chemical: $169.07/system or booth
- Raise existing roof equipment: $24.17/ton
- Homesteaded hardening exact AC/heat: $130/system (not new construction)
- Owner-builder SFR: $0.10/sf

## Electrical fee sheet — category baseline

Published minimum: **$227.90**.

- Residential wiring on master: $0.11/sf
- Outlet box: $2.59. Fixture: $2.59. AC electrical: $9.66/ton
- Service / repair / safety check: $7.26 per 100 A
- Special outlets ≥30 A: $11.28
- Panel / switchboard / FA panel: $32.21/board
- Fire alarm new: $201.26/floor. Repair: $96.62/floor. Access control: $144.91/floor
- Temp construction / asbestos / elevator test: $147 (elevator-test temp is **not** a universal 180 days — that sheet said 180 days from issuance for Cat 15; Cat 26 service-test temp said **30 days**)
- Category 31 exact AC replacement: $9.66/ton or $11.28/kW — **not the mechanical permit**
- PV ground $325/system; roof $365.63; County-prescribed $250
- Generator: $11.28 per 10 kW; typically **not attached to a master permit**
- Homesteaded panel change-out: $28.63/board. Residential generator hardening: $10.03 per 10 kW

## Plumbing / gas fee sheet — category baseline

Published minimum: **$227.90**. Gas is a **separate application**.

- SFR/duplex on master: $0.14/sf
- Rough/plug / fixture: $9.66. Condensate drain: $5.10/outlet
- Sewer public or private connection: $48.31. Building sewer: $11.28 per 50 ft
- Backflow ≤2": $56.36. ≥2½": $88.55
- Interceptor / grease trap: $50.73 — **not a P-trap**
- Residential gas outlet: $9.66. Commercial gas outlet: $16.10
- LP tanks above-grade or underground: $96.62 per group at a location
- Lift station: $386.42. Medical gas: $9.66/fixture set
- Homesteaded WH exact change-out: $130/heater (limited to one; sheet noted >50 gallon)
- Owner-builder plumbing: $0.129/sf. Owner-builder gas outlets: $8.59

Public site uses these figures only as a **dated educational snapshot** with “not a quote.” Always point visitors to the live County PDF.
