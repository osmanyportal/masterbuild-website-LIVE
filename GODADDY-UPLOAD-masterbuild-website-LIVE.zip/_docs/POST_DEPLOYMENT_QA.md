# Post-deployment QA — Pass 5

Every check below was run against the packaged tree with a real headless browser performing real
clicks, at desktop 1280 and mobile 390. Field Core Web Vitals, FormSubmit delivery, and Search
Console ingestion require the live host and are not claimed.

## Automated results

| Suite | Result |
|---|---|
| 104 tools — fill, submit, render | **104 / 104 pass** |
| 104 tools — submit empty, still answer | **104 / 104 pass** |
| Copy button injected on every result | 104 / 104 |
| Adopted-code line on every result | 104 / 104 |
| Contextual guide offer with catalog price | 68 / 104 (36 correctly none) |
| Spanish page, same suite | 9 / 9 |
| Site suite (calculations, carry-over, status, overflow, mobile) | **67 / 67 pass** |
| JavaScript page errors, 24 pages | **0** |
| Internal links, 689 HTML files | **22,071 checked, 0 broken** |
| JSON-LD across the tree | 0 invalid |
| `node --check`, every JS file | pass |

## Regression checks specific to this pass

| Was broken | Now |
|---|---|
| `/resources/` rendered 0 Stripe links, 0 headings, 0 prices | 21 links, 14 headings, 35 prices |
| `#cbtu` refused 200000 | accepts any value; returns 50 in² each |
| `vsize` threw `show is not a function` | renders |
| "IMC 703 / 704 / 706" cited | FBC Fuel Gas 304.5 / 304.6 / 304.9 with full method |
| "Detectors fail-safe to Full-On" stated as code | detector heights and UL 2075 stated instead |
| Spanish submissions logged as English | logged by actual page language |
| Three cache tokens, 502 stale references | one token, 1,394 references |
| 433 `.htaccess` files | 1 |
| No compression, no cache headers | gzip/brotli + immutable asset caching |
| TOC category of 68 tools | twelve categories, every anchor verified |
| "48 pantallas" on two pages | 104, with a full Spanish index |

## Owner must verify on the live domain

See `ITEMS_REQUIRING_OWNER_INPUT.md` section 7. Start with `/resources/`.

## Not claimed

- Live FormSubmit delivery
- Field LCP, INP, CLS
- Search ranking or permit-approval rates
- That any tool output is a code determination, a load calculation, or sealed engineering
