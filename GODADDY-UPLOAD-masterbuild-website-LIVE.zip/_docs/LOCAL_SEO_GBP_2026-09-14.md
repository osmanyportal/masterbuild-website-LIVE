# Google Business Profile — audit and build record

**Audit run 14 September 2026** against Google Business Profile Manager (signed in as
osmany.portal@gmail.com) and Google Maps.

## Finding

**No profile exists.** GBP Manager reports `0 businesses, 0% verified`. No Maps listing for
Masterbuild Consulting. A branded search for the exact firm name in Miami returns the website at
position 1 and the LinkedIn company page at 2, with **no knowledge panel and no map pack entry**.

Competing MEP/drafting listings that DO hold the local pack carry **one to four reviews**. That is
the competitive bar. Ten honest reviews would make Masterbuild the most-reviewed MEP engineer on
that map.

## Decisions made (owner, 14 Sept 2026)

| Field | Decision |
|---|---|
| Public phone | **(786) 398-6940** — the number already on the site (767 occurrences, 27 schema blocks). 786-630-3700 stays the direct/signature line and off the profile. |
| Public email | osmany.portal@masterbuildconsulting.com |
| Address | **Service-area business, address hidden.** Owner raised Avalon South Miami as a possible meeting location; recommended against publishing it — see risk below. |
| Business name | `Masterbuild Consulting` exactly, no keyword suffix. |
| Primary category | Mechanical engineer |
| Additional categories | Electrical engineer · Fire protection consultant · Building consultant · Design engineer |

## Risks flagged to the owner

1. **Residential address = suspension trigger.** Google requires a service-area business to hide
   its address. Publishing an apartment address for a business that travels to the job is among the
   most common suspension causes, and it publishes his home on a map permanently. Recommendation:
   enter for verification, then switch off "Show business address to customers."
2. **WASD conflict of interest.** Osmany is plans review supervisor for Miami-Dade WASD donation
   projects — he approves, comments on and rejects EOR submittals. **Engineers of record whose work
   he reviews are off-limits as a review source for MasterBuild.** Clean sources are private
   clients, commercial collaborators (architects, contractors), and peers outside his review
   authority. This was written into the launch pack.
3. **Wrong categories attract wrong leads.** HVAC contractor / Plumber / General contractor /
   Drafting service would raise volume and destroy the price point, and two of them are claims he
   cannot defend under review.
4. **Measurement is unproven.** Plausible loads on every page but nothing in the workspace confirms
   events are arriving. Verify before drawing any conclusion from the channel.

## Free actions taken this session

- **Site schema.** Added a `ProfessionalService` node (`@id` `#localbusiness`) to `index.html`,
  `en.html` and `es.html`. The site previously carried only `Organization`, which does not supply
  the local-business entity Google matches against a Business Profile. The node carries telephone,
  email, image, priceRange, opening hours, `areaServed` as a GeoCircle (Miami centroid, 64 km) plus
  Miami-Dade / Broward / Florida, `knowsLanguage` en+es, `parentOrganization` → `#org`,
  `founder` → `#principal`, and a `hasOfferCatalog` of the five existing Service nodes.
  **No street address and no home coordinates are published** — locality and region only, correct
  for a service-area business. All JSON-LD revalidated: 0 invalid blocks, 22,916 links, 0 broken.
- **Launch pack built** — paste-ready field values, 750-char description, five service
  descriptions, seven GBP Products drawn from the live Stripe catalog, a photo checklist, twelve
  weekly posts, ten seeded Q&A, three review-request templates and a 90-day scoreboard.
  Published as the "Masterbuild Map Pack" artifact (progress checkboxes persist across devices).

## Owner-only, in order

1. Create the profile at google.com/business and complete **video verification** (~14 days).
   Have the PE seal, a printed permit set and a business card ready.
2. Paste the identity fields, categories, service areas, description and five services.
3. Upload 12+ photos (redact title blocks).
4. Add the seven Products with the `utm_campaign=gbp-product` tail appended in `mb-catalog.js`.
5. Seed the ten Q&A — ask from a personal account, answer from the business.
6. Ask ten clean contacts for reviews, within 7 days of a permit clearing. One follow-up, never two.
7. Post weekly. All twelve posts are written.
8. Fill the two Q&A answers marked `[YOUR NUMBER]` — turnaround and quoting inputs.
