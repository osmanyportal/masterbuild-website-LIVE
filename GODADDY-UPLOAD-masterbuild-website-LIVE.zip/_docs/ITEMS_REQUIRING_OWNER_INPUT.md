# Items requiring owner input — updated for Pass 7, 13 September 2026

> **Pass 7 status.** Item 1 (the two-build fork) is now closed on the file side: this package is
> the canonical tree, the other lineage's unique work is ported, and the old
> `masterbuild-website-LIVE.zip` is archived. What remains of item 1 is the governance half —
> one agent owns the website. Item 3 (Chapter 8) is built, QA'd and wired, waiting only on a
> price and a Stripe link; see `STRIPE_SETUP_Chapter_8.md`. Item 2 (Chapter 7 naming) is
> unchanged and is now the highest-value open decision. Item 4 (Spanish) partially addressed:
> ten screens run natively in Spanish and the full library is indexed in Spanish.

---

## Original list — Pass 5

Nothing below blocked the package. Each is a decision only Osmany Portal, PE can make, ordered by
what it is worth.

---

## 1. Two builds of this site still exist. Close the fork this week.

`G:\My Drive\MasterBuild\06_WEBSITE\` is maintained by the Codex "Masterbuild Marketing" agent
with a gated release pipeline (`tools/qa_release.py`, `mb_rebuild_zip2.py`, `mb_bump_tag.py`).
The grok lineage — which produced this package — has 689 pages, 104 field tools, and no gates.
Between 7 and 12 September both independently built `/about/`, `/contact/`, `/combustion-air/`,
`/field-tools/` and eight more pages. Same work, paid for twice, and the two disagree about whether
`/field-tools/` is free tools or a paid membership prelaunch.

You have now answered the strategy question — free tools. What is left is mechanical:

1. Make this package the canonical tree.
2. Port the `06_WEBSITE` lineage's unique work into it: `field-tools-demo.js`, the Project Basis and
   Evidence Readiness demo (EN + ES), and any newer glossary or Daily Code Talk corpus.
3. Move the membership prelaunch page to its own URL and link it from the free tools page. The tools
   feed the consulting funnel *and* the membership waitlist; that is strictly better than either
   page alone.
4. Put this tree under the existing gate scripts, adding the new pages to
   `qa_landing_pages.py` `SLUGS` and `qa_responsive_check.py` `PAGES`.
5. **One agent owns the website from here.** Two agents on one folder with no lock is how a
   storefront shipped blank.

Until step 1 happens, uploading either tree deletes the other's work.

## 2. The paid Chapter 7 guide is named after a chapter that has no content in it

Chapter 7 of the Mechanical code is 701.1 Scope and 701.2 Dampered openings. Everything the guide
teaches lives in IFGC 304. That is consistent with the Daily Code Talk archive, which has exactly
one Chapter 7 post — the series could not continue, because there is nothing else in the chapter.

Three decisions:

1. **Naming.** "IMC 2024 Chapter 7 Combustion Air Field Guide" at $149 describes its contents by a
   chapter that does not contain them. Naming it after the subject and the real authority removes
   the exposure and reads as more expert, not less.
2. **Series continuation.** The arc continues in IFGC 304. Nobody in this market is walking IFGC 304
   section by section, and the demand is real because the sizing lives there.
3. **Guide body.** This package corrected the website only. If the guide PDF cites IMC 703/704/706-
   style sections anywhere, it needs the same correction. Worth a find-and-check pass before the
   next sale.

## 3. Chapter 8 is the product gap the tool library just exposed

There are 22 chimney, vent and connector tools with no guide behind them — the largest unmonetised
cluster on the site. Every tool now reports usage to Plausible as `Field Tool Used`. Give it thirty
days: if that cluster shows real traffic, it is the next $149 guide, and you will have demand
evidence before you write a page. If it does not, you have saved yourself a product.

That same data answers a harder question: **which of the 104 tools earn their maintenance.** You
have been investing in a large library with no usage signal at all.

## 4. The 104 tool interfaces are English only

The Spanish page now carries a Spanish-labelled index of all 104 and says plainly that the screens
are in English while intake and project work are in Spanish. That is honest and usable, but it is
not parity — and Miami is the market where parity pays.

Translating 104 interfaces is a real project: roughly 700 labels, options and result strings, all of
them technical, where a sloppy translation is worse than English because it invites a wrong reading
of a code path. The pragmatic sequence: wait for the usage data from item 3, translate the top ten
tools properly, and leave the rest indexed in Spanish and answered in English.

## 5. The contact form publishes your email address in the page source

Both forms post to `https://formsubmit.co/ajax/osmany.portal@masterbuildconsulting.com`. That hands
the address to anyone reading the source, which is how addresses get harvested. FormSubmit issues a
hashed endpoint that hides it. Two-line change **once you have the hash from FormSubmit** — not done
here because guessing it would break every inbound lead.

## 6. Brand capitalization still disagrees with your own standard

The Firm Identity and Contact Standard locks the public brand as **MasterBuild Consulting**. The
site uses **Masterbuild Consulting** throughout, including titles, schema, and every Daily Code Talk
post. Either amend the standard or run the rename as its own release with its own QA. A locked
standard the site does not follow is worse than either.

## 7. Confirm on the live domain after upload

1. `/resources/` renders the product grid with Stripe buttons. **This is the one that was broken.**
2. A `TEST — ignore` from `/send/`, then one from `/contacto/`. Confirm inbox, spam, Reply-To,
   `[NEW PROJECT]` subject — and that Plausible now labels the Spanish one Spanish.
3. The combustion tool accepts 200000.
4. A tool result carries into `/send/` with the numbers in the message.
5. Each Stripe Payment Link opens the intended SKU. No prices were edited.
6. Resubmit `sitemap.xml` in Search Console.
7. Re-confirm the 9th Edition date against floridabuilding.org before treating 31 December 2026 as
   fixed.

## Resolved since the last pass

- **Florida PE number.** Published as 95945 across 413 pages with correct `hasCredential` schema.
  No longer an open item.

## Do not add without a source

- Fabricated "X projects approved" or savings claims
- A Miami-Dade map pin
- A chatbot or a client portal
- A recertification due-date calculator
- A claim that Masterbuild performs Florida's statewide structural milestone inspection
- Hood exhaust rates by hood style or type — a table reproduction with no lead-gen upside
