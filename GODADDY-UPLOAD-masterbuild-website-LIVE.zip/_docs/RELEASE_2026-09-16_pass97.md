# Release note — Pass 97 (16 September 2026)

Cache token: `20260916-prod106`. Field tools: 113 screens.

## This pass

Spray-finish already owned the booth and the gun interlock. Leftover unique from the same Daily Code Talk post:

1. **502.7.7 dip / electrostatic / powder** — not a spray gun. Dedicated outdoor exhaust. Non-sparking wheels. Motors out of the airstream. No invented face velocity. 1 cfm/ft² stays on 502.12.
2. **502.7 floor-resurfacing, including during construction** — Miami TI epoxy and parking-garage recoats. A box fan at the roll-up is not 502.7. 404 is carbon monoxide in normal use. HB 803 does not exempt mechanical.

Do not invent 110.26.
