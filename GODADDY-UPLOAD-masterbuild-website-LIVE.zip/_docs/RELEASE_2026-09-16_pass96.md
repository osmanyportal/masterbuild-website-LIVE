# Release note — Pass 96 (16 September 2026)

Cache token: `20260916-prod105`. Field tools: 111 screens.

## Thoughts on the recent revisions

Pass 95 (502.17 tires / 502.19 ranges) was the right leftover unique pair, and the honesty about no invented capture velocity is the brand. Firing ranges are rare in Miami; the page still earns its keep because it stops a reviewer from treating Table 403 “storage” as live fire.

Highest-conversion leftover this pass is **502.13–502.15 pits**. Every independent oil-change, dealership lube, and some parking basements under repair shops. A CO sensor on the floor above is the actual miss. Distinct from 404 (the parking floor) and 502.14 (the hose on the tailpipe).

**502.2 aircraft** is the other leftover unique. MIA / OPF / TMB exist. Distinct from 502.1.2 (18 in AFF at a gasoline island). Same density, different occupancy. No invented cfm/ft².

Fixed a real marketing bug: `/empezar/` still said “104 pantallas.”

Still waiting on the owner: IMC 901 DCT #167, NEC 110.26 numbers, Chapter 7 naming, accent color, first Buttondown issue, one live Stripe purchase-and-refund.

## This pass

502.2 aircraft fueling: floor-level or in-slab pickup so heavy vapors cannot pool.
502.13–502.15 garage pits: inlet in the hole. No invented pit cfm.

Do not invent 110.26.
