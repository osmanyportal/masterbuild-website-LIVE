﻿// mb-hero.jsx  -  Nav + Hero + Differentiators

const MB_CONTENT = {
  en: {
    nav: {
      services: "Services",
      about: "About",
      codetak: "Daily Code Talk",
      resources: "Resources",
      pricing: "Pricing",
      faq: "FAQ",
      cta: "Book a Scoping Call"
    },
    hero: {
      eyebrow: "/ For Architects · GCs · Owner-Reps · MEP Teams",
      headline: ["MEP drawings that hold.", "Permit-ready. Field-aware.", "PE-direct."],
      rotatingWords: ["Code-Backed Details.", "Field-Coordinated Work.", "Principal-Led Delivery.", "Reviewer-Ready Sets.", "Permit-Ready Drawings."],
      sub: "Most permit delays start at the drawings — not in the field. Masterbuild delivers PE-direct MEP sets built around code logic, reviewer expectations, and constructability. Commercial, TI, existing-building, and mission-critical scopes. Fixed-fee. Florida-licensed. TX, NJ, NY, PA by request.",
      cta1: "Book a 30-Min Scoping Call",
      cta2: "Browse Free Archive",
      badge: "PE-direct · Permit-minded · Fixed-fee",
      stats: [
        { num: "251", label: "Technical posts" },
        { num: "FL",   label: "Licensed PE" },
        { num: "Fixed",label: "Fee engagements" },
        { num: "EN/ES",label: "Bilingual service" }
      ],
      proofCard: {
        label: "What Masterbuild Delivers",
        items: [
          "Permit-ready MEP construction documents",
          "Code path documented on every sheet",
          "Field-aware coordination built in",
          "Comment-response strategy included",
          "PE-sealed deliverables, no delegation"
        ],
        sig: "Osmany Portal, PE · Principal Engineer"
      }
    },
    diff: {
      headline: "What sets Masterbuild apart",
      items: [{
        num: "01",
        title: "PE-Led, Not Delegated",
        body: "Clients work directly with the licensed engineer making technical calls  -  not a project manager relaying messages. Direct judgment applied to every scope, regardless of project size."
      }, {
        num: "02",
        title: "Permit-Minded Documentation",
        body: "Drawings are built around code logic, jurisdiction expectations, and reviewer sensitivity. Reducing comments and supporting approvals is built into the process  -  not addressed after the fact."
      }, {
        num: "03",
        title: "Field-Aware Coordination",
        body: "Constructability, access, clearances, and coordination gaps are caught on paper. Fewer RFIs, fewer field surprises, and tighter alignment between design intent and what gets built."
      }]
    }
  },
  es: {
    nav: {
      services: "Servicios",
      about: "Nosotros",
      codetak: "Daily Code Talk",
      resources: "Recursos",
      pricing: "Precios",
      faq: "FAQ",
      cta: "Agendar Llamada de Alcance"
    },
    hero: {
      eyebrow: "/ Para Arquitectos · Contratistas · Propietarios · Equipos MEP",
      headline: ["Planos MEP que aguantan.", "Listos para permisos. Campo.", "PE directo."],
      rotatingWords: ["Planos para Permisos.", "Detalles Respaldados.", "Trabajo Coordinado.", "Dirección PE Directa.", "Sets Listos para Revisión."],
      sub: "La mayoría de los retrasos en permisos empiezan en los planos — no en el campo. Masterbuild entrega sets MEP PE-directo construidos alrededor de la lógica del código, las expectativas del revisor y la constructibilidad. Proyectos comerciales, TI, edificios existentes y misión crítica. Precio fijo. Licencia en Florida. TX, NJ, NY, PA disponibles.",
      cta1: "Reservar Llamada de 30 Min",
      cta2: "Ver Archivo Gratis",
      badge: "PE directo · Orientado a permisos · Precio fijo",
      stats: [
        { num: "251", label: "Artículos técnicos" },
        { num: "FL",   label: "Licencia PE" },
        { num: "Fijo", label: "Honorarios definidos" },
        { num: "EN/ES",label: "Servicio bilingüe" }
      ],
      proofCard: {
        label: "Qué Entrega Masterbuild",
        items: [
          "Documentos MEP listos para permiso",
          "Ruta de código en cada plano",
          "Coordinación de campo integrada",
          "Estrategia de respuesta a comentarios incluida",
          "Entregables sellados por PE, sin delegación"
        ],
        sig: "Osmany Portal, PE · Ingeniero Principal"
      }
    },
    diff: {
      headline: "Lo que distingue a Masterbuild",
      items: [{
        num: "01",
        title: "PE Directo, sin Delegación",
        body: "Los clientes trabajan directamente con el ingeniero licenciado que toma las decisiones técnicas, no con un gerente de proyecto que transmite mensajes. Juicio directo en cada alcance."
      }, {
        num: "02",
        title: "Planos Orientados a Permisos",
        body: "Los planos se desarrollan en torno a la lógica del código, las expectativas de la jurisdicción y la sensibilidad del revisor. Reducir comentarios y apoyar las aprobaciones es parte del proceso."
      }, {
        num: "03",
        title: "Coordinación Consciente del Campo",
        body: "La constructibilidad, el acceso, los espacios libres y las brechas de coordinación se identifican en papel. Menos RFIs, menos sorpresas en campo y mayor alineación entre diseño y construcción."
      }]
    }
  }
};
window.MB_CONTENT = MB_CONTENT;

// ─── Hero Proof Card (right-side credential card, desktop only) ────────────
function MBProofCard({ t, accent }) {
  const pc = t.proofCard;
  return /*#__PURE__*/React.createElement("div", {
    className: "mb-hero-proof-card",
    style: {
      position: "absolute",
      right: 40,
      top: "50%",
      transform: "translateY(-50%)",
      zIndex: 3,
      width: 264,
      background: "rgba(13,14,17,0.92)",
      border: "1px solid rgba(196,120,58,0.22)",
      borderTop: "2px solid rgba(196,120,58,0.65)",
      padding: "22px 24px",
      backdropFilter: "blur(12px)",
      boxShadow: "0 24px 64px rgba(0,0,0,0.45)",
      animation: "fadeSlideUp 0.8s 0.5s ease both"
    }
  },
    /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9,
        color: accent,
        letterSpacing: "0.12em",
        textTransform: "uppercase",
        marginBottom: 16
      }
    }, pc.label),
    /*#__PURE__*/React.createElement("div", {
      style: { display: "flex", flexDirection: "column", gap: 10 }
    },
      pc.items.map((item, i) => /*#__PURE__*/React.createElement("div", {
        key: i,
        style: { display: "flex", gap: 10, alignItems: "flex-start" }
      },
        /*#__PURE__*/React.createElement("span", {
          style: {
            color: accent,
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            lineHeight: 1.6,
            flexShrink: 0
          }
        }, "✓"),
        /*#__PURE__*/React.createElement("span", {
          style: {
            color: "rgba(240,237,232,0.72)",
            fontFamily: "'IBM Plex Sans', sans-serif",
            fontSize: 13,
            lineHeight: 1.6
          }
        }, item)
      ))
    ),
    /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 18,
        paddingTop: 14,
        borderTop: "1px solid rgba(255,255,255,0.06)",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 9,
        color: "rgba(240,237,232,0.3)",
        letterSpacing: "0.07em"
      }
    }, pc.sig)
  );
}

// ─── Animated rotating word (hero headline line 2) ────────────────────────
// Cycles through `words` array every 2800ms with CSS slide-in/out transitions.
// wordRevealIn / wordRevealOut keyframes are defined in index.html <style>.
function MBAnimatedWord({ words, accent, lang }) {
  var _state = React.useState({ idx: 0, visible: true });
  var state = _state[0];
  var setState = _state[1];

  // Reset to first word when language switches
  React.useEffect(function () {
    setState({ idx: 0, visible: true });
  }, [lang]);

  // Interval: exit → swap word → enter
  React.useEffect(function () {
    var t = setInterval(function () {
      setState(function (s) { return { idx: s.idx, visible: false }; });
      setTimeout(function () {
        setState(function (s) { return { idx: (s.idx + 1) % words.length, visible: true }; });
      }, 400);
    }, 2800);
    return function () { clearInterval(t); };
  }, [lang]);

  return /*#__PURE__*/React.createElement("em", {
    style: {
      color: accent,
      fontStyle: "normal",
      display: "inline-block",
      whiteSpace: "nowrap",
      lineHeight: 1.12,
      paddingTop: "0.04em",
      paddingBottom: "0.08em",
      willChange: "transform, opacity",
      animation: state.visible
        ? "wordRevealIn 0.4s cubic-bezier(0.23,1,0.32,1) forwards"
        : "wordRevealOut 0.4s cubic-bezier(0.55,0,1,0.45) forwards"
    }
  }, words[state.idx]);
}

// ─── Hero Stats Strip ─────────────────────────────────────────────────────
function MBHeroStats({ stats, accent }) {
  return /*#__PURE__*/React.createElement("div", {
    className: "mb-hero-stats",
    style: {
      display: "flex",
      gap: 0,
      marginTop: 36,
      animation: "fadeSlideUp 0.7s 0.55s ease both"
    }
  },
    stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        paddingRight: 28,
        paddingLeft: i === 0 ? 0 : 28,
        borderLeft: i === 0 ? "none" : "1px solid rgba(255,255,255,0.08)"
      }
    },
      /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: "'Plus Jakarta Sans', sans-serif",
          fontWeight: 700,
          fontSize: "clamp(18px, 2.2vw, 24px)",
          color: accent,
          lineHeight: 1.1,
          marginBottom: 4
        }
      }, s.num),
      /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: "'IBM Plex Mono', monospace",
          fontSize: 10,
          color: "rgba(240,237,232,0.38)",
          letterSpacing: "0.06em",
          textTransform: "uppercase"
        }
      }, s.label)
    ))
  );
}

// ─── Nav ───────────────────────────────────────────────────────────────────
function MBNav({
  lang,
  setLang,
  tweaks
}) {
  const t = MB_CONTENT[lang].nav;
  const [scrolled, setScrolled] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("nav", {
    className: "mb-nav",
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      padding: scrolled ? "12px 40px" : "20px 40px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: scrolled ? "rgba(11,12,14,0.97)" : "transparent",
      backdropFilter: scrolled ? "blur(12px)" : "none",
      borderBottom: scrolled ? `1px solid rgba(255,255,255,0.06)` : "none",
      transition: "all 0.3s ease"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/",
    style: {
      textDecoration: "none",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "uploads/Master Build Logo- Revised.png",
    alt: "Masterbuild",
    decoding: "async",
    width: "40",
    height: "40",
    style: {
      height: 40,
      width: 40,
      objectFit: "contain",
      filter: "invert(1)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 15,
      color: "#F0EDE8",
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      lineHeight: 1
    }
  }, "Masterbuild"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 400,
      fontSize: 10,
      color: accent,
      letterSpacing: "0.12em",
      textTransform: "uppercase"
    }
  }, "Consulting"))), /*#__PURE__*/React.createElement("div", {
    className: "mb-nav-links",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 32
    }
  }, [["#services", t.services], ["#about", t.about], ["/daily-code-talk/", t.codetak], ["/resources/", t.resources], ["#pricing", t.pricing], ["#faq", t.faq]].map(([href, label]) => /*#__PURE__*/React.createElement("a", {
    key: href,
    href: href,
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      textDecoration: "none",
      letterSpacing: "0.02em",
      transition: "color 0.2s",
      color: "rgba(240,237,232,0.6)",
      whiteSpace: "nowrap"
    },
    onMouseEnter: e => e.target.style.color = "#F0EDE8",
    onMouseLeave: e => e.target.style.color = "rgba(240,237,232,0.6)"
  }, label))), /*#__PURE__*/React.createElement("div", {
    className: "mb-nav-actions",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 0,
      background: "rgba(255,255,255,0.06)",
      borderRadius: 4,
      overflow: "hidden",
      border: "1px solid rgba(255,255,255,0.08)"
    }
  }, ["en", "es"].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => setLang(l),
    style: {
      padding: "5px 12px",
      background: lang === l ? accent : "transparent",
      color: lang === l ? "#0B0C0E" : "rgba(240,237,232,0.5)",
      border: "none",
      cursor: "pointer",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.05em",
      textTransform: "uppercase",
      transition: "all 0.2s"
    }
  }, l))), /*#__PURE__*/React.createElement("a", {
    className: "mb-nav-cta",
    href: "#contact",
    style: {
      padding: "8px 18px",
      background: accent,
      color: "#0B0C0E",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 13,
      fontWeight: 600,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      transition: "opacity 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.opacity = "0.85",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, t.cta), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "mb-hamburger",
    "aria-label": menuOpen ? "Close navigation" : "Open navigation",
    "aria-expanded": menuOpen,
    "aria-controls": "mb-mobile-menu",
    onClick: () => setMenuOpen(!menuOpen),
    style: {
      display: "none",
      background: "none",
      border: "none",
      cursor: "pointer",
      flexDirection: "column",
      gap: 5,
      padding: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 2,
      background: "#F0EDE8",
      display: "block",
      transition: "all 0.2s",
      transform: menuOpen ? "rotate(45deg) translateY(7px)" : "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 2,
      background: "#F0EDE8",
      display: "block",
      opacity: menuOpen ? 0 : 1,
      transition: "all 0.2s"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 2,
      background: "#F0EDE8",
      display: "block",
      transition: "all 0.2s",
      transform: menuOpen ? "rotate(-45deg) translateY(-7px)" : "none"
    }
  }))), menuOpen && /*#__PURE__*/React.createElement("div", {
    id: "mb-mobile-menu",
    style: {
      position: "absolute",
      top: "100%",
      left: 0,
      right: 0,
      background: "#0B0C0E",
      borderBottom: "1px solid rgba(255,255,255,0.08)",
      padding: "20px 40px",
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, [["#services", t.services], ["#about", t.about], ["/daily-code-talk/", t.codetak], ["/resources/", t.resources], ["#pricing", t.pricing], ["#faq", t.faq]].map(([href, label]) => /*#__PURE__*/React.createElement("a", {
    key: href,
    href: href,
    onClick: () => setMenuOpen(false),
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: "#F0EDE8",
      textDecoration: "none"
    }
  }, label)), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    onClick: () => setMenuOpen(false),
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 15,
      color: accent,
      textDecoration: "none",
      fontWeight: 600
    }
  }, t.cta)));
}

// ─── Hero ──────────────────────────────────────────────────────────────────
function MBHero({
  lang,
  tweaks
}) {
  const t = MB_CONTENT[lang].hero;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      padding: "120px 40px 80px",
      overflow: "hidden",
      background: `#0B0C0E`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 0,
      backgroundImage: `linear-gradient(to right, rgba(196,120,58,0.055) 1px, transparent 1px), linear-gradient(to bottom, rgba(196,120,58,0.055) 1px, transparent 1px)`,
      backgroundSize: "48px 48px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 1,
      background: "radial-gradient(ellipse at 60% 50%, transparent 20%, #0B0C0E 75%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: "-2%",
      top: "50%",
      transform: "translateY(-50%)",
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(120px, 20vw, 280px)",
      color: "rgba(255,255,255,0.025)",
      letterSpacing: "-0.04em",
      lineHeight: 1,
      userSelect: "none",
      zIndex: 1,
      pointerEvents: "none"
    }
  }, "MEP"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2,
      maxWidth: 1200,
      width: "100%",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 28,
      padding: "6px 14px",
      animation: "fadeSlideUp 0.6s 0.1s ease both",
      background: `rgba(196,120,58,0.1)`,
      border: `1px solid rgba(196,120,58,0.25)`,
      borderRadius: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: accent,
      display: "block",
      flexShrink: 0,
      animation: "dotPulse 2.4s ease-in-out infinite"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, t.eyebrow)), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: "clamp(36px, 5vw, 70px)",
      lineHeight: 1.06,
      animation: "fadeSlideUp 0.7s 0.2s ease both",
      letterSpacing: "-0.02em",
      color: "#F0EDE8",
      margin: "0 0 28px",
      overflow: "visible"
    }
  }, t.headline.map((line, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    ...(i === 1 ? { "aria-live": "polite", "aria-atomic": "true" } : {}),
      style: {
        display: "block",
        overflow: "visible",
        paddingTop: "0.02em",
        paddingBottom: "0.05em"
      }
  }, i === 1
    ? /*#__PURE__*/React.createElement(MBAnimatedWord, { words: t.rotatingWords, accent: accent, lang: lang })
    : i === 2
      ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("em", {
          style: { color: accent, fontStyle: "normal" }
        }, line))
      : line))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 400,
      fontSize: "clamp(15px, 1.6vw, 18px)",
      lineHeight: 1.55,
      color: "rgba(240,237,232,0.65)",
      margin: "0 0 30px",
      animation: "fadeSlideUp 0.7s 0.3s ease both",
      maxWidth: 640
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 14,
      marginBottom: 48,
      animation: "fadeSlideUp 0.7s 0.4s ease both"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    onClick: () => window.trackMBEvent && window.trackMBEvent("Hero CTA Click", {
      target: "contact",
      language: lang
    }),
    style: {
      padding: "14px 28px",
      background: accent,
      color: "#0B0C0E",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 700,
      fontSize: 14,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      display: "inline-block",
      transition: "opacity 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.opacity = "0.85",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, t.cta1), /*#__PURE__*/React.createElement("a", {
    href: "/daily-code-talk/",
    style: {
      padding: "14px 28px",
      background: "transparent",
      border: "1px solid rgba(240,237,232,0.2)",
      color: "#F0EDE8",
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontWeight: 500,
      fontSize: 14,
      textDecoration: "none",
      borderRadius: 3,
      letterSpacing: "0.02em",
      display: "inline-block",
      transition: "border-color 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = "rgba(240,237,232,0.5)",
    onMouseLeave: e => e.currentTarget.style.borderColor = "rgba(240,237,232,0.2)"
  }, t.cta2)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      animation: "fadeSlideUp 0.7s 0.5s ease both"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 1,
      background: `rgba(196,120,58,0.5)`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: "rgba(240,237,232,0.35)",
      letterSpacing: "0.06em",
      textTransform: "uppercase"
    }
  }, t.badge)),
  /*#__PURE__*/React.createElement(MBHeroStats, { stats: t.stats, accent: accent }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 36,
      left: "50%",
      transform: "translateX(-50%)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6,
      animation: "scrollBounce 2.2s ease-in-out infinite",
      opacity: 0.3,
      pointerEvents: "none",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 9,
      color: "#F0EDE8",
      letterSpacing: "0.15em",
      textTransform: "uppercase"
    }
  }, "scroll"), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "18",
    viewBox: "0 0 14 18",
    fill: "none"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "7",
    y1: "0",
    x2: "7",
    y2: "12",
    stroke: "#F0EDE8",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "2,8 7,14 12,8",
    stroke: "#F0EDE8",
    strokeWidth: "1",
    fill: "none"
  }))));
}

// ─── Differentiators ──────────────────────────────────────────────────────
function MBDifferentiators({
  lang,
  tweaks
}) {
  const t = MB_CONTENT[lang].diff;
  const accent = tweaks.accent;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "#0F1013",
      padding: "60px 40px",
      borderTop: "1px solid rgba(255,255,255,0.06)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 56,
      display: "flex",
      alignItems: "baseline",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      textTransform: "uppercase"
    }
  }, "/ Approach"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: "clamp(24px, 3vw, 36px)",
      color: "#F0EDE8",
      margin: 0
    }
  }, t.headline)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      gap: 2
    }
  }, t.items.map(item => /*#__PURE__*/React.createElement("div", {
    key: item.num,
    style: {
      padding: "40px 36px",
      background: "#131417",
      borderTop: `2px solid ${accent}`,
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 16,
      right: 20,
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 800,
      fontSize: 72,
      color: "rgba(255,255,255,0.03)",
      lineHeight: 1
    }
  }, item.num), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'IBM Plex Mono', monospace",
      fontSize: 11,
      color: accent,
      letterSpacing: "0.1em",
      marginBottom: 16
    }
  }, item.num), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Plus Jakarta Sans', sans-serif",
      fontWeight: 700,
      fontSize: 20,
      color: "#F0EDE8",
      margin: "0 0 14px",
      lineHeight: 1.2
    }
  }, item.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'IBM Plex Sans', sans-serif",
      fontSize: 14,
      lineHeight: 1.7,
      color: "rgba(240,237,232,0.55)",
      margin: 0
    }
  }, item.body))))));
}
// ─── Early Lead Capture Strip (Square 4 — 1PMP) ──────────────────────────────
// Compact newsletter strip placed immediately after MBDifferentiators.
// Captures email before the prospect scrolls into the services/nurture sections.
function MBEarlyCapture({ lang }) {
  const [email, setEmail] = React.useState("");
  const [joined, setJoined] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const ACCENT = "#C4783A";
  const copy = {
    en: {
      pre: "Get the free ",
      link: "Permit Readiness Sample",
      post: " + weekly Code Desk — one practical MEP code insight per week.",
      placeholder: "email@example.com",
      cta: "Subscribe →",
      success: "✓ You're on the Code Desk list. Check your inbox to confirm if requested.",
      privacy: "Free email list. Unsubscribe anytime. We do not sell subscriber data.",
      error: "Could not subscribe. Try again or use buttondown.com/masterbuild."
    },
    es: {
      pre: "Obtén la ",
      link: "Muestra de Lista de Permisos gratis",
      post: " + el Code Desk semanal — una idea práctica de código MEP por semana.",
      placeholder: "correo@ejemplo.com",
      cta: "Suscribirse →",
      success: "✓ Está en la lista Code Desk. Revise su correo para confirmar si se solicita.",
      privacy: "Lista gratuita. Puede cancelar cuando quiera. No vendemos datos de suscriptores.",
      error: "No se pudo suscribir. Intente de nuevo o use buttondown.com/masterbuild."
    }
  };
  const t = copy[lang] || copy.en;
  const handleSubmit = () => {
    if (!email.trim()) return;
    setLoading(true);
    setError("");
    const fd = new FormData();
    fd.append("email", email.trim());
    fd.append("tag", "homepage");
    fetch(window.MB_CATALOG.subscribe.endpoint, { method: "POST", body: fd })
      .then(response => {
        if (!response.ok) throw new Error("Subscription request failed");
        setJoined(true);
        if (window.trackMBEvent) window.trackMBEvent("Homepage Subscribe", { provider: "buttondown", source: "early-capture-strip", language: lang });
      })
      .catch(() => setError(t.error))
      .finally(() => setLoading(false));
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "rgba(196,120,58,0.07)",
      borderTop: "1px solid rgba(196,120,58,0.25)",
      borderBottom: "1px solid rgba(196,120,58,0.15)",
      padding: "18px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "0 auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24,
      flexWrap: "wrap"
    }
  }, joined ? /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: ACCENT, fontWeight: 600 }
  }, t.success) : /*#__PURE__*/React.createElement(React.Fragment, null,
    /*#__PURE__*/React.createElement("p", {
      style: { fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 14, color: "rgba(240,237,232,0.7)", margin: 0, lineHeight: 1.5 }
    }, t.pre,
      /*#__PURE__*/React.createElement("a", {
        href: "uploads/permit-readiness-sample-checklist.pdf", download: true,
        style: { color: ACCENT, textDecoration: "underline" }
      }, t.link),
      t.post
    ),
    /*#__PURE__*/React.createElement("div", {
      style: { display: "flex", gap: 8, flexShrink: 0, flexWrap: "wrap", maxWidth: 480 }
    },
      /*#__PURE__*/React.createElement("input", {
        type: "email", value: email, onChange: e => setEmail(e.target.value),
        onKeyDown: e => e.key === "Enter" && handleSubmit(),
        placeholder: t.placeholder,
        style: {
          padding: "9px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.15)",
          color: "#F0EDE8", fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, minWidth: 220
        }
      }),
      /*#__PURE__*/React.createElement("button", {
        onClick: handleSubmit, disabled: loading,
        style: {
          padding: "9px 18px", background: ACCENT, border: "none", color: "#0B0C0E",
          fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 13, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap"
        }
      }, loading ? (lang === "en" ? "Submitting…" : "Enviando…") : t.cta),
      /*#__PURE__*/React.createElement("span", {
        style: { flexBasis: "100%", fontFamily: "'IBM Plex Sans', sans-serif", fontSize: 10, color: error ? "#E5A5A5" : "rgba(240,237,232,0.38)", lineHeight: 1.4 }
      }, error || t.privacy)
    )
  )));
}

Object.assign(window, {
  MB_CONTENT,
  MBAnimatedWord,
  MBProofCard,
  MBHeroStats,
  MBNav,
  MBHero,
  MBDifferentiators,
  MBEarlyCapture
});
